#include "vars.h"
#pragma hdrstop


#define WORKBUFSIZE       0x8000

#define hdr_private 0x001
#define hdr_netmail 0x002
#define hdr_internet 0x004

void setGateway(hdrinfo *hdr)
{
//    hdr->t=
}

int getReceiver(hdrinfo *hdr)
{
    unsigned short i,i1;
    char s[81];
    userrec u;

    inputdat("Receiver",s,41,1);
    if(!(hdr->attr & hdr_private)) {
        if(!s[0])
            strcpy(hdr->who_to,"All");
        else
            strcpy(hdr->who_to,s);
    } else {
        if(!s[0])
            return 0;

        if((hdr->attr & hdr_netmail)) {
            strcpy(hdr->who_to,s);
            nl();
            inputdat("Destination Address",s,21,0);
            if(!s[0])
                return 0;
            parseadd(s,&hdr->t);
        } else {
            if(!(hdr->attr & hdr_internet))
                if(strchr(s,'@')) {
                    strcpy(hdr->who_to,s);
                    setGateway(hdr);
                    return 1;
                }
            if(strcmpi(s,"sysop")==0)
                strcpy(s,"1");
            i=atoi(s);
            if(!i)
                parse_email_info(s,&i);
            if(!i)
                return 0;
            read_user(i,&u);
            strcpy(hdr->who_to,pnam(&u));
        }
    }

    return 1;
}



int inputHeader(hdrinfo *hdr,int usehdr,int sb)
{
    addressrec add;
    originrec o;

    char s[81];

    if(!hdr->subject[0]&&!usehdr) {
        inputdat("Subject",s,60,1);

        if (!s[0])
            return 0;
        else
            strcpy(hdr->subject,s);
    }

    nl();
    if(usehdr) {
        strcpy(hdr->who_to,hdr->who_from);

        hdr->t=hdr->f;
        getorigin(sb,&o);
        hdr->f=o.add;
    } 
    else
        if(!getReceiver(hdr))
            return 0;

    return 1;
}
