#include <alloc.h>
#include <fcntl.h>
#include <io.h>
#include <string.h>

void DisplayQuote(char *quote,long l)
{
    int i,i1;
    char *p;
    char s[81];
    long cur=0;
    int numLines;

    numLines=0;

    i1=0;
    for(i=0;i<l;i++)
        if(quote[i]==13||quote[i]==10)
            i1++;
    printf("%d crs, len=%d\n",i1,l);
    getch();

    while(cur<l) {
        i1=0;
        while(quote[cur]!=10&&quote[cur]!=13&&cur<l) {
            s[i1++]=quote[cur++];
        }
        cur++;
        s[i1]=0;
        printf("%d: %s\n",numLines+1,s);
        numLines++;
    }
}


int getnextword(char *buf,long len, long *pos,char *s)
{
    long i,i1=0;
    int ret=0;

    i= *pos;

    while(i<len&&buf[i]!=32&&buf[i]!=13&&buf[i]!=10&&i1<81)
        s[i1++]=buf[i++];

    if(buf[i]==13||buf[i]==10)
        ret=1;

    *pos=i+1;
    s[i1]=0;

    return ret;
}

void addline(char *b, char *s, long *ll)
{
    strcpy(&(b[*ll]),s);
    *ll +=strlen(s);
    strcpy(&(b[*ll]),"\n");
    *ll += 1;
}

void quote(char *text,long len,char *who_from)
{
    char *outbuf;
    long cur=0,oln=0;
    char curword[81];
    char curline[81];
    char initials[21];
    int EOLFlag=0,thisEOL;
    int StartLine=1;
    int EndLine=0;
    int DontGet=0;

    outbuf=(char *)malloc(len);

//    strcpy(initials,ini(who_from));
    strcpy(initials,"FA> ");

    text[len]=0;
    while(cur<len) {
        if(!DontGet)
            thisEOL=getnextword(text,len,&cur,curword);
        if(thisEOL&&!EOLFlag)
                EOLFlag=1;
        else if(EOLFlag&&thisEOL) {
            EndLine=1;
            EOLFlag=0;
        }

        if(StartLine) {
            StartLine=0;
            strcpy(curline,initials);
        }
        if((strlen(curword)+strlen(curline))>72) {
            DontGet=1;
            EndLine=1;
        } else {
            DontGet=0;
            strcat(curline,curword);
            strcat(curline," ");
        }

        if(strlen(curline)>70)
            EndLine=1;

        if(EndLine) {
            addline(outbuf,curline,&oln);
            if(!EOLFlag)
                addline(outbuf,initials,&oln);
            StartLine=1;
            EOLFlag=0;
            EndLine=0;
        }
    }
    puts("Done quoting");

    DisplayQuote(outbuf,oln);
}



void main(void)
{
    int i,i1;
    char *text,ch;
    long l,len=0;

    i=open("test",O_RDWR|O_BINARY);
    l=filelength(i);
    text=(char *)malloc(l);
    for(i1=0;i1<l;i1++) {
        read(i,&ch,sizeof(ch));
        if(ch!='\r')
            text[len++]=ch;
    }
    close(i);
    write(1,text,len);
    getch();
    quote(text,len,"FA");
}
