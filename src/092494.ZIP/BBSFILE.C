#include "vars.h"
#pragma hdrstop

#include "link.h"
#include "stack.h"
#include "fileDir.h"

StackContainer dirStack;
PWDrec PWD;
char dirPath[81];

void destroyList(PWDrec *tmpPwd)
{
    while(numLinks(&tmpPwd->files))
        DeleteLink(&tmpPwd->files,0);
    while(numLinks(&tmpPwd->links))
        DeleteLink(&tmpPwd->links,0);
}

int comparefn(fileRec *a,fileRec *b)
{
    return(strcmp(a->fn,b->fn));
}

void getExtension(char *fn,char *ext)
{
    int i,i1;
    char *p;

    ext[0]=0;

    if(fn[0]=='.')
        return;

    p=strchr(fn,'.');
    if(p!=NULL)
        strcpy(ext,p+1);
    else
        ext[0]=0;

    p[0]=0;
}


void createPathName(void)
{
    int i;
    pathStack si;

    dirPath[0]=0;

    for(i=dirStack.list.num-1;i>0;--i) {
        getStackItem(&dirStack,&si,i);
        sprintf(&dirPath[strlen(dirPath)],"%s/",si.alias);
    }

    strcat(dirPath,PWD.alias);
}

void sendFile(char  *fn)
{
    char s[MAXPATH];
    pathStack si;

    sprintf(s,"%s\\%s",PWD.path,fn);
    unlisteddl(s);
}

void printInfo(fileRec *f, int *abort,int number)
{
    char s[161],ss[39],s1[10],s2[5],s3[5],s4[5],fn[MAXPATH];
    int i,i1,i2;
    double t;
    pathStack si;
    char fileName[14];

    sprintf(fn,"%s\\%s",PWD.path,f->fn);

    if(modem_speed)
        t=((double) (((f->size*1024)+127)/128)) * (1620.0)/((double) (modem_speed));

    if(f->attr & File_direc)
        strcpy(s1,"DIR");
    else
        sprintf(s1,"%4d",f->size);

    sprintf(s2,"%4d",f->points);
    sprintf(s3,"%3d",number);
    sprintf(ss,"%-39.39s",f->description);
    sprintf(s4,"%3d",f->numDls);

    sprintf(fileName,"%12s",f->fn);

    if(exist(fn))
        stuff_in1(s,filelistformat,fileName,ss,s1,s2,s3,"","",s4,ctim(t));
    else
        stuff_in1(s,filelistformat2,fileName,ss,s1,s2,s3,"","",s4,ctim(t));

    pl(s);

}


int pauseLine(int line,int *abort)
{
    int cont=0,i;
    char c;
    char s[40];

    if(line)
        pl(getfhead(1));

    do {
        outstr(get_string(39));
        strcpy(s,"I?VWMDSNBRZ\r");
        if(cs())
            strcat(s,"!@#$");
        c=onek(s);
        if(okansi()) outstr("[A[K");
        checkhangup();
        switch(c) {
        case '\r': 
            cont=1; 
            break;
        case '?': 
            printmenu(22); 
            if(cs()) printmenu(17); 
            break;
        }
    } 
    while(!cont&&!hangup);
    return 0;
}


void listDir(void)
{
    int i;
    fileRec f;
    linkRec l;
    int numListed=0;
    int abort=0;
    int listNum=0;
    PWDrec tmpPwd;

    setformat();

    for(i=0;i<numLinks(&PWD.links);i++) {
        GetLink(&PWD.links,i,&l);
        readDirHeader(l.linkData,&tmpPwd);
        npr("%d. %s - %s \r\n",listNum++,l.fn,tmpPwd.desc);
        if(numListed>20) {
            pauseLine(1,&abort);
            numListed=0;
        } 
        else
            numListed++;
    }

    for(i=0;i<numLinks(&PWD.files);i++) {
        GetLink(&PWD.files,i,&f);
        printInfo(&f,&abort,i);
        if(numListed>20) {
            pauseLine(1,&abort);
            numListed=0;
        } 
        else
            numListed++;
    }
    npr("%d files\r\n",numLinks(&PWD.files));
}


void Quicksort(int l,int r,List *list)
{
    register int i,j;
    fileRec a,a2,x;

    i=l; 
    j=r;
    GetLink(list,(l+r)/2,&x);
    do {
        GetLink(list,(i),&a);
        while (comparefn(&a,&x)<0) {
            GetLink(list,++i,&a);
        }
        GetLink(list,j,&a2);
        while (comparefn(&a2,&x)>0) {
            GetLink(list,--j,&a2);
        }
        if (i<=j) {
            if (i!=j) {
                PutLink(list,i,&a2);
                PutLink(list,j,&a);
            }
            i++;
            j--;
        }
    } 
    while (i<j);
    if (l<j)
        Quicksort(l,j,list);
    if (i<r)
        Quicksort(i,r,list);
}

void findDescription(char *fn,char *path,char *descript)
{
    FILE *f;
    char s[81];
    char *p;

    descript[0]=0;
    sprintf(s,"%s\\descript.ion",path);
    f=fopen(s,"rt");
    if(f==NULL)
        return;

    while(fgets(s,81,f)!=NULL) {
        if(stristr(s,fn)) {
            filter(s,'\n');
            p=strchr(s,32);
            strcpy(descript,p+1);
            fclose(f);
            return;
        }
    }

    fclose(f);
}

void registerDir(char *path)
{
    char s[MAXPATH];
    FILE *f;
    int i;
    fileRec inf;
    struct find_t t;
    PWDrec p;
    char *pp;
    PWDrec tmpPwd;
    char desc[81];
    char alias[81];

    if(so()) {
        inputdat("Name for new Directory",alias,14,1);
        inputdat("Description for new Directory",desc,50,1);
    } 
    else {
        strcpy(alias,"NewArea");
        strcpy(desc,"NewArea");
    }

    strcpy(tmpPwd.acs,"S30");
    sprintf(tmpPwd.alias,"%s",alias);
    sprintf(tmpPwd.desc,"%s",desc);


    sprintf(s,"%s\\dominion.dir",path);
    npr("Registering: %s\r\n",path);
    f=fopen(s,"wt");
    fprintf(f,"Dominion Directory\n");
    fprintf(f,"%s\n",tmpPwd.acs);
    fprintf(f,"%s\n",tmpPwd.alias);
    fprintf(f,"%s\n",tmpPwd.desc);

    sprintf(s,"%s\\*.*",path);

    i=_dos_findfirst(s,FA_ARCH|FA_HIDDEN|FA_SYSTEM|FA_RDONLY|FA_DIREC,&t);
    while(!i) {
        if(t.name[0]!='.') {
            if(t.attrib & FA_DIREC) {
                sprintf(s,"%s\\%s",path,t.name);
                fprintf(f,"Link %s %s\n",t.name,s);
            } 
            else {
                inf.attr=0;
                inf.size=(t.size+1023)/1024;
                inf.points=inf.size/10;
                inf.ulDate=time(NULL);
                strcpy(inf.fn,t.name);
                findDescription(inf.fn,path,inf.description);
                if(inf.description[0]==0)
                    strcpy(inf.description,"describe me!");
                fprintf(f,"%s %s\n",inf.fn,inf.description);
                fprintf(f,"   %ld $%d #%d @%d D%ld \n",inf.size,inf.points,inf.numDls,inf.owner,inf.ulDate);
            }
        }
        i=_dos_findnext(&t);
    }

    fclose(f);
}

void writeDirData(char *path,PWDrec *tmpPwd)
{
    char s[MAXPATH];
    FILE *f;
    int i;
    fileRec inf;
    linkRec l;

    sprintf(s,"%s\\dominion.dir",path);
    f=fopen(s,"wt");
    fprintf(f,"Dominion Directory\n");
    fprintf(f,"%s\n",tmpPwd->acs);
    fprintf(f,"%s\n",tmpPwd->alias);
    fprintf(f,"%s\n",tmpPwd->desc);

    for(i=0;i<numLinks(&tmpPwd->links);i++) {
        GetLink(&tmpPwd->links,i,&l);
        fprintf(f,"Link %s %s\n",l.fn,l.linkData);
    }
    for(i=0;i<numLinks(&tmpPwd->files);i++) {
        GetLink(&tmpPwd->files,i,&inf);
        fprintf(f,"%s %s\n",inf.fn,inf.description);
        fprintf(f,"   %ld $%d #%d @%d D%ld \n",inf.size,inf.points,inf.numDls,inf.owner,inf.ulDate);
    }

    fclose(f);
}

int readDirHeader(char *path,PWDrec *tmpPwd)
{
    FILE *f;
    char s[255];
    fileRec inf;
    linkRec l;
    char *p;
    pathStack si;

    sprintf(s,"%s\\dominion.dir",path);
    if(!exist(s)) {
        strcpy(tmpPwd->alias,"Newdir");
        strcpy(tmpPwd->desc,"Newdir");
        strcpy(tmpPwd->acs,"S255");
        strcpy(tmpPwd->path,path);
        return 1;
    }

    f=fopen(s,"rt");
    if(f==NULL) {
        npr("Bad path %s\r\n",path);
        return 1;
    }

    fgets(s,81,f);
    if(!strcmpi(s,"Dominion Directory\n")) {
        fgets(s,81,f); 
        filter(s,'\n');
        strcpy(tmpPwd->acs,s);
        fgets(s,81,f); 
        filter(s,'\n');
        strcpy(tmpPwd->alias,s);
        fgets(s,81,f); 
        filter(s,'\n');
        strcpy(tmpPwd->desc,s);
    }
    fclose(f);

    return 0;
}


int readDirData(char *path,PWDrec *tmpPwd)
{
    FILE *f;
    char s[255];
    fileRec inf;
    linkRec l;
    char *p;

    sprintf(s,"%s\\dominion.dir",path);
    if(!exist(s)) {
        npr("file %s not found, registering\r\n",s);
        registerDir(path);
    }

    f=fopen(s,"rt");
    if(f==NULL) {
        npr("Bad path %s\r\n",path);
        return 1;
    }

    fgets(s,81,f);
    if(!strcmpi(s,"Dominion Directory\n")) {

        destroyList(tmpPwd);

        fgets(s,81,f); 
        filter(s,'\n');
        strcpy(tmpPwd->acs,s);
        fgets(s,81,f); 
        filter(s,'\n');
        strcpy(tmpPwd->alias,s);
        fgets(s,81,f); 
        filter(s,'\n');
        strcpy(tmpPwd->desc,s);

        strcpy(tmpPwd->path,path);

        while(fgets(s,255,f)!=NULL) {
            filter(s,'\n');

            p=strtok(s," ,");
            if(!stricmp(p,"link")) {
                p=strtok(NULL," ,");
                strcpy(l.fn,p);
                p=strtok(NULL,";");
                strcpy(l.linkData,p);
                InsertLink(&tmpPwd->links,numLinks(&tmpPwd->links),&l);
            } 
            else {
                inf.size=0;
                inf.points=0;
                inf.numDls=0;
                inf.owner=0;
                inf.ulDate=0;

                strcpy(inf.fn,p);
                p=strtok(NULL,";");
                strcpy(inf.description,p);

                fgets(s,255,f);

                p=strtok(s," ,");
                inf.size=atol(p);
                p=strtok(NULL," ,");

                while(p) {
                    switch(p[0]) {
                    case '$':
                        inf.points=atoi(p+1);
                        break;

                    case '#':
                        inf.numDls=atoi(p+1);
                        break;

                    case '@':
                        inf.owner=atoi(p+1);
                        break;

                    case 'D':
                        inf.ulDate=atoi(p+1);
                        break;
                    }
                    p=strtok(NULL," ,");
                }

                InsertLink(&tmpPwd->files,numLinks(&tmpPwd->files),&inf);
            }
        }
    } 
    else {
        fclose(f);
        return(1);
    }


    numf=numLinks(&tmpPwd->files)+numLinks(&tmpPwd->links);


    fclose(f);
    return(0);
}

int isNumeric(char *s)
{
    int i;
    int len;

    len=strlen(s);

    if(len==0)
        return 0;

    for(i=0;i<len;i++) {
        switch(s[i]) {
        case '0':
        case '1':
        case '2':
        case '3':
        case '4':
        case '5':
        case '6':
        case '7':
        case '8':
        case '9':  
            break;
        default: 
            return 0;
        }
    }

    return 1;
}

void loadDir(char *path)
{
    pathStack si;
    linkRec l;
    fileRec inf;
    int i;

    if(!strcmp(path,"..")) {
        popStack(&dirStack);
        getStackTop(&dirStack,&si);
        readDirData(si.path,&PWD);
        createPathName();
        return;
    } 
    else
        if(!strcmp(path,"/")) {
        dirStack.list.num=0;
        readDirData(syscfg.dloadsdir,&PWD);
        strcpy(si.alias,PWD.alias);
        strcpy(si.path,syscfg.dloadsdir);
        pushStack(&dirStack,&si);
        createPathName();
        return;
    }

    for(i=0;i<numLinks(&PWD.links);i++) {
        GetLink(&PWD.links,i,&l);
        if(!stricmp(path,l.fn)) {
            readDirData(l.linkData,&PWD);
            strcpy(si.alias,PWD.alias);
            strcpy(si.path,l.linkData);
            pushStack(&dirStack,&si);
            createPathName();
            return;
        }
    }

    npr("Bad path: %s\r\n",path);
}

void executeNumberic(char *s)
{
    int i;
    fileRec inf;
    linkRec l;
    pathStack si;

    i=atoi(s);
    if(i<numLinks(&PWD.links)) {
        GetLink(&PWD.links,i,&l);
        readDirData(l.linkData,&PWD);
        strcpy(si.alias,PWD.alias);
        strcpy(si.path,l.linkData);
        pushStack(&dirStack,&si);
        createPathName();
    } 
    else if(i<=numLinks(&PWD.files)) {
        i-=numLinks(&PWD.links);
        GetLink(&PWD.files,i,&inf);
        npr("Executing %s\r\n",inf.fn);
    }
}

void initFileSystem(void)
{
    pathStack si;

    createList(&PWD.files,sizeof(fileRec));
    createList(&PWD.links,sizeof(linkRec));

    createStack(&dirStack,sizeof(pathStack));

    strcpy(si.alias,"Root");
    strcpy(si.path,syscfg.dloadsdir);
    pushStack(&dirStack,&si);
    readDirData(syscfg.dloadsdir,&PWD);
    createPathName();
}


void recurseDir(int actOnFiles,int actOnLinks,void (*func)(char *,fileRec *),char *parameter)
{
    int i;
    char s[81];
    fileRec inf;
    linkRec l;
    int abort=0;

    if(actOnFiles) {
        for(i=0;i<numLinks(&PWD.files)&&!hangup;i++) {
            GetLink(&PWD.files,i,&inf);
            func(parameter,&inf);
        }
    } else
        func(parameter,NULL);

    if(actOnLinks) {
        for(i=0;i<numLinks(&PWD.links)&&!hangup;i++) {
            GetLink(&PWD.links,i,&l);
            loadDir(l.fn);
            recurseDir(actOnFiles,actOnLinks,func,parameter);
            loadDir("..");
        }
    }
}



void searchDir(char *spec,fileRec *inf)
{
    int printData=0;
    char s[81];
    int abort=0;

    strcpy(s,inf->fn);
    strupr(s);
    if(strstr(s,spec))
        printData=1;
    else {
        strcpy(s,inf->description);
        strupr(s);
        if(strstr(s,spec))
            printData=1;
    }
    if(printData)
        printInfo(inf,&abort,0);
}



void syncDir(char *parameter,fileRec *inf)
{
    int i;
    linkRec l;
    PWDrec linkHeader;
    pathStack si;

    for(i=0;i<numLinks(&PWD.links)&&!hangup;i++) {
        GetLink(&PWD.links,i,&l);
        readDirHeader(l.linkData,&linkHeader);
        strcpy(l.fn,linkHeader.alias);
        PutLink(&PWD.links,i,&l);
    }

    writeDirData(PWD.path,&PWD);
}

void findPath(char *path)
{
    PWDrec tmpPwd;
    char *piece;
    pathStack si;
    char pathStr[81];
    int i;
    fileRec inf;
    linkRec link;

    createList(&tmpPwd.links,sizeof(fileRec));
    createList(&tmpPwd.files,sizeof(fileRec));

    pl("find start");
    switch(path[0]) {
        case '/':
            pl("find /");
            readDirData(syscfg.dloadsdir,&tmpPwd);
            strcpy(pathStr,&path[1]);
            break;
        case '.':
            pl("found ../");
            GetLink(&dirStack.list,1,&si);
            readDirData(si.path,&tmpPwd);
            strcpy(pathStr,&path[3]);
            break;
        default:
            pl("otherwise");
            strcpy(si.path,"");
            strcpy(pathStr,path);
    }
    pl(si.path);
    npr("pathStr is: %s\r\n",pathStr);
    piece=strtok(pathStr,"/");

    for(i=0;i<numLinks(&tmpPwd.files);i++) {
        GetLink(&tmpPwd.files,i,&inf);
        if(!stricmp(piece,inf.fn)) {
            destroyList(&tmpPwd);
            npr("the dominion.dir file is: %s\\dominion.dir",si.path);
            return;
        }
    }

    pl("file's not in this directory");
    for(i=0;i<numLinks(&tmpPwd.links);i++) {
        GetLink(&tmpPwd.links,i,&link);
        if(!stricmp(piece,link.fn)) {
            destroyList(&tmpPwd);
            npr("a link match is found in %s\\dominion.dir",si.path);
            return;
        }
    }

    destroyList(&tmpPwd);
}

void filearea(void)
{
    int done=0;
    char s[81],*p;
    char cmd[21],args[81];
    int i;
    pathStack si;

    initFileSystem();

    while(!done&&!hangup) {
        npr("%s>",dirPath);
        inputl(s,80);
        p=strchr(s,32);
        strcpy(args,p+1);
        p[0]=0;
        strcpy(cmd,s);
        if(!stricmp(cmd,"dir"))
            listDir();
        else if(!stricmp(cmd,"cd"))
            loadDir(args);
        else if(!stricmp(cmd,"send"))
            sendFile(args);
        else if(!stricmp(cmd,"sort")) {
            Quicksort(0,numLinks(&PWD.files),&PWD.files);
            Quicksort(0,numLinks(&PWD.links),&PWD.links);
            writeDirData(PWD.path,&PWD);
        }
        else if(!stricmp(cmd,"find")) {
            strupr(args);
            recurseDir(1,1,&searchDir,args);
        }
        else if(!stricmp(cmd,"sync"))
            recurseDir(0,1,&syncDir,NULL);
        else if(!stricmp(cmd,"exit"))
            done=1;
        else if(!stricmp(cmd,"path"))
            findPath(args);
        else if(isNumeric(cmd))
            executeNumberic(cmd);
    }
}
