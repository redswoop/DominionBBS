#include "vardec.h"
#include <dos.h>
#include <conio.h>
#include <stdio.h>

int rc;

configrec syscfg;
niftyrec nifty;



void movecsr(int x,int y)
{
    union REGS r;
    if (x<0)
        x=0;
    if (x>79)
        x=79;
    if (y<0)
        y=0;
    r.h.bh=0x00;
    r.h.dh=y;
    r.h.dl=x;
    r.h.ah=0x02;
    int86(0x10,&r,&r);

}


void makewindowt(int x, int y, int xlen, int ylen,char *msg)
{
    int i,xx,yy,old;
    unsigned char s[81];


    xx=wherex();
    yy=wherey();
    directvideo=1;
    textattr(31);
    for (i=1; i<xlen-1; i++)
      s[i]=196;
    s[0]='�';
    s[xlen-1]='�';
    s[xlen]=0;
    movecsr(x,y);
    cprintf(s);
    movecsr(x+1,y);
    cprintf("[ %s ]",msg);
    s[0]='�';
    s[xlen-1]='�';
    movecsr(x,y+ylen-1);
    cprintf(s);
    movecsr(x+1,y+1);
    for (i=0; i<xlen-2; i++)
        s[i]=32;
    s[xlen-2]=0;
    for (i=1; i<ylen-1; i++) {
        movecsr(x,i+y);
        textattr(31);
        cprintf("�");
        cprintf(s);
        cprintf("�");
    }
    movecsr(xx,yy);
}

int tempio;

int wherex()
{
    union REGS r;

    r.h.bh=0x00;
    r.h.ah=0x03;
    int86(0x10,&r,&r);
    tempio=r.h.dl;
    return(tempio);
}


int wherey()
{
    union REGS r;

    r.h.bh=0x00;
    r.h.ah=0x03;
    int86(0x10,&r,&r);
    tempio=r.h.dh;
    return(tempio);

}

void dispbit(char *msg,int on)
{
    textattr(31);
    cprintf("%-23s",msg);
    textcolor(10);
    cprintf("(%c)",on?254:32);
    textcolor(15);
}


void editline(char *s, int len, int status, int *returncode, char *ss)
{
    int i,j,k,oldatr,cx,cy,pos,ch,done,insert,i1;

    cx=wherex();
    cy=wherey();
    for (i=strlen(s); i<len; i++)
        s[i]=32;
    s[len]=0;
    cprintf(s);
    textattr(112);
    movecsr(cx,cy);
    done=0;
    pos=0;
    insert=0;
    do {
        ch=getch();
        if (ch==0) {
            ch=getch();
            switch (ch) {
            case 59:
                done=1;
                *returncode=DONE;
                break;
            case 71: 
                pos=0; 
                movecsr(cx,cy); 
                break;
            case 79: 
                pos=len; 
                movecsr(cx+pos,cy); 
                break;
            case 77: 
                if (pos<len) {
                    pos++;
                    movecsr(cx+pos,cy);
                }
                break;
            case 75: 
                if (pos>0) {
                    pos--;
                    movecsr(cx+pos,cy);
                }
                break;
            case 72:
            case 15:
                done=1;
                *returncode=PREV;
                break;
            case 80:
                done=1;
                *returncode=NEXT;
                break;
            case 82:
                if (status!=SET) {
                    if (insert)
                        insert=0;
                    else
                        insert=1;
                }
                break;
            case 83:
                if (status!=SET) {
                    for (i=pos; i<len; i++)
                        s[i]=s[i+1];
                    s[len-1]=32;
                    movecsr(cx,cy);
                    cprintf(s);
                    movecsr(cx+pos,cy);
                }
                break;
            }
        } 
        else {
            if (ch>31) {
                if (status==UPPER_ONLY)
                    ch=toupper(ch);
                if (status==SET) {
                    ch=toupper(ch);
                    if (ch!=' ') {
                        i1=1;
                        for (i=0; i<len; i++)
                            if ((ch==ss[i]) && (i1)) {
                                i1=0;
                                pos=i;
                                movecsr(cx+pos,cy);
                                if (s[pos]==' ')
                                    ch=ss[pos];
                                else
                                    ch=' ';
                            }
                        if (i1)
                            ch=ss[pos];
                    }
                }
                if ((pos<len)&&((status==ALL) || (status==UPPER_ONLY) || (status==SET) ||
                    ((status==NUM_ONLY) && (((ch>='0') && (ch<='9')) || (ch==' '))))) {
                    if (insert) {
                        for (i=len-1; i>pos; i--)
                            s[i]=s[i-1];
                        s[pos++]=ch;
                        movecsr(cx,cy);
                        cprintf(s);
                        movecsr(cx+pos,cy);
                    } 
                    else {
                        s[pos++]=ch;
                        putch(ch);
                    }
                }
            } 
            else {
                ch=ch;
                switch(ch) {
                case 13:
                case 9:
                    done=1;
                    *returncode=NEXT;
                    break;
                case 27:
                    done=1;
                    *returncode=DONE;
                    break;
                case 8:
                    if (pos>0) {
                        if (insert) {
                            for (i=pos-1; i<len; i++)
                                s[i]=s[i+1];
                            s[len-1]=32;
                            pos--;
                            movecsr(cx,cy);
                            cprintf(s);
                            movecsr(cx+pos,cy);
                        } 
                        else {
                            pos--;
                            movecsr(cx+pos,cy);
                        }
                    }
                    break;
                }
            }
        }
    } 
    while (done==0);
    movecsr(cx,cy);
    cprintf(s);
    movecsr(cx,cy);
}


void editdata(char *str,int len,int xcoord,int ycoord, int away)
{
    int i;

    textcolor(0);
    textbackground(7);
    movecsr(xcoord+away,ycoord);
    editline(str,len,ALL,&rc,"");
    for(i=strlen(str)-1;i>=0 && str[i]==32;i--);
    str[i+1]=0;
    textattr(31);
}


void editdig(int *i,int len,int xcoord,int ycoord,int away)
{
    int real;
    char s[81];

    textcolor(0);
    textbackground(7);
 
    itoa(*i,s,10);
    movecsr(xcoord+away,ycoord);
    editline(s,len,NUM_ONLY,&rc,"");
    *i=atoi(s);

    textattr(31);
}

int highlight(char *msg, int x, int y,int code)
{
    int i,done=0,ret=0;
    char ch;

    do {
        movecsr(x,y);
        textcolor(0);
        textbackground(7);
        cprintf("%-20.20s",msg);
        ch=getch();
        if(ch==0) {
            ch=getch();
            movecsr(x,y);
            textattr(31);
            cprintf("%-20.20s",msg);
            switch(ch) {
                case 72:
                    done=1;
                    return PREV;
                case 80:
                    done=1;
                    return NEXT;
             }
        } else if(ch==27) {
            return DONE;
        } else if(ch==13) {
            return code;
        }
    } while(!done);

    movecsr(x,y);
    textattr(31);
    cprintf("%-20.20s",msg);
    return ret;
}





void prdata(char *str,char *what,int xcoord, int ycoord)
{
    char s[81],i;

    movecsr(xcoord,ycoord);
    textattr(31);
    cprintf("[%-15s] ",str);
    textattr(112);
    cprintf("%-40s",what);
}


int togglebit(int *byte,int bit,int x, int y)
{
    int i,done=0;
    char ch;


    do {
        textattr(31);
        textcolor(10);
        movecsr(x,y);
        if(*byte & bit)
            cprintf("(�)\b\b");
        else
            cprintf("( )\b\b");
        textattr(31);
        ch=getch();
        if(ch==0) {
            ch=getch();
            switch(ch) {
                case 72:
                    done=1;
                    return PREV;
                case 80:
                    done=1;
                    return NEXT;
            }
        } else if(ch==32) {
            if(*byte & bit) *byte ^=bit;
            else *byte |=bit;
        } else if(ch==27) {
            return DONE;
        } else if(ch==13) {
            return NEXT;
        }
    } while(!done);
    return NEXT;
}

void configmain(void)
{
    int cp=1,i,done=0,i1;
    char s1[71],s[81];


    makewindowt(0,0,65,8,"System Paths");

    prdata("Data Dir",syscfg.datadir,3,1);
    prdata("Afiles Dir",syscfg.gfilesdir,3,2);
    prdata("Menu Dir",syscfg.menudir,3,3);
    prdata("Temp Dir",syscfg.tempdir,3,4);
    prdata("Batch Dir",syscfg.batchdir,3,5);
    prdata("Msgs Dir",syscfg.msgsdir,3,6);


    do {
        switch(cp) {
        case 1: 
            editdata(syscfg.datadir,40,3,1,18);
            break;
        case 2: 
            editdata(syscfg.gfilesdir,40,3,2,18);
            break;
        case 3: 
            editdata(syscfg.menudir,40,3,3,18);
            break;
        case 4: 
            editdata(syscfg.tempdir,40,3,4,18);
            break;
        case 5: 
            editdata(syscfg.batchdir,40,3,5,18);
            break;
        case 6: 
            editdata(syscfg.msgsdir,39,3,6,18);
            break;
        }
        switch(rc) {
        case DONE: 
            done=1; 
            break;
        case NEXT: 
            if (cp<6) cp++;
            else cp=1; 
            break;
        case PREV: 
            if (cp>1) cp--; 
            else cp=6;
            break;

        }
    } 
    while(!done);
}

void confignames(void)
{
    int cp=1,i,done=0,i1;
    char s1[71],s[81];


    makewindowt(0,0,65,10,"System Info");

    prdata("System Name",syscfg.systemname,3,2);
    prdata("Phone Number",syscfg.systemphone,3,3);
    prdata("SysOp Name",syscfg.sysopname,3,4);
    ltoa(nifty.lockoutrate,s,10);
    prdata("Min. Baud Rate",s,3,6);
    itoa(syscfg.maxusers,s,10);
    prdata("Maximum Users",s,3,7);
    itoa(nifty.systemtype,s,10);
    prdata("Max. Log Days",s,3,8);

    do {
        switch(cp) {
        case 1:
            editdata(syscfg.systemname,40,3,2,18);
            break;
        case 2:
            editdata(syscfg.systemphone,12,3,3,18);
            break;
        case 3:
            editdata(syscfg.sysopname,31,3,4,18);
            break;
        case 4:
            ltoa(nifty.lockoutrate,s,10);
            editdata(s,5,3,6,18);
            nifty.lockoutrate=atol(s);
            break;
        case 5:
            editdig(&syscfg.maxusers,4,3,7,18);
            break;
        case 6:
            i1=nifty.systemtype;
            editdig(&i1,4,3,8,18);
            nifty.systemtype=i1;
            break;
        }
        switch(rc) {
        case DONE: 
            done=1; 
            break;
        case NEXT: 
            if (cp<6) cp++;
            else cp=1; 
            break;
        case PREV: 
            if (cp>1) cp--; 
            else cp=6;
            break;

        }
    } 
    while(!done);
}



void configpass(void)
{
    int cp=1,i,done=0,i1;
    char s1[71],s[81];


    makewindowt(0,4,62,8,"Passwords");

    prdata("System Password",syscfg.systempw,2,6);
    prdata("NUP",syscfg.newuserpw,2,7);
    prdata("Matrix Password",nifty.matrix,2,8);
    prdata("Lockout Password",nifty.lockoutpw,2,9);


    do {
        switch(cp) {
        case 1:
            editdata(syscfg.systempw,20,2,6,18);
            break;
        case 2:
            editdata(syscfg.newuserpw,20,2,7,18);
            break;
        case 3:
            editdata(nifty.matrix,30,2,8,18);
            break;
        case 4:
            editdata(nifty.lockoutpw,30,2,9,18);
            break;
        }
        switch(rc) {
        case DONE: 
            done=1; 
            break;
        case NEXT: 
            if (cp<4) cp++;
            else cp=1; 
            break;
        case PREV: 
            if (cp>1) cp--; 
            else cp=4;
            break;
        }
    } 
    while(!done);
}

void configfile(void)
{
    int cp=1,i,done=0,i1;
    char s1[71],s[81];


    makewindowt(23,2,52-20,16,"File Area Data");

    textattr(31);
    movecsr(27,4); dispbit("All Uploads to SysOp",syscfg.sysconfig & sysconfig_all_sysop);
    movecsr(27,5); dispbit("Kilo Byte Ratio",nifty.nifstatus & nif_ratio);
    movecsr(27,6); dispbit("File Point System",nifty.nifstatus & nif_fpts);
    movecsr(27,7); dispbit("Post Call Ratio",nifty.nifstatus & nif_pcr);
    movecsr(27,8); dispbit("Auto Upload Credit",nifty.nifstatus & nif_autocredit);

    movecsr(27,10); cprintf("New Uploads Dir   %d",syscfg.newuploads);
    movecsr(27,11); cprintf("File K Ratio      %5.3f",syscfg.req_ratio);
    movecsr(27,12); cprintf("Post Call Ratio   %5.3f",syscfg.post_call_ratio);
    movecsr(27,13); cprintf("File Point Factor %d",nifty.fptsratio);

    do {
        switch(cp) {
        case 1: rc=togglebit(&syscfg.sysconfig,sysconfig_all_sysop,50,4); break;
        case 2: rc=togglebit(&nifty.nifstatus,nif_ratio,50,5); break;
        case 3: rc=togglebit(&nifty.nifstatus,nif_fpts,50,6); break;
        case 4: rc=togglebit(&nifty.nifstatus,nif_pcr,50,7); break;
        case 5: rc=togglebit(&nifty.nifstatus,nif_autocredit,50,8); break;
        case 6: editdig(&syscfg.newuploads,4,27,10,18); break;
        case 7: sprintf(s,"%5.3f",syscfg.req_ratio);
                editdata(s,5,27,11,18);
                sscanf(s,"%f",&syscfg.req_ratio);
                break;
        case 8: sprintf(s,"%5.3f",syscfg.post_call_ratio);
                editdata(s,5,27,12,18);
                sscanf(s,"%f",&syscfg.post_call_ratio);
                break;
        case 9: editdig(&nifty.fptsratio,4,27,13,18); break;
        }
        switch(rc) {
        case DONE: 
            done=1; 
            break;
        case NEXT: 
            if (cp<9) cp++;
            else cp=1; 
            break;
        case PREV: 
            if (cp>1) cp--; 
            else cp=9;
            break;

        }
    } 
    while(!done);
}

void configlogon(void)
{
    int cp=1,i,done=0,i1;
    char s1[71],s[81];


    makewindowt(23,2,52,16,"Logon Setup");

    textattr(31);
    movecsr(27,4); dispbit("Real Names Only",syscfg.sysconfig & sysconfig_no_alias);
    movecsr(27,5); dispbit("Ask Phone Number",syscfg.sysconfig & sysconfig_free_phone);
    movecsr(27,6); dispbit("",nifty.nifconfig & nif_);


    do {
        switch(cp) {
        case 1: rc=togglebit(&syscfg.sysconfig,sysconfig_all_sysop,50,4); break;
        case 2: rc=togglebit(&nifty.nifstatus,nif_ratio,50,5); break;
        case 3: rc=togglebit(&nifty.nifstatus,nif_fpts,50,6); break;
        case 4: rc=togglebit(&nifty.nifstatus,nif_pcr,50,7); break;
        case 5: rc=togglebit(&nifty.nifstatus,nif_autocredit,50,8); break;
        case 6: editdig(&syscfg.newuploads,4,27,10,18); break;
        case 7: sprintf(s,"%5.3f",syscfg.req_ratio);
                editdata(s,5,27,11,18);
                sscanf(s,"%f",&syscfg.req_ratio);
                break;
        case 8: sprintf(s,"%5.3f",syscfg.post_call_ratio);
                editdata(s,5,27,12,18);
                sscanf(s,"%f",&syscfg.post_call_ratio);
                break;
        case 9: editdig(&nifty.fptsratio,4,27,13,18); break;
        }
        switch(rc) {
        case DONE: 
            done=1; 
            break;
        case NEXT: 
            if (cp<9) cp++;
            else cp=1; 
            break;
        case PREV: 
            if (cp>1) cp--; 
            else cp=9;
            break;

        }
    } 
    while(!done);
}


void selectconfig(void)
{
    int cp=1,i,done=0,i1;
    char s1[71],s[81];


top:
    makewindowt(23,2,52-24,12,"Dominion Configuration");

    textattr(31);
    movecsr(27,4); cprintf("Paths");
    movecsr(27,5); cprintf("File Area Data");
    movecsr(27,6); cprintf("Passwords");
    movecsr(27,7); cprintf("System Info");
    movecsr(27,8); cprintf("Logon Setup");

    do {
        switch(cp) {
            case 1: rc=highlight("Paths",27,4,100); break;
            case 2: rc=highlight("File Area Data",27,5,101); break;
            case 3: rc=highlight("Passwords",27,6,102); break;
            case 4: rc=highlight("System Info",27,7,103); break;
            case 5: rc=highlight("Logon Setup",27,8,104); break;
        }
        if(rc>99) {
          if(rc==100) configmain();
          if(rc==101) configfile();
          if(rc==102) configpass();
          if(rc==103) confignames();
          if(rc==104) configlogon();
          goto top;
        } else
        switch(rc) {
        case DONE: 
            done=1;
            return;
        case NEXT: 
            if (cp<4) cp++;
            else cp=1; 
            break;
        case PREV: 
            if (cp>1) cp--; 
            else cp=4;
            break;
        }
    } 
    while(!done);
}



void main(void)
{
    int i,i1;
    char s[81];
    FILE *f;

    f=fopen("config.dat","rb");
    fread(&syscfg,sizeof(syscfg),1,f);
    fread(&nifty,sizeof(niftyrec),1,f);
    fclose(f);


    selectconfig();

    f=fopen("config.dat","wb");
    fwrite(&syscfg,sizeof(syscfg),1,f);
    fwrite(&nifty,sizeof(niftyrec),1,f);
    fclose(f);
    movecsr(0,20);
}
