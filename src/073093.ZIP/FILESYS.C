#include "vars.h"
#pragma hdrstop

#include <time.h>
#include <dir.h>

#define SETREC(i)  lseek(dlf,((long) (i))*((long)sizeof(uploadsrec)),SEEK_SET);

void quicksort(int l,int r,int type)
{
    register int i,j;
    uploadsrec a,a2,x;

    i=l; 
    j=r;
    SETREC(((l+r)/2));
    read(dlf, (void *)&x,sizeof(uploadsrec));
    do {
        SETREC(i);
        read(dlf, (void *)&a,sizeof(uploadsrec));
        while (comparedl(&a,&x,type)<0) {
            SETREC(++i);
            read(dlf, (void *)&a,sizeof(uploadsrec));
        }
        SETREC(j);
        read(dlf, (void *)&a2,sizeof(uploadsrec));
        while (comparedl(&a2,&x,type)>0) {
            SETREC(--j);
            read(dlf, (void *)&a2,sizeof(uploadsrec));
        }
        if (i<=j) {
            if (i!=j) {
                SETREC(i);
                write(dlf,(void *)&a2,sizeof(uploadsrec));
                SETREC(j);
                write(dlf,(void *)&a,sizeof(uploadsrec));
            }
            i++;
            j--;
        }
    } 
    while (i<j);
    if (l<j)
        quicksort(l,j,type);
    if (i<r)
        quicksort(i,r,type);
}


void sortdir(int dn, int type)
{
    dliscan1(dn);
    if (numf>1)
        quicksort(1,numf,type);
    closedl();
}


void sort_all(char ms[81])
{
    int type,i,all,abort=0,next;

    if(!ms[0]) {
        nl();
        npr("5Sort all dirs? ");
        all=yn(); nl();
        npr("5Sort by date? ");
        if(yn()) type=2; else type=0;
    } else {
        if(ms[0]=='G') all=1; else all=0;
        if(ms[1]=='D') type=2; else type=0;
    }

    if(!all)
        sortdir(udir[curdir].subnum,type);
    else
    for (i=0; (i<64) && (udir[i].subnum!=-1) && (!abort); i++) {
        nl();
        dliscan1(i);
        if(!ms[0]) {
            npr("5Sorting 0%-40s 3(3%d Files3)",directories[udir[i].subnum].name,numf);
            checka(&abort,&next,0);
        }
        sortdir(i,type);
    }
}


void valfiles()
{
    char s[81],s1[81],s2[81],*ss,s3[81],ch;
    int i,cp,done,valall=0;
    uploadsrec u;
    userrec uu;

    strcpy(s,"*.*");
    align(s);
    dliscan();
    done=0;
    strcpy(s3,s);
    i=recno(s);
    while (i>0&&!done) {
        cp=i;
        SETREC(i);
        read(dlf,(void *)&u,sizeof(uploadsrec));
        if(!u.ats[0]) {
            nl();
            nl();
            if(valall) {
                u.ats[0]=1;
                SETREC(i);
                write(dlf,(void *)&u,sizeof(uploadsrec));
                sprintf(s2,"%s was Validated on %s",u.filename,date());
                ssm(u.ownerusr,0,s2);
                read_user(u.ownerusr,&uu);
                u.points=((u.numbytes+1023)/10240);
                uu.fpts+=u.points;
                write_user(u.ownerusr,&uu);
                close_user();
                logtypes(3,"Validated file 4%s0 to 4%d0 points",u.filename,u.points);
            } 
            else {
                printfileinfo(&u,udir[curdir].subnum);
                outstr("7Validate 0(2Y/N/P/Q/All0)7? ");
                ch=onek("YNQPA\r");
                switch(ch) {
                case 'P':
                case 'Y':
                case 'A':
                case '\r': 
                    u.ats[0]=1;
                    if(ch=='A') valall=1;
                    if(ch=='P') {
                        nl();
                        outstr("Enter Points: ");
                        input(s2,5);
                        if(s2[0]) u.points=atoi(s2);
                        else u.points=((u.numbytes+1023)/10240);
                    } 
                    else
                        u.points=((u.numbytes+1023)/10240);
                    SETREC(i);
                    write(dlf,(void *)&u,sizeof(uploadsrec));
                    sprintf(s2,"%s was Validated on %s",u.filename,date());
                    ssm(u.ownerusr,0,s2);
                    read_user(u.ownerusr,&uu);
                    uu.fpts+=u.points;
                    write_user(u.ownerusr,&uu);
                    close_user();
                    logtypes(3,"Validated file 4%s0 to 4%d0 points",u.filename,u.points);
                    break;
                case 'N': 
                    break;
                case 'Q': 
                    done=1; 
                    break;
                }
            }
        }
        i=nrecno(s3,cp);
    }
    closedl();
}


int upload_file(char *fn, int dn)
{
    directoryrec d;
    uploadsrec u,u1;
    int i,i1,i2,ok=1,f;
    char s[81],s1[81],ff[81],*ss;
    long l,len;
    double ti;

    d=directories[dn];
    strcpy(s,fn);
    align(s);
    strcpy(u.filename,s);
    u.ownerusr=usernum;
    u.ownersys=0;
    u.numdloads=0;
    u.filetype=0;
    u.mask=0;
    u.points=0;
    u.ats[0]=1;
    strcpy(ff,d.dpath);
    strcat(ff,s);
    f=open(ff,O_RDONLY | O_BINARY);
    l=filelength(f);
    u.numbytes=l;
    close(f);
    strcpy(u.upby,nam(&thisuser,usernum));
    strcpy(u.date,date());
    if (d.mask & mask_PD)
        d.mask=mask_PD;
    npr("0%s5:3 %4ldk 5:2 ",u.filename,(u.numbytes+1023)/1024);
    mpl(39);
    inputl(u.description,39);
    if (u.description[0]=='.')
        switch(toupper(u.description[1])) {
        case 'N': 
            return -1;
        case 'S': 
            ok=0; 
            break;
        case 'D': 
            ok=0; 
            unlink(ff); 
            break;
        case 'Q': 
            return -2;
        }
    if(u.description[0]=='/') {
        modify_extended_description(&ss);
        add_extended_description(u.filename,ss);
        farfree(ss);
        u.mask |= mask_extended;
        strcpy(s1,u.description+1);
        strcpy(u.description,s1);
    }
    if (u.description[0]==0)
        strcpy(u.description,"No Description Given at Upload");
    if(ok) {
        thisuser.fpts+=(u.numbytes+1023)/10240;
        ++thisuser.uploaded;
        if (strstr(u.filename,".GIF"))
            addgif(ff,u.description);
        comment_arc(stripfn(u.filename),d.dpath,d.upath);
        strcpy(ff,d.dpath);
        strcat(ff,stripfn(u.filename));
        adddiz(ff,&u);
        u.points=((l+1023)/10240);
        thisuser.uk += ((l+1023)/1024);
        time(&l);
        u.daten=l;
        for (i=numf; i>=1; i--) {
            SETREC(i);
            read(dlf,(void *)&u1,sizeof(uploadsrec));
            SETREC(i+1);
            write(dlf,(void *)&u1,sizeof(uploadsrec));
        }
        SETREC(1);
        write(dlf,(void *)&u,sizeof(uploadsrec));
        ++numf;
        u1.numbytes=numf;
        SETREC(0);
        write(dlf,(void *)&u1,sizeof(uploadsrec));
        ++status.uptoday;
        save_status();
        logpr("3+ 2Locally uploaded %s on %s",u.filename,d.name);
    }
    return(1);
}


int uploadall(int dn, char s[20])
{
    int i,i1,f1,maxf,ok,ocd,title=0;
    char s1[81];
    struct ffblk ff;
    uploadsrec u;

    dliscan1(dn);
    ocd=curdir;
    curdir=dn;
    nl();
    strcpy(s1,(directories[dn].dpath));
    maxf=directories[dn].maxfiles;
    strcat(s1,s);
    f1=findfirst(s1,&ff,0);
    ok=1;
    i1=0;
    while ((f1==0) && (!hangup) && (numf<maxf) && (ok)) {
        strcpy(s,(ff.ff_name));
        align(s);
        i=recno(s);
        if (i==-1) {
            if(!title) {
                pl("5Enter File Descriptions. A / As the first letter gets Extened Description.");
                pl("2.S to Skip File, .N to Skip Directory, .Q to Quit, .D to Delete");
                pl("Blank Lines will be 'No Description Given at Upload'");
                title=1;
            }

            i1=upload_file(s,dn);
            if(i1==-1)
                ok=0;
            if(i1==-2) return(i1);
        } 
        else {
            SETREC(i);
            read(dlf,(void *)&u, sizeof(uploadsrec));
        }
        f1=findnext(&ff);
    }
    curdir=ocd;
    closedl();
    if (!ok)
        pl("Aborted.");
    if (numf>=maxf)
        pl("directory full.");
    return(i1);
}

void removefile(int offline)
{
    int i,i1,ok,rm,abort,rdlp,num;
    char ch,s[81],s1[81];
    uploadsrec u;
    userrec uu;

    dliscan();
    nl();
    if(!offline) {
        file_mask(s);
    } 
    else strcpy(s,"*.*");
    if (s[0]==0) {
        closedl();
        return;
    }
    if (strchr(s,'.')==NULL)
        strcat(s,".*");
    align(s);

    i=recno(s);
    abort=0;
    while ((!hangup) && (i>0) && (!abort)) {
        SETREC(i);
        read(dlf,(void *)&u,sizeof(uploadsrec));
        strcpy(s1,(directories[udir[curdir].subnum].dpath));
        strcat(s1,u.filename);
        if ((offline && !exist(s1)) || (!offline && ((dcs()) || (u.ownerusr==usernum))) ) {
            nl();
            printfileinfo(&u,udir[curdir].subnum);
            prt(5,"Remove? (Y/N/Q) ");
            ch=onek("QNY");
            if (ch=='Q')
                abort=1;
            if (ch=='Y') {
                rdlp=1;
                if (dcs()&&!offline) {
                    prt(5,"Delete file too? ");
                    rm=yn();
                    if (rm) {
                        prt(5,"Remove DL fpts? ");
                        rdlp=yn();
                    }
                } 
                else
                    rm=1;
                if (rm) {
                    strcpy(s1,(directories[udir[curdir].subnum].dpath));
                    strcat(s1,u.filename);
                    unlink(s1);
                    if ((rdlp) && (u.ownersys==0)) {
                        read_user(u.ownerusr,&uu);
                        if ((uu.inact & inact_deleted)==0) {
                            --uu.uploaded;
                            uu.uk -= ((u.numbytes+1023)/1024);
                            uu.fpts-=u.points;
                            write_user(u.ownerusr,&uu);
                        }
                        close_user();
                    }
                }
                if (u.mask & mask_extended)
                    delete_extended_description(u.filename);
                logtypes(3,"4%s 0Removed off of 4%s",u.filename,
                directories[udir[curdir].subnum].name);
                for (i1=i; i1<numf; i1++) {
                    SETREC(i1+1);
                    read(dlf,(void *)&u,sizeof(uploadsrec));
                    SETREC(i1);
                    write(dlf,(void *)&u,sizeof(uploadsrec));
                }
                --i;
                --numf;
                u.numbytes=numf;
                SETREC(0);
                write(dlf,(void *)&u,sizeof(uploadsrec));
            }
        }
        i=nrecno(s,i);
    }
    closedl();
}


void editfile()
{
    char s[81],s1[81],s2[81],*ss,s3[81],ch,changed;
    int i,cp,done,num=0,l=0,m,dd,y,i1;
    uploadsrec u;
    userrec ur;
    struct date d;
    struct time t;

    nl();
    nl();
    num=file_mask(s);
    dliscan();
    nl();
    strcpy(s3,s);

    if(!num)
        i1=recno(s);
    else {
        i1=num;
        l=1;
    }

    done=0;
    while (done!=2) {
        cp=i1;
        SETREC(i1);
        read(dlf,(void *)&u,sizeof(uploadsrec));
        nl();
        changed=0;
        do {
            printfileinfo(&u,udir[curdir].subnum);
            nl();
            npr("5File Information Editor (?=Help) ");
            ch=onek("DQNGFVEUPS!?B\r");
            switch(ch) {
            case 'B':
                inputdat("Private User Name/Number",s,31,0);
                i=finduser1(s);
                if(i)
                    u.ownersys=i;
                if(u.ownersys) {
                    nl();
                    read_user(u.ownersys,&ur);
                    npr("3File now private for 0%s\r\n",nam(&ur,u.ownersys));
                    changed=1;
                }
                break;
            case '?': 
                printmenu(23); 
                break;
            case '!': 
                if(u.ats[1]!=100)
                    u.ats[1]=100;
                else
                    u.ats[1]=0;
                break;
            case '\r': 
                done=1; 
                break;
            case 'Q': 
                done=2; 
                break;
            case 'S':
                nl();
                npr("3Upload Date\r\n5: 0");
                inputdate(s,0);
                m=atoi(s);
                dd=atoi(&(s[3]));
                y=atoi(&(s[6]))+1900;
                if ((strlen(s)==8) && (m>0) && (m<=12) && (dd>0) && (dd<32) && (y>=1980)) {
                    t.ti_min=0;
                    t.ti_hour=0;
                    t.ti_hund=0;
                    t.ti_sec=0;
                    d.da_year=y;
                    d.da_day=dd;
                    d.da_mon=m;
                    u.daten=dostounix(&d,&t);
                    strcpy(u.date,s);
                }
                break;
            case 'U': 
                changed=1; 
                nl();
                inputdat("New Uploader",s,45,1);
                if(s[0])
                    strcpy(u.upby,s);
                break;
            case 'F': 
                changed=1; 
                nl();
                inputdat("New Filename",s,12,0);
                if (!okfn(s))
                    s[0]=0;
                if (s[0]) {
                    align(s);
                    if (strcmp(s,"        .   ")) {
                        strcpy(s1,directories[udir[curdir].subnum].dpath);
                        strcpy(s2,s1);
                        strcat(s1,s);
                        if (exist(s1))
                            pl("Filename already in use; not changed.");
                        else {
                            strcat(s2,u.filename);
                            rename(s2,s1);
                            if (exist(s1)) {
                                ss=read_extended_description(u.filename);
                                if (ss) {
                                    delete_extended_description(u.filename);
                                    add_extended_description(s,ss);
                                    farfree(ss);
                                }
                                strcpy(u.filename,s);
                            } 
                            else
                                pl("Bad filename.");
                        }
                    }
                }
                break;
            case 'D': 
                changed=1;
                nl();
                inputdat("Description",s,39,1);
                if (s[0])
                    strcpy(u.description,s);
                break;
            case 'V': 
                changed=1;
                if(u.ats[0]) u.ats[0]=0; 
                else u.ats[0]=1; 
                break;
            case 'P': 
                changed=1;
                nl();
                inputdat("File Points",s,3,0);
                if(s[0]) u.points=atoi(s);
                break;
            case 'E': 
                changed=1;
                ss=read_extended_description(u.filename);
                nl();
                nl();
                prt(5,"Modify extended description? ");
                if (yn()) {
                    nl();
                    if (ss) {
                        prt(5,"Delete it? ");
                        if (yn()) {
                            farfree(ss);
                            delete_extended_description(u.filename);
                            u.mask &= ~mask_extended;
                        } 
                        else {
                            u.mask |= mask_extended;
                            modify_extended_description(&ss);
                            if (ss) {
                                delete_extended_description(u.filename);
                                add_extended_description(u.filename,ss);
                                farfree(ss);
                            }
                        }
                    } 
                    else {
                        modify_extended_description(&ss);
                        if (ss) {
                            add_extended_description(u.filename,ss);
                            farfree(ss);
                            u.mask |= mask_extended;
                        } 
                        else
                            u.mask &= ~mask_extended;
                    }
                } 
                else
                    if (ss) {
                    farfree(ss);
                    u.mask |= mask_extended;
                } 
                else
                    u.mask &= ~mask_extended;
                break;
            }
        } 
        while (!done);
        if(changed)
            logtypes(3,"Edited file information for 4%s",u.filename);
        SETREC(i1);
        write(dlf,(void *)&u,sizeof(uploadsrec));
        i1=nrecno(s3,cp);
        if(l) i1=0;
    }
    closedl();
}

void localupload()
{
    char s[20],s1[20];
    int i=1,i1=0,done=0;

    file_mask(s);
    stripfn(s);
    outstr("5Upload to All Areas? ");
    if(yn()) {
        while(!done) {
            strcpy(s1,s);
            if(i1>num_dirs) {
                done=1;
                continue;
            }
            if(udir[i1].subnum<0) {
                done=1;
                continue;
            }
            npr("7Local Uploading: 0 %s\r\n",directories[udir[i1].subnum].name);
            i=uploadall(udir[i1].subnum,s1);
            if(i==-2) return;
            i1++;
        }
    } 
    else uploadall(udir[curdir].subnum,s);
}

void create_file()
{
    directoryrec d;
    uploadsrec u,u1;
    int i,i1,i2,ok=1,f;
    char s[81],s1[81],ff[81],*ss;
    long l,len;
    double ti;

    d=directories[udir[curdir].subnum];

    if(file_mask(u.filename)==-1) return;

    dliscan();
    u.ownerusr=usernum;
    u.ownersys=0;
    u.numdloads=0;
    u.filetype=0;
    u.mask=0;
    u.points=0;
    u.ats[0]=1;
    strcpy(ff,d.dpath);
    strcat(ff,s);
    f=open(ff,O_RDONLY | O_BINARY);
    if(f<0) {
        inputdat("Approx. Size in K",s,15,0);
        u.numbytes=(long)atoi(s)*1024;
        l=u.numbytes;
    } 
    else {
        l=filelength(f);
        u.numbytes=l;
        close(f);
    }
    strcpy(u.upby,nam(&thisuser,usernum));
    strcpy(u.date,date());
    if (d.mask & mask_PD)
        d.mask=mask_PD;
    npr("0%s5:3 %4ldk 5:2 ",u.filename,(u.numbytes+1023)/1024);
    mpl(39);
    inputl(u.description,39);
    if(u.description[0]=='/') {
        modify_extended_description(&ss);
        add_extended_description(u.filename,ss);
        farfree(ss);
        u.mask |= mask_extended;
        strcpy(s1,u.description+1);
        strcpy(u.description,s1);
    }
    if (u.description[0]==0)
        strcpy(u.description,"No Description Given at Upload");
    if(ok) {
        thisuser.fpts+=(u.numbytes+1023)/10240;
        ++thisuser.uploaded;
        if (strstr(u.filename,".GIF"))
            addgif(ff,u.description);
        comment_arc(stripfn(u.filename),d.dpath,d.upath);
        strcpy(ff,d.dpath);
        strcat(ff,stripfn(u.filename));
        adddiz(ff,&u);
        u.points=((l+1023)/10240);
        thisuser.uk += ((l+1023)/1024);
        time(&l);
        u.daten=l;
        for (i=numf; i>=1; i--) {
            SETREC(i);
            read(dlf,(void *)&u1,sizeof(uploadsrec));
            SETREC(i+1);
            write(dlf,(void *)&u1,sizeof(uploadsrec));
        }
        SETREC(1);
        write(dlf,(void *)&u,sizeof(uploadsrec));
        ++numf;
        u1.numbytes=numf;
        SETREC(0);
        write(dlf,(void *)&u1,sizeof(uploadsrec));
        ++status.uptoday;
        save_status();
        logtypes(3,"Created File %s on %s",u.filename,d.name);
    }
    closedl();
}

void move_file(int offline)
{
  char sx[81],s[81],s1[81],s2[81],ch,*ss,type[10];
  int i,i1,ok,d1,d2,done,cp,abort=0,dest;
  uploadsrec u,u1,u2;
  char *b;

  ok=0;
  nl();
  nl();

  npr("5Move 0A5ll files, 0O5ffline, or 0U5nvaldidated Only? ");
  ch=onek("\rAOV");
  if(ch=='A'||ch=='\r')
    offline=0;
  else if(ch=='O')
    offline=1;
  else if(ch=='U')
    offline=2;

  file_mask(sx);

  dliscan();
  i=recno(sx);
  if (i<0) {
    nl();
    pl("File not found.");
    closedl();
    return;
  }
  done=0;
  while ((!hangup) && (i>0) && (!done)) {
    cp=i;
    dliscan();
    SETREC(i);
    read(dlf,(void *)&u,sizeof(uploadsrec));
    nl();
    strcpy(s,directories[udir[curdir].subnum].dpath);
    strcat(s,u.filename);
    if((!exist(s)&&offline)||(!offline)) {
       printinfo(&u,&abort,0);
       nl();
       prt(5,"Move this (Y/N/Q)? ");
       ch=onek("QNY");
       if (ch=='Q')
         done=1;
       if (ch=='Y') {
         strcpy(s1,directories[udir[curdir].subnum].dpath);
         strcat(s1,u.filename);
         d1=-1;
         do {
           nl();
           prt(5,"Destination? ");
           input(type,3);
           if (type[0]=='?')
             dirlist(0);
         } while ((!hangup) && (type[0]=='?'));
         if (type[0])
           for (i1=0; (i1<64) && (udir[i1].subnum!=-1); i1++)
             if (strcmp(udir[i1].keys,type)==0)
               d1=i1;
         if(i1<64&&udir[i1].subnum!=-1)
             d1=i1;
         if (d1!=-1) {
           ok=1;
           d1=udir[d1].subnum;
           dest=d1;
           dliscan1(d1);
           if (recno(u.filename)>0) {
             ok=0;
             nl();
             pl("Filename already in use in that directory.");
           }
           if (numf>=directories[d1].maxfiles) {
             ok=0;
             nl();
             pl("Too many files in that directory.");
           }
           if (freek1(directories[d1].dpath)<((double)(u.numbytes/1024L)+3)) {
             ok=0;
             nl();
             pl("Not enough disk space to move it.");
           }
           closedl();
           dliscan();
         } else {
           ok=0;
        }
       } else {
         ok=0;
        }
       if (ok) {
         --cp;
         logtypes(3,"Moved file 4%s0 to 2%s",u.filename,directories[d1].name);
         for (i1=i; i1<numf; i1++) {
           SETREC(i1+1);
           read(dlf,(void *)&u1,sizeof(uploadsrec));
           SETREC(i1);
           write(dlf,(void *)&u1,sizeof(uploadsrec));
         }
         --numf;
         u1.numbytes=numf;
         SETREC(0);
         write(dlf,(void *)&u1,sizeof(uploadsrec));
         ss=read_extended_description(u.filename);
         if (ss)
           delete_extended_description(u.filename);
         closedl();

         strcpy(s2,directories[d1].dpath);
         strcat(s2,u.filename);
         dliscan1(d1);
         for (i=numf; i>=1; i--) {
           SETREC(i);
           read(dlf,(void *)&u1,sizeof(uploadsrec));
           SETREC(i+1);
           write(dlf,(void *)&u1,sizeof(uploadsrec));
         }
         SETREC(1);
         write(dlf,(void *)&u,sizeof(uploadsrec));
         ++numf;
         u1.numbytes=numf;
         SETREC(0);
         write(dlf,(void *)&u1,sizeof(uploadsrec));
         if (ss) {
           add_extended_description(u.filename,ss);
           farfree(ss);
         }

         closedl();

         if ((strcmp(s1,s2)!=0) && (exist(s1))) {
           d2=0;
           if ((s1[1]!=':') && (s2[1]!=':'))
             d2=1;
           if ((s1[1]==':') && (s2[1]==':') && (s1[0]==s2[0]))
             d2=1;
           if (d2) {
             rename(s1,s2);
             unlink(s1);
           } else {
             if ((b=malloca(16400))==NULL)
               return;
             d1=open(s1,O_RDONLY | O_BINARY);
             d2=open(s2,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
             i=read(d1,(void *)b,16384);
             while (i>0) {
               write(d2,(void *)b,i);
               i=read(d1,(void *)b,16384);
             }
             close(d1);
             close(d2);
             unlink(s1);
             farfree(b);
           }
         }
         nl();
         npr("File Moved to %s\r\n",directories[dest].name);
        }
       } else
         closedl();
       dliscan();
       i=nrecno(sx,cp);

  }
  closedl();
}

