#include <fcntl.h>
#include <io.h>
#include <string.h>
#include <sys\stat.h>
#include "doorutl.c"

typedef struct {
  unsigned char thesaying[81];
} sayingrec;

void listsayings()
{
  static char s[81],s1[81];
  int i,num=1;
  sayingrec asaying;

    sprintf(s1,"sayings.dat");
    i=open(s1,O_RDWR | O_BINARY);

    nl();
  lseek(i,0L,SEEK_SET);
  while(read(i,(void *)&asaying,sizeof(asaying))) {
    sprintf(s,"%d>%s",num++,&asaying.thesaying);
    pl(s);
    }
}

void main(void)
{
    char s[81],s1[81];
    int i,ednum,m=1;
    sayingrec asaying;

  sprintf(s1,"sayings.dat");
  i=open(s1,O_RDWR | O_CREAT |O_BINARY | S_IREAD | S_IWRITE );
  pl("List Rumours? ");
  gets(s);
  if(toupper(s[0])=='Y') listsayings();
  pl("Edit Which?");
  gets(s);
  ednum=atoi(s);
  lseek(i,((long)(ednum-1))*(sizeof(asaying)),SEEK_SET);
  read(i,(void *)&asaying,sizeof(asaying));
  lseek(i,((long)(ednum-1))*(sizeof(asaying)),SEEK_SET);
  pl("This is:");
  pl(asaying.thesaying);
  pl("New String?");
  outstr(":");
  gets(s);
  if(s[0]) {strcpy(asaying.thesaying,s);
  write(i,(void *)&asaying,81L);}
  close(i);
}
