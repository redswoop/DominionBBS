#include <sys\stat.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>
#include <io.h>
#include <fcntl.h>
#include <alloc.h>
#include "fcns.h"
#include "nifrec.h"

extern int hangup,fwaiting,lokb;
extern niftyrec nifty;
extern char dc[81],dcd[81],odc[81];
extern char charbuffer[161];
extern userrec thisuser;
extern int charbufferpointer,chatting;
extern int usernum,useron;
extern configrec syscfg;
extern int echo,smwcheck,okskey;
extern unsigned char realsl;
extern double timeon,thing,reinit;
extern char curspeed[80],cdir[81],cfilt[255];
extern int heymsg, nummsgs,mci;
extern unsigned int modem_speed,com_speed;
extern int cursub,curdir,curdloads;
extern usersubrec usub[32],udir[32];
extern statusrec status;
extern int incom,msgreadlogon;
extern int fsenttoday,userfile,chatcall;
extern char chatreason[81],irt[81];
extern subboardrec subboards[32];
extern directoryrec directories[64];
extern smalrec *smallist;

int ok_local()
{
  if (syscfg.sysconfig& sysconfig_no_local)
    return(0);
  else
    return(1);
}


int finduser1(char *sx)
{
  int i,i1,i2;
  char s[81],s1[81],ch;
  userrec u;

  if (sx[0]==0)
    return(0);
  i=finduser(sx);
  if (i>0)
    return(i);
  strcpy(s,sx);
  for (i=0; s[i]!=0; i++)
    s[i]=upcase(s[i]);
  i2=0;
  for (i=0; (i<status.users) && (i2==0); i++) {
    if (strstr(smallist[i].name,s)!=NULL) {
      i1=smallist[i].number;
      read_user(i1,&u);
      sprintf(s1,"Do you mean %s (Y/N/Q) ? ",nam(&u,i1));
      prt(5,s1);
      ch=onek("QYN");
      if (ch=='Y')
	i2=i1;
      if (ch=='Q')
	i=status.users;
    }
  }
  return(i2);
}


void sl1(int cmd,char *s)
{
  static int midline=0,slf=-1;
  static char f[81];
  char l[180],ch1;
  int i;

  switch(cmd) {
    case 0: /* Write line to sysop's log */
      if (slf<=0) {
        slf=open(f,O_RDWR | O_CREAT | O_BINARY, S_IREAD | S_IWRITE);
        if (filelength(slf)) {
          lseek(slf,-1L,SEEK_END);
          read(slf,((void *)&ch1),1);
          if (ch1==26)
            lseek(slf,-1L,SEEK_END);
        }
      }
      if (midline) {
        strcpy(l, "\r\n");
        strcat(l, s);
        midline = 0;
      } else
        strcpy(l,s);
      if (syscfg.sysconfig & sysconfig_printer)
        fprintf(stdprn,"%s\r\n",s);
      i=strlen(l);
      l[i++]='\r';
      l[i++]='\n';
      l[i]=0;
      write(slf,(void *)l,i);
      break;
    case 1: /* Close sysop's log */
      if (slf>0) {
        close(slf);
        slf=-1;
      }
      break;
    case 2: /* Set filename */
      if (slf>0) {
        close(slf);
        slf=-1;
      }
      strcpy(f,syscfg.gfilesdir);
      i=strlen(f);
      f[i++]=s[6];
      f[i++]=s[7];
      f[i++]=s[0];
      f[i++]=s[1];
      f[i++]=s[3];
      f[i++]=s[4];
      f[i]=0;
      strcat(f,".LOG");
      break;
    case 3: /* Close sysop's log  + return filename */
      if (slf>0) {
        close(slf);
        slf=-1;
      }
      strcpy(s,&f[strlen(syscfg.gfilesdir)]);
      break;
    case 4:
      if (slf <= 0) {
      slf = open(f, O_RDWR | O_CREAT | O_BINARY, S_IREAD | S_IWRITE);
      if (filelength(slf)) {
        lseek(slf, -1L, SEEK_END);
        read(slf, ((void *)&ch1), 1);
        if (ch1 == 26)
          lseek(slf, -1L, SEEK_END);
        }
      }
     if (!midline || ((midline + 2 + strlen(s)) > 78)) {
       strcpy(l, midline ? "\r\n   " : "   ");
       strcat(l, s);
       midline = 3 + strlen(s);
       }
     else {
       strcpy(l, ", ");
       strcat(l, s);
       midline += (2 + strlen(s));
       }
     if (syscfg.sysconfig & sysconfig_printer)
       fprintf(stdprn, "%s", l);
     i = strlen(l);
     write(slf, (void *)l, i);
     break;
  }
}

void sysopchar(char *s)
{
  if ((incom || (thisuser.sl != 255)) && (s[0]))
    sl1(4, s);
}

void sysoplog(char *s)
{
  char s1[180];

  if ((incom) || (thisuser.sl!=255)) {
    strcpy(s1,"   ");
    strcat(s1,s);
    sl1(0,s1);
  }
}


void ssm(int un, int sy, char *s)
{
  int  f,i,i1;
  userrec u;
  char s1[81];
  shortmsgrec sm;

  if (sy!=0)
    return;
  strcpy(s1,syscfg.datadir);
  sprintf(s1,"%sSMW.DAT",syscfg.datadir);
  f=open(s1,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
  i=(int) (filelength(f) / sizeof(shortmsgrec));
  i1=i-1;
  if (i1>=0) {
    lseek(f,((long) (i1)) * sizeof(shortmsgrec), SEEK_SET);
    read(f,(void *)&sm,sizeof(shortmsgrec));
    while ((sm.tosys==0) && (sm.touser==0) && (i1>0)) {
      --i1;
      lseek(f,((long) (i1)) * sizeof(shortmsgrec), SEEK_SET);
      read(f,(void *)&sm,sizeof(shortmsgrec));
    }
    if ((sm.tosys) || (sm.touser))
      ++i1;
  } else
    i1=0;
  sm.tosys=sy;
  sm.touser=un;
  strcpy(sm.message,s);
  lseek(f,((long) (i1)) * sizeof(shortmsgrec), SEEK_SET);
  write(f,(void *)&sm,sizeof(shortmsgrec));
  close(f);
  if (sy==0) {
    read_user(un,&u);
    u.sysstatus |= sysstatus_smw;
    if ((u.inact & inact_deleted)==0)
      write_user(un,&u);
    close_user();
  }
}


void rsm(int un, userrec *u)
{
  shortmsgrec sm;
  int i,i1,f,any;
  char s1[81];

  any=0;
  if ((u->sysstatus) & sysstatus_smw) {
    strcpy(s1,syscfg.datadir);
    sprintf(s1,"%sSMW.DAT",syscfg.datadir);
    f=open(s1,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
    i=(int) (filelength(f) / sizeof(shortmsgrec));
    for (i1=0; i1<i; i1++) {
      lseek(f,((long) (i1)) * sizeof(shortmsgrec),SEEK_SET);
      read(f,(void *)&sm,sizeof(shortmsgrec));
      if ((sm.touser==un) && (sm.tosys==0)) {
        pl(sm.message);
        sm.touser=0;
        sm.tosys=0;
        sm.message[0]=0;
        lseek(f,((long) (i1)) * sizeof(shortmsgrec),SEEK_SET);
        write(f,(void *)&sm,sizeof(shortmsgrec));
	any=1;
      }
    }
    close(f);
    u->sysstatus ^= sysstatus_smw;
    smwcheck=1;
  }
  if (any)
    nl();
}

void alfer(int f, char *s)
{
  char s1[100];

  strcpy(s1,s);
  strcat(s1,"");
  write(f,(void *)s1,strlen(s1));
}


void dorinfo_def()
{
int x=0,i;
char *first,*last,*s,s1[220];
return;
  i=open("dorinfo1.def",O_RDWR|O_CREAT|O_BINARY,S_IREAD|S_IWRITE);
  alf(i,syscfg.systemname);
  if(lokb) strcpy(s,"COM0");
  else sprintf(s1,"COM%d",syscfg.primaryport);
  alf(i,s);  if(lokb) strcpy(s,"0");  else sprintf(s,"%d",curspeed);
  sprintf(s,"%s BAUD,N,8,1",s);
  alf(i,s);
  x=0;
  while(thisuser.realname[x]!=' ') first[x]=thisuser.realname[x++];
  strcpy(last,thisuser.realname+x);
  alf(i,first);
  alf(i,last);
  alf(i,thisuser.citystate);
  if(thisuser.sysstatus & sysstatus_color) alf(i,"1");
   else alf(i,"0");
  sprintf(s,"%d",thisuser.sl);
  alf(i,s);
  sprintf(s,"%d",thisuser.extratime*60);
  alf(i,s);
  alf(i,"0");
  close(i);
}

void prinfo(char ch)
{
  char s[81];
  int x;
  strcpy(s,"");

    switch (ch) {
       case '@': strcpy(s,"@"); break;
       case 'B': sprintf(s,"%s",subboards[usub[cursub].subnum].name); break;
       case 'A': sprintf(s,"%s",usub[cursub].keys); break;
       case 'D': sprintf(s,"%s",directories[udir[curdir].subnum].name); break;
       case 'C': sprintf(s,"%s",udir[curdir].keys); break;
       case 'M': nl(); break;
       case 'N': strcpy(s,nam(&thisuser,usernum)); break;
       case 'R': sprintf(s,"%s",thisuser.realname); break;
       case 'L': sprintf(s,"%d",usernum); break;
       case 'I': strcpy(s,""); break;
       case 'F': itoa((int)thisuser.filepoint,s,10); break;
       case 'S': itoa(thisuser.sl,s,10); break;
       case 'G': sprintf(s,"%.0f",thisuser.credits); break;
       case 'P': pausescr(); break;
       case 'T': strcpy(s,ctim(nsl())); break;
       case 'E': strcpy(s,date());  break;
       case 'V': sprintf(s,"%d",heymsg); break;
       case 'W': sprintf(s,"%d",nummsgs); break;
       case 'Z': sprintf(s,"%s",get_say(0)); break;
       case 'U': if(okansi()) sprintf(s,"[1A"); break;
       case 'O': if(okansi()) sprintf(s,"[1B"); break;
       case 'Q': sprintf(s,"%d",nifty.postcredits); break;
       case 'J': sprintf(s,"%d",thisuser.dsl); break;
       case 'K': sprintf(s,"%d/%d",thisuser.uk,thisuser.dk); break;
       case 'H': sprintf(s,"%s",nam(&thisuser,usernum)); break;
       case 'Y': delay(750); break;
       default:
         break;
    }
    if(s[0]) outstr(s);
}



void readscreen(char filename[41])
{
  int i,x;
  char screen[10000];
  i=open(filename,O_RDONLY);
  x=read(i,screen,9999);
  write(1,screen,x);
  close(i);
}

void things(int x,int xx,int yy)
{
    char c;
    nl();
    printf("[0m");
    movecsr(xx,yy);
    printf("[0;1m");
    for(c=0;c<x;c++)
    printf("�");
    printf("\n");
    printf("[47m");
    for(c=0;c<x;c++)
    printf(" ");
    printf("[0;30;1m");
    printf("\n");
    for(c=0;c<x;c++)
    printf("�");
    movecsr(xx,yy+1);
}

void wfct(void)
{
    char s[81];
    double tt;
    tt=timer();
    tt=tt-reinit;
    if(tt>600.0) { imodem(); reinit=timer(); }
    tt=timer();
    tt-=thing;
    if(tt<60.0) {
    sprintf(s,"[1;34;47m[Time: [32m%s[34m]",times());
    movecsr(0,20);
    outstr(s);
    movecsr(0,23);
    if(sysop2())
         outstr("[1;36;47mSysOp [32mAvailable  ");
    else outstr("[1;36;47mSysOp [32mUnavailable");
    outstr("[0m");
    }
    else clrscrb();
}

void wfcs(void)
{
    char s[81];
    echo=1;
    clrscrb();
    thing=timer();
    reinit=timer();
    sprintf(s,"%s\\wfc.ans",syscfg.gfilesdir);
    readscreen(s);
    makeansi(121,s);  printf("%s",s);
    things(79,0,1);
    sprintf(s,"[1;32;47m  %s [33m - [36mDominous Productions",VERSION_NUMBER);
    printf(s);
    things(30,0,4);
    sprintf(s,"[1;34;47m[Callers Today ] [32m%d",status.callstoday);
    printf("%s",s);
    things(30,0,7);
    sprintf(s,"[1;34;47m[Activity Today] [32m%d%%",(10*status.activetoday/144));
    printf("%s",s);
    things(30,0,10);
    sprintf(s,"[1;34;47m[Messages Today] [32m%d",status.msgposttoday);
    printf("%s",s);
    things(30,0,13);
    sprintf(s,"[1;34;47m[Uploads Today ] [32m%d",status.uptoday);
    printf("%s",s);
    things(30,0,16);
    sprintf(s,"[1;34;47m[Mail Waiting  ] [32m%d",fwaiting);
    printf("%s",s);
    things(30,0,19);
    things(30,0,22);
}

char *filter1(char *s)
{
 char c='*';
 int x=0;
 while(s[x++]!=c);
 s[x-1]='';
return s;
}

void infoform(char fn[8]) {
char s[81],s1[81];
FILE *fnin,*fno;

sprintf(s1,"%s%s.inf",syscfg.gfilesdir,fn);
if(!exist(s1)) { pl("Infoform Not Found."); return; }
fnin=fopen(s1,"rt");
sprintf(s,"%s%s.ser",syscfg.gfilesdir,fn);
fno=fopen(s,"a");
sprintf(s,"~%s\n",thisuser.name);
fputs(s,fno);

 while(fgets(s,81,fnin)!=NULL) {
    strcpy(s,filter(s));
    if(!strchr(s,'*')) {
       pl(s); strcat(s,"\n"); fputs(s,fno);
       } else {
          strcpy(s,filter1(s));
          do {
             outstr(s); inputl(s1,51);
             } while(!s1[0]);
          strcat(s,s1); strcat(s,"\n"); fputs(s,fno); }
          }

fclose(fno);
fclose(fnin);
}

void readform(char fn[8],char i[31]) {
char s[81],s1[81],go=1;
int i1;
FILE *fnin;
userrec u;

sprintf(s,"%s%s.ser",syscfg.gfilesdir,fn);
if(!exist(s)) {pl("not found"); return; }
fnin=fopen(s,"rt");
i1=finduser(i);
if(i1>0) read_user(i1,&u); else return;

while(fgets(s,81,fnin)!=NULL&&go) {
    if(s[0]=='~') {
    strcpy(s1,filter(s+1));
    if(!strcmp(u.name,s1)) { go=0;
      while((fgets(s,81,fnin))!=NULL&&s[0]!='~') pl(filter(s)); }
    }
  }
fclose(fnin);
pausescr();
}
