#include <stdio.h>
#include <dos.h>
#include <alloc.h>
#include <mem.h>
#include <io.h>
#include <sys\stat.h>
#include <fcntl.h>
#include <conio.h>
#include <stdlib.h>
#include "fcns.h"
#include "nifrec.h"

extern int outcom,tempio,okskey,lines_listed,two_color,echo,screenlinest,ok_modem_stuff;
extern int topline,curatr,useron,using_modem,incom,chat_file,screenlen;
extern int hangup,sysop_alert,charbufferpointer,lastcon;
extern char charbuffer[161],curspeed[80];
extern unsigned int modem_speed,com_speed;
extern char far *scrn;
extern userrec thisuser;
extern niftyrec nifty;
extern int oldx,oldy;
extern int topdata,chatcall;
extern char chatreason[81],crttype;
extern configrec syscfg;
extern statusrec status;
extern int fwaiting;
extern char ctypes[NUM_CTYPES][18];
extern unsigned char realsl;
extern int chatting,global_handle;
extern char endofline[81],cfilt[255];
extern unsigned int usernum;
extern screentype screensave;
extern double extratimecall,timeon;
extern int screenbottom,defscreenbottom;
int begxx,begyy;

#define TWO_WAY

#define SCROLL_UP(t,b,l) \
  _CH=t;\
  _DH=b;\
  _BH=curatr;\
  _AL=l;\
  _CL=0;\
  _DL=79;\
  _AH=6;\
  my_video_int();


#define GLOBAL_SIZE 256

static char global_buf[GLOBAL_SIZE];
static int global_ptr;

void my_video_int()
{
  static unsigned short sav_bp;

  __emit__(0x56, 0x57); /* push si, push di */
  sav_bp = _BP;
  geninterrupt(0x10);
  _BP = sav_bp;
  __emit__(0x5f, 0x5e); /* pop di, pop si */
}


void set_global_handle(int i)
{
  char s[81];

  if (i) {
    if (!global_handle) {
      sprintf(s,"%sGLOBAL.TXT",syscfg.gfilesdir);
      global_handle=open(s,O_RDWR | O_APPEND | O_BINARY | O_CREAT,
                           S_IREAD | S_IWRITE);
      if (global_handle<0)
        global_handle=0;
      global_ptr=0;
    }
  } else {
    if (global_handle) {
      write(global_handle,global_buf,global_ptr);
      close(global_handle);
      global_handle=0;
    }
  }
}


void global_char(char ch)
{
  global_buf[global_ptr++]=ch;
  if (global_ptr==GLOBAL_SIZE) {
    write(global_handle,global_buf,global_ptr);
    global_ptr=0;
  }
}



void movecsr(int x,int y)
/* This, obviously, moves the cursor to the location specified, offset from
 * the protected dispaly at the top of the screen
 */
{
  if (x<0)
    x=0;
  if (x>79)
    x=79;
  if (y<0)
    y=0;
  y+=topline;
  if (y>screenbottom)
    y=screenbottom;

  _BH=0x00;
  _DH=y;
  _DL=x;
  _AH=0x02;
  my_video_int();
}



int wherex()
/* This function returns the current X cursor position, as the number of
 * characters from the left hand side of the screen.  An X position of zero
 * means the cursor is at the left-most position
 */
{
  _BH=0x00;
  _AH=0x03;
  my_video_int();
  tempio=_DL;
  return(tempio);
}



int wherey()
/* This function returns the Y cursor position, as the line number from
 * the top of the logical window.  The offset due to the protected top
 * of the screen display is taken into account.  A wherey() of zero means
 * the cursor is at the top-most position it can be at.
 */
{
  _BH=0x00;
  _AH=0x03;
  my_video_int();
  tempio=_DH;
  return(tempio-topline);
}



void lf()
/* This function performs a linefeed to the screen (but not remotely) by
 * either moving the cursor down one line, or scrolling the logical screen
 * up one line.
 */
{
  _BH=0x00;
  _AH=0x03;
  my_video_int();
  tempio=_DL;
  if (_DH==screenbottom) {
    SCROLL_UP(topline,screenbottom,1);
    _DL=tempio;
    _DH=screenbottom;
    _BH=0;
    _AH=0x02;
    my_video_int();
  } else {
    tempio=_DH+1;
    _DH=tempio;
    _AH=0x02;
    my_video_int();
  }
}



void cr()
/* This short function returns the local cursor to the left-most position
 * on the screen.
 */
{
  _BH=0x00;
  _AH=0x03;
  my_video_int();
  _DL=0x00;
  _AH=2;
  my_video_int();
}

void clrscrb()
/* This clears the local logical screen */
{
  SCROLL_UP(topline,screenbottom,0);
  movecsr(0,0);
  lines_listed=0;
}



void bs()
/* This function moves the cursor one position to the left, or if the cursor
 * is currently at its left-most position, the cursor is moved to the end of
 * the previous line, except if it is on the top line, in which case nothing
 * happens.
 */
{
  _BH=0;
  _AH=3;
  my_video_int();
  if (_DL==0) {
    if (_DH != topline) {
      _DL=79;
      tempio=_DH-1;
      _DH=tempio;
      _AH=2;
      my_video_int();
    }
  } else {
    _DL--;
    _AH=2;
    my_video_int();
  }
}



void out1chx(unsigned char ch)
/* This function outputs one character to the screen, then updates the
 * cursor position accordingly, scolling the screen if necessary.  Not that
 * this function performs no commands such as a C/R or L/F.  If a value of
 * 8, 7, 13, 10, 12 (backspace, beep, C/R, L/F, TOF), or any other command-
 * type characters are passed, the appropriate corresponding "graphics"
 * symbol will be output to the screen as a normal character.
 */
{
  _BL=curatr;
  _BH=0x00;
  _CX=0x01;
  _AL=ch;
  _AH=0x09;
  my_video_int();
  _BH=0x00;
  _AH=0x03;
  my_video_int();
  ++_DL;
  if (_DL==80) {
    _DL=0;
    if (_DH==screenbottom) {
      SCROLL_UP(topline,screenbottom,1);
      _DH=screenbottom;
      _DL=0;
      _BH=0;
      _AH=0x02;
      my_video_int();
    } else {
      tempio=_DH+1;
      _DH=tempio;
      _AH=0x02;
      my_video_int();
    }
  } else {
    _AH=0x02;
    my_video_int();
  }
}




void out1ch(unsigned char ch)
/* This function outputs one character to the local screen.  C/R, L/F, TOF,
 * BS, and BELL are interpreted as commands instead of characters.
 */
{
  if (ch>31)
    out1chx(ch);
  else
    if (ch==13)
      cr();
    else
      if (ch==10)
        lf();
      else
        if (ch==12)
          clrscrb();
        else
          if (ch==8)
            bs();
          else
            if (ch==7)
              if (outcom==0) {
                setbeep(1);
                wait1(4);
                setbeep(0);
              }
}


void outs(char *s)
/* This (obviously) outputs a string TO THE SCREEN ONLY */
{
  int i;
  char ch;

  for (i=0; s[i]!=0; i++) {
    ch=s[i];
    out1ch(ch);
  }
}



void pr_wait(int i1)
{
  int i;
  char s[10];

  if (i1) {
    if (okansi()) {
      begxx=wherex();
      begyy=wherey();
      i=curatr;
      setc((thisuser.sysstatus & sysstatus_color) ? thisuser.colors[3] :
            thisuser.bwcolors[3]);
      outstr(get_string(24));
      setc(i);
    } else {
      outstr(get_string(24));
    }
  } else {
    sprintf(s,"[%d;%dH",begxx,begyy);
    outstr(s);
    for(i=0;i<=begxx;i++) backspace();}
}



void set_protect(int l)
/* set_protect sets the number of lines protected at the top of the screen. */
{
  if (l!=topline) {
    if (l>topline) {
      if ((wherey()+topline-l) < 0) {
        _CH=topline;
        _DH=screenbottom+1;
        _AL=l-topline;
        _CL=0;
        _DL=79;
        _BH=0x07;
        _AH=7;
        my_video_int();
        movecsr(wherex(),wherey()+l-topline);
      } else {
        oldy += (topline-l);
      }
    } else {
      SCROLL_UP(l,topline-1,0);
      oldy += (topline-l);
    }
  }
  topline=l;
  if (using_modem)
    screenlinest=thisuser.screenlines;
  else
    screenlinest=defscreenbottom+1-topline;
}


void savescreen(screentype *s)
{
  memmove(s->scrn1,scrn,screenlen);
  s->x1=wherex();
  s->y1=wherey();
  s->topline1=topline;
  s->curatr1=curatr;
}

void restorescreen(screentype far *s)
/* restorescreen restores a screen previously saved with savescreen */
{
  memmove(scrn,s->scrn1,screenlen);
  topline=s->topline1;
  curatr=s->curatr1;
  movecsr(s->x1,s->y1);
}


void makewindow(int x, int y, int xlen, int ylen)
{
  int i,xx,yy;
  unsigned char s[81];

  if (xlen>80)
    xlen=80;
  if (ylen>(screenbottom+1-topline))
    ylen=(screenbottom+1-topline);
  if ((x+xlen)>80)
    x=80-xlen;
  if ((y+ylen)>screenbottom+1)
    y=screenbottom+1-ylen;

  xx=wherex();
  yy=wherey();
  for (i=1; i<xlen-1; i++)
    s[i]=196;
  s[0]=218;
  s[xlen-1]=191;
  s[xlen]=0;
  movecsr(x,y);
  printf("[34;1m%s",s);
  s[0]=192;
  s[xlen-1]=217;
  movecsr(x,y+ylen-1);
    printf("[34;1m%s",s);
  for (i=1; i<xlen-1; i++)
    s[i]=32;
  s[0]=179;
  s[xlen-1]=179;
  for (i=1; i<ylen-1; i++) {
    movecsr(x,i+y);
   printf("[34;1m%s",s);
  }
  movecsr(xx,yy);
}


void editline(char *s, int len, int status, int *returncode, char *ss)
/* editline edits a string, doing I/O to the screen only. */
{
  int i,j,k,oldatr,cx,cy,pos,ch,done,insert,i1;

  oldatr=curatr;
  cx=wherex();
  cy=wherey();
  for (i=strlen(s); i<len; i++)
    s[i]=32;
  s[len]=0;
  //curatr=0x70;
  ansic(6);
  outs(s);
  movecsr(cx,cy);
  done=0;
  pos=0;
  insert=0;
  do {
    ch=getchd();
    if (ch==0) {
      ch=getchd();
      switch (ch) {
        case 59:
          done=1;
          *returncode=DONE;
          break;
        case 71: pos=0; movecsr(cx,cy); break;
        case 79: pos=len; movecsr(cx+pos,cy); break;
        case 77: if (pos<len) {
            pos++;
            movecsr(cx+pos,cy);
          }
          break;
        case 75: if (pos>0) {
            pos--;
            movecsr(cx+pos,cy);
          }
          break;
        case 72:
        case 15:
          done=1;
          *returncode=PREV;
          break;
        case 80:
          done=1;
          *returncode=NEXT;
          break;
        case 82:
          if (status!=SET) {
            if (insert)
              insert=0;
            else
              insert=1;
          }
          break;
        case 83:
          if (status!=SET) {
            for (i=pos; i<len; i++)
              s[i]=s[i+1];
            s[len-1]=32;
            movecsr(cx,cy);
            outs(s);
            movecsr(cx+pos,cy);
          }
          break;
      }
    } else {
      if (ch>31) {
        if (status==UPPER_ONLY)
          ch=upcase(ch);
        if (status==SET) {
          ch=upcase(ch);
          if (ch!=' ') {
            i1=1;
            for (i=0; i<len; i++)
              if ((ch==ss[i]) && (i1)) {
                i1=0;
                pos=i;
                movecsr(cx+pos,cy);
                if (s[pos]==' ')
                  ch=ss[pos];
                else
                  ch=' ';
              }
            if (i1)
              ch=ss[pos];
          }
        }
        if ((pos<len)&&((status==ALL) || (status==UPPER_ONLY) || (status==SET) ||
            ((status==NUM_ONLY) && (((ch>='0') && (ch<='9')) || (ch==' '))))) {
          if (insert) {
            for (i=len-1; i>pos; i--)
              s[i]=s[i-1];
            s[pos++]=ch;
            movecsr(cx,cy);
            outs(s);
            movecsr(cx+pos,cy);
          } else {
            s[pos++]=ch;
            out1ch(ch);
          }
        }
      } else {
        ch=ch;
        switch(ch) {
          case 13:
          case 9:
            done=1;
            *returncode=NEXT;
            break;
          case 27:
            done=1;
            *returncode=DONE;
            break;
          case 8:
            if (pos>0) {
              if (insert) {
                for (i=pos-1; i<len; i++)
                  s[i]=s[i+1];
                s[len-1]=32;
                pos--;
                movecsr(cx,cy);
                outs(s);
                movecsr(cx+pos,cy);
              } else {
                pos--;
                movecsr(cx+pos,cy);
              }
            }
            break;
        }
      }
    }
  } while (done==0);
  movecsr(cx,cy);
  curatr=oldatr;
  outs(s);
  movecsr(cx,cy);
}

void viewfile(char *fn)
{
    messagerec m;
    int next;

    m.stored_as=0L;
    m.storage_type=255;
    next=0;
    read_message1(&m,0,0,&next,fn);
}

void val_cur_user()
{
  char sl[4],dsl[4],exempt[4],sysopsub[4],ar[17],dar[17],restrict[17],rst[17],
       tl[50];
  int cp,i,done,rc,wx,wy;

  pr_wait(1);
  thisuser.sl=realsl;
  savescreen(&screensave);
  curatr=7;
  wx=15;
  wy=4;
  makewindow(wx,wy,50,7);
  itoa((int)thisuser.sl,sl,10);
  itoa((int)thisuser.dsl,dsl,10);
  itoa((int)thisuser.exempt,exempt,10);
  itoa((int)thisuser.sysopsub,sysopsub,10);
  strcpy(rst,restrict_string);
  for (i=0; i<=15; i++) {
    if (thisuser.ar & (1 << i))
      ar[i]='A'+i;
    else
      ar[i]=32;
    if (thisuser.dar & (1 << i))
      dar[i]='A'+i;
    else
      dar[i]=32;
    if (thisuser.restrict & (1 << i))
      restrict[i]=rst[i];
    else
      restrict[i]=32;
  }
  dar[16]=0;
  ar[16]=0;
  restrict[16]=0;
  cp=0;
  done=0;

  movecsr(wx+2,wy+1); sprintf(tl,"[33;1mSl  [35;1m: [0m%s",sl); printf("%s",tl);
  movecsr(wx+26,wy+1); sprintf(tl,"[33;1mAr  [35;1m: [0m%s",ar); printf("%s",tl);
  movecsr(wx+2,wy+2); sprintf(tl,"[33;1mDsl [35;1m: [0m%s",dsl); printf("%s",tl);
  movecsr(wx+26,wy+2); sprintf(tl,"[33;1mDar [35;1m: [0m%s",dar); printf("%s",tl);
  movecsr(wx+2,wy+3); sprintf(tl,"[33;1mExmt[35;1m: [0m%s",exempt); printf("%s",tl);
  movecsr(wx+26,wy+3); sprintf(tl,"[33;1mRstr[35;1m: [0m%s",restrict); printf("%s",tl);
  movecsr(wx+2,wy+4); sprintf(tl,"[33;1mSysOpSub[35;1m: [0m%s",sysopsub); printf("%s",tl);
  movecsr(wx+2,wy+5); sprintf(tl,"[33;1mNote[35;1m: [0m%s",thisuser.note); printf("%s",tl);
  while (done==0) {
    switch(cp) {
      case 0:
        movecsr(wx+8,wy+1);
        editline(sl,3,NUM_ONLY,&rc,"");
        thisuser.sl=(char) atoi(sl);
        itoa((int)thisuser.sl,sl,10);
        sprintf(tl,"%-3s",sl); outs(tl);
        break;
      case 1:
        movecsr(wx+32,wy+1);
        editline(ar,16,SET,&rc,"ABCDEFGHIJKLMNOP");
        thisuser.ar=0;
        for (i=0; i<=15; i++)
          if (ar[i]!=32)
            thisuser.ar |= (1 << i);
        break;
      case 2:
        movecsr(wx+8,wy+2);
        editline(dsl,3,NUM_ONLY,&rc,"");
        thisuser.dsl=(char) atoi(dsl);
        itoa((int)thisuser.dsl,dsl,10);
        sprintf(tl,"%-3s",dsl); outs(tl);
        break;
      case 3:
        movecsr(wx+32,wy+2);
        editline(dar,16,SET,&rc,"ABCDEFGHIJKLMNOP");
        thisuser.dar=0;
        for (i=0; i<=15; i++)
          if (dar[i]!=32)
            thisuser.dar |= (1 << i);
        break;
      case 4:
        movecsr(wx+8,wy+3);
        editline(exempt,3,NUM_ONLY,&rc,"");
        thisuser.exempt=(char) atoi(exempt);
        itoa((int)thisuser.exempt,exempt,10);
        sprintf(tl,"%-3s",exempt); outs(tl);
        break;
      case 5:
        movecsr(wx+32,wy+3);
        editline(restrict,16,SET,&rc,rst);
        thisuser.restrict=0;
        for (i=0; i<=15; i++)
          if (restrict[i]!=32)
            thisuser.restrict |= (1 << i);
        break;
      case 6:
        movecsr(wx+12,wy+4);
        editline(sysopsub,3,NUM_ONLY,&rc,"");
        thisuser.sysopsub=(char) atoi(sysopsub);
        itoa((int)thisuser.sysopsub,sysopsub,10);
        sprintf(tl,"%-3s",sysopsub); outs(tl);
        break;
      case 7:
        movecsr(wx+8,wy+5);
        editline(thisuser.note,40,ALL,&rc,"");
        break;
    }
    switch(rc) {
      case DONE: done=1; break;
      case NEXT: cp=(cp+1) % 8; break;
      case PREV: cp--; if (cp==-1) cp=7;  break;
    }
  }
  restorescreen(&screensave);
  changedsl();
  pr_wait(0);
}

void drop_to_dos(int shrink)
{
  int i;

  i=topline;
  topline=0;
  curatr=0x07;
  clrscrb();
  if (shrink)
    shrink_out(getenv("COMSPEC"),1,0,0,0);
  else
    do_remote(getenv("COMSPEC"),0);
  topline=i;
}

void outfast(char *s)
/* This RAPIDLY outputs ONE LINE to the screen only*/
{
  int i,i1;

  i1 = (wherey() * 80 + wherex()) *2 ;
  for (i=0;s[i]!=0;i++) {
    scrn[i*2+i1+1]=curatr;
    scrn[i*2+i1]=s[i];
  }
  movecsr(wherex()+strlen(s),wherey());
}



void skey(char ch)
/* skey handles all f-keys and the like hit FROM THE KEYBOARD ONLY */
{
  int i,i1;
  char s[51];

  if (((syscfg.sysconfig & sysconfig_no_local) ==0) && (okskey)) {
    if ((ch>=104) && (ch<=113)) {
      set_autoval(ch-104);
    } else
      switch ((unsigned char) ch) {
        case 59: /* F1 */
          val_cur_user();
          break;
        case 60: /* F2 */
          topdata+=1;
          if (topdata==3)
            topdata=0;
          topscreen();
          break;
        case 61: /* F3 */
          if (using_modem) {
            incom=(!incom);
            dump();
            tleft(0);
          }
          break;
        case 86: /* Shift F3 */
          if (using_modem) {
            outcom=(!outcom);
            dump();
            tleft(0);
          }
          break;

        case 62: /* F4 */
          chatcall=0;
          chatreason[0]=0;
          topscreen(0);
          break;
        case 63: /* F5 */
          hangup=1;
          dtr(0);
          break;
        case 64: /* F6 */
          sysop_alert=!sysop_alert;
          tleft(0);
          break;
        case 65: /* F7 */
          thisuser.extratime-=5.0*60.0;
          tleft(0);
          break;
        case 66: /* F8 */
          thisuser.extratime+=5.0*60.0;
          tleft(0);
          break;
        case 67: /* F9 */
          if (realsl!=255) {
            if (thisuser.sl!=255)
              thisuser.sl=255;
            else
              thisuser.sl=realsl;
            i=realsl;
            changedsl();
            realsl=i;
            tleft(0);
          }
          break;
        case 68: /* F10 */
          if (chatting==0) {
            if (syscfg.sysconfig & sysconfig_2_way)
              chat1("",1);
            else
              chat1("",0);
          } else
            chatting=0;
          break;
        case 35: // Alt-H
            sprintf(s,"%ssyshelp.ans",syscfg.gfilesdir);
            savescreen(&screensave);
            readscreen(s);
            getch();
            restorescreen(&screensave);
            break;
        case 71: /* HOME */
          if (chatting) {
            if (chat_file)
              chat_file=0;
            else
              chat_file=1;
          }
          break;
        case 88: /* Shift-F5 */
          i1=(rand() % 20) + 10;
          for (i=0; i<i1; i++)
            outchr(rand() % 256);
          hangup=1;
          dtr(0);
          break;

    case 89: /* Shift-F6 */
      savescreen(&screensave);
      printf("[2JExit BBS?!?! ");
       if(toupper(getche()) == 'Y') {
        printf("[2JSave Online data? ");
        if(toupper(getche())=='Y')
        save_state("restore.wwv",1,0);
        sl1(1,"");
        sysoplog("SysOp BBS Exit");
        pr_wait(1);
      if (ok_modem_stuff)
       closeport();
       exit(255); }
         restorescreen(&screensave);
         break;
    case 90: // Shift-F7
           chuser2(); break;
        case 98: /* Ctrl-F5 */
          nl();
          pl("Call back later when you are there.");
          nl();
          hangup=1;
          dtr(0);
          break;
        case 93: /* Ctrl-F10 */
          if (chatting==0)
            chat1("",0);
          else
            chatting=0;
          break;
        case 84: /* Shift-F1 */
          set_global_handle(!global_handle);
          tleft(0);
          break;
        case 103: /* Shift-F10 */
          pr_wait(1);
          savescreen(&screensave);
          i=topline;
          topline=0;
          curatr=0x07;
          clrscrb();
          do_remote(getenv("COMSPEC"),0);
          restorescreen(&screensave);
          topline=i;
          pr_wait(0);
          break;
      }
  }
}


void tleft(int x)
{
  int cx,cy,ctl,cc,ln;
  double nsln;
  char tl[30];

  cx=wherex();
  cy=wherey();
  ctl=topline;
  cc=curatr;
  if (crttype==7)
    curatr=0x30;
  else
    curatr=0x0e;
  topline=0;
  nsln=nsl();
  if (chatreason[0] && (topdata==2))
    ln=5;
  else if(topdata==1)
    ln=9;
  else if(topdata==2) ln=4;

  if (topdata)
  {
   printf("[37;1;44m");
    movecsr(10,ln);
    if ((using_modem) && (!incom))
      printf("Remote Lock");
    else
      printf("             ");

    movecsr(24,ln);
    if ((realsl !=255) && (thisuser.sl==255))
      printf("Temp Sysop");
    else
      printf("          ");

    movecsr(41,ln);
    if (global_handle)
      printf("Capture");
    else
      printf("       ");

    movecsr(55,ln);
    if (sysop_alert)
      printf("Alert");
    else
      printf("     ");

    movecsr(65,ln);
    if (sysop1())
      printf("Available");
    else
      printf("         ");
  }
  printf("[0m");
  switch (topdata)
    {
    case 1:
    case 2:
      if (useron) {
      movecsr(0,ln);
      sprintf(tl,"Time Left %6.2f",nsln/60.0);
      printf("[0;1;44m%s",tl); }
      else {
        movecsr(0,ln);
       printf("[0;1;44m%s",thisuser.pw);
    }
      break;
    case 3: break;
  }
  topline=ctl;
  curatr=cc;
  movecsr(cx,cy);
  if ((x) && (useron))
    if ((nsln==0.0) && (thisuser.sl!=255)){
        if(thisuser.res[3]) {
            outstr("You have time in the time bank. Withdraw it? ");
            if(ny()) remove_time();
        } else
      outstr("\r\nTime expired.\r\n");
      hangup=1;
    }
}

//ScanMark1
void topscreen()
{
  int cc,cx,cy,ctl,i,x,ff;
  char sl[81],s2[100],ar[17],dar[17],restrict[17],rst[17],lo[90],ol[255],
  credits[10],filepoint[10];
  zlogrec z;


  switch(topdata) {
    case 0:
      set_protect(0);
      break;
    case 1:
      set_protect(10);
      break;
    case 2:
      if (chatreason[0])
        set_protect(6);
      else {
        if (topline==6)
          set_protect(0);
        set_protect(5);
      }
      break;
  }
  cx=wherex();
  cy=wherey();
  ctl=topline;
  cc=curatr;
  if (crttype==7)
    curatr=0x07;
  else
    curatr=0x0e;
  topline=0;
  movecsr(0,3);
  for (i=0; i<80; i++)
    sl[i]=' ';
  sl[80]=0;

  switch (topdata) {
    case 0:
      break;
        case 1:

      movecsr(0,0);
      sprintf(ol,"%-50s  Activity for %8s:      ",
          syscfg.systemname,status.date1);
      outs(ol);

      movecsr(0,1);
      sprintf(ol,"[0;35;1mUsers:[36m %4d       [35;1mTotal Calls:[36m %5ld      [35;1mCalls Today:[36m %4d    [35;1mPosted      :[36m%3d ",
          status.users,status.callernum1,status.callstoday,status.msgposttoday);
      printf("%s",ol);

      movecsr(0,2);
      sprintf(ol,"[36m%-36s      %-4d min   [32m/ [36m %2d%%    [35;1mE-mail sent :[36m%3d ",
          nam(&thisuser,usernum),status.activetoday,
          (10*status.activetoday/144),status.emailtoday);
      printf("%s",ol);

      movecsr(0,3);
      sprintf(ol,"[35mSL=[36m%3d   [35mDL=[36m%3d               [35mFW=[36m%3d      [35mUploaded:[36m%2d files    [35mFeedback    :[36m%3d ",
          thisuser.sl,thisuser.dsl,fwaiting,status.uptoday,status.fbacktoday);
      printf("%s",ol);
      movecsr(0,4);
      printf("[33m  Date     [36mCalls  [33mActive   [36mPosts   [33mEmail   [36mFback   [33m U/L   [36m %Act");
      movecsr(0,5);
  printf("[0;1m��������   �����  ������   �����   �����   �����    ���    ����   ");
      sprintf(ol,"%szlog.dat",syscfg.datadir);
      ff=open(ol,O_RDWR|O_BINARY);
      lseek(ff,0L,SEEK_SET);
      for(x=6;x<9;x++) {
      movecsr(0,x);
      read(ff,(void *)&z,sizeof(zlogrec));
      printf("%s    %4d    %4d     %3d     %3d     %3d    %3d     %3d     ",
         z.date,z.calls,z.active,z.posts,z.email,z.fback,z.up,10*z.active/144);
    } close(ff);
      break;

    case 2:
         itoa((int)thisuser.filepoint,filepoint,10);
         itoa((int)thisuser.credits,credits,10);
      strcpy(rst,restrict_string);
      for (i=0; i<=15; i++) {
        if (thisuser.ar & (1 << i))
          ar[i]='A'+i;
        else
          ar[i]='a'+i;
        if (thisuser.dar & (1 << i))
          dar[i]='A'+i;
        else
          dar[i]=32;
        if (thisuser.restrict & (1 << i))
          restrict[i]=rst[i];
        else
          restrict[i]=32;
      }
      dar[16]=0;
      ar[16]=0;
      restrict[16]=0;
      if (strcmp(thisuser.laston,date()))
        strcpy(lo,thisuser.laston);
      else
        sprintf(lo,"Today:%2d",thisuser.ontoday);

      movecsr(0,0);
      sprintf(ol,"[0;33;1m%-36s[34;1m�[35;1mSL/DSL=%-4d/%-4d[34;1m�[32;1mEx = %3d Res = %-16s",nam(&thisuser,usernum),thisuser.sl
      ,thisuser.dsl,thisuser.exempt,restrict);
      printf("%s",ol);

      movecsr(0,1);
      sprintf(ol,"[33;1m%-36s[34;1m�[35;1mPS/ES =%-4d/%-4d[34;1m�[32;1mU/D= %-5d/%-5d",thisuser.realname,
      thisuser.msgpost,thisuser.emailsent+thisuser.emailnet,thisuser.uploaded,thisuser.downloaded);

      printf("%s",ol);
      
      movecsr(0,2);
      sprintf(ol,"[33;1m%-36s[34;1m�[35;1mTC/CT =%-4d/%-4d[34;1m�[32;1mAR =%s",thisuser.citystate,thisuser.logons,
      thisuser.ontoday,ar);
      printf("%s",ol);

      movecsr(0,3);
      sprintf(s2,"[33;1m%-12s, %-2d, %c, %-15s",thisuser.phone,thisuser.age,thisuser.sex,
      ctypes[thisuser.comp_type]);
      sprintf(ol,"%-36s[34;1m�[35;1mFP/C  =%-4s/%-4s[34;1m�[32;1m[32;1mDAR=%s",s2,filepoint,credits,dar);
      printf("%s",ol);

      if (chatreason[0]) {
        movecsr(0,4);
    printf("[36;5;1mCHAT! [0;33;1m%-50s",chatreason);
      }
      break;
  }
  if (ctl!=0) {
    printf("[37;44m");
    movecsr(0,ctl-1);
    printf("%s[0m",sl);
  }
  topline=ctl;
  movecsr(cx,cy);
  curatr=cc;
  tleft(0);
}


#ifdef TWO_WAY

int x1,y1,x2,y2,cp0,cp1;

void two_way_chat(char *s, char *rollover, int maxlen, int crend)
{
  char s2[100], temp1[50], side0[12] [80], side1[12] [80];
  int side, cnt, cnt2, cntr;
  int i,i1,done,cm,begx,chatcolr;
  char s1[255];
  unsigned char ch;


  cm=chatting;
  begx=wherex();
  if (rollover[0]!=0) {
    if (charbufferpointer) {
      strcpy(s1,rollover);
      strcat(s1,&charbuffer[charbufferpointer]);
      strcpy(&charbuffer[1],s1);
      charbufferpointer=1;
    } else {
      strcpy(&charbuffer[1],rollover);
      charbufferpointer=1;
    }
    rollover[0]=0;
  }

  done=0;
  side = 0;
  do {
    ch=getkey();
     if (lastcon)
        {
          if(nifty.chatcolor) { chatcolr=random(10);
              if((chatcolr==8) || (chatcolr==6)) chatcolr++;
              ansic(chatcolr); }
              else ansic(0);
          if (wherey() == 11)
            {
              outstr("\x1b[12;1H");
              ansic(nifty.col[2]);
                for(cnt=0;cnt<=thisuser.screenchars;cnt++)
                    s2[cnt]=196;
              sprintf(temp1,"%d [%dTwoWayChat%d] %d",nifty.col[0],nifty.col[1],nifty.col[0],nifty.col[2]);

              cnt=(((thisuser.screenchars-strlen(temp1)) /2));
              strncpy(&s2[cnt+1],temp1,(strlen(temp1)));
              s2[thisuser.screenchars]=0;
              outstr(s2);
              s2[0]=0;
              temp1[0]=0;
                for(cntr=1;cntr<12;cntr++)
                  {
                    sprintf(s2,"\x1b[%d;%dH",cntr,1);
                    outstr(s2);
                      if ((cntr >=0) && (cntr <5))
                        {
                          ansic(0);
                          outstr(side0[cntr+6]);
                         }
                    outstr("\x1b[K");
                    s2[0]=0;
                  }
              sprintf(s2,"\x1b[%d;%dH",5,1);
              outstr(s2);
              s2[0]=0;
            }
          else
            if (wherey() > 11)
              {
                x2=(wherex()+1);
                y2=(wherey()+1);
                sprintf(s2,"\x1b[%d;%dH",y1,x1);
                outstr(s2);
                s2[0]=0;
              }
          side = 0;
        }
      else
        { if(nifty.chatcolor) {chatcolr=random(10);
              if((chatcolr==8) || (chatcolr==6)) chatcolr++;
              ansic(chatcolr);} else ansic(1);
          if (wherey() >= 23)
            {
              for(cntr=13;cntr<25;cntr++)
                {
                  sprintf(s2,"\x1b[%d;%dH",cntr,1);
                  outstr(s2);
                    if ((cntr >= 13) && (cntr <17))
                      {
                        outstr(side1[cntr-7]);
                      }
                  outstr("\x1b[K");
                  s2[0]=0;
                }
              sprintf(s2,"\x1b[%d;%dH",17,1);
              outstr(s2);
              s2[0]=0;
            }
          else
            if ((wherey() < 12) && (side == 0))
              {
                x1=(wherex()+1);
                y1=(wherey()+1);
                sprintf(s2,"\x1b[%d;%dH",y2,x2);
                outstr(s2);
                s2[0]=0;
              }
          side=1;
        }
    if (cm)
      if (chatting==0)
        ch=13;
    if ((ch>=32)) {
      if (side==0)
       {
         if ((wherex()<(thisuser.screenchars-1)) && (cp0<maxlen))
           {
             if (wherey() < 11)
               {
                 side0[wherey()][cp0++]=ch;
                 outchr(ch);
               }
             else
              {
              side0[wherey()][cp0++]=ch;
              side0[wherey()][cp0]=0;
              for(cntr=0;cntr<12;cntr++)
                {
                  sprintf(s2,"\x1b[%d;%dH",cntr,1);
                  outstr(s2);
                  if ((cntr >=0) && (cntr <6))
                    {
                      ansic(0);
                      outstr(side0[cntr+6]);
                      y1=wherey()+1;
                      x1=wherex()+1;
                    }
                  outstr("\x1b[K");
                  s2[0]=0;
                }
              sprintf(s2,"\x1b[%d;%dH",y1,x1);
              outstr(s2);
              s2[0]=0;
            }
        if (wherex()==(thisuser.screenchars-1))
            done=1;
      } else {
        if (wherex()>=(thisuser.screenchars-1))
            done=1;
      }
      }
      else
       {
         if ((wherex()<(thisuser.screenchars-1)) && (cp1<maxlen) )
           {
              if (wherey() < 23)
                {
                  side1[wherey()-13][cp1++]=ch;
                  outchr(ch);
                }
             else
              {
                side1[wherey()-13][cp1++]=ch;
                side1[wherey()-13][cp1]=0;
                  for(cntr=13;cntr<25;cntr++)
                    {
                      sprintf(s2,"\x1b[%d;%dH",cntr,1);
                      outstr(s2);
                        if ((cntr >=13) && (cntr <18))
                          {
                            ansic(0);
                            outstr(side1[cntr-7]);
                            y2=wherey()+1;
                            x2=wherex()+1;
                          }
                       outstr("\x1b[K");
                       s2[0]=0;
                     }
              sprintf(s2,"\x1b[%d;%dH",y2,x2);
              outstr(s2);
              s2[0]=0;
            }
        if (wherex()==(thisuser.screenchars-1))
            done=1;
      } else {
        if (wherex()>=(thisuser.screenchars-1))
            done=1;
      }
      }
    } else
        switch(ch) {
          case 7:
            if ((chatting) && (outcom))
              outcomch(7);
            break;
          case 13: /* C/R */
              if (side == 0)
                side0[wherey()][cp0]=0;
              else
                side1[wherey()-13][cp1]=0;
            done=1;
            break;
          case 8:  /* Backspace */
            if (side==0)
              {
                if (cp0)
                  {
                    if (side0[wherey()][cp0-2]==3)
                      {
                        cp0-=2;
                        ansic(0);
                      }
                    else
                      if (side0[wherey()][cp0-1]==8)
                        {
                          cp0--;
                          outchr(32);
                        }
                      else
                        {
                          cp0--;
                          backspace();
                        }
                  }
              }
            else
              if (cp1)
                {
                  if (side1[wherey()-13][cp1-2]==3)
                    {
                      cp1-=2;
                      ansic(0);
                    }
                  else
                    if (side1[wherey()-13][cp1-1]==8)
                      {
                        cp1--;
                        outchr(32);
                      }
                    else
                      {
                        cp1--;
                        backspace();
                      }
                }
            break;
          case 24: /* Ctrl-X */
            while (wherex()>begx) {
              backspace();
                if (side==0)
                  cp0=0;
                else
                  cp1=0;
            }
            ansic(0);
            break;
          case 23: /* Ctrl-W */
            if (side==0)
              {
              if (cp0) {
              do {
                if (side0[wherey()][cp0-2]==3) {
                  cp0-=2;
                  ansic(0);
                } else
                  if (side0[wherey()][cp0-1]==8) {
                    cp0--;
                    outchr(32);
                  } else {
                    cp0--;
                    backspace();
                  }
              } while ((cp0) && (side0[wherey()][cp0-1]!=32) &&
                       (side0[wherey()][cp0-1]!=8) &&
                       (side0[wherey()][cp0-2]!=3));
              }
              }
            else
              {
              if (cp1) {
              do {
                if (side1[wherey()-13][cp1-2]==3) {
                  cp1-=2;
                  ansic(0);
                } else
                  if (side1[wherey()-13][cp1-1]==8) {
                    cp1--;
                    outchr(32);
                  } else {
                    cp1--;
                    backspace();
                  }
              } while ((cp1) && (side1[wherey()-13][cp1-1]!=32) &&
                       (side1[wherey()-13][cp1-1]!=8) &&
                       (side1[wherey()-13][cp1-2]));
              }
            }
            break;
          case 14: /* Ctrl-N */
                if (side == 0)
                  {
                    if ((wherex()) && (cp0<maxlen))
                      {
                        outchr(8);
                        side0[wherey()][cp0++]=8;
                      }
                  }
                else
                  if ((wherex()) && (cp1<maxlen))
                    {
                      outchr(8);
                      side1[wherey()-13][cp1++]=8;
                    }
            break;
          case 16: /* Ctrl-P */
            if (side==0)
              {
                if (cp0<maxlen-1)
                  {
                    ch=getkey();
                      if ((ch>='0') && (ch<='7'))
                        {
                          side0[wherey()][cp0++]=3;
                          side0[wherey()][cp0++]=ch;
                          ansic(ch-'0');
                        }
                  }
              }
            else
              {
                if (cp1<maxlen-1)
                  {
                    ch=getkey();
                      if ((ch>='0') && (ch<='7'))
                        {
                          side1[wherey()-13][cp1++]=3;
                          side1[wherey()-13][cp1++]=ch;
                          ansic(ch-'0');
                        }
                  }
              }
            break;
          case 9:  /* Tab */
            if (side==0)
              {
                i=5-(cp0 % 5);
                  if (((cp0+i)<maxlen) && ((wherex()+i)<thisuser.screenchars))
                    {
                      i=5-((wherex()+1) % 5);
                        for (i1=0; i1<i; i1++)
                          {
                            side0[wherey()][cp0++]=32;
                            outchr(32);
                          }
                    }
              }
            else
              {
                i=5-(cp1 % 5);
                  if (((cp1+i)<maxlen) && ((wherex()+i)<thisuser.screenchars))
                    {
                      i=5-((wherex()+1) % 5);
                        for (i1=0; i1<i; i1++)
                          {
                            side1[wherey()-13][cp1++]=32;
                            outchr(32);
                          }
                    }
              }
            break;
        }
  } while ((done==0) && (hangup==0));

  if (ch!=13)
  {
    if (side==0)
      {
        i=cp0-1;
          while ((i>0) && (side0[wherey()][i]!=32) &&
                 (side0[wherey()][i]!=8) || (side0[wherey()][i-1]==3))
            i--;
              if ((i>(wherex()/2)) && (i!=(cp0-1)))
                {
                  i1=cp0-i-1;
                    for (i=0; i<i1; i++)
                      outchr(8);
                    for (i=0; i<i1; i++)
                      outchr(32);
                    for (i=0; i<i1; i++)
                      rollover[i]=side0[wherey()][cp0-i1+i];
                  rollover[i1]=0;
                  cp0 -= i1;
                }
          side0[wherey()][cp0]=0;
      }
  else
      {
        i=cp1-1;
          while ((i>0) && (side1[wherey()-13][i]!=32) &&
                 (side1[wherey()-13][i]!=8) || (side1[wherey()-13][i-1]==3))
            i--;
              if ((i>(wherex()/2)) && (i!=(cp1-1)))
                {
                  i1=cp1-i-1;
                    for (i=0; i<i1; i++)
                      outchr(8);
                    for (i=0; i<i1; i++)
                      outchr(32);
                    for (i=0; i<i1; i++)
                      rollover[i]=side1[wherey()-13][cp1-i1+i];
                  rollover[i1]=0;
                  cp1 -= i1;
                }
          side1[wherey()-13][cp1]=0;
      }
  }
  if ((crend) && (wherey() != 11) && (wherey()<23))
    nl();
  if (side == 0)
    cp0=0;
  else
    cp1=0;
 s[0]=0;
}

#endif



void chat1(char *chatline, int two_way)
{

  int tempdata, cnt;
  char cl[81],xl[81],s[161],s1[161],atr[81],s2[81],cc;
  int i,i1,cf,oe;
  double tc;

  chatcall=0;
    chatting=1;
  chatreason[0]=0;
  tc=timer();
  cf=0;

  savel(cl,atr,xl,&cc);
  s1[0]=0;

  oe=echo;
  echo=1;
  nl();
  nl();
  tempdata=topdata;
  if (!okansi())
    two_way=0;
  if (modem_speed==300)
    two_way=0;

#ifndef TWO_WAY
  two_way=0;
#endif

  if (syscfg.sysconfig & sysconfig_two_color)
    two_color=1;
#ifdef TWO_WAY
  if (two_way) {
    clrscrb();
    cp0=0;
    cp1=1;
    if (defscreenbottom==24) {
      topdata=0;
      topscreen();
    }
    outstr("\x1b[2J");
    x2=1;
    y2=13;
    outstr("\x1b[1;1H");
    x1=wherex();
    y1=wherey();
    outstr("\x1b[12;1H");
    ansic(nifty.col[2]);
    for(cnt=0;cnt<thisuser.screenchars;cnt++)
      outchr(196);
   sprintf(s,"%d [%dTwoWayChat%d] %d",nifty.col[0],nifty.col[1],nifty.col[0],nifty.col[2]);

    cnt=((thisuser.screenchars-strlen(s))/2);
    sprintf(s1,"\x1b[12;%dH",cnt);
    outstr(s1);
    outstr(s);
    outstr("\x1b[1;1H");
    s[0]=0;
    s1[0]=0;
    s2[0]=0;
  }
#endif
  pl(get_string(6));
  nl();
  nl();
  strcpy(s1,chatline);
  readfilter("sysop.flt","user.flt");
  do {
#ifdef TWO_WAY
    if (two_way)
      two_way_chat(s,s1,160,1);
    else
#endif
      inli(s,s1,160,1);
      if(s[0]=='/')
        {
            switch(toupper(s[1]))
              {
                case 'Q': chatting=0; break;
                case 'S': if(thisuser.sl>=100)
                          prt(5,"Sure? "); if(yn())  shrink_out(getenv("COMSPEC"),1,1,1,0);
                          break;
                case 'P': pl("7Paging...");
                          for(s[0]=1;s[0]<5;s[0]++) {
                          sound(1000); delay(100); sound(1200);
                          delay(100); sound(1400); delay(100);
                          outchr(7);
                          }
                          nosound();
                          break;
                case 'B': prt(5,"Sure? "); if(yn()) hangup=1; break;
                case '�': if (realsl!=255) {
                          if (thisuser.sl!=255)
              thisuser.sl=255;
            else
              thisuser.sl=realsl;
            i=realsl;
            changedsl();
            realsl=i;
            tleft(0);
          }
          break;
                case '?':
                     pl("/Q>uit Chat");
                     if(thisuser.sl>=100) pl("/S>hell to Dos");
                     pl("/P>age");
                     pl("/B>ye Bye...");
                     pl("/V>iew a File");
                     break;
                case 'V':
                    pl("View What file?");
                    mpl(51);
                    input(s,51);
                    viewfile(s);
                    break;
              }
       }

    if ((nifty.nifstatus & nif_autochat) || (chat_file) && (!two_way)) {
      if (cf==0) {
        if (!two_way)
          outs("-] Chat file opened.\r\n");
        sprintf(s2,"%sCHAT.log",syscfg.gfilesdir);
        cf=open(s2,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
        lseek(cf,0L,SEEK_END);
        sprintf(s2,"\r\n\r\nChat file opened %s %s\r\n",date(),times());
        write(cf,(void *)s2,strlen(s2));
        strcpy(s2,"���������������������������������\r\n\r\n");
        write(cf,(void *)s2,strlen(s2));
      }
      strcat(s,"\r\n");
      write(cf,(void *)s,strlen(s));
    } else
      if (cf) {
        close(cf);
        cf=0;
        if (!two_way)
          outs("�] Chat file closed.\r\n");
      }
    if (hangup)
      chatting=0;
  } while (chatting);
  if (chat_file) {
    close(cf);
    chat_file=0;
  }
  ansic(0);
  two_color=0;


  if (two_way)
    outstr("\x1b[2J");

  nl();
  pl(get_string(7));
  nl();
  chatting=0;
  tc=timer()-tc;
  if (tc<0)
    tc += 86400.0;
  extratimecall += tc;
  topdata=tempdata;
  if (useron)
    topscreen();
  echo=oe;
  restorel(cl,atr,xl,&cc);
}


void set_autoval(int n)
{
  valrec v;

  v=syscfg.autoval[n];

  thisuser.sl=v.sl;
  thisuser.dsl=v.dsl;
  thisuser.ar=v.ar;
  thisuser.dar=v.dar;
  thisuser.restrict=v.restrict;
  changedsl();
}

