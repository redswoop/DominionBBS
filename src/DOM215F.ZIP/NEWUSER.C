#include "fcns.h"
#include <string.h>
#include <stdlib.h>
#include <io.h>
#include <fcntl.h>
#include "nifrec.h"

extern userrec thisuser;
extern niftyrec nifty;
extern configrec syscfg;
extern int hangup;
extern char ctypes[NUM_CTYPES][18];
extern unsigned char realsl;
extern statusrec status;
extern int usernum,userfile,incom,echo,screenlinest,reply;
extern char irt[81],curspeed[80],byline[81];


#include "\dom\inputpl3.c"
#include "\dom\inputpl.c"
int check_name(char *nn)
{
  int ok,f,i;
  char s[161],s1[161],s2[81];
  long p,l;

  ok=1;
  if (nn[strlen(nn)-1]==32)
    ok=0;
  if (nn[0]<65)
    ok=0;
  if (finduser(nn)!=0)
    ok=0;
  if (strchr(nn,'@')!=NULL)
    ok=0;
  if (strchr(nn,'#')!=NULL)
    ok=0;

  if (!ok)
    return(ok);

  sprintf(s,"%sTRASHCAN.TXT",syscfg.gfilesdir);
  f=open(s,O_RDWR | O_BINARY);

  if (f<0)
    return(ok);

  lseek(f,0L,SEEK_SET);
  l=filelength(f);
  p=0;
  sprintf(s2," %s ",nn);
  while ((p<l) && (ok)) {
    lseek(f,p,SEEK_SET);
    read(f,(void *)s,150);
    i=0;
    while ((i<150) && (s[i])) {
      if (s[i]==13)
	s[i]=0;
      else
	++i;
    }
    s[150]=0;
    p += (long) (i+2);
    if (s[i-1]==1)
      s[i-1]=0;
    for (i=0; i<strlen(s); i++)
      s[i]=upcase(s[i]);
    sprintf(s1," %s ",s);
    if (strstr(s2,s1)!=NULL)
      ok=0;
  }
  close(f);
  if (!ok)
    hangup=1;

  return(ok);
}

void input_name()
{
  int ok,count;
  char s[41];

  count=0;
  do {
    nl();
    if (syscfg.sysconfig & sysconfig_no_alias)
      pl("Enter your full REAL name.");
    else
      pl("Enter your full name, or your alias.");
    outstr(":");
    input(thisuser.name,30);
    ok=check_name(thisuser.name);
    if (!ok) {
      nl();
      pl("I'm sorry, you can't use that name.");
      ++count;
      if (count==3)
        hangup=1;
    }
  } while ((!ok) && (!hangup));
}

void input_realname()
{
  do {
    nl();
      pl("Enter your real name, or = if same as real name.");
    outstr(":");
    inputpl3(thisuser.realname,20);

    if (thisuser.realname[0]==0) {
      nl();
      pl("Sorry, you must enter your real name.");
    }

    if (thisuser.realname[0]=='=') strcpy(thisuser.realname,thisuser.name);
  } while ((thisuser.realname[0]==0) && (!hangup));
}

void input_city()
{
  char s[10],s1[43];
  nl();
  thisuser.street[0]=0;
  thisuser.citystate[0]=0;
  do
   {
  pl("Enter your Street Address.");
  outstr(":");
  inputpl3(thisuser.street,81);
  }while((thisuser.street[0]==0) && (!hangup));

  nl();

  do
   {
  pl("Enter your City/Township Name");
  outstr(":");
  inputpl(s1,41);
  pl("Now enter your State");
  prompt(":","");
  input(s,2);
  sprintf(thisuser.citystate,"%s, %s",s1,s);
  }while((thisuser.citystate[0]==0) && (!hangup));
  nl();
}

void input_phone()
{
  int ok,i;
  thisuser.phone[0]=0;
  do {
    nl();
    pl("Enter your VOICE phone no. in the form:");
    pl(" ###-###-####");
    outstr(":");
    inputl(thisuser.phone,12);

    ok=1;
    if ((syscfg.sysconfig & sysconfig_free_phone)==0) {
      if (strlen(thisuser.phone)!=12)
        ok=0;
      if ((thisuser.phone[3]!='-') || (thisuser.phone[7]!='-'))
        ok=0;
      if ((thisuser.phone[1]!='0') && (thisuser.phone[1]!='1'))
        ok=0;
      for (i=0; i<12; i++)
        if ((i!=3) && (i!=7))
          if ((thisuser.phone[i]<'0') || (thisuser.phone[i]>'9'))
            ok=0;
    }

    if (!ok) {
      nl();
      pl("Please enter a valid phone number");
      pl("in the correct format.");
    }
  } while ((!ok) && (!hangup));
}

void input_sex()
{
  nl();
  outstr("Sex <M>ale,<F>emale,<Y>es,<L>ots:");
  thisuser.sex=onek("MFYL");
}

/* void input_age(userrec *u)
{
  int a,ok,ok1,y,m,d;
  char ag[10],s[20],s1[5];

  do {
    nl();
    ok1=0;
    do
      {
     outstr("Enter your birthdate (mm/dd/yy): ");
     input(s,10);
     s1[0]=s[0];
     s1[1]=s[1];
     m=atoi(s1);
     if((m>12) || (m<1)); else ok1=1;
     s1[0]=s[3];
     s1[1]=s[4];
     d=atoi(s1);
     if((d>31) || (d<1)); else ok1=1;
     s1[0]=s[6];
     s1[1]=s[7];
      y=atoi(s1);
      y+=1900;
    if((y>2000) || (y<1900)); else ok1=1;
    } while((!ok1) && (!hangup));

   ok=1;
    if (((m==2) || (m==9) || (m==4) || (m==6) || (m==11)) && (d==31))
      ok=0;
    if ((m==2) && (y%4!=0) && (d==30))
      ok=0;
    if (!ok) {
      nl();
      pl("There aren't that many days in that month.");
    }

  } while ((!ok) && (!hangup));
  u->month=(unsigned char) m;
  u->day=(unsigned char) d;
  u->year=(unsigned char) (y-1900);
  u->age=years_old(u->month,u->day,u->year);
  nl();
}*/

void input_age(userrec *u)
{
  int a,ok,y,m,d;
  char ag[10];

  do {
    nl();
    do {
      nl();
      outstr("Month you were born (1-12) : ");
      input(ag,2);
      m=atoi(ag);
    } while ((!hangup) && ((m>12) || (m<1)));
    do {
      nl();
      outstr("Day of month you were born (1-31) : ");
      input(ag,2);
      d=atoi(ag);
    } while ((!hangup) && ((d>31) || (d<1)));
    do {
      nl();
      outstr("Year you were born :19");
      input(ag,2);
      y=atoi(ag);
      y=y+1900;
    } while ((!hangup) && ((y>2000) || (y<1900)));
    ok=1;
    if (((m==2) || (m==9) || (m==4) || (m==6) || (m==11)) && (d==31))
      ok=0;
    if ((m==2) && (y%4!=0) && (d==30))
      ok=0;
    if (!ok) {
      nl();
      pl("There aren't that many days in that month.");
    }
  } while ((!ok) && (!hangup));
  u->month=(unsigned char) m;
  u->day=(unsigned char) d;
  u->year=(unsigned char) (y-1900);
  u->age=years_old(u->month,u->day,u->year);
  nl();
}


void input_comptype()
{
  int i,ok,ct;
  char c[5];

  do {
   nl();
   nl();
   for (i=0; i<NUM_CTYPES; i++)
     print(itoa(i+1,c,10),". ",ctypes[i],"");
   nl();
   pl("Enter your computer type");
   outstr(":");
   input(c,2);
   ct=atoi(c);

   ok=1;
   if ((ct<1) || (ct>NUM_CTYPES))
     ok=0;

  } while ((!ok) && (!hangup));
  thisuser.comp_type=ct-1;
  if (checkcomp("Ami"))
    thisuser.colors[0]=4;
  if (hangup)
    thisuser.comp_type=0;
}

void input_screensize()
{
  int ok,x,y;
  char s[5];

  do {
    nl();
    pl("How wide is your screen (chars, <CR>=80) ?");
    outstr(":");
    input(s,2);
    x=atoi(s);
    if (s[0]==0)
      x=80;

    if ((x<32) || (x>80))
      ok=0;
    else
      ok=1;
  } while ((!ok) && (!hangup));

  do {
    nl();
    pl("How tall is your screen (lines, <CR>=25) ?");
    outstr(":");
    input(s,2);
    y=atoi(s);
    if (s[0]==0)
      y=25;

    if ((y<4) || (y>60))
      ok=0;
    else
      ok=1;
  } while ((!ok) && (!hangup));

  thisuser.screenchars=x;
  thisuser.screenlines=y;
  screenlinest=y;
}

void input_pw()
{
  int ok;
  char s[81];

  do {
    nl();
    pl("Please enter a password, 3-20 chars.");
    outstr(":");
    input(s,20);

    ok=1;
    if (strlen(s)<3)
      ok=0;
  } while ((!ok) && (!hangup));
  if (ok)
    strcpy(thisuser.pw,s);
  else
    pl("Password not changed.");
}


void input_ansistat()
{
  int i,c,c2;
  char ch;

  nl();
  outstr("\x1b[0;34;3mTEST\x1b[C");
  outstr("\x1b[0;30;45mTEST\x1b[C");
  outstr("\x1b[0;1;31;44mTEST\x1b[C");
  outstr("\x1b[0;32;7mTEST\x1b[C");
  outstr("\x1b[0;1;5;33;46mTEST\x1b[C");
  pl("\x1b[0;4mTEST\x1b[0m");
  thisuser.sysstatus &= ~(sysstatus_ansi | sysstatus_color);
  pl("Is the above line colored, italicized,");
  outstr("bold, inversed, or blinking? ");
  if (yn())
    {
  thisuser.colors[0]=15;
  thisuser.colors[1]=7;
  thisuser.colors[2]=13;
  thisuser.colors[3]=11;
  thisuser.colors[4]=14;
  thisuser.colors[5]=9;
  thisuser.colors[6]=31;
  thisuser.colors[7]=12;
  thisuser.colors[8]=140;
  thisuser.colors[9]=10;
  thisuser.colors[10]=15;
  thisuser.colors[11]=8;
  thisuser.colors[12]=5;
  thisuser.colors[13]=3;
  thisuser.colors[14]=6;
  thisuser.colors[15]=1;
  thisuser.colors[16]=141;
  thisuser.colors[17]=4;
  thisuser.colors[18]=142;
  thisuser.colors[19]=2;

  thisuser.bwcolors[0]=7;
  thisuser.bwcolors[1]=15;
  thisuser.bwcolors[2]=15;
  thisuser.bwcolors[3]=15;
  thisuser.bwcolors[4]=7;
  thisuser.bwcolors[5]=15;
  thisuser.bwcolors[6]=112;
  thisuser.bwcolors[7]=7;
  thisuser.bwcolors[8]=143;
  thisuser.bwcolors[9]=112;
  thisuser.bwcolors[10]=7;
  thisuser.bwcolors[11]=15;
  thisuser.bwcolors[12]=15;
  thisuser.bwcolors[13]=15;
  thisuser.bwcolors[14]=7;
  thisuser.bwcolors[15]=15;
  thisuser.bwcolors[16]=112;
  thisuser.bwcolors[17]=7;
  thisuser.bwcolors[18]=143;
  thisuser.bwcolors[19]=112;



    thisuser.sysstatus |= sysstatus_ansi;
    nl();
    outstr("Do you want color? ");
    if (yn())
      thisuser.sysstatus |= sysstatus_color;
    else {
      color_list();
      nl();
      outstr("Monochrome base color? ");
      ch=onek("1234567");
      c=ch-'0';
      c2=c << 4;
      for (i=0; i<8; i++) {
       if ((thisuser.bwcolors[i] & 0x70) == 0)
	 thisuser.bwcolors[i]=(thisuser.bwcolors[i] & 0x88) | c;
       else
	 thisuser.bwcolors[i]=(thisuser.bwcolors[i] & 0x88) | c2;
      }
    }
   }
}


void newuser()
{
  int i,ok;
  char s[255],s1[81],ch;
  userrec u;
  long l1,l2;

  sprintf(s,"*** NEW USER %s   %s    %s",date(),times(),curspeed);
  sl1(0,"");
  sl1(0,s);
  if (status.users>=syscfg.maxusers) {
    nl();
    nl();
    pl("I'm sorry, but the system currently has");
    pl("the maximum number of users it can");
    pl("handle.");
    nl();
    hangup=1;
  }
  if (syscfg.closedsystem) {
    nl();
    nl();
    pl("I'm sorry, but the system is currently");
    pl("closed, and not accepting new users.");
    nl();
    hangup=1;
  }
  if ((syscfg.newuserpw[0]!=0) && (incom)) {
    nl();
    nl();
    ok=0;
    i=0;
    do {
      outstr("New User Password :");
      input(s,20);
      if (strcmp(s,syscfg.newuserpw)==0)
        ok=1;
      else {
        sprintf(s1,"Wrong newuser password: %s",s);
        sl1(0,s1);
      }
    } while ((!ok) && (!hangup) && (i++<4));
    if (!ok)
      hangup=1;
  }

  strcpy(thisuser.firston,date());
  strcpy(thisuser.laston,"Never.");
  strcpy(&thisuser.macros[0][0],"This is the Ctrl-D Macro");
  strcpy(&thisuser.macros[1][0],"This is the Ctrl-F Macro");
  strcpy(&thisuser.macros[2][0],"Whatever");
  strcpy(thisuser.note,"");
  strcpy(thisuser.pw,"NONE");

  thisuser.screenlines=25;
  screenlinest=25;

  thisuser.inact=0;
  thisuser.defprot=0;
  thisuser.defed=0;
  thisuser.sl=syscfg.newusersl;
  thisuser.dsl=syscfg.newuserdsl;
  thisuser.exempt=0;
  for (i=0; i<20; i++)
    thisuser.votes[i]=0;
  for (i=0; i<20; i++)
    thisuser.colors[i]=0x07;
  thisuser.illegal=0;
  thisuser.waiting=0;
  thisuser.sysopsub=255;
  thisuser.ontoday=1;
  thisuser.month=0;
  thisuser.day=0;
  thisuser.year=0;
  thisuser.age=0;

  thisuser.homeuser=0;
  thisuser.homesys=0;
  thisuser.forwardusr=0;
  thisuser.forwardsys=0;
  thisuser.msgpost=0;
  thisuser.emailsent=0;
  thisuser.feedbacksent=0;
  thisuser.posttoday=0;
  thisuser.etoday=0;
  thisuser.ar=0;
  thisuser.dar=0;
  thisuser.restrict=syscfg.newuser_restrict;
  thisuser.ass_pts=0;
  thisuser.uploaded=0;
  thisuser.downloaded=0;
  thisuser.lastrate=0;
  thisuser.logons=0;
  thisuser.msgread=0;
  thisuser.uk=0;
  thisuser.dk=0;
  thisuser.qscn=0xFFFFFFFF;
  for (i=0; i<33; i++)
    thisuser.qscnptr[i]=0;
  thisuser.nscn1=0xFFFFFFFF;
  thisuser.nscn2=0xFFFFFFFF;
  thisuser.daten=0;
  thisuser.sysstatus=sysstatus_pause_on_page | sysstatus_nscan_file_system;
  thisuser.sysstatus=nifty.sysstatus;

  thisuser.timeontoday=0.0;
  thisuser.extratime=0.0;
  thisuser.timeon=0.0;
  thisuser.pos_account=0.0;
  thisuser.neg_account=0.0;
  thisuser.credits=syscfg.newusergold;
  thisuser.filepoint=syscfg.newusergold;
  thisuser.emailnet=0;
  thisuser.postnet=0;
  thisuser.fsenttoday1=0;
  thisuser.num_extended=0;
  thisuser.optional_val=0;


  for (i=0; i<33; i++)
  thisuser.res[i]=0;

  
  realsl=thisuser.sl;

  if (!hangup) {
    if (incom) {
      if (printfile("SYSTEM.MSG"))
	sl1(0,"#Aborted SYSTEM.MSG");
      if (printfile("NEWUSER.MSG"))
	sl1(0,"#Aborted NEWUSER.MSG");
    }
    input_name();
    if(!strcmp("MIRIYA STERLING",thisuser.name)) {
    nl();
    outchr(':');
    input(s,22);
    if(!strcmp("SOUNDS LIKE A MELODY",s))
        thisuser.res[5]=1;
   }
    input_realname();
    input_screensize();
    input_ansistat();
    input_phone();
    input_city();
    input_sex();
    input_age(&thisuser);
    input_comptype();
    ex("OP","3","");
    ex("OP","A","");
    thisuser.res[0]=0;
    input_pw();
  }

  if (!hangup)
    do {
      nl();
      nl();
      outchr(12);
      print("017>1 Name            3",thisuser.name,"");
      print("027>1 Real Name       3",thisuser.realname,"");
         pl("037>1 Change Address  3");
      print("047>1 Phone No.       3",thisuser.phone,"");
      s[0]=thisuser.sex;
      s[1]=0;
      print("057>1 Gender          3",s,"");
      sprintf(s,"%02d/%02d/%02d",(int) thisuser.month,
			      (int) thisuser.day,
			      (int) thisuser.year);
      print("067>1 Birthdate       3",s,"");
      print("077>1 Computer type   3",ctypes[thisuser.comp_type],"");
      print("087>1 Screen size     3",itoa(thisuser.screenchars,s,10)," X ",itoa(thisuser.screenlines,s1,10),"");
      print("097>1 Password        3",thisuser.pw,"");
         pl("0Q7>1 No changes.  ");
      nl();
      nl();
      prt(2,"Which (1-9,Q) : ");
      ch=onek("Q123456789");
      ok=0;
      switch(ch) {
        case 'Q': ok=1; break;
        case '1': input_name(); break;
        case '2': input_realname(); break;
        case '3': input_city(); break;
        case '4': input_phone(); break;
        case '5': input_sex(); break;
        case '6': input_age(&thisuser); break;
        case '7': input_comptype(); break;
        case '8': input_screensize(); break;
        case '9': input_pw(); break;
      }
    } while ((!ok) && (!hangup));

  if (!hangup) {

    nl();
    pl("Please wait...");
    nl();
    read_user(0,&u);
    l1=(filelength(userfile)) / ((long) sizeof(userrec))-1;
    if (l1==(long) status.users) {
      usernum=status.users+1;
    } else {
      usernum=1;
      do {
        read_user(usernum,&u);
        if ((u.inact & inact_deleted)==0)
          ++usernum;
      } while (((u.inact & inact_deleted)==0) && ((long)usernum<=l1));
    }
    write_user(usernum,&thisuser);
    close_user();
    isr(usernum,thisuser.name);
    ok=0;
    topscreen();
      nl();
      print("Your user number is ",itoa(usernum,s,10),".","");
      print("Your password is '",thisuser.pw,"'.","");
      nl();
      pausescr();
    sprintf(s,"Newuser %s at %s",thisuser.name,times());
    ssm(1,0,s);
    changedsl();
    if (incom) {
    ex("OG","newuser","");
      if (printfile("FEEDBACK.MSG"))
    sl1(0,"#Aborted FEEDBACK.MSG!!");
	  byline[0]=0;
      reply=1;
      sprintf(irt,"Validation Feedback (%d slots left)",syscfg.maxusers-status.users);
      email(1,0,1,0);
    }
    if (syscfg.newuser_c[0]) ex("D1",syscfg.newuser_c,"");
  }
}

