#include "fcns.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <io.h>
#include <fcntl.h>
#include <sys\stat.h>
#include <time.h>


extern int hangup,useron,wfc;
extern configrec syscfg;
extern statusrec status;
extern char cdir[81];
extern userrec thisuser;
extern int numextrn;
extern externalrec *externs;
extern unsigned char realsl;



void protdata(int n, char *s)
{
  externalrec r;

  r=externs[n];
  sprintf(s,"3%-2d 3%-3d 3%-3d  3%-59s",n,r.ok1,r.nok1,r.description);
}

void showprots()
{
  int abort,i;
  char s[180];

  outchr(12);
  abort=0;
  pla("0NN2�0OK2��0NK2��0Description2���������������������������������������������������������",&abort);
  for (i=0; (i<numextrn) && (!abort); i++) {
    protdata(i,s);
    pla(s,&abort);
  }
}



void modify_prot(int n)
{
  externalrec r;
  char s[81],s1[81],ch,ch2,*ss;
  int i,i1,done;

  done=0;
  r=externs[n];
  do {
    outchr(12);
    pl("1. Descrition : ");
    pl(r.description);
    pl("2. Receive Command");
    pl(r.receivefn);
    pl("3. Send Command");
    pl(r.sendfn);
    sprintf(s,"4. Ok Errorlevel     %-3d",r.ok1); pl(s);
    sprintf(s,"5. Not Ok Errorlevel %-3d",r.nok1); pl(s);
    nl();
    pl("%1 = Com port and Baud Rate");
    pl("%2 = Com Port");
    pl("%3 = File Name");
    pl("%4 = Port Speed");
    nl();
    prt(2,"Which (1-5,Q,J,[,]) ? ");
    ch=onek("Q1234J0A[]");
    switch(ch) {
      case 'Q':done=1; break;
      case ']': if((n>=0) && (n<numextrn-1))  { externs[n++]=r; r=externs[n];}break;
      case '[': if(n>0){ externs[n--]=r; r=externs[n];} break;
      case 'J': nl(); prt(4,"Jump to which dir? ");
                input(s,4); if(s[0]){
		i=atoi(s);
		externs[n]=r;
		r=externs[i];}
		break;
      case '1': nl(); pl("New Description? ");
                      mpl(79); inputl(s,79);
                      if(s[0]) strcpy(r.description,s); break;
      case '2': nl(); pl("New Receive Command Line? ");
                      mpl(79); inputl(s,79);
                      if(s[0]) strcpy(r.receivefn,s); break;
      case '3': nl(); pl("New Send Command Line? ");
                      mpl(79); inputl(s,79);
                      if(s[0]) strcpy(r.sendfn,s); break;
      case '4': nl(); pl("New Ok Error Level");
                      input(s,3); if(s[0]) r.ok1=atoi(s); break;
      case '5': nl(); pl("New Not Ok Error Level");
                      input(s,3); if(s[0]) r.nok1=atoi(s); break;
    }
  } while ((!done) && (!hangup));
  externs[n]=r;
  if (!wfc)
    changedsl();
}


void insert_prot(int n)
{
  externalrec r;
  int i,i1,nu;
  long l1,l2,l3;

  for (i=numextrn-1; i>=n; i--)
    externs[i+1]=externs[i];
    numextrn++;

  strcpy(r.description,"** New Protocol **");
  strcpy(r.receivefn,"");
  strcpy(r.sendfn,"");
  r.ok1=0;
  r.nok1=-1;
  externs[n]=r;
  modify_prot(n);
}


void delete_prot(int n)
{
  int i;

  for (i=n; i<numextrn; i++)
    externs[i]=externs[i+1];
  --numextrn;
}


void protedit()
{
  int i,i1,i2,done,f;
  char s[81],s1[81],s2[81],ch;

  if (!checkpw())
    return;
  showprots();
  done=0;
  do {
    nl();
    outstr("5[3D5]0elete 5[3I5]0nsert 5[3M5]0odify 5[3Q5]0uit: ");
    ch=onek("QDIM?");
    switch(ch) {
      case '?':
        showprots();
        break;
      case 'Q':
        done=1;
        break;
      case 'M':
        nl();
        prt(2,"Prot number? ");
        input(s,2);
        i=atoi(s);
        if ((s[0]!=0) && (i>=0) && (i<numextrn))
          modify_prot(i);
        break;
      case 'I':
        if (numextrn<64) {
          nl();
          prt(2,"Insert before which prot? ");
          input(s,2);
          i=atoi(s);
          if ((s[0]!=0) && (i>=0) && (i<=numextrn))
            insert_prot(i);
        }
        break;
      case 'D':
        nl();
        prt(2,"Delete which prot? ");
        input(s,2);
        i=atoi(s);
        if ((s[0]!=0) && (i>=0) && (i<numextrn)) {
          nl();
          sprintf(s1,"Delete %s? ",externs[i].description);
          prt(5,s1);
          if (yn())
            delete_prot(i);
        }
        break;
    }
  } while ((!done) && (!hangup));
  sprintf(s,"%sextern.DAT",syscfg.datadir);
  f=open(s,O_RDWR | O_BINARY | O_CREAT | O_TRUNC, S_IREAD | S_IWRITE);
  write(f,(void *)&externs[0], numextrn * sizeof(externalrec));
  close(f);
}



