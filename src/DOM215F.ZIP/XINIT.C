#include <stdlib.h>
#include <sys\stat.h>
#include <dos.h>
#include <io.h>
#include <fcntl.h>
#include <string.h>
#include <stdio.h>
#include <alloc.h>
#include <dir.h>
#include <math.h>
#include <time.h>
#include "vardec.h"
#include "fcns.h"
#include "nifrec.h"

extern int outcom,incom,dlf,okskey,input_extern,chat_file,two_color;
extern int charbufferpointer,screenlinest,restoring_shrink;
extern int hangup,hungup,using_modem;
extern int checkit,in_extern,live_user;
extern unsigned char andwith;
//extern protocolrec proto[20];
extern int topline,okmacro;
extern int curatr,num_sec;
extern int ansiptr,high_speed;
extern int oldx,oldy,change_color,change_ecolor,use_workspace,oklevel,noklevel;
extern char endofline[81],cdir[81],crttype;
extern char far *scrn;
extern statusrec status;
extern configrec syscfg;
extern userrec thisuser;
extern int topdata,chatcall,sysop_alert,global_handle;
extern char chatreason[81];
extern int usernum;
extern double timeon,extratimecall;
extern int userfile,configfile,statusfile,niftyfile;
extern int useron,wfc,echo,lecho;
extern subboardrec subboards[32];
extern directoryrec directories[64];
extern usersubrec usub[32],udir[64];
extern int num_subs,num_dirs,chatting,okskey,lines_listed,num_prot;
extern char dc[81],dcd[81];
extern smalrec *smallist;
extern char curspeed[80];
extern int curlsub,curldir,fwaiting,mailcheck,smwcheck;
extern char irt[81];
extern postrec *msgs;
extern messagerec menus[30];
extern externalrec *externs;
extern niftyrec nifty;
extern int numextrn,screenlen;
extern int checkext[10];
extern int checked[50];
extern unsigned char agemin,agemax,slmin,slmax,dslmin,dslmax,ressex;
extern int daysmin,daysmax,numed,screenbottom,defscreenbottom,flow_control;
extern unsigned short arres,darres,resres;
extern editorrec *editors,*backuped;
extern char gatfn[81],ver_no[21],ver_no1[51];
extern char *xenviron[50],newprompt[161],dszlog[81];
extern int questused[20];
extern double last_time,time_event;
extern int do_event,num_ncn,ok_modem_stuff,num_result_codes;
extern net_contact_rec *ncn;
extern screentype screensave;
extern unsigned char realsl,actsl;
extern void far *funcs[25];
extern resultrec *result_codes;
extern int ok_abort;
extern char *quote;                                          /* mod - add V3 */
extern int bquote,equote;                                    /* mod - add V3 */

void far interrupt inlii();
void far interrupt checkai();
void far interrupt plai();
void far interrupt outchri();
void far interrupt outstri();
void far interrupt nli();
void far interrupt pli();
void far interrupt emptyi();
void far interrupt inkeyi();
void far interrupt getkeyi();
void far interrupt inputi();
void far interrupt inputli();
void far interrupt yni();
void far interrupt nyi();
void far interrupt ansici();
void far interrupt oneki();
void far interrupt prti();
void far interrupt mpli();

void init(int x)
{
  char s[161],*buf,ch,*ss;
  int i,i1,i2,sm,cp,n,f;
  long l;
  union REGS r;
  struct date today;
  votingrec v;


  crttype=peekb(0x0040,0x0049);
  if (crttype==7)
    scrn=MK_FP(0xb000,0x0000);
  else
    scrn=MK_FP(0xb800,0x0000);
  r.h.ah=15;
  int86(0x10,&r,&r);
  sm=r.h.al;
  if (r.h.ah!=80) {
    printf("\n\nYou must be in 80 column mode to run the BBS.\n\n");
    end_bbs(noklevel);
  }
  if ((sm==4) || (sm==5) || (sm==6)) {
    printf("\n\nYou must be in text mode to run the BBS.\n\n");
    end_bbs(noklevel);
  }
  defscreenbottom=(int) peekb(0x0000,0x0484);
  if (defscreenbottom<24)
    defscreenbottom=24;
  if (defscreenbottom>63)
    defscreenbottom=24;
  if ((defscreenbottom!=42) && (defscreenbottom!=49))
    defscreenbottom=24;
  screenbottom=defscreenbottom;
  screenlen=160*(screenbottom+1);
  if (!exist("restore.wwv")) {
    for (i=0; i<screenbottom; i++)
      printf("\n");
    strcpy(s,VERSION_NUMBER);
    printf(s);
    printf("\nLoading System Config....");
  }
  strcpy(cdir,"X:\\");
  cdir[0]='A'+getdisk();
  getcurdir(0,&(cdir[3]));
  userfile=-1;
  configfile=-1;
  statusfile=-1;
  niftyfile=-1;
  dlf=-1;
  curlsub=-1;
  curldir=-1;
  setvect(0x68,getvect(0x10));
  setvect(0x69,getvect(0x21));
  oldx=0;
  oldy=0;
  itimer();
  r.h.ah=0x33;
  r.h.al=0x01;
  r.h.dl=0x00;
  int86(0x21,&r,&r);
  agemin=0;
  agemax=255;
  slmin=0;
  slmax=255;
  dslmin=0;
  dslmax=255;
  ressex=0;
  daysmin=0;
  daysmax=9999;
  arres=0;
  darres=0;
  resres=0;
  use_workspace=0;
  input_extern=0;
  chat_file=0;
  do_event=0;
  sysop_alert=0;
  ncn=NULL;
  num_ncn=0;
  global_handle=0;
  quote=NULL;                                              /* mod - add V3 */
  bquote=0;                                                /* mod - add V3 */
  equote=0;                                                /* mod - add V3 */


  if (x) {
    for (i=0; i<25; i++)
      funcs[i]=NULL;
    funcs[0]=(void far *)inlii;
    funcs[1]=(void far *)checkai;
    funcs[2]=(void far *)plai;
    funcs[3]=(void far *)outchri;
    funcs[4]=(void far *)outstri;
    funcs[5]=(void far *)nli;
    funcs[8]=(void far *)pli;
    funcs[9]=(void far *)emptyi;
    funcs[10]=(void far *)inkeyi;
    funcs[11]=(void far *)getkeyi;
    funcs[12]=(void far *)inputi;
    funcs[13]=(void far *)inputli;
    funcs[14]=(void far *)yni;
    funcs[15]=(void far *)nyi;
    funcs[16]=(void far *)ansici;
    funcs[17]=(void far *)oneki;
    funcs[18]=(void far *)prti;
    funcs[19]=(void far *)mpli;
    setvect(0x6a,(void far interrupt (*) (void))funcs);


    strcpy(ver_no,VERSION_NUMBER);
    strcpy(ver_no1,"BBS=");
    strcat(ver_no1,ver_no);

    getdate(&today);
    if (today.da_year<1991) {
      printf("You need to set the date & time before running the BBS.\n");
      end_bbs(noklevel);
    }
    strcpy(s,"CONFIG.DAT");
    configfile=open(s,O_RDWR | O_BINARY);
    _setcursortype(0);
    if (!exist("restore.wwv"))
    printf("[1;1HReading %s",s);
    if (configfile<0) {
      printf("%s NOT FOUND.\n",s);
      end_bbs(noklevel);
    }
    read(configfile,(void *) (&syscfg), sizeof(configrec));
    close(configfile);

    if (!syscfg.primaryport)
      ok_modem_stuff=0;

    strcpy(s,syscfg.tempdir);
    i=strlen(s);
    if (s[0]==0)
      i1=1;
    else {
      if ((s[i-1]=='\\') && (s[i-2]!=':'))
        s[i-1]=0;
      i1=chdir(s);
    }
    if (i1) {
      printf("\nYour temporary directory isn't valid.\n");
      printf("It is now set to: '%s'\n\n",syscfg.tempdir);
      end_bbs(noklevel);
    } else
      cd_to(cdir);

    sprintf(s,"%sSTATUS.DAT",syscfg.datadir);
    if (!exist("restore.wwv"))printf("[1;1HReading %s         ",s);
    statusfile=open(s,O_RDWR | O_BINARY);
    if (statusfile<0) {
      printf("%s NOT FOUND.\n",s);
      end_bbs(noklevel);
    }
    read(statusfile,(void *)(&status), sizeof(statusrec));

    
    strcpy(s,VERSION_NUMBER);
    status.bbs_version=(s[6]-'0')*100+(s[8]-'0')*10+(s[9]-'0');
    smallist=(smalrec *) mallocx((long)syscfg.maxusers * (long)sizeof(smalrec));

    screensave.scrn1=(char *)mallocx(screenlen);

    read_in_file("MENUS.MSG",(menus),30);


    sprintf(s,"%sNAMES.LST             ",syscfg.datadir);
    if (!exist("restore.wwv"))printf("[1;1HReading %s",s);
    i=open(s,O_RDWR | O_BINARY);
    if (i<0) {
      printf("%s NOT FOUND.\n",s);
      end_bbs(noklevel);
    }
    read(i,(void *) (smallist), (sizeof(smalrec) * status.users));
    close(i);

    sprintf(s,"%sSUBS.DAT         ",syscfg.datadir);
    if (!exist("restore.wwv"))printf("[1;1HReading %s",s);
    i=open(s,O_RDWR | O_BINARY);
    if (i<0) {
      printf("%s NOT FOUND.\n",s);
      end_bbs(noklevel);
    }
    num_subs=(read(i,(void *) (&subboards), (32*sizeof(subboardrec))))/
             sizeof(subboardrec);
    close(i);


    sprintf(s,"%sDIRS.DAT",syscfg.datadir);
    if (!exist("restore.wwv"))printf("[1;1HReading %s",s);
    i=open(s,O_RDWR | O_BINARY);
    if (i<0) {
      printf("%s NOT FOUND.\n",s);
      end_bbs(noklevel);
    }
    num_dirs=(read(i,(void *) (&directories), (64*sizeof(directoryrec))))/
             sizeof(directoryrec);
    close(i);

    backuped=editors;
    numextrn=0;
    numed=0;
    sprintf(s,"%sRESULTS.DAT",syscfg.datadir);
if (!exist("restore.wwv"))    printf("[1;1HReading %s",s);
    i=open(s,O_RDWR | O_BINARY);
    if (i>0) {
      l=filelength(i);
      if (l>40*sizeof(resultrec))
        l=40*sizeof(resultrec);
      result_codes=mallocx(l+10);
      num_result_codes=(read(i,result_codes,(unsigned) l))/sizeof(resultrec);
      close(i);
    } else {
      printf("\nRun INIT.EXE to convert result code data.\n\n");
      end_bbs(noklevel);
    }

    sprintf(s,"%sEXTERN.DAT         ",syscfg.datadir);
if (!exist("restore.wwv"))printf("[1;1HReading %s",s);
    i=open(s,O_RDWR | O_BINARY);
    if (i>0) {
      l=filelength(i);
      if (l>15*sizeof(externalrec))
        l=15*sizeof(externalrec);
      externs=mallocx(l+10);
      numextrn=(read(i,(void *)externs, (unsigned) l))/sizeof(externalrec);
      close(i);
    }
    for (i=0; i<numextrn; i++) {
      checkext[i]=0;
      for (i1=0; i1<81; i1++) {
        checkext[i]+=externs[i].description[i1];
        checkext[i]+=externs[i].sendfn[i1];
        checkext[i]+=externs[i].receivefn[i1];
      }
    }

sprintf(s,"%sNSTATUS.DAT",syscfg.datadir);
    if (!exist("restore.wwv"))printf("[1;1HReading %s         ",s);
    niftyfile=open(s,O_RDWR | O_BINARY);
    if (niftyfile<0) {
      printf("%s NOT FOUND.\n",s);
      end_bbs(noklevel);
    }
    read(niftyfile,(void *)(&nifty), sizeof(niftyrec));
    close(niftyfile);

    sprintf(s,"%sEDITORS.DAT         ",syscfg.datadir);
if (!exist("restore.wwv"))printf("[1;1HReading %s",s);
    i=open(s,O_RDWR | O_BINARY);
    if (i>0) {
      l=filelength(i);
      if (l>10*sizeof(editorrec))
        l=10*sizeof(editorrec);
      editors=mallocx(l+10);
      numed=(read(i,(void *)editors, (unsigned) l))/sizeof(editorrec);
      numed=numed;
      close(i);
    }
    for (i=0; i<numed; i++) {
      checked[i]=0;
      for (i1=0; i1<81; i1++) {
        checked[i]+=editors[i].filename[i1];
	checked[i]+=editors[i].filenamecon[i1];
      }
    }
//    batch=mallocx(MAX_BATCH * sizeof(batchrec));

    read_user(1,&thisuser);
    if (thisuser.inact & inact_deleted)
      fwaiting=0;
    else
      fwaiting=thisuser.waiting;
    sl1(2,status.date1);
    if (ok_modem_stuff)
      initport(syscfg.primaryport);
    if (syscfg.sysconfig & sysconfig_no_local)
      topdata=0;
    else
      topdata=2;
    ss=getenv("PROMPT");
    strcpy(newprompt,"PROMPT=BBS: ");
    if (ss)
      strcat(newprompt,ss);
    else
      strcat(newprompt,"$P$G");
    sprintf(dszlog,"%s\\WWIVDSZ.LOG",cdir);
    sprintf(s,"DSZLOG=%s",dszlog);
    i=0;
    while (environ[i]!=NULL) {
      if (strncmp(environ[i],"PROMPT=",7)==0)
	xenviron[i]=newprompt;
      else
        if (strncmp(environ[i],"DSZLOG=",7)==0)
          xenviron[i]=strdup(s);
        else
          xenviron[i]=environ[i];
      ++i;
    }
    if (!getenv("DSZLOG"))
      xenviron[i++]=strdup(s);
    if (!ss)
      xenviron[i++]=newprompt;
    xenviron[i++]=ver_no1;
    xenviron[i]=NULL;
    for (i=0; i<20; i++)
      questused[i]=0;
    sprintf(s,"%sVOTING.DAT         ",syscfg.datadir);
if (!exist("restore.wwv"))    printf("[1;1HReading %s",s);
    f=open(s,O_RDWR | O_BINARY);
    if (f>0) {
      n=(int) (filelength(f) / sizeof(votingrec)) -1;
      for (i=0; i<n; i++) {
        lseek(f,(long) i * sizeof(votingrec),SEEK_SET);
        read(f,(void *)&v,sizeof(votingrec));
        if (v.numanswers)
	  questused[i]=1;
      }
      close(f);
    }
if (!exist("restore.wwv"))
     {
         clrscrb();
         printf("[1;1H[33;1mAll Files Read         ");
         printf("[2;1HEntering [36mWaiting For Caller Mode");
     }
    if(exist("restore.wwv")) readmenu(nifty.firstmenu);
    _setcursortype(2);
    if (syscfg.sysconfig & sysconfig_high_speed)
      high_speed=1;
    else
      high_speed=0;
    if (syscfg.sysconfig & sysconfig_flow_control)
      flow_control=1;
    else
      flow_control=0;
    time_event=((double)syscfg.executetime)*60.0;
    last_time=time_event-timer();
    if (last_time<0.0)
      last_time+=24.0*3600.0;
    do_event=0;
    if (status.callernum!=65535) {
      status.callernum1=(long)status.callernum;
      status.callernum=65535;
      save_status();
    }
    msgs=(postrec *) mallocx((long)(255 * sizeof(postrec)));
    read_bbs_list_index();
    frequent_init();
    if (!restoring_shrink)
      remove_from_temp("*.*",1);
    read_contacts();
    if (!restoring_shrink)
      cleanup_net();
  } else {
    topdata=0;
    ansiptr=0;
    curatr=0x07;
    outcom=0;
    incom=0;
    charbufferpointer=0;
    andwith=0xff;
    checkit=0;
    topline=0;
    endofline[0]=0;
    hangup=0;
    hungup=0;
    chatcall=0;
    chatreason[0]=0;
    useron=0;
    change_color=0;
    change_ecolor=0;
    chatting=0;
    echo=1;
    lines_listed=0;
    using_modem=0;
    thisuser.sysstatus=0;
  }
  lecho=ok_local();
  clrscrb();
}
