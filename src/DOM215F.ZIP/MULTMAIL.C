#include "fcns.h"
#include <fcntl.h>
#include <io.h>
#include <sys\stat.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <dos.h>
#include <alloc.h>
#include <stdio.h>
#include <dir.h>

extern subboardrec subboards[32];
extern usersubrec usub[32];
extern int cursub,express,expressabort,num_sys_list,screenlinest;
extern int curlsub,nummsgs;
extern postrec *msgs;
extern configrec syscfg;
extern int bchanged;
extern userrec thisuser;
extern int hangup,incom;
extern int usernum,using_modem,topline,defscreenbottom;
extern statusrec status;
extern char irt[81],cdir[81],net_email_name[81];
extern int fwaiting,fsenttoday,msgreadlogon,useron,wfc,mailcheck,numed;
extern editorrec *editors,*backuped;
extern short gat[2048];
extern char gatfn[81],byline[81];
extern int use_workspace;
extern int checked[50];


#define ALLOW_FULLSCREEN 1
#define EMAIL_STORAGE 2


void multimail(int *un, int numu)
{
  int i,i1,f,len,an,cv,ok;
  mailrec m,m1;
  char s[81],s1[81],t[81];
  userrec ur;
  slrec ss;

  if (freek1(syscfg.msgsdir)<10.0) {
    nl();
    pl("Sorry, not enough disk space left.");
    nl();
    return;
  }
  nl();
  sprintf(s,"%sEMAIL.DAT",syscfg.datadir);
  ss=syscfg.sl[thisuser.sl];

  if (ss.ability & ability_email_anony)
    i=anony_enable_anony;
  else
    i=0;
  m.msg.storage_type=EMAIL_STORAGE;
  strcpy(irt,"Multi-Mail");
  byline[0]=0;
  inmsg(&m.msg,t,&i,1,"EMAIL",ALLOW_FULLSCREEN);
  if (m.msg.stored_as==0xffffffff)
    return;
  strcpy(m.title,t);
  m.anony=i;
  m.fromsys=0;
  m.fromuser=usernum;
  m.tosys=0;
  m.touser=0;
  m.status=status_multimail;
  time((long *)&(m.daten));
  f=open(s,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
  len=(int) filelength(f)/sizeof(mailrec);
  if (len==0)
    i=0;
  else {
    i=len-1;
    lseek(f,((long) (i))*(sizeof(mailrec)), SEEK_SET);
    read(f,(void *)&m1,sizeof(mailrec));
    while ((i>0) && (m1.tosys==0) && (m1.touser==0)) {
      --i;
      lseek(f,((long) (i))*(sizeof(mailrec)), SEEK_SET);
      i1=read(f,(void *)&m1,sizeof(mailrec));
      if (i1==-1)
        pl("DIDN'T READ RIGHT.");
    }
    if ((m1.tosys) || (m1.touser))
      ++i;
  }
  lseek(f,((long) (i))*(sizeof(mailrec)), SEEK_SET);
  pl("Mail sent to:");
  sysoplog("Multi-Mail to:");

  for (cv=0; cv<numu; cv++) {
    read_user(un[cv],&ur);
    ok=1;
    if (((ur.sl==255) && (ur.waiting>(syscfg.maxwaiting * 5))) ||
        ((ur.sl!=255) && (ur.waiting>syscfg.maxwaiting)) ||
        (ur.waiting>200)) {
      strcpy(s,nam(&ur,un[cv]));
      strcat(s,"  mailbox full, not sent.");
      pl(s);
      ok=0;
    }
    if (ur.inact & inact_deleted) {
      sprintf(s,"User #%d deleted, not sent.",un[cv]);
      pl(s);
      ok=0;
    }

    if (ok) {
      m.touser=un[cv];
      write(f,(void *)&m,sizeof(mailrec));
      strcpy(s,"   ");
      ++ur.waiting;
      write_user(un[cv],&ur);
      if (un[cv]==1)
        ++fwaiting;
      strcat(s,nam(&ur,un[cv]));
      if (un[cv]==1)  {
        ++status.fbacktoday;
        ++thisuser.feedbacksent;
	++thisuser.fsenttoday1;
	++fsenttoday;
      } else {
        ++status.emailtoday;
        ++thisuser.etoday;
        ++thisuser.emailsent;
      }
      sysoplog(s);
      pl(s);
    }
  }
  close_user();
  close(f);
  save_status();
  if (!wfc)
    topscreen();
}


char *mml_s;
int mml_started;


int oneuser()
{
  char s[81],*ss;
  unsigned short un,sn,i;
  userrec u;

  if (mml_s) {
    if (mml_started)
      ss=strtok(NULL,"\r\n");
    else
      ss=strtok(mml_s,"\r\n");
    mml_started=1;
    if (ss==NULL) {
      farfree(mml_s);
      mml_s=NULL;
      return(-1);
    }
    strcpy(s,ss);
    for (i=0; s[i]!=0; i++)
      s[i]=upcase(s[i]);
  } else {
    prt(2,">");
    input(s,40);
  }
  un=finduser(s);
  if (un==65535)
    return(-1);
  if (s[0]==0)
    return(-1);
  if (un==0) {
    nl();
    pl("Unknown user.");
    nl();
    return(0);
  }
  sn=0;
  if (forwardm(&un,&sn)) {
    nl();
    pl("Forwarded.");
    nl();
    if (sn) {
      pl("Forwarded to another system.");
      pl("Can't send multi-mail to another system.");
      nl();
      return(0);
    }
  }
  if (un==0) {
    nl();
    pl("Unknown user.");
    nl();
    return(0);
  }
  read_user(un,&u);
  if (((u.sl==255) && (u.waiting>(syscfg.maxwaiting * 5))) ||
      ((u.sl!=255) && (u.waiting>syscfg.maxwaiting)) ||
      (u.waiting>200)) {
    nl();
    pl("Mailbox full.");
    nl();
    return(0);
  }
  if (u.inact & inact_deleted) {
    nl();
    pl("Deleted user.");
    nl();
    return(0);
  }
  sprintf(s,"     -> %s",nam(&u,un));
  pl(s);
  return(un);
}


void add_list(int *un, int *numu, int maxu, int allowdup)
{
  int i,i1,i2,done, mml;

  done=0;
  mml=(mml_s!=NULL);
  mml_started=0;
  while ((!done) && (!hangup) && (*numu<maxu)) {
    i=oneuser();
    if (mml && (!mml_s))
      done=1;
    if (i==-1)
      done=1;
    else
      if (i) {
        if (!allowdup)
          for (i1=0; i1<*numu; i1++)
            if (un[i1]==i) {
              nl();
              pl("Already in list, not added.");
              nl();
              i=0;
            }
        if (i)
          un[(*numu)++]=i;
      }
  }
  if (*numu==maxu) {
    nl();
    pl("List full.");
    nl();
  }
}


#define MAX_LIST 40


void slash_e()
{
  int un[MAX_LIST],numu,done,i,i1,f1;
  char s[81],s1[81],ch,*sss;
  slrec ss;
  userrec u;
  struct ffblk ff;

  mml_s=NULL;
  mml_started=0;
  ss=syscfg.sl[thisuser.sl];
  if (freek1(syscfg.msgsdir)<10.0) {
    nl();
    pl("Sorry, not enough disk space left.");
    nl();
    return;
  }
  if (((fsenttoday>=5) || (thisuser.fsenttoday1>=10) ||
    (thisuser.etoday>=ss.emails)) && (!cs())) {
    pl("Too much mail sent today.");
    return;
  }
  if (restrict_email & thisuser.restrict) {
    pl("You can't send mail.");
    return;
  }
  done=0;
  numu=0;
  do {
    nl();
    nl();
    prt(2,"Multi-Mail: A,M,D,L,E,Q,? : ");
    ch=onek("QAMDEL?");
    switch(ch) {
      case '?':
        printmenu(12);
        break;
      case 'Q':
        done=1;
        break;
      case 'A':
        nl();
        pl("Enter names/numbers for users, one per line, max 20.");
        nl();
        mml_s=NULL;
        add_list(un,&numu,MAX_LIST,so());
        break;
      case 'M':
        sprintf(s,"%s*.mml",syscfg.datadir);
        f1=findfirst(s,&ff,0);
        if (f1) {
          nl();
          pl("No mailing lists available.");
          nl();
          break;
        }
        nl();
        pl("Available mailing lists:");
        nl();
        while (f1==0) {
          strcpy(s,ff.ff_name);
          sss=strchr(s,'.');
          if (sss)
            *sss=0;
          pl(s);

          f1=findnext(&ff);
        }

        nl();
        prt(2,"Which? ");
        input(s,8);

        sprintf(s1,"%s%s.mml",syscfg.datadir,s);
        i=open(s1,O_RDONLY | O_BINARY);
        if (i<0) {
          nl();
          pl("Unknown mailing list.");
          nl();
        } else {
          i1=filelength(i);
          mml_s=malloca(i1+10L);
          read(i,mml_s,i1);
          mml_s[i1]='\n';
          mml_s[i1+1]=0;
          close(i);
          mml_started=0;
          add_list(un,&numu,MAX_LIST,so());
          if (mml_s) {
            farfree(mml_s);
            mml_s=NULL;
          }
        }
        break;
      case 'E':
        if (!numu) {
          nl();
          pl("Need to specify some users first - use A or M");
          nl();
        } else {
          multimail(un,numu);
          done=1;
        }
        break;
      case 'D':
        if (numu) {
          nl();
          prt(2,"Delete which? ");
          input(s,2);
          i=atoi(s);
          if ((i>0) && (i<=numu)) {
            --numu;
            for (i1=i-1; i1<numu; i1++)
              un[i1]=un[i1+1];
          }
        }
        break;
      case 'L':
        for (i=0; i<numu; i++) {
          read_user(un[i],&u);
          itoa(i+1,s,10);
          strcat(s,". ");
          strcat(s,nam(&u,un[i]));
          pl(s);
        }
        break;
    }
  } while ((!done) && (!hangup));
}


