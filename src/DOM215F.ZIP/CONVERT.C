/*  CONVERT USERLIST PROGRAM */

/*  Written by The Black Dragon, 1989 */
/*  (C) 1989 Black Dragon Enterprises */
/*  Compiled and tested using Borland Turbo C - Version 1.5 */
/*  License granted to freely distribute without compensation and to */
/*  modify as needed "to get the job done."  Use at your own risk.  */
/*  Distributed "as is".  No warranty or guarentee */

/*  Command Parameters:  */
/*  CONVERT  <old user filename>  <new user filename>  */

/* This file was modified by Lord Elric, 1@8251, 9/24/89, 5:17am
after yet another all-night BBS modding session. Many thanks to Black Dragon,
1@2380, for writing this conversion program. With little modifications here
and there, this can be used to add or delete almost anything from the user
record.

Lord Elric 1@8251 WWIVNet*/

/* This file was modified AGAIN by Dr. Discord, 1@8873, 2/23/90, 12:53am
for use in the Extra Colors Mod by MetalStorm Productions.  Make sure to
make a backup of your USER.LST file before running this program!

Dr. Discord, LDD 1@8873 WWIVnet*/

#include <stdio.h>
#include <string.h>
#include <mem.h>
#include <io.h>
#include <fcntl.h>
#include <sys\stat.h>
#include "oldrec.h"        /* put your old userlist here and */
#include "vardec.h"		/* rename it from userrec to olduserrec */

void main(int argc, char *argv[])
{
  int f,g,i;
  unsigned int loop,num=0;
  unsigned long len;
  userrec new;
  olduserrec old;

  if (argc<3) {
    printf("\nRequires 2 parameters.\n");
    abort();
  }
  if ((f=open(argv[1],O_RDWR|O_BINARY,S_IREAD|S_IWRITE))<=0) {
    printf("\nCould not open user list %s\n",argv[1]);
    abort();
  }
  if ((g=open(argv[2],O_RDWR|O_BINARY|O_CREAT|O_TRUNC,S_IREAD|S_IWRITE))<=0) {
    printf("\nCould not open output file %s\n",argv[2]);
    abort();
  }
  len=filelength(f);
  num=(len/sizeof(olduserrec))+!(len%sizeof(olduserrec));
  for (loop=0;loop<num;loop++) {
    printf("\015Processing user #%u of %u",loop,num);
    read(f,&old,sizeof(olduserrec));

    memset(&new,0,sizeof(userrec));	/* Nice to clear out garbage */
    strcpy(new.name,old.name);		/* Now copy all data over    */
    strcpy(new.realname,old.realname);
    strcpy(new.pw,old.pw);
    strcpy(new.laston,old.laston);
    strcpy(new.firston,old.firston);
    strcpy(new.note,old.note);
/******************************************/
/*  strcpy(new.street,old.street);        */
/*  strcpy(new.citystate,old.citystate);  */
/*  strcpy(new.zip,old.zip);              */
/******************************************/
/*  Unmark if using the FROM modification */
/******************************************/
    for (i=0;i<3;i++)
      strcpy(new.macros[i],old.macros[i]);
    new.sex=old.sex;
    new.month=old.month;
    new.day=old.day;
    new.year=old.year;
    new.age=old.age;
    new.sl=old.sl;
    new.dsl=old.dsl;
    new.inact=old.inact;
    new.exempt=old.exempt;
    new.sysopsub=old.sysopsub;
    new.comp_type=old.comp_type;
    new.screenchars=old.screenchars;
    new.screenlines=old.screenlines;
    for (i=0;i<20;i++) {
      new.colors[i]=old.colors[i];
    }
    new.colors[8]=11;
    new.colors[9]=79;
    for (i=0;i<8;i++) {
      new.bwcolors[i]=old.bwcolors[i];
    }
    new.bwcolors[8]=15;
    new.bwcolors[9]=112;
    for (i=0;i<20;i++)
      new.votes[i]=old.votes[i];
    new.illegal=old.illegal;
    new.ontoday=old.ontoday;
    new.defed=old.defed;
    new.defprot=old.defprot;
    new.num_extended=old.num_extended;
    new.waiting=old.waiting;
    new.fsenttoday1=old.fsenttoday1;
    new.homeuser=old.homeuser;
    new.homesys=old.homesys;
    new.forwardusr=old.forwardusr;
    new.forwardsys=old.forwardsys;
    new.msgpost=old.msgpost;
    new.emailsent=old.emailsent;
    new.feedbacksent=old.feedbacksent;
    new.posttoday=old.posttoday;
    new.etoday=old.etoday;
    new.emailnet=old.emailnet;
    new.postnet=old.postnet;
    new.ar=old.ar;
    new.dar=old.dar;
    new.restrict=old.restrict;
    new.ass_pts=old.ass_pts;
    new.uploaded=old.uploaded;
    new.downloaded=old.downloaded;
    new.lastrate=old.lastrate;
    new.logons=old.logons;
    strcpy(new.phone,old.phone);
    new.msgread=old.msgread;
    new.uk=old.uk;
    new.dk=old.dk;
    new.daten=old.daten;
    new.sysstatus=old.sysstatus;
    new.qscn=old.qscn;			/* copies existing n-scan ptrs */
    new.nscn1=old.nscn1;
    new.nscn2=old.nscn2;
    for(i=0;i<33;i++)
      new.qscnptr[i]=old.qscnptr[i];
    new.timeontoday=old.timeontoday;
    new.extratime=old.extratime;
    new.timeon=old.timeon;
    new.filepoint=old.filepoint;
    new.credits=old.credits;
    new.pos_account=old.pos_account;
    new.neg_account=old.neg_account;
    new.timebank=0;
    strcpy(new.citystate,old.citystate);

    write(g,&new,sizeof(userrec));	/* User record converted here */
  }
  close(f);
  close(g);
}
