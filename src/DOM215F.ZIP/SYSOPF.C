
#include "fcns.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <io.h>
#include <fcntl.h>
#include <sys\stat.h>
#include <time.h>


extern subboardrec subboards[32];
extern directoryrec directories[64];
extern int num_subs, num_dirs,hangup,userfile,echo,useron,wfc,userfile,usernum;
extern int incom,fwaiting;
extern configrec syscfg;
extern statusrec status;
extern char ctypes[NUM_CTYPES][18];
extern char cdir[81];
extern userrec thisuser;
extern int numextrn;
extern screentype screensave;
extern externalrec *externs;
extern unsigned char agemin,agemax,slmin,slmax,dslmin,dslmax,ressex;
extern int daysmin,daysmax,lecho;
extern unsigned short arres,darres,resres;
extern int questused[20];
extern unsigned char realsl;
extern char chatreason[81];
extern int topdata;

extern int num_sec,hangup,userfile,echo,useron,userfile,usernum,using_modem;
extern int incom,fwaiting,userfile;
extern configrec syscfg;
extern statusrec status;
extern char ctypes[NUM_CTYPES][18];
extern char cdir[81];
extern userrec thisuser;
extern int numextrn;
extern externalrec *externs;
extern smalrec *smallist;
extern int num_call_sys,num_ncn,num_sys_list,global_xx;
extern net_contact_rec *ncn;
extern net_call_out_rec *con;
extern net_interconnect_rec *cnn;
extern messagerec menus[30];
extern long last_time_c;
extern unsigned char realsl;
extern net_system_list_rec *csn;

void isr1(int un, char *name)
{
  int cp,i;
  char s[81];
  smalrec sr;

  cp=0;
  while ((cp<status.users) && (strcmp(name,(smallist[cp].name))>0))
    ++cp;
  memmove(&(smallist[cp+1]),&(smallist[cp]),sizeof(smalrec)*(status.users-cp));
  strcpy(sr.name,name);
  sr.number=un;
  smallist[cp]=sr;
  ++status.users;
}



void reset_files()
{
  int i,i1;
  userrec u;
  char s[81];

  outstr("Are You Sure? "); if(!yn()) return;
  status.users=0;

  read_user(1,&u);
  i1=filelength(userfile)/sizeof(userrec)-1;
  for (i=1; i<=i1; i++) {
    read_user(i,&u);
    if ((u.inact & inact_deleted)==0)
      isr1(i,u.name);
    if ((i % 10)==0) {
      itoa(i,s,10);
      pl(s);
    }
  }

  pl("Reseting Name List");
  sprintf(s,"%sNAMES.LST",syscfg.datadir);
  i=open(s,O_RDWR | O_BINARY | O_TRUNC);
  if (i<0) {
    printf("%s NOT FOUND.\n",s);
    abort();
  }
  write(i,(void *) (smallist), (sizeof(smalrec) * status.users));
  close(i);

  pl("Reseting User Sayings");
  sprintf(s,"%ssayings.dat",syscfg.datadir);
  remove(s);

  save_status();
  close_user();
}


void get_status()
{
  char s[81];
  int statusfile;

  sprintf(s,"%sSTATUS.DAT",syscfg.datadir);
  statusfile=open(s,O_RDWR | O_BINARY);
  if (statusfile>=0) {
    read(statusfile,(void *)(&status), sizeof(statusrec));
    close(statusfile);
  } else
    save_status();
}




void prstatus()
{
  char s[81],s1[10];
  int i;
  long l;

  outchr(12);
  print("7[0New User Pass   7]1 ",syscfg.newuserpw,"");
  if (syscfg.closedsystem)
    pl("7[0Board is        7]1 Closed");
  else
    pl("7[0Board is        7]1 Open");
  itoa(status.users,s,10);
  print("7[0Number Users    7]1 ",s,"");
  ltoa(status.callernum1,s,10);
  print("7[0Number Calls    7]1 ",s,"");
  print("7[0Last Date       7]1 ",status.date1,"");
  print("7[0Time            7]1 ",times(),"");
  itoa(status.activetoday,s,10);
  print("7[0Active Today    7]1 ",s,"");
  itoa(status.callstoday,s,10);
  print("7[0Calls Today     7]1 ",s,"");
  itoa(status.msgposttoday,s,10);
  print("7[0M Posted Today  7]1 ",s,"");
  itoa(status.emailtoday,s,10);
  print("7[0E Sent Today    7]1 ",s,"");
  itoa(status.fbacktoday,s,10);
  print("7[0F Sent Today    7]1 ",s,"");
  itoa(status.uptoday,s,10);
  print("7[0Uploads Today   7]1 ",s,"");
  itoa(fwaiting,s,10);
  print("7[0Feedback Waiting7]1 ",s,"");
  i=3;
  l=(long) freek(3);
  while ((l>0) && ((i+'@')<=cdir[0])){
    ltoa(l,s,10);
    s1[1]=0;
    s1[0]='@'+(char) i;
    print("7[0",s1,": Free Space   7]1 ",s,"k","");
    l=(long) freek(++i);
  }
  if (sysop2())
    pl("7[0Sysop           7]1 Available");
  else
    pl("7[0Sysop           7]1 NOT Available");
}

void valuser(int un)
{
  userrec u;
  char s[81],s1[81],s2[81],s3[81],ar1[20],dar1[20],ch1;
  int i,i1,ar2,dar2;

  read_user(un,&u);
  if ((u.inact & inact_deleted)==0) {
    nl();
    print("Name: ",nam(&u,un),"");
    print("RN  : ",u.realname,"");
    print("PH  : ",u.phone,"");
    itoa(u.age,s,10);
    s1[0]=32;
    s1[1]=u.sex;
    s1[2]=0;
    print("Age : ",s,s1,"");
    print("Comp: ",&(ctypes[u.comp_type][0]),"");
    if (u.note[0])
      print("Note: ",(u.note),"");
    nl();
    itoa(u.sl,s,10);
    print("SL  : ",s,"");
    if ((u.sl!=255) && (u.sl<thisuser.sl)) {
      outstr("New ? ");
      input(s,3);
      if (s[0]) {
        i=atoi(s);
        if ((!wfc) && (i>=thisuser.sl))
          i=-2;
        if ((i>=0) && (i<255))
          u.sl=i;
	if (i==-1) {
	  nl();
	  prt(5,"Delete? ");
	  if (yn()) {
            deluser(un);
	    nl();
	    pl("Deleted.");
	    nl();
	  } else {
	    nl();
	    pl("NOT deleted.");
	  }
	  return;
	}
      }
    }
    nl();
    itoa(u.dsl,s,10);
    print("DSL : ",s,"");
    if ((u.dsl!=255) && (u.dsl<thisuser.dsl)) {
      outstr("New ? ");
      input(s,3);
      if (s[0]) {
        i=atoi(s);
        if ((!wfc) && (i>=thisuser.dsl))
          i=-1;
        if ((i>=0) && (i<255))
          u.dsl=i;
      }
    }
    strcpy(s3,restrict_string);
    ar2=1;
    dar2=1;
    ar1[0]=13;
    dar1[0]=13;
    for (i=0; i<=15; i++) {
      if (u.ar & (1 << i))
        s[i]='A'+i;
      else
        s[i]=32;
      if (thisuser.ar & (1 << i))
        ar1[ar2++]='A'+i;
      if (u.dar & (1 << i))
        s1[i]='A'+i;
      else
        s1[i]=32;
      if (thisuser.dar & (1 << i))
        dar1[dar2++]='A'+i;
      if (u.restrict & (1 << i))
        s2[i]=s3[i];
      else
        s2[i]=32;
    }
    s[16]=0;
    s1[16]=0;
    s2[16]=0;
    ar1[ar2]=0;
    dar1[dar2]=0;
    nl();
    ch1=0;
    if (ar2>1)
      do {
        print("AR  : ",s,"");
        prt(2,"Togl? ");
        ch1=onek(ar1);
        if (ch1!=13) {
          ch1-='A';
          if (s[ch1]==32)
            s[ch1]=ch1+'A';
          else
            s[ch1]=32;
          u.ar ^= (1 << ch1);
          ch1=0;
        }
      } while ((!hangup) && (ch1!=13));
    nl();
    ch1=0;
    if (dar2>1)
      do {
        print("DAR : ",s1,"");
        prt(2,"Togl? ");
        ch1=onek(dar1);
        if (ch1!=13) {
          ch1-='A';
          if (s1[ch1]==32)
            s1[ch1]=ch1+'A';
          else
            s1[ch1]=32;
          u.dar ^= (1 << ch1);
          ch1=0;
        }
      } while ((!hangup) && (ch1!=13));
    nl();
    ch1=0;
    s[0]=13;
    s[1]='?';
    strcpy(&(s[2]),restrict_string);
    do {
      print("      ",s3,"");
      print("Rstr: ",s2,"");
      prt(2,"Togl? ");
      ch1=onek(s);
      if ((ch1!=13) && (ch1!=32) && (ch1!='?')) {
        i=-1;
        for (i1=0; i1<16; i1++)
          if (ch1==s[i1+2])
            i=i1;
        if (i>-1) {
          u.restrict ^= (1 << i);
          if (s2[i]==32)
            s2[i]=s3[i];
          else
            s2[i]=32;
        }
        ch1=0;
      }
      if (ch1=='?') {
        ch1=0;
        printmenu(10);
      }
    } while ((!hangup) && (ch1==0));
    write_user(un,&u);
    close_user();
    nl();
  } else {
    nl();
    pl("No Such User.");
    nl();
  }
}


void print_net_listing()
{
  int i,i1,i2,abort,f;
  char s[161],ch;
  net_system_list_rec csne;

  abort=0;
  nl();
  pla("  Num  Phone         Name                                     Hop  Next",&abort);
  pla("-----  ============  ---------------------------------------- === -----",&abort);
  sprintf(s,"%sBBSDATA.NET",syscfg.datadir);
  f=open(s,O_RDONLY | O_BINARY);
  for (i=0; (i<num_sys_list) && (!abort); i++) {
    read(f,&csne,sizeof(net_system_list_rec));
    if (csne.forsys!=65535) {
      if (csne.other & other_net_coord)
        ch='&';
      else if (csne.other & other_group_coord)
        ch='%';
      else if (csne.other & other_coordinator)
        ch='^';
      else
        ch=' ';
      sprintf(s,"%5d%c %12s  %-40s %3d %5d",
        csne.sysnum,ch,csne.phone,csne.name,csne.numhops,
        csne.forsys);
      pla(s,&abort);
    }
  }
  close(f);
}


void read_new_stuff()
{
  int i;
  char s[81];

  if (ncn!=NULL)
    farfree(ncn);
  if (cnn!=NULL)
    farfree(cnn);
  if (csn!=NULL)
    farfree(csn);
  if (con!=NULL)
    farfree(con);
  ncn=NULL;
  cnn=NULL;
  csn=NULL;
  con=NULL;
  read_in_file("MENUS.MSG",(menus),30);

  if (csn!=NULL)
    farfree(csn);
  if (cnn!=NULL)
    farfree(cnn);
  if (con!=NULL)
    farfree(con);
  read_bbs_list_index();
  read_contacts();
}


void mailr()
{
  int i,abort,a,f,next;
  mailrec m;
  char c,s[81];
  userrec u;

  sprintf(s,"%sEMAIL.DAT",syscfg.datadir);
  f=open(s,O_BINARY | O_RDWR);
  if (f!=-1) {
    i=filelength(f)/sizeof(mailrec)-1;
    c=' ';
    while ((i>=0) && (c!='Q') && (!hangup)) {
      lseek(f,((long) (i)) * ((long) sizeof(mailrec)),SEEK_SET);
      read(f,(void *)&m,sizeof(mailrec));
      if (m.touser!=0) {
        do {
          if (m.tosys!=0) {
	    outstr("To   : System #");
	    itoa(m.tosys,s,10);
	    pl(s);
	  } else {
	    read_user(m.touser,&u);
        print("7[0To       7]1 ",nam(&u,m.touser),"");
	  }
          print("7[0Title    7]1 ",m.title,"");
          setorigin(m.fromsys);
          read_message1(&(m.msg),m.anony & 0x0f,1,&next,"EMAIL");
          outstr("0R2>1eRead,0D2>1elete,0Q2>1uit,0W2>1Reply,Space for next: ");
          if (next)
	    c=' ';
	  else
        c=onek("QRDW ");
          if (c=='W') {
            prompt("Reply? ","");
            if(yn()) {
                read_user(0,&u);
                email(m.fromuser,0,0,0); }
            }
          if (c=='D') {
            delmail(f,i);
	    if ((!useron) && (m.touser==1) && (m.tosys==0))
	      --thisuser.waiting;
          }
          nl();
	  nl();
        } while ((c=='R') && (!hangup));
      }
      i-=1;
    }
    close(f);
    close_user();
  }
}


void chuser()
{
  char s[81];
  int i;

  if (!checkpw())
    return;
  if (!so())
    return;
  prt(2,"User to change to? ");
  input(s,30);
  i=finduser1(s);
  if (i>0) {
    thisuser.sl=realsl;
    write_user(usernum,&thisuser);
    read_user(i,&thisuser);
    usernum=i;
    close_user();
    realsl=thisuser.sl;
    thisuser.sl=255;
    sprintf(s,"#*#*#* Changed to %s",nam(&thisuser,usernum));
    topscreen();
    sysoplog(s);
  } else
    pl("Unknown user.");
}

void chuser2(void)
{
  int i;
  char s[81];
  strcpy(s,"");

  savescreen(&screensave);
  movecsr(0,0);
  printf("[KUser to change to? ");
  gets(s);

  i=finduser1(s);
  if (i>0) {
    thisuser.sl=realsl;
    write_user(usernum,&thisuser);
    read_user(i,&thisuser);
    usernum=i;
    close_user();
    realsl=thisuser.sl;
    thisuser.sl=255;
    sprintf(s,"#*#*#* SysOp Changed to %s",nam(&thisuser,usernum));
    topscreen();
    sysoplog(s);
  } else
    outs("Unknown user.");
    restorescreen(&screensave);
    topscreen();
}


void zlog()
{
  zlogrec z;
  char s[81];
  int abort,f,i,i1;

  sprintf(s,"%sZLOG.DAT",syscfg.datadir);
  f=open(s,O_RDWR | O_BINARY);
  if (f<0)
    return;
  i=0;
  abort=0;
  read(f,(void *)&z,sizeof(zlogrec));
  printf("[0;1m  Date     Calls  Active   Posts   Email   Fback    U/L    %Act   T/user");
  printf("\n[31m��������   �����  ������   �����   �����   �����    ���    ����   ������\n");
  while ((i<97) && (!abort) && (!hangup) && (z.date[0]!=0)) {
    if (z.calls)
      i1=z.active/z.calls;
    else
      i1=0;
    sprintf(s,"%s    %4d    %4d     %3d     %3d     %3d    %3d     %3d      %3d",
         z.date,z.calls,z.active,z.posts,z.email,z.fback,z.up,10*z.active/144,i1);
    pla(s,&abort);
    ++i;
    if (i<97) {
      lseek(f,((long) i) * sizeof(zlogrec),SEEK_SET);
      read(f,(void *)&z,sizeof(zlogrec));
    }
  }
  close(f);
}


void beginday()
{
  char s[255];
  zlogrec z,z1;
  int f,i,i1;

  double fk;
  int    nus;

  strcpy(z.date,status.date1);
  z.active=status.activetoday;
  z.calls=status.callstoday;
  z.posts=status.msgposttoday;
  z.email=status.emailtoday;
  z.fback=status.fbacktoday;
  z.up=status.uptoday;
  status.callstoday=0;
  status.msgposttoday=0;
  status.emailtoday=0;
  status.fbacktoday=0;
  status.uptoday=0;
  status.activetoday=0;
  strcpy(status.date3,status.date2);
  strcpy(status.date2,status.date1);
  strcpy(status.date1,date());
  strcpy(status.log2,status.log1);
  sl1(3,status.log1);
  sl1(2,date());
  if (1) {
    strcpy(s,syscfg.gfilesdir);
    strcat(s,status.log2);
    unlink(s);
  }
  sprintf(s,"%sUSER.LOG",syscfg.gfilesdir);
  unlink(s);
  save_status();
  sprintf(s,"%sZLOG.DAT",syscfg.datadir);
  f=open(s,O_RDWR | O_BINARY);
  if (f<0) {
    f=open(s,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
    z1.date[0]=0;
    z1.active=0;
    z1.calls=0;
    z1.posts=0;
    z1.email=0;
    z1.fback=0;
    z1.up=0;
    for (i=0; i<97; i++)
      write(f,(void *)&z1,sizeof(zlogrec));
  } else {
    for (i=96; i>=1; i--) {
      lseek(f,(long) ((i-1) * sizeof(zlogrec)),SEEK_SET);
      read(f,(void *)&z1,sizeof(zlogrec));
      lseek(f,(long) (i * sizeof(zlogrec)),SEEK_SET);
      write(f,(void *)&z1,sizeof(zlogrec));
    }
  }
  lseek(f,0L,SEEK_SET);
  write(f,(void *)&z,sizeof(zlogrec));
  close(f);
  if (syscfg.beginday_c[0]) {
    stuff_in(s,syscfg.beginday_c,create_chain_file("CHAIN.TXT"),"","","","");
    full_external(s,0,1);
  }

  voteprint();
  fk=freek1(syscfg.datadir);
  nus=syscfg.maxusers-status.users;

  if (fk<512.0) {
    sprintf(s,"Only %dk free in data directory.",(int) fk);
    ssm(1,0,s);
  }

  if ((!syscfg.closedsystem) && (nus<15)){
    sprintf(s,"Only %d new user slots left.",nus);
    ssm(1,0,s);
  }
}


