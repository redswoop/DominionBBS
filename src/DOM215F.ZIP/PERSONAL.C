#include <sys\stat.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>
#include <io.h>
#include <fcntl.h>
#include <alloc.h>
#include "fcns.h"
#include "nifrec.h"


extern int hangup,checkit,okmacro,two_color,lastcon,using_modem,live_user;
extern niftyrec nifty;
extern char dc[81],dcd[81],odc[81];
extern userrec thisuser;
extern int usernum,useron,num_sec;
extern configrec syscfg;
extern int echo;
extern subboardrec subboards[32];
extern usersubrec usub[32];
extern unsigned char realsl;
extern double timeon,extratimecall;
extern int cursub,curdir,curdloads,use_workspace,global_xx;
extern int incom,outcom,msgreadlogon;
extern int fsenttoday,userfile,chatcall,mailcheck,smwcheck;
extern int numed,lines_listed,okskey;
extern editorrec *editors;

void select_editor()
{
  char s[81],s1[81],*ss;
  int i;

  if (numed==0) {
    nl();
    pl("No full screen editors available.");
    nl();
    return;
  }
  for (i=0; i<5; i++)
    odc[i]=0;
  pl("0. Normal non-full screen editor");
  for (i=0; i<numed; i++) {
    itoa(i+1,s,10);
    strcat(s,". ");
    strcat(s,editors[i].description);
    pl(s);
    if (((i+1) %10)==0)
      odc[(i+1)/10-1]=(i+1)/10;
  }
  nl();
  strcpy(s,"Which editor (1-");
  itoa(numed,s1,10);
  strcat(s,s1);
  strcat(s,", <C/R>=leave as is) ? ");
  prt(2,s);
  ss=mmkey(2);
  i=atoi(ss);
  if ((i>=1) && (i<=numed))
    thisuser.defed=i;
  else
    if (strcmp(ss,"0")==0)
      thisuser.defed=0;
}





char *cn(char c)
{
  static char s[20];

  if ((checkcomp("Ami")) || (checkcomp("Mac"))) {
    sprintf(s,"Color #%d",c);
    return(s);
  }

  switch(c) {
    case 0:
      return("Black");
    case 1:
      return("Blue");
    case 2:
      return("Green");
    case 3:
      return("Cyan");
    case 4:
      return("Red");
    case 5:
      return("Magenta");
    case 6:
      return("Yellow");
    case 7:
      return("White");
  }
  return("");
}

char *describe(char col)
{
  static char s[81];


  if (thisuser.sysstatus & sysstatus_color) {
    strcpy(s,cn(col & 0x07));
    strcat(s," on ");
    strcat(s,cn((col >> 4) & 0x07));
  } else {
    if ((col & 0x07) == 0)
      strcpy(s,"Inversed");
    else
      strcpy(s,"Normal");
  }
  if (col & 0x08) {
    if ((checkcomp("Ami")) || (checkcomp("Mac")))
      strcat(s,", Bold");
    else
      strcat(s,", Intense");
  }
  if (col & 0x80) {
    if (checkcomp("Ami"))
      strcat(s,", Italicized");
    else
      if (checkcomp("Mac"))
        strcat(s,", Underlined");
      else
        strcat(s,", Blinking");
  }
  return(s);
}

void color_list()
{
  int i;
  char s[81];

  nl();
  nl();
  for (i=0; i<8; i++) {
    if (i==0)
      makeansi(0x70,s);
    else
      makeansi(i,s);
    outstr(s);
    itoa(i,s,8);
    strcat(s,". ");
    strcat(s,cn(i));
    outstr(s);
    makeansi(0x07,s);
    outstr(s);
    nl();
  }
}



void change_colors()
{
  int i,done,i1,i2;
  char s[81],ch,nc;

  done=0;
  nl();
  do {
    if ((thisuser.sysstatus & sysstatus_color)==0) {
      strcpy(s,"Monochrome base color : ");
      if ((thisuser.bwcolors[1] & 0x70) == 0)
        strcat(s,cn(thisuser.bwcolors[1] & 0x07));
      else
        strcat(s,cn((thisuser.bwcolors[1] >> 4) & 0x07));
      pl(s);
      nl();
    }
    for (i=0; i<10; i++) {
      ansic(i);
      itoa(i,s,10);
      strcat(s,". ");
      switch(i) {
        case 0:
          strcat(s,"Standard: ");
          break;
        case 1:
          strcat(s,"Note    : ");
          break;
        case 2:
          strcat(s,"Unused  : ");
          break;
        case 3:
          strcat(s,"Alert!  : ");
          break;
        case 4:
          strcat(s,"Bold    : ");
          break;
        case 5:
          strcat(s,"Yes/No  : ");
          break;
        case 6:
          strcat(s,"Input   : ");
          break;
        case 7:
          strcat(s,"Notice! : ");
          break;
        case 8:
          strcat(s,"Blinking: ");
          break;
        case 9:
          strcat(s,"UnUsed  : ");
          break;
     }
      if (thisuser.sysstatus & sysstatus_color)
        strcat(s,describe(thisuser.colors[i]));
      else
        strcat(s,describe(thisuser.bwcolors[i]));
      pl(s);
    }
    nl();
    prt(2,"Change which (0-9, Q=Quit) ? ");
    ch=onek("Q0123456789");
    if (ch=='Q')
      done=1;
    else {
      i1=ch-'0';
      if (thisuser.sysstatus & sysstatus_color)  {
        color_list();
        ansic(0);
        nl();
        prt(2,"Foreground? ");
        ch=onek("01234567");
        nc=ch-'0';
        prt(2,"Background? ");
        ch=onek("01234567");
        nc=nc | ((ch-'0') << 4);
      } else {
         nl();
         prt(7,"Inversed? ");
           if (yn()) {
             if ((thisuser.bwcolors[1] & 0x70) == 0)
               nc=0 | ((thisuser.bwcolors[1] & 0x07) << 4);
             else
               nc=(thisuser.bwcolors[1] & 0x70);
           } else {
             if ((thisuser.bwcolors[1] & 0x70) == 0)
               nc=0 | (thisuser.bwcolors[1] & 0x07);
             else
               nc=((thisuser.bwcolors[1] & 0x70) >> 4);
           }
      }
      if ((checkcomp("Ami")) || (checkcomp("Mac")))
        prt(7,"Bold? ");
      else
        prt(7,"Intensified? ");
      if (yn())
        nc |= 0x08;

      if (checkcomp("Ami"))
        prt(7,"Italicized? ");
      else
        if (checkcomp("Mac"))
          prt(7,"Underlined? ");
        else
          prt(7,"Blinking? ");
      if (yn())
        nc |= 0x80;

      nl();
      nl();
      makeansi(nc,s);
      outstr(s);
      outstr(describe(nc));
      ansic(0);
      nl();
      nl();
      prt(7,"Is this OK? ");
      if (yn()) {
        nl();
        pl("Color saved.");
        nl();
        if (thisuser.sysstatus & sysstatus_color)
          thisuser.colors[i1]=nc;
        else
          thisuser.bwcolors[i1]=nc;
      } else {
        nl();
        pl("Not saved, then.");
        nl();
      }
    }
  } while ((!done) && (!hangup));
}

void change_ecolors()
{
  int i,done,i1,i2;
  char s[81],ch,nc;

  done=0;
  nl();
  do {
    if ((thisuser.sysstatus & sysstatus_color)==0) {
      strcpy(s,"Monochrome base color : ");
      if ((thisuser.bwcolors[1] & 0x70) == 0)
        strcat(s,cn(thisuser.bwcolors[1] & 0x07));
      else
        strcat(s,cn((thisuser.bwcolors[1] >> 4) & 0x07));
      pl(s);
      nl();
    }
    for (i=10; i<20; i++) {
      ansic(i);
      itoa(i,s,10);
      strcat(s,". ");
      switch(i) {
        case 10:
          strcat(s,"Standard: ");
          break;
        case 11:
          strcat(s,"Note    : ");
          break;
        case 12:
          strcat(s,"Unused  : ");
          break;
        case 13:
          strcat(s,"Alert!  : ");
          break;
        case 14:
          strcat(s,"Bold    : ");
          break;
        case 15:
          strcat(s,"Yes/No  : ");
          break;
        case 16:
          strcat(s,"Input   : ");
          break;
        case 17:
          strcat(s,"Notice! : ");
          break;
        case 18:
          strcat(s,"Blinking: ");
          break;
        case 19:
          strcat(s,"UnUsed  : ");
          break;
      }
      if (thisuser.sysstatus & sysstatus_color)
        strcat(s,describe(thisuser.colors[i]));
      else
        strcat(s,describe(thisuser.bwcolors[i]));
      pl(s);
    }
    nl();
    prt(2,"Change which (0-9, Q=Quit) ? ");
    ch=onek("Q0123456789");
    if (ch=='Q')
      done=1;
    else {
        ch+=10;
      i1=ch-'0';
      if (thisuser.sysstatus & sysstatus_color)  {
        color_list();
        ansic(0);
        nl();
        prt(2,"Foreground? ");
        ch=onek("01234567");
        nc=ch-'0';
        prt(2,"Background? ");
        ch=onek("01234567");
        nc=nc | ((ch-'0') << 4);
      } else {
         nl();
         prt(7,"Inversed? ");
           if (yn()) {
             if ((thisuser.bwcolors[1] & 0x70) == 0)
               nc=0 | ((thisuser.bwcolors[1] & 0x07) << 4);
             else
               nc=(thisuser.bwcolors[1] & 0x70);
           } else {
             if ((thisuser.bwcolors[1] & 0x70) == 0)
               nc=0 | (thisuser.bwcolors[1] & 0x07);
             else
               nc=((thisuser.bwcolors[1] & 0x70) >> 4);
           }
      }
      if ((checkcomp("Ami")) || (checkcomp("Mac")))
        prt(7,"Bold? ");
      else
        prt(7,"Intensified? ");
      if (yn())
        nc |= 0x08;

      if (checkcomp("Ami"))
        prt(7,"Italicized? ");
      else
        if (checkcomp("Mac"))
          prt(7,"Underlined? ");
        else
          prt(7,"Blinking? ");
      if (yn())
        nc |= 0x80;

      nl();
      nl();
      makeansi(nc,s);
      outstr(s);
      outstr(describe(nc));
      ansic(0);
      nl();
      nl();
      prt(7,"Is this OK? ");
      if (yn()) {
        nl();
        pl("Color saved.");
        nl();
        if (thisuser.sysstatus & sysstatus_color)
          thisuser.colors[i1]=nc;
        else
          thisuser.bwcolors[i1]=nc;
      } else {
        nl();
        pl("Not saved, then.");
        nl();
      }
    }
  } while ((!done) && (!hangup));
}





void l_config_qscan()
{
  int i,abort;
  char s[81];

  abort=0;
  nl();
  pl("Boards to q-scan marked with '*'");
  nl();
  for (i=0; (i<32) && (usub[i].subnum!=-1) && (!abort); i++) {
    if ((1L << (usub[i].subnum)) & thisuser.qscn)
      strcpy(s,"* ");
    else
      strcpy(s,"  ");
    strcat(s,(usub[i].keys));
    strcat(s,". ");
    strcat(s,subboards[usub[i].subnum].name);
    pla(s,&abort);
  }
  nl();
  nl();
}

void config_qscan()
{
  char *s;
  int i,done;

  l_config_qscan();
  done=0;
  do {
    nl();
    pl("Enter sub-board identifier, or Q to Quit");
    outstr("Config: ");
    s=mmkey(0);
    if (s[0])
      for (i=0; i<32; i++)
        if (strcmp(usub[i].keys,s)==0)
          thisuser.qscn ^=((1L) << (usub[i].subnum));
    if (strcmp(s,"Q")==0)
      done=1;
    if (strcmp(s,"?")==0)
      l_config_qscan();
  } while ((!done) && (!hangup));
}


void list_macro(unsigned char *s)
{
  int i;

  i=0;
  outchr('"');
  while ((i<80) && (s[i]!=0)) {
    if (s[i]>=32)
      outchr(s[i]);
    else {
      outchr('^');
      outchr(s[i]+64);
    }
    ++i;
  }
  outchr('"');
  nl();
}


void make_macros()
{
  unsigned char tempmac[81],s[81];
  unsigned char ch,ch1;
  int i,i1,done,done1;

  done=0;
  do {
    nl();
    outstr("0Macros7: 0L2>1ist, 0M2>1ake, 0Q2>1uit?  ");
    ch=onek("QLM");
    switch(ch) {
      case 'Q':
        done=1;
        break;
      case 'L':
        nl();
        nl();
        pl("Ctrl-D macro: ");
        list_macro(&(thisuser.macros[0][0]));
        nl();
        pl("Ctrl-F macro: ");
        list_macro(&(thisuser.macros[1][0]));
        nl();
        pl("Ctrl-A macro: ");
        list_macro(&(thisuser.macros[2][0]));
        nl();
        pl("Ctrl-R macro: ");
        list_macro(&(thisuser.macros[3][0]));
        break;

      case 'M':
        nl();
        prt(2,"Which (A,D,F,R, Q=quit) : ");
        ch1=onek("QADRF");
        if (ch1!='Q') {
          switch(ch1) {
            case 'A': i1=2; break;
            case 'D': i1=0; break;
            case 'F': i1=1; break;
            case 'R': i1=3; break;
          }
          strcpy(s,&(thisuser.macros[i1][0]));
          thisuser.macros[i1][0]=0;
          done1=0;
          i=0;
          nl();
          pl("Enter your macro now, hit ctrl-Z when done.");
          nl();
	  okskey=0;
          do {
            ch1=getkey();
            if (ch1==26)
              done1=1;
            else
              if (ch1==8) {
                if (i>0) {
                  i--;
                  backspace();
                  if (tempmac[i]<32)
                    backspace();
                }
              } else {
                if (ch1>=32) {
                  tempmac[i++]=ch1;
                  outchr(ch1);
                } else {
                  tempmac[i++]=ch1;
                  outchr('^');
                  outchr(ch1+64);
                }
              }
            if (i>=78)
              done1=1;
          } while ((!done1) && (!hangup));
	  okskey=1;
          tempmac[i]=0;
          nl();
          pl("You entered:");
          nl();
          nl();
          list_macro(tempmac);
          nl();
          prt(7,"Is this OK? ");
          if (yn()) {
            strcpy(&(thisuser.macros[i1][0]),tempmac);
            nl();
            pl("Macro saved.");
          } else {
            nl();
            strcpy(&(thisuser.macros[i1][0]),s);
            pl("Nothing saved, then.");
          }
        }
        break;
    }
  } while ((!done) && (!hangup));
}


void input_pw1()
{
  char s[81],s1[81];
  int ok;

  nl();
  prt(7,"Change password? ");
  if (yn()) {
    nl();
    pl("You must now enter your current password.");
    outstr(": ");
    echo=0;
    input(s,20);
    if (strcmp(s,thisuser.pw)) {
      nl();
      pl("Incorrect.");
      nl();
      return;
    }
    nl();
    nl();
    pl("Enter your new password, 3 to 20 characters long.");
    outstr(": ");
    echo=1;
    input(s,20);
    nl();
    nl();
    pl("Repeat password for verification.");
    outstr(": ");
    echo=0;
    input(s1,20);
    if (strcmp(s,s1)==0) {
      strcpy(thisuser.pw,s);
      nl();
      pl("Password changed.");
      nl();
      sysoplog("Changed Password.");
    } else {
      nl();
      pl("VERIFY FAILED.");
      pl("Password not changed.");
      nl();
    }
  }
}

void modify_mailbox()
{
  int i,i1,i2;
  unsigned int u;
  char s[81];
  net_system_list_rec *csne;

  nl();
  prt(7,"Do you want to forward your mail? ");
  if (!yn()) {
    thisuser.forwardsys=0;
    thisuser.forwardusr=0;
    return;
  }
  nl();
  if (syscfg.systemnumber) {
    prt(7,"Forward to another system? ");
    if (yn()) {
      nl();
      prt(2,"Which system (number)? ");
      input(s,5);
      i2=atoi(s);
      if ((csne=next_system(i2))==NULL) {
        nl();
        pl("Unknown system.");
        nl();
        return;
      }
      nl();
      print("System name: ",csne -> name,"");
      nl();
      if (i2==syscfg.systemnumber) {
        nl();
        pl("That's this system.");
        nl();
        return;
      }
      prt(2,"Which user number on that system? ");
      input(s,5);
      i=atoi(s);
      if ((i>0) && (i<20000)) {
        thisuser.forwardsys=i2;
        thisuser.forwardusr=i;
        nl();
        pl("Saved.");
        nl();
      }
      return;
    }
  }
  nl();
  prt(2,"Forward to which user? ");
  input(s,40);
  i=finduser1(s);
  if (i==usernum) {
    thisuser.forwardsys=0;
    thisuser.forwardusr=0;
    nl();
    pl("Forwarding reset.");
    nl();
    return;
  }
  if (i>0) {
    thisuser.forwardsys=0;
    thisuser.forwardusr=i;
    nl();
    pl("Saved.");
    nl();
  }
}


void optional_lines()
{
  char s[81];
  int i;

  pl("You may specify your optional lines value from 0-10,");
  pl("0 being all, 10 being none.");
  prt(2,"What value? ");
  input(s,2);

  i=atoi(s);
  if ((s[0]) && (i>=0) && (i<11))
    thisuser.optional_val = i;

}


