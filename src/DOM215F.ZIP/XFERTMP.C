#include <stdio.h>
#include <sys\stat.h>
#include <fcntl.h>
#include <time.h>
#include <dos.h>
#include <dir.h>
#include <string.h>
#include <io.h>
#include <alloc.h>
#include <stdlib.h>
#include "fcns.h"

extern userrec thisuser;
extern directoryrec directories[64];
extern int num_dirs,hangup,userfile,echo,useron,userfile,usernum;
extern int incom,fwaiting;
extern configrec syscfg;
extern statusrec status;
extern char ctypes[NUM_CTYPES][18];
extern int edlf,dlf,curdir,numf;
extern usersubrec udir[64];
extern long nscandate;
extern char curspeed[81],cdir[81],dszlog[81];
extern unsigned int modem_speed,com_speed;
extern float batchtime;
extern int numbatch, numbatchdl, num_listed;
extern batchrec *batch;
extern double extratimecall;
extern unsigned char realsl;

#define SETREC(i)  lseek(dlf,((long) (i))*((long)sizeof(uploadsrec)),SEEK_SET);

/* the archive type to use */
#define ARC_NUMBER 0

void download_temp_arc()
{
  char s[81],s1[81],s2[21];
  long numbytes;
  double d;
  int i,f,sent,abort;

  if (!ratio_ok())
    return;
  sprintf(s1,"%sTEMP.%s",syscfg.tempdir,syscfg.arcs[ARC_NUMBER].extension);
  f=open(s1,O_RDWR | O_BINARY);
  if (f<0) {
    nl();
    nl();
    pl("There is no temporary archive file.");
    nl();
    return;
  }
  numbytes=filelength(f);
  close(f);
  if (numbytes==0L) {
    nl();
    nl();
    pl("There is no temporary archive file.");
    nl();
    return;
  }
  d=((double) (((numbytes)+127)/128)) *
    (1620.0) /
    ((double) (modem_speed));
  if (d<=nsl()) {
    print("Approx. time: ",ctim(d),"");
    sent=0;
    abort=0;
    strcpy(s,"TEMP.");
    strcat(s,syscfg.arcs[ARC_NUMBER].extension);
    send_file(s1,&sent,&abort,s2,s,-1,numbytes);
    if (sent) {
      ++thisuser.downloaded;
      thisuser.dk += ((numbytes+1023)/1024);
      sprintf(s1,"Downloaded %ldk of temporary file",(numbytes+1023)/1024);
      sysoplog(s1);
      nl();
      nl();
      sprintf(s1,"%-6.3f",ratio());
      print("Your ratio is now: ",s1,"");
      if (useron)
        topscreen();
    }
  } else {
    nl();
    nl();
    pl("Not enough time left to D/L.");
    nl();
  }
}

void add_temp_arc()
{
  char s[255],s1[81],s2[81],s3[81];
  int i;

  nl();
  pl("Enter filename to add to temporary");
  pl("archive file.  May contain wildcards.");
  prt(2,": ");
  input(s,12);
  if (!okfn(s))
    return;
  if (s[0]==0)
    return;
  if (strchr(s,'.')==NULL)
    strcat(s,".*");
  strcpy(s2,stripfn(s));
  for (i=0; i<strlen(s2); i++)
    if ((s2[i]=='|') || (s2[i]=='>') || (s2[i]=='<') || (s2[i]==';') || (s2[i]==' ') ||
        (s2[i]==':') || (s2[i]=='/') || (s2[i]=='\\'))
      return;
  sprintf(s1,"%sTEMP.%s",syscfg.tempdir,syscfg.arcs[ARC_NUMBER].extension);
  strcpy(s3,syscfg.tempdir);
  strcat(s3,s2);
  get_arc_cmd(s,s1,2,s3);
  if (s[0]) {
    strcpy(s1,"Added '");
    strcat(s1,s2);
    strcat(s1,"' to temporary archive");
    sysoplog(s1);
    do_external(s,0);
  } else
    pl("Sorry, can't add to temp archive.");
}

void del_temp()
{
  char s[81],s1[81];
  nl();
  prt(2,"Filename to delete: ");
  input(s1,12);
  if (!okfn(s1))
    return;
  if (s1[0]) {
    if (strchr(s1,'.')==NULL)
      strcat(s1,".*");
    remove_from_temp(s1,1);
  }
}

void list_temp_dir()
{
  int i,i1,f1,ok;
  char s[81],s1[81];
  struct ffblk ff;
  uploadsrec u;

  strcpy(s1,syscfg.tempdir);
  strcpy(s,"*.*");
  strcat(s1,s);
  f1=findfirst(s1,&ff,0);
  ok=1;
  nl();
  pl("Files in temporary directory:");
  nl();
  i1=0;
  while ((f1==0) && (!hangup) && (ok)) {
    strcpy(s,(ff.ff_name));
    align(s);
    sprintf(s1,"%12s  %-8ld",s,ff.ff_fsize);
    pl(s1);
    f1=findnext(&ff);
    i1=1;
  }
  if (!i1)
    pl("None.");
  nl();
  if ((ok) && (!hangup)) {
    sprintf(s,"Free space: %ldk.",(long) freek1(syscfg.tempdir));
    pl(s);
    nl();
  }
}


void temp_extract()
{
  int i,i1,i2,i3,ok,abort,ok1;
  char s[255],s1[255],s2[81],s3[255];
  uploadsrec u,u1;

  dliscan();
  nl();
  pl("Extract to temporary directory:");
  nl();
  prt(2,"Filename: ");
  input(s,12);
  if ((!okfn(s)) || (s[0]==0)) {
    closedl();
    return;
  }
  if (strchr(s,'.')==NULL)
    strcat(s,".*");
  align(s);
  i=recno(s);
  ok=1;
  while ((i>0) && (ok) && (!hangup)) {
    SETREC(i);
    read(dlf,(void *)&u,sizeof(uploadsrec));
    strcpy(s2,(directories[udir[curdir].subnum].path));
    strcat(s2,u.filename);
    get_arc_cmd(s1,s2,1,"");
    if ((s1[0]) && (exist(s2))) {
      nl();
      nl();
      abort=0;
      printinfo(&u,&abort);
      nl();
      do {
        prt(2,"Extract what (?=list,Q=abort) ? ");
        input(s1,12);
        if (s1[0]==0)
          ok1=0;
        else
          ok1=1;
        if (!okfn(s1))
          ok1=0;
        if (strcmp(s1,"?")==0) {
          list_arc_out(stripfn(u.filename),directories[udir[curdir].subnum].path);
          s1[0]=0;
        }
        if (strcmp(s1,"Q")==0) {
          ok=0;
          s1[0]=0;
        }
        i2=0;
        for (i1=0; i1<strlen(s1); i1++)
          if ((s1[i1]=='|') || (s1[i1]=='>') || (s1[i1]=='<') || (s1[i1]==';') || (s1[i1]==' '))
	    i2=1;
        if (i2)
          s1[0]=0;
        if (s1[0]) {
          if (strchr(s1,'.')==NULL)
            strcat(s1,".*");
          cd_to(directories[udir[curdir].subnum].path);
          get_dir(s2,1);
          strcat(s2,stripfn(u.filename));
          cd_to(cdir);
          cd_to(syscfg.tempdir);
          get_arc_cmd(s3,s2,1,stripfn(s1));
          if (!okfn(s1))
            s3[0]=0;
          if (s3[0]) {
            do_external(s3,0);
            sprintf(s2,"Extracted out %s from %s",s1,u.filename);
          } else
            s2[0]=0;
          cd_to(cdir);
          if (s2[0])
            sysoplog(s2);
        }
      } while ((!hangup) && (ok) && (ok1));
    } else
      if (s1[0]) {
        nl();
        pl("That file currently isn't there.");
        nl();
      }
    if (ok)
      i=nrecno(s,i);
  }
  closedl();
}

void list_temp_text()
{
  int i,i1,f1,ok,sent;
  char s[81],s1[81];
  struct ffblk ff;
  uploadsrec u;
  double percent;

  nl();
  prt(2,"List what file(s) ? ");
  input(s,12);
  if (!okfn(s))
    return;
  if (s[0]) {
    if (strchr(s,'.')==NULL)
      strcat(s,".*");
    strcpy(s1,syscfg.tempdir);
    strcat(s1,stripfn(s));
    f1=findfirst(s1,&ff,0);
    ok=1;
    nl();
    while ((f1==0) && (ok)) {
      strcpy(s,syscfg.tempdir);
      strcat(s,(ff.ff_name));
      nl();
      print("Listing ",ff.ff_name,"");
      nl();
      ascii_send(s,&sent,&percent);
      if (sent) {
        sprintf(s,"Temp text D/L '%s'",ff.ff_name);
        sysoplog(s);
      } else {
        sprintf(s,"Temp Tried text D/L '%s' %3.2f%%",ff.ff_name,percent*100.0);
        sysoplog(s);
        ok=0;
      }
      f1=findnext(&ff);
    }
  }
}


void list_temp_arc()
{
  char s1[81],s2[81];

  strcpy(s1,"TEMP.");
  strcat(s1,syscfg.arcs[ARC_NUMBER].extension);
  list_arc_out(s1,syscfg.tempdir);
  nl();
}




void temporary_stuff()
{
  char s[81],s1[81],ch;
  int done;

  done=0;
  do {
    nl();
    prt(2,"Archive: Q,D,R,A,V,L,T: ");
    ch=onek("Q?DRAVLT");
    switch(ch) {
      case 'Q':
	done=1;
	break;
      case 'D':
	download_temp_arc();
	break;
      case 'V':
	list_temp_arc();
	break;
      case 'A':
        add_temp_arc();
	break;
      case 'R':
	del_temp();
	break;
      case 'L':
	list_temp_dir();
	break;
      case 'T':
	list_temp_text();
	break;
      case '?':
	printmenu(14);
	break;
    }
  } while ((!hangup) && (!done));
}



