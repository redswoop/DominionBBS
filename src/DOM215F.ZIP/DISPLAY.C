#include <stdio.h>
#include <dos.h>
#include "vardec.h"

userrec *u;


void main()
{

  printf("Userrec length is %d\nMail waiting offset is %d\nInact offset is %d\n\n",
  sizeof(userrec),
  FP_OFF(&(u->waiting))-FP_OFF(u->name),
  FP_OFF(&(u->inact))-FP_OFF(u->name));
}
