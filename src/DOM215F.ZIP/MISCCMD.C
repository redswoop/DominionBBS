#include <sys\stat.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>
#include <io.h>
#include <fcntl.h>
#include <alloc.h>
#include "fcns.h"
#include "nifrec.h"

extern int hangup;
extern niftyrec nifty;
extern char dc[81],dcd[81],odc[81];
extern char charbuffer[161];
extern userrec thisuser;
extern int charbufferpointer,chatting;
extern int usernum,useron;
extern configrec syscfg;
extern int echo,smwcheck,okskey;
extern unsigned char realsl;
extern double timeon;
extern char curspeed[80];
extern unsigned int modem_speed,com_speed;
extern int cursub,curdir,curdloads;
extern usersubrec usub[32],udir[32];
extern statusrec status;
extern int incom,msgreadlogon;
extern int fsenttoday,userfile,chatcall;
extern char chatreason[81],irt[81];
extern subboardrec subboards[32];
extern smalrec *smallist;


void read_automessage()
{
  int i,i1,i2,i3,f,len,ptrbeg[10],ptrend[10],abort=0;
  char s[81],l[6][81],anon,buf[512],s2[10];
  slrec ss;

  sprintf(s,"%sAUTO.MSG",syscfg.gfilesdir);
  f=open(s,O_RDWR | O_BINARY);
  nl();
  anon=status.amsganon;
  if (f<1) {
    pl("No auto-message.");
  } else {
    len=read(f,(void *)buf,512);
    close(f);
    for (i=0; i<10; i++) {
      ptrbeg[i]=0;
      ptrend[i]=0;
    }
    i=0;
    i1=0;
    i2=0;
    for(i=0; i<len; i++) {
      if (i1) {
        if (buf[i]==10) {
          ptrbeg[i2]=i+1;
          i1=0;
        }
      } else {
        if (buf[i]==13) {
          ptrend[i2]=i-1;
          if (i2<6) {
            for (i3=ptrbeg[i2]; i3<=ptrend[i2]; i3++)
              l[i2][i3-ptrbeg[i2]]=buf[i3];
              l[i2][ptrend[i2]-ptrbeg[i2]+1]=0;
          }
          ++i2;
          i1=1;
        }
      }
    }
    ss=syscfg.sl[thisuser.sl];
    if (anon)
      if (ss.ability & ability_read_post_anony) {
        strcpy(s,"<<< ");
        strcat(s,&(l[0][0]));
        strcat(s," >>>");
      } else
        strcpy(s,">UNKNOWN<");
    else
      strcpy(s,&(l[0][0]));
    nl();
    print(get_string(13),s,"");
    ansic(2);
    strcpy(s2,get_string(8));
    for(i=0;i<70;i++) outchr(s2[0]);
    ansic(0);
    nl();
    i=1;
    while ((ptrend[i]) && (i<6)) {
      pla(&(l[i][0]),&abort);
      ++i;
    }
    ansic(2);
    for(i=0;i<70;i++) outchr(s2[0]);
  }
  nl();
}

void write_automessage1()
{
  int i,i1,f;
  char s[81],l[10][81],s1[81];
  slrec ss;

 {
  nl();
  pl("Enter auto-message, 5 lines, '.' to end:");
  nl();
  strcpy(s1,"");
  for (i=0; i<10 && s[0]!='.'; i++) {
    inli(s,s1,70,1);
    strcpy(&(l[i][0]),s);
    strcat(&(l[i][0]),"\r\n");
  }
  if(l[i-1][0]=='.') l[i-1][0]='';
  nl();
  ss=syscfg.sl[thisuser.sl];
  if (ss.ability & ability_post_anony) {
    prt(7,"Anonymous? ");
    if (yn())
      i1=anony_sender;
    else
      i1=0;
  } else
    i1=0;
  prt(7,"Do you want to save this? ");
  if (yn()) {
    status.amsganon=i1;
    status.amsguser=usernum;
    save_status();
    sprintf(s,"%sAUTO.MSG",syscfg.gfilesdir);
    f=open(s,O_RDWR | O_BINARY | O_CREAT | O_TRUNC, S_IREAD | S_IWRITE);
    strcpy(s,nam(&thisuser,usernum));
    strcat(s,"\r\n");
    write(f,(void *)s,strlen(s));
    for (i=0; i<10; i++)
      write(f,(void *)&(l[i][0]),strlen(&(l[i][0])));
    sysoplog("Changed Auto-message");
    for (i=0; i<10; i++) {
      strcpy(s,"   ");
      l[i][strlen(&(l[i][0]))-2]=0;
      strcat(s,&(l[i][0]));
      sysoplog(s);
    }
    nl();
    pl("AutoMessage saved.");
    nl();
    close(f);
  }

 }
}


void bbslist()
{
  int i,i1,i2,f,done,ok;
  char s[150],s1[150],s2[150],ch,ch1,*ss,s3[40],s4[40],final[150];
  long l,l1;

  done=0;
  do {
    nl();
    outstr("5[3R5]0ead, 5[3A5]0dd, 5[3N5]0et, 5[3Q5]0uit: ");
    ch=onek("QRNA");
    switch(ch) {
      case 'Q':
        done=1;
        break;
      case 'R':
        printfile("BBSLIST.MSG");
        break;
      case 'N':
	print_net_listing();
	break;
      case 'A':
        if ((thisuser.sl<=10)) {
          nl();
          nl();
          pl("You must be a validated user to add to the BBS list.");
          nl();
          break;
        }
	if (thisuser.restrict & restrict_automessage) {
          nl();
          nl();
          pl("You can not add to the BBS list.");
          nl();
          break;
	}
        nl();
        pl("Please enter phone number:");
        pl(" ###-###-####");
        mpl(12);
        input(s,12);
	if ((s[3]!='-') || (s[7]!='-'))
	  s[0]=0;
        if (strlen(s)==12) {
          ok=1;
          sprintf(s1,"%sBBSLIST.MSG",syscfg.gfilesdir);

          f=open(s1,O_RDWR | O_CREAT | O_BINARY, S_IREAD | S_IWRITE);
          if (f>0) {
            lseek(f,0L,SEEK_SET);
            l=filelength(f);
            if ((ss=malloca(l+500L))==NULL) {
              close(f);
              return;
            }
            read(f,ss,(int)l);
            l1=0L;
            while ((l1<l) && (ok)) {
              i=0;
              do {
                ch=ss[l1++];
                s1[i]=ch;
                if (ch==13)
                  s1[i]=0;
                ++i;
              } while ((ch!=10) && (i<120) && (l1<l));
              if (strstr(s1,s)!=NULL)
                ok=0;
          if (!strncmp(s1,s,12))
		ok=0;
            }
            farfree(ss);
            close(f);
          }
          if (ok) {
            pl("Number not yet in BBS list.");
            nl();
            pl("Enter BBS name and comments:");
            mpl(46);
            inputl(s1,40);
            pl("Enter maximum speed of the BBS:");
            pl("ie, 300,1200,2400,9600,19.2");
            mpl(4);
            input(s2,4);
            pl("Enter BBS type (ie, Dominion):");
            mpl(8);
            input(s3,8);
            nl();
            sprintf(final,"2%s 4%-40s 7[0%-4s7] 5(3%-8s5)\n\r",s,s1,s2,s3);
            pl(final);
            prt(7,"Is this correct? ");
            if (yn()) {
              sprintf(s1,"%sBBSLIST.MSG",syscfg.gfilesdir);
              f=open(s1,O_RDWR | O_CREAT | O_BINARY, S_IREAD | S_IWRITE);
	      if (filelength(f)) {
                lseek(f,-1L,SEEK_END);
                read(f,((void *)&ch1),1);
                if (ch1==26)
                  lseek(f,-1L,SEEK_END);
          }
              write(f,(void *)final,strlen(final));
              close(f);
              nl();
              pl("Added to BBS list.");
            }
          } else {
            pl("It's already in the BBS list.");
            nl();
            nl();
          }
        } else {
	  nl();
	  pl("Please enter number in correct format.");
	  nl();
	}
        break;
    }
  } while ((!done) && (!hangup));
}


void kill_old_email()
{
  int cur,max,i,i1,f,done,done1,forward;
  char s[81],s1[81],ch;
  long l;
  mailrec m;
  userrec u;
  slrec ss;

  prt(5,"List mail starting at most recent? ");
  forward=(yn());
  ss=syscfg.sl[thisuser.sl];
  sprintf(s,"%sEMAIL.DAT",syscfg.datadir);
  f=open(s,O_RDWR | O_BINARY);
  if (f==-1) {
    nl();
    pl("No mail.");
    return;
  }
  max=(int) (filelength(f) / sizeof(mailrec));
  if (forward)
    cur=max-1;
  else
    cur=0;
  done=0;
  do {
    lseek(f,((long) cur) * sizeof(mailrec), SEEK_SET);
    read(f,(void *)&m,sizeof(mailrec));
    while (((m.fromsys!=0) || (m.fromuser!=usernum) || (!m.touser)) && (cur<max) && (cur>=0)) {
      if (forward)
        --cur;
      else
        ++cur;
      if ((cur<max) && (cur>=0)) {
        lseek(f,((long) cur) * sizeof(mailrec), SEEK_SET);
        read(f,(void *)&m,sizeof(mailrec));
      }
    }
    if ((m.fromsys!=0) || (m.fromuser!=usernum) || (!m.touser) || (cur>=max) || (cur<0))
      done=1;
    else {
      do {
        done1=0;
        nl();
        if (!m.tosys) {
          read_user(m.touser,&u);
          strcpy(s1,nam(&u,m.touser));
          if ((m.anony & (anony_receiver | anony_receiver_pp | anony_receiver_da))
              && ((ss.ability & ability_read_email_anony)==0))
            strcpy(s1,">UNKNOWN<");
          print("To   : ",s1,"");
        } else {
          itoa(m.touser,s,10);
          itoa(m.tosys,s1,10);
          print("To   : User ",s1,", System ",s,"");
        }
        print("Title: ",m.title,"");
        time(&l);
        i=(int) ((l-m.daten)/24.0/3600.0);
        itoa(i,s,10);
        print("Sent : ",s," days ago","");
        nl();
        prt(2,"R:ead, D:elete, N:ext, Q:uit : ");
        ch=onek("QRDN");
        switch(ch) {
          case 'Q':
            done1=1;
            done=1;
            break;
          case 'N':
            done1=1;
            if (forward)
              --cur;
            else
              ++cur;
            if ((cur>=max) || (cur<0))
              done=1;
            break;
          case 'D':
            done1=1;
            delmail(f,cur);
            nl();
            pl("Mail deleted.");
            nl();
            sysoplog("Deleted mail.");
            break;
          case 'R':
            nl();
            nl();
            strcpy(s,"Title: ");
            strcat(s,m.title);
            pl(s);
            setorigin(0);
            read_message1(&m.msg,(m.anony & 0x0f), 0, &i1,"EMAIL");
            break;
        }
      } while ((!hangup) && (!done1));
    }
  } while ((!done) && (!hangup));
  close(f);
}

void list_users()
{
  subboardrec s;
  userrec u;
  int i,nu,abort,ok,num;
  char st[81];

  if (usub[cursub].subnum==-1) {
    nl();
    pl("No sub!");
    nl();
    return;
  }
  s=subboards[usub[cursub].subnum];
  nl();
  pl("Users with access to current sub:");
  nl();
  abort=0;
  num=0;
  for (i=0; (i<status.users) && (!abort) && (!hangup); i++) {
    read_user(smallist[i].number,&u);
    ok=1;
    if (u.sl<s.readsl)
      ok=0;
    if (u.age<s.age)
      ok=0;
    if ((s.ar!=0) && ((u.ar & s.ar)==0))
      ok=0;
    if (ok) {
      pla(nam(&u,smallist[i].number),&abort);
      ++num;
    }
  }
  if (!abort) {
    itoa(num,st,10);
    nl();
    print(st," users.","");
    nl();
  }
}

void print_quest(int f, int mapp, int map[21])
{
  char s[100];
  int i,abort;
  votingrec v;

  outchr(12);
  abort=0;
  for (i=1; (i<=mapp) && (!abort); i++) {
    lseek(f,((long) (map[i])) * sizeof(votingrec), SEEK_SET);
    read(f,(void *)&v,sizeof(votingrec));
    if (thisuser.votes[map[i]])
      s[0]=32;
    else
      s[0]='�';
    s[1]=32;
    if (i<10)
      itoa(i,&s[2],10);
    else
      itoa(i,&s[1],10);
    strcat(s,": ");
    strcat(s,v.question);
    pla(s,&abort);
  }
  nl();
  if (abort)
    nl();
}


int print_question(int f, int i, int ii)
{
  char s[101],s1[81],s2[81],s3[20];
  int i1,i2,i3,t,t1,abort;
  votingrec v;
  voting_response vr;

  lseek(f,((long) ii)*sizeof(votingrec),SEEK_SET);
  read(f,(void *)&v,sizeof(votingrec));
  abort=0;

  outchr(12);
  sprintf(s,"3Voting question #%d:",i);
  pla(s,&abort);
  pla(v.question,&abort);
  pla("",&abort);
  t=0;
  for (i1=0; i1<v.numanswers; i1++) {
    vr=v.responses[i1];
    t+=vr.numresponses;
  }

  ltoa( (((long)t) * 1000L) / ((long)status.users),s1,10);
  i2=strlen(s1);
  if (i2>1) {
    strcpy(s2,s1);
    s2[i2-1]='.';
    s2[i2]=s1[i2-1];
    s2[i2+1]=0;
  } else {
    strcpy(s2,"0.");
    strcat(s2,s1);
  }
  strcpy(s,"2Users voting:3 ");
  strcat(s,s2);
  strcat(s,"%");
  pla(s,&abort);
  pla("",&abort);
  if (t)
    t1=t;
  else
    t1=1;
  pla(" 70: 0No Comment",&abort);
  for (i1=0; i1<5; i1++)
    odc[i1]=0;
  for (i1=0; (i1<v.numanswers) && (!abort); i1++) {
    if (((i1+1) % 10)==0)
      odc[((i1+1)/10)-1]='0'+((i1+1)/10);
    s3[0]=32;
    if (i1<9)
      itoa(i1+1,&s3[1],10);
    else
      itoa(i1+1,&s3[0],10);
    strcpy(s,"7");
    strcat(s,s3);
    strcat(s,": 0");
    vr=v.responses[i1];
    strcat(s,vr.response);
    for (i2=strlen(s); i2<64; i2++)
      s[i2]=32;
    s[64]=0;
    strcat(s," : ");
    itoa(vr.numresponses,s1,10);
    i3=4+strlen(s);
    for (i2=strlen(s); i2<i3-strlen(s1); i2++)
      s[i2]=32;
    s[i3-strlen(s1)]=0;
    strcat(s,s1);
    strcat(s,"  ");
    ltoa( (((long)vr.numresponses) * 1000L) / ((long)t1),s1,10);
    i2=strlen(s1);
    if (i2>1) {
      strcpy(s2,s1);
      s2[i2-1]='.';
      s2[i2]=s1[i2-1];
      s2[i2+1]=0;
    } else {
      strcpy(s2,"0.");
      strcat(s2,s1);
    }
    for (i2=0; i2<5-strlen(s2); i2++)
      strcat(s," ");
    strcat(s,s2);
    strcat(s,"%");
    pla(s,&abort);
  }
  nl();
  if (abort)
    nl();
  return(!abort);
}


void vote_question(int f, int i, int ii)
{
  int ok,pqo,i1,i2,doit=0;
  char s[81],*ss;
  votingrec v;
  voting_response vr;

  pqo=print_question(f,i,ii);
  ok=pqo;
  ok=1;
  if (restrict_vote & thisuser.restrict)
    ok=0;
  if (thisuser.sl<=10)
    ok=0;
  if (!ok)
    return;

  lseek(f,((long) ii)*sizeof(votingrec),SEEK_SET);
  read(f,(void *)&v,sizeof(votingrec));

  strcpy(s,"7Your vote: 9");
  vr=v.responses[thisuser.votes[ii]-1];
  if (thisuser.votes[ii]) {
    strcat(s,vr.response);
    pl(s);
    prt(7,"Change it? ");
    doit=yn();
    }
  else {
    strcat(s,"4No Comment");
    pl(s); doit=1;
  }

  if(!doit) return;

  outstr("9Your Choice>0 ");
  ss=mmkey(2);
  i1=atoi(ss);
  if (i1>v.numanswers)
    i1=0;
  if ((i1==0) && (strcmp(ss,"0")))
    return;

  if (thisuser.votes[ii]) {
    vr=v.responses[thisuser.votes[ii]-1];
    --vr.numresponses;
    v.responses[thisuser.votes[ii]-1]=vr;
  }
  thisuser.votes[ii]=i1;
  if (i1) {
    vr=v.responses[thisuser.votes[ii]-1];
    ++vr.numresponses;
    v.responses[thisuser.votes[ii]-1]=vr;
  }
  lseek(f,((long) ii)*sizeof(votingrec),SEEK_SET);
  write(f,(void *)&v,sizeof(votingrec));
  nl();
  nl();
}


void vote()
{
  int i,i1,i2,f,map[21],mapp,abort,n,done;
  char s[81],s1[81],s2[81],sodc[10],*ss;
  votingrec v;

  sprintf(s,"%sVOTING.DAT",syscfg.datadir);
  f=open(s,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
  n=(int) (filelength(f) / sizeof(votingrec)) -1;
  if (n<20) {
    v.question[0]=0;
    v.numanswers=0;
    for (i=n; i<20; i++)
      write(f,(void *)&v,sizeof(votingrec));
  }
  mapp=0;
  for (i=0; i<5; i++)
    odc[i]=0;
  for (i=0; i<20; i++) {
    lseek(f,((long) i) * sizeof(votingrec),SEEK_SET);
    read(f,(void *)&v,sizeof(votingrec));
    if (v.numanswers) {
      map[++mapp]=i;
      if ((mapp % 10)==0)
        odc[(mapp/10)-1]='0'+(mapp/10);
    }
  }
  strcpy(sodc,odc);
  if (mapp==0) {
    nl();
    nl();
    pl("No voting questions currently.");
    nl();
    close(f);
    return;
  }
  print_quest(f,mapp,&map[0]);
  done=0;
  do {
    nl();
    prompt("0Voting : 3<0#3>1Vote, 3<0A3>1ll, 3<0Q3>1uit, 3<0?3>1help 0: ","");
    strcpy(odc,sodc);
    ss=mmkey(2);
    i=atoi(ss);
    if ((i>0) && (i<=mapp))
      vote_question(f,i,map[i]);
    else
      if (!strcmp(ss,"Q"))
        done=1;
      else
        if (!strcmp(ss,"?"))
          print_quest(f,mapp,&map[0]);
    else if(!strcmp(ss,"A"))
          for(i=1;i<=mapp;i++)
             if(!thisuser.votes[i])
                vote_question(f,i,map[i]);
  } while ((!done) && (!hangup));
  close(f);
}



