#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

char col=0;
void outchr(char c)
{if(col) {col=0; switch(c) {
    case '0': printf("[0;1m"); return;
    case '1': printf("[0m"); return;
    case '2': printf("[0;35;1m"); return;
    case '3': printf("[0;36;1m"); return;
    case '4': printf("[0;33;1m"); return;
    case '5': printf("[0;34;1m"); return;
    case '6': printf("[0;33;44;1m"); return;
    case '7': printf("[0;31;1m"); return;
    case '8': printf("[0;31;1;5m"); return;
    case '9': printf("[0;32;1m"); return;
}}
if(c=='|') {col=1; return; }
printf("%c",c);}
void outstr(char *s)
{int x=0; while(s[x]) outchr(s[x++]);}
void nl()
{printf("\n");}
void pl(char *s)
{outstr(s);nl();}

int yn(void)
{
    int x;
    x=toupper(getch());
    if(x=='Y') {printf("[36;1mYes[0;1m\n"); return 1; }
    else {printf("[36;1mNo\[0;1mn"); return 0; }
}

int ny(void)
{
    int x;
    x=toupper(getch());
    if(x=='N') {printf("[36;1mNo[0;1m\n"); return 0; }
    else {printf("[36;1mYes\[0;1mn"); return 1; }
}

void input(char *s,int len)
{
char c,done=0,x=0;
strcpy(s,"");

 do {
   c=getch();
   if( x<=len || ( (c==8) && x>=0) )
   switch(c) {
           case 13: nl(); done=1; break;
           case 24: exit(0); break;
           case 8: if(x<1) break; printf("\b \b"); s[x]=0; x--; break;
           case '': exit(0);
           default: printf("%c",c); s[x++]=c; break;
          }
  } while(!done);
}

void npr(char *fmt, ...)
/* just like printf, only out to the com port */
{
  va_list ap;
  char s[512];

  va_start(ap, fmt);
  vsprintf(s, fmt, ap);
  va_end(ap);
  outstr(s);
  nl();
}

