#include "fcns.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <io.h>
#include <fcntl.h>
#include <sys\stat.h>
#include <time.h>


extern subboardrec subboards[32];
extern directoryrec directories[64];
extern int num_subs, num_dirs,hangup,userfile,echo,useron,wfc,userfile,usernum;
extern int incom,fwaiting;
extern configrec syscfg;
extern statusrec status;
extern char ctypes[NUM_CTYPES][18];
extern char cdir[81];
extern userrec thisuser;
extern int numextrn;
extern externalrec *externs;
extern unsigned char agemin,agemax,slmin,slmax,dslmin,dslmax,ressex;
extern int daysmin,daysmax,lecho;
extern unsigned short arres,darres,resres;
extern int questused[20];
extern unsigned char realsl;



void dirdata(int n, char *s)
{
  char x,y,k,i;
  directoryrec r;

  r=directories[n];
  if (r.dar==0)
    x=32;
  else {
    for (i=0; i<16; i++)
      if ((1 << i) & r.dar)
        x='A'+i;
  }
  sprintf(s,"3%2d  3%1c  3%-40s  3%-8s 3%-3d 3%-3d 3%-3d 3%-9.9s",
            n,x,r.name,r.filename,r.dsl,r.age,r.maxfiles,r.path);
}

void showdirs()
{
  int abort,i;
  char s[180];

  outchr(12);
  abort=0;
  pla("0NN2�0Dar2�0Name2��������������������������������������0Filename2�0Dsl2�0AGE2�0Max2�0Path2����",
      &abort);
  for (i=0; (i<num_dirs) && (!abort); i++) {
    dirdata(i,s);
    pla(s,&abort);
  }
}



void modify_dir(int n)
{
  directoryrec r;
  char s[81],s1[81],ch,ch2,*ss;
  int i,i1,done;

  done=0;
  r=directories[n];
  do {
    outchr(12);
    print("1. Name       : ",r.name,"");
    print("2. Filename   : ",r.filename,"");
    print("3. Path       : '",r.path,"'","");
    itoa(r.dsl,s,10);
    print("4. DSL        : ",s,"");
    itoa(r.age,s,10);
    print("5. Min. Age   : ",s,"");
    itoa(r.maxfiles,s,10);
    print("6. Max Files  : ",s,"");
    strcpy(s,"None.");
    if (r.dar!=0) {
      for (i=0; i<16; i++)
        if ((1 << i) & r.dar)
          s[0]='A'+i;
      s[1]=0;
    }
    print("7. DAR        : ",s,"");
    itoa(r.mask,s,2);
    print("8. Mask       : ",s,"");
    itoa(r.type,s,10);
    print("9. Dir Type   : ",s,"");
    if (r.mask & mask_no_uploads)
      ss="Disallowed";
    else
     ss="Allowed";
    print("0. Uploads    : ",ss,"");
    if (r.mask & mask_archive)
      ss="Yes";
    else
      ss="No";
    print("A. Arch. only : ",ss,"");
    nl();
    prt(2,"Which (1-0,A,Q,J,[,]) ? ");
    ch=onek("Q123456789J0A[]");
    switch(ch) {
      case 'Q':done=1; break;
      case ']': if((n>=0) && (n<num_dirs-1))  { directories[n++]=r; r=directories[n];}break;
      case '[': if(n>0){ directories[n--]=r; r=directories[n];} break;
      case 'J': nl(); prt(4,"Jump to which dir? ");
                input(s,4); if(s[0]){
                i=atoi(s);
                directories[n]=r;
                r=directories[++n];}
                break;
      case '1':
        nl();
        prt(2,"New Name? ");
        inputl(s,40);
        if (s[0])
          strcpy(r.name,s);
        break;
      case '2':
        nl();
        prt(2,"New Filename? ");
        input(s,8);
        if ((s[0]!=0) && (strchr(s,'.')==0))
          strcpy(r.filename,s);
        break;
      case '3':
        nl();
        pl("Enter new path, optionally with drive specifier.");
        pl("No backslash on end.");
        prt(2,"New Path? ");
        input(s,80);
        if (s[0]) {
          if (chdir(s)) {
            chdir(cdir);
            if (mkdir(s)) {
              pl("Unable to create or change to directory.");
              pl("Hit any key.");
              getkey();
              s[0]=0;
            }
          } else {
            chdir(cdir);
          }
          if (s[0]) {
            strcat(s,"\\");
            strcpy(r.path,s);
            pl("Path for directory changed.");
            pl("If there are any files in it, you must");
            pl("manually move them to the new directory.");
            pl("Hit any key.");
            getkey();
          }
        }
        break;
      case '4':
        nl();
        prt(2,"New DSL? ");
        input(s,3);
        i=atoi(s);
        if ((i>=0) && (i<256) && (s[0]))
          r.dsl=i;
        break;
      case '5':
        nl();
        prt(2,"New Min Age? ");
        input(s,3);
        i=atoi(s);
        if ((i>=0) && (i<128) && (s[0]))
          r.age=i;
        break;
      case '6':
        nl();
        prt(2,"New Max files? ");
        input(s,3);
        i=atoi(s);
        if ((i>0) && (i<500) && (s[0]))
          r.maxfiles=i;
        break;
      case '7':
        nl();
        prt(2,"New DAR (<SPC>=None) ? ");
        ch2=onek("ABCDEFGHIJKLMNOP ");
        if (ch2==32)
          r.dar=0;
        else
          r.dar=1 << (ch2-'A');
        break;
      case '8':
        nl();
        prt(2,"New Mask? ");
        input(s,3);
        i=atoi(s);
        if ((i>=0) && (i<32767) && (s[0]))
          r.mask=i;
        break;
      case '9':
        nl();
        prt(2,"New Dir Type? ");
        input(s,4);
        i=atoi(s);
        if (s[0])
          r.type=i;
        break;
      case '0':
        r.mask &= ~mask_no_uploads;
        nl();
        prt(5,"Allow uploads to this directory? ");
        if (!ny())
          r.mask |= mask_no_uploads;
        break;
      case 'A':
        r.mask &= ~mask_archive;
        nl();
        prt(5,"Require uploads to be archived? ");
        if (yn())
          r.mask |= mask_archive;
        break;
    }
  } while ((!done) && (!hangup));
  directories[n]=r;
  if (!wfc)
    changedsl();
}


void insert_dir(int n)
{
  directoryrec r;
  int i,i1,nu;
  userrec u;
  long l1,l2,l3;

  for (i=num_dirs-1; i>=n; i--)
    directories[i+1]=directories[i];
  strcpy(r.name,"** NEW DIR **");
  strcpy(r.filename,"NONAME");
  strcpy(r.path,syscfg.dloadsdir);
  r.dsl=10;
  r.age=0;
  r.maxfiles=50;
  r.dar=0;
  r.type=0;
  r.mask=0;
  directories[n]=r;
  ++num_dirs;
  read_user(1,&u);
  nu=(int) (filelength(userfile) / sizeof(userrec));
  if (n>=32) {
    l1=0xffffffff >>(64-n);
    l2=0xffffffff <<(n-31);
    l3=1L << (n-32);
    for (i=1; i<nu; i++) {
      read_user(i,&u);
      u.nscn2=(u.nscn2 & l1) | ((u.nscn2 << 1) & l2) | l3;
      write_user(i,&u);
    }
  } else {
    l1=0xffffffff >>(32-n);
    l2=0xffffffff <<(n+1);
    l3=1L << n;
    for (i=1; i<nu; i++) {
      read_user(i,&u);
      u.nscn2=(u.nscn2 << 1) | (u.nscn1 >> 31);
      u.nscn1=(u.nscn1 & l1) | ((u.nscn1 << 1) & l2) | l3;
      write_user(i,&u);
    }
  }
  modify_dir(n);
}


void delete_dir(int n)
{
  int i,i1,nu;
  userrec u;
  long l1,l2;

  for (i=n; i<num_dirs; i++)
    directories[i]=directories[i+1];
  --num_dirs;
  read_user(1,&u);
  nu=(int) (filelength(userfile) / sizeof(userrec));
  if (n>=32) {
    l1=0xffffffff >>(64-n);
    l2=0xffffffff <<(n-32);
    for (i=1; i<nu; i++) {
      read_user(i,&u);
      u.nscn2=(u.nscn2 & l1) | ((u.nscn2 >> 1) & l2);
      write_user(i,&u);
    }
  } else {
    l1=0xffffffff >>(32-n);
    l2=0xffffffff <<(n);
    for (i=1; i<nu; i++) {
      read_user(i,&u);
      u.nscn1=(u.nscn1 & l1) | ((u.nscn1 >> 1) & l2) | (u.nscn2 << 31);
      u.nscn2=u.nscn2 >> 1;
      write_user(i,&u);
    }
  }
  if (!wfc)
    changedsl();
}


void dlboardedit()
{
  int i,i1,i2,done,f;
  char s[81],s1[81],s2[81],ch;

  if (!checkpw())
    return;
  showdirs();
  done=0;
  do {
    nl();
    outstr("5[3D5]0elete, 5[3I5]0nsert, 5[3M5]0odify, 5[3Q5]0uit: ");
    ch=onek("QDIM?");
    switch(ch) {
      case '?':
        showdirs();
        break;
      case 'Q':
        done=1;
        break;
      case 'M':
        nl();
        prt(2,"Dir number? ");
        input(s,2);
        i=atoi(s);
        if ((s[0]!=0) && (i>=0) && (i<num_dirs))
          modify_dir(i);
        break;
      case 'I':
        if (num_dirs<64) {
          nl();
          prt(2,"Insert before which dir? ");
          input(s,2);
          i=atoi(s);
          if ((s[0]!=0) && (i>=0) && (i<=num_dirs))
            insert_dir(i);
        }
        break;
      case 'D':
        nl();
        prt(2,"Delete which dir? ");
        input(s,2);
        i=atoi(s);
        if ((s[0]!=0) && (i>=0) && (i<num_dirs)) {
          nl();
          sprintf(s1,"Delete %s? ",directories[i].name);
          prt(5,s1);
          if (yn())
            delete_dir(i);
        }
        break;
    }
  } while ((!done) && (!hangup));
  sprintf(s,"%sDIRS.DAT",syscfg.datadir);
  f=open(s,O_RDWR | O_BINARY | O_CREAT | O_TRUNC, S_IREAD | S_IWRITE);
  write(f,(void *)&directories[0], num_dirs * sizeof(directoryrec));
  close(f);
}



