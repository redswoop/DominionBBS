#include <sys\stat.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>
#include <io.h>
#include <fcntl.h>
#include <alloc.h>
#include "fcns.h"
#include "nifrec.h"


extern int hangup,checkit,okmacro,two_color,lastcon,using_modem,live_user,mciok;
extern char dc[81],dcd[81],odc[81];
extern char charbuffer[161];
extern userrec thisuser;
extern int charbufferpointer,chatting,curatr;
extern int expressabort,express;
extern int usernum,useron,num_sec;
extern configrec syscfg;
extern niftyrec nifty;
extern int echo,topdata;
extern unsigned char realsl;
extern double timeon,extratimecall;
extern char curspeed[80],cfilt[255],scfilt[255];
extern int cursub,curdir,curdloads,use_workspace,global_xx;
extern usersubrec usub[32],udir[32];
extern statusrec status;
extern int incom,outcom,msgreadlogon;
extern int fsenttoday,userfile,chatcall,mailcheck,smwcheck;
extern char chatreason[81],irt[81],byline[81];
extern subboardrec subboards[32];
extern long nscandate;
extern float batchtime;
extern float batchsize;
extern int numbatch,numbatchdl,numed,lines_listed;
extern editorrec *editors;
extern char xdate[9];
extern int questused[20];
extern unsigned int modem_speed,com_speed;
extern char ctypes[NUM_CTYPES][18];


void far *malloca(unsigned long nbytes)
{
  void *buf;
  char x[81];

  buf=farmalloc(nbytes+1);
  if (buf==NULL) {
    nl();
    ltoa(nbytes,x,10);
    print("Not enough memory, needed ",x," bytes","");
    nl();
    sysoplog("!!! Ran out of memory !!!");
  }
  return(buf);
}

/* Begin message base title search routine */

void find_subject(void)
{
	char subject[80], string[80], s[80], s1[80],s2[80];
	char title[80];
	char *result;
	int i,k,yes,count,abort;
	subboardrec sb;
	postrec m;
	FILE *fptr,*fptr2;

	i=k=count=abort=0;
	nl();
	if (okansi()) {
	 prt(1,"Search for what? ");
	 mpl(30);
	 inputl(subject,30);
	}
	else {
	 pl("                  [------------------------------]");
	 outstr("Search for what? ");
	 inputl(subject,30);
	}
	if (subject[0]==0)
		return;
	nl();
	strcpy(string,subject);
	strupr(subject);
	strcpy(s1,syscfg.datadir);
	strcat(s1,"\\SUBS.DAT");
	fptr=fopen(s1,"rb");
	prt(0,"Seaching for \"");
	prt(0,string);
	prt(0,"\" ...");
	nl();
	nl();
	while ((fread(&sb, sizeof(sb),1,fptr)==1) && (abort==0)){
		result=NULL;
		if (thisuser.sl>=sb.readsl) {
			k++;
			strcpy(s1,syscfg.datadir);
			strcat(s1,sb.filename);
			strcat(s1,".SUB");
			fptr2=fopen(s1,"rb");
			i=yes=0;
			while (fread(&m, sizeof(m),1,fptr2)==1) {
				strcpy(title,m.title);
				strupr(m.title);
				result=strstr(m.title,subject);
				if ((result!=NULL) && (i!=0)){
					if (!yes) {
						ansic(2);
						itoa(k, s, 10);
						strcpy(s2, "[");
						strcat(s2,s);
						strcat(s2,"] [");
						strcat(s2,sb.name);
						strcat(s2,"]");
						pla(s2,&abort);
						yes=1;
					}
					ansic(0);
					itoa(i,s,10);
					strcpy(s2,"\t#");
					if (strlen(s) < 2)
						strcat(s2," ");
					strcat(s2, s);
					strcat(s2,": ");
					strcat(s2, title);
					pla(s2,&abort);
					count++;
				}
			i++;
			}
		}
	fclose(fptr2);
	}
	fclose(fptr);
	if (abort==0) {
		itoa(count,s,10);
		nl();
		prt(0,s);
		prt(0," match");
		if (count!=1)
			prt(0,"es");
		prt(0," found");
	}
}

/* End message base title search routine */


void stuff_in(char *s, char *s1, char *f1, char *f2, char *f3, char *f4, char *f5)
{
  int r=0,w=0;

  while (s1[r]!=0) {
    if (s1[r]=='%') {
      ++r;
      s[w]=0;
      switch(s1[r]) {
        case '1': strcat(s,f1); break;
        case '2': strcat(s,f2); break;
        case '3': strcat(s,f3); break;
        case '4': strcat(s,f4); break;
        case '5': strcat(s,f5); break;
      }
      w=strlen(s);
      r++;
    } else
      s[w++]=s1[r++];
  }
  s[w]=0;
}

void copy_line(char *s, char *b, long *ptr, long len)
{
  int i;
  long l;

  if (*ptr>=len) {
    s[0]=0;
    return;
  }
  l=*ptr;
  i=0;
  while ((b[l]!='\r') && (b[l]!='\n') && (l<len)) {
    s[i++]=b[l++];
  }
  s[i]=0;
  if ((b[l]=='\r') && (l<len))
    ++l;
  if ((b[l]=='\n') && (l<len))
    ++l;
  *ptr=l;
}

char *mmkey(int dl)
{
  static unsigned char cmd1[10],cmd2[81],ch;
  int i,i1,i2,p;

  if(thisuser.res[0]) {
        input(cmd2,50);
        return(cmd2);
  } else

  do {
    do {
      ch=getkey();
    } while ((((ch<' ') && (ch!=13)) || (ch>126)) && (hangup==0));
    ch=upcase(ch);
    outchr(ch);
    if (ch==13)
      cmd1[0]=0;
    else
      cmd1[0]=ch;
    cmd1[1]=0;
    p=0;
    switch(dl) {

    case 1:
      if (strchr(dcd,ch)!=NULL)
        p=1;
      break;
    case 2:
      if (strchr(odc,ch)!=NULL)
        p=1;
      break;
    case 0:
      if (strchr(dc,ch)!=NULL)
        p=1;
      break;
    }
    if (p) {
      do {
        ch=getkey();
      } while ((((ch<' ') && (ch!=13) && (ch!=8)) || (ch>126)) && (hangup==0));
      ch=upcase(ch);
      if (ch==13) {
        return(cmd1);
      } else
        if (ch==8) {
          backspace();
        } else {
          cmd1[1]=ch;
          cmd1[2]=0;
          outchr(ch);
          if (ch=='/') {
            outstr("\b\b  \b\b");
            nl();
            outstr("0Extended Command7>1");
            input(cmd2,50);
            return(cmd2);
          }

            return(cmd1);
        }
    } else
      return(cmd1);

  } while (hangup==0);
  cmd1[0]=0;
  return(cmd1);
}


int inli2(char *s, char *rollover, int maxlen, int crend, int wb)
{
  int cp,i,i1,done,cm,begx,chatrand=0;
  char s1[255];
  unsigned char ch;

  cm=chatting;
  mciok=0;

  begx=wherex();
  if (rollover[0]!=0) {
    if (charbufferpointer) {
      strcpy(s1,rollover);
      strcat(s1,&charbuffer[charbufferpointer]);
      strcpy(&charbuffer[1],s1);
      charbufferpointer=1;
    } else {
      strcpy(&charbuffer[1],rollover);
      charbufferpointer=1;
    }
    rollover[0]=0;
  }
  cp=0;
  done=0;
  do {
    ch=getkey();
    if (two_color)
        {
          switch(nifty.chatcolor)
          {
            case 1:chatrand=random(10);
                if((chatrand==8) || (chatrand==6)) chatrand--;
                 ansic(chatrand); break;
            default:
            case 0: if(lastcon) ansic(0); else ansic(1); break;
            case 2: if(ch==' '||ch=='\b') break; ansic(nifty.rotate[chatrand++]); if(chatrand>4) chatrand=0; break;
            case 3: if(lastcon) makeansi(cfilt[ch],s1);
                                else makeansi(scfilt[ch],s1);
                                outstr(s1); break;
          }
        }
    if (cm)
      if (chatting==0)
        ch=13;
    if ((ch>=32)) {
      if ((wherex()<(thisuser.screenchars-1)) && (cp<maxlen)) {
        s[cp++]=ch;
        outchr(ch);
        if (wherex()==(thisuser.screenchars-1))
          done=1;
      } else {
        if (wherex()>=(thisuser.screenchars-1))
          done=1;
      }
    } else
        switch(ch) {
	  case 7:
	    if ((chatting) && (outcom))
	      outcomch(7);
	    break;
          case 13: /* C/R */
            s[cp]=0;
            done=1;
            break;
          case 8:  /* Backspace */
            if (cp) {
              if (s[cp-2]==3) {
                cp-=2;
                ansic(0);
              } else
              if (s[cp-2]==14) {
                cp-=2;
                ansic(0);
              } else
                if (s[cp-1]==8) {
                  cp--;
                  outchr(32);
                } else {
                  cp--;
                  backspace();
                }
             } else
               if (wb) {
                 i=curatr;
                 ansic(4);
                 pl("Going To Last Line");
                 setc(i);
                 return(1);
               }
            break;
          case 24: /* Ctrl-X */
            while (wherex()>begx) {
              backspace();
              cp=0;
            }
            ansic(0);
            break;
          case 23: /* Ctrl-W */
            if (cp) {
              do {
                if (s[cp-2]==3) {
                  cp-=2;
                  ansic(0);
                } else
                if (s[cp-2]==14) {
                cp-=2;
                ansic(0);
              } else
                  if (s[cp-1]==8) {
                    cp--;
                    outchr(32);
                  } else {
                    cp--;
                    backspace();
                  }
              } while ((cp) && (s[cp-1]!=32) && (s[cp-1]!=8) && (s[cp-2]!=3)&&
              (s[cp-2]!=14));
            }
            break;
          case 14: /* Ctrl-N */
            if ((wherex()) && (cp<maxlen)) {
              outchr(8);
              s[cp++]=8;
            }
            break;

           case 16: /* Ctrl-P */
             if (cp<maxlen-1) {
               ch=getkey();
               if (((ch>='0') && (ch<='9')) ||  /* This might need to be a */
                   ((ch>='A') && (ch<='Z')) ||
                   ((ch>='A') && (ch<='z'))) {
                 s[cp++]=3;
                 s[cp++]=ch;
                 if ((ch>='0') && (ch<='9'))
                   ansic(ch-'0');
                 else if (thisuser.restrict & restrict_wwiv_mci)
                    cp -=2;
                 else if ((ch>='A') && (ch<='Z'))
                   prinfo(ch);
                 else {
                   ch=upcase(ch);
                   prinfo(ch);
                 }
               }
             }
             break;



           case 5: /* Ctrl-E */
            if (cp<maxlen-1) {
              ch=getkey();
              if ((ch>='0') && (ch<='9')) {
                s[cp++]=14;
                s[cp++]=ch;
                ch+=10;
                ansic(ch-'0');
              }
            }
            break;

     
          case 9:  /* Tab */
            i=5-(cp % 5);
            if (((cp+i)<maxlen) && ((wherex()+i)<thisuser.screenchars)) {
	      i=5-((wherex()+1) % 5);
              for (i1=0; i1<i; i1++) {
                s[cp++]=32;
                outchr(32);
              }
            }
            break;
        }
  } while ((done==0) && (hangup==0));
  if (ch!=13) {
    i=cp-1;
    while ((i>0) && (s[i]!=32) && (s[i]!=8) || (s[i-1]==3) || (s[i-1]==14))
      i--;
    if ((i>(wherex()/2)) && (i!=(cp-1))) {
      i1=cp-i-1;
      for (i=0; i<i1; i++)
        outchr(8);
      for (i=0; i<i1; i++)
        outchr(32);
      for (i=0; i<i1; i++)
        rollover[i]=s[cp-i1+i];
      rollover[i1]=0;
      cp -= i1;
    }
    s[cp++]=1;
    s[cp]=0;
  }
  if (crend)
    nl(); return 0;

}

void inli(char *s, char *rollover, int maxlen, int crend)
{  inli2(s,rollover,maxlen,crend,0);  mciok=1; }


int check_ansi()
{
  long l;
  char ch;
  pl("Please Wait - AutoSensing Ansi");

  while (comhit())
    get1c();

  pr1("\x1b[6n");

  l=timer1()+36;

  while ((timer1()<l) && (!hangup)) {
    checkhangup();
    ch=get1c();
    if (ch=='\x1b')
      return(1);
    else if(ch==21)
     return(2);
  }
  return(0);
}

void getuser(char who[31])
{
  char s[81],s2[81];
  int ok,count,net_only,ans;
  long l;

  thisuser.sysstatus &= (~sysstatus_ansi);
  net_only=1;
  if (syscfg.netlowtime!= syscfg.nethightime) {
    if (syscfg.nethightime>syscfg.netlowtime) {
      if ((timer()<=(syscfg.netlowtime*60.0)) || (timer()>=(syscfg.nethightime*60.0)))
        net_only=0;
    } else {
      if ((timer()<=(syscfg.netlowtime*60.0)) && (timer()>=(syscfg.nethightime*60.0)))
        net_only=0;
    }
  } else
    net_only=0;
  count=0;
  ok=0;
  checkit=1;
  okmacro=0;
  if ((!net_only) && (incom)) {
    sprintf(s,"%swelcome.ans",syscfg.gfilesdir);
    if (exist(s)) {
      nl();
      ans=check_ansi();
      if (ans==1) {
        printfile("welcome.ans");
      } else
	printfile("welcome.msg");
    } else
      printfile("welcome.msg");
  }
  ansic(0);
    do {
    nl();
    if (net_only) {
      pl("This time is reserved for net-mail ONLY.");
      pl("Please try calling back again later.");
    } else
//    if(ans) read_user(1,&thisuser);
    pl(get_string(1));
    pl(get_string(2));
    prompt(get_string(3),"");
    if(!who[0]) input(s,30);
    else strcpy(s,who);
    usernum=finduser(s);
    if ((net_only) && (usernum!=-2))
      usernum=0;
    if (usernum>0) {
      read_user(usernum,&thisuser);
      realsl=thisuser.sl;
      topscreen();
      ok=1;
      outstr("Password: ");
      echo=0;
      input(s,20);
      if (strcmp(s,thisuser.pw)!=0)
        ok=0;
      if (syscfg.sysconfig & sysconfig_free_phone) {
        outstr("Last For Digits of Fone: ");
        echo=0;
        input(s,4);
        if (strcmp(s,&thisuser.phone[8])!=0) {
          ok=0;
          if ((strlen(s)==4) && (s[3]=='-')) {
            nl();
            pl("!! Enter the LAST 4 DIGITS of your phone number ONLY !!");
            nl();
          }
        }
      }
      if ((thisuser.sl==255) && (incom) && (ok)) {
        outstr("SY: ");
        echo=0;
        input(s,20);
        if (strcmp(s,syscfg.systempw)!=0)
          ok=0;
      }
      echo=1;
      if (ok) {
        changedsl();
      } else {
        ++thisuser.illegal;
        write_user(usernum,&thisuser);
        close_user();
        nl();
        pl("\7ILLEGAL LOGON\7");
        nl();
        strcpy(s,"### ILLEGAL LOGON for ");
        strcat(s,nam(&thisuser,usernum));
        sl1(0,s);
	usernum=0;
      }
    } else
      if (usernum==-1) {
        newuser();
        ok=1;
      } else
        if (usernum==0) {
	  if (net_only)
	    nl();
      else pl("Unknown User");
        } else
          if ((usernum==-2) || (usernum==-3)) {
	    if (incom) {
              time(&l);
              if (usernum==-2)
                sprintf(s,"NETWORK /B%u /T%ld",modem_speed,l);
              else if(usernum==-3)
                sprintf(s,"REMOTE /B%u",modem_speed);
              save_status();
              run_external1(s);
              get_status();
              hangup=1;
              dtr(0);
              global_xx=0;
              wait(1.0);
              dtr(1);
              wait(0.1);
	      cleanup_net();
          imodem();
	    }
	    hangup=1;
          }
  } while ((!hangup) && (!ok) && (++count<5));
  if (count==5)
    hangup=1;
  checkit=0;
  okmacro=1;
  if ((!hangup) && (usernum>0) && (thisuser.restrict & restrict_logon) &&
    (strcmp(date(),thisuser.laston)==0) && (thisuser.ontoday>0)) {
    nl();
    pl("Sorry, you can only logon once per day.");
    nl();
    hangup=1;
  }
}


void logon()
{
  char s[255],s1[81],s2[81],*ss,c;
  int i,i1,f,abort=0;
  long len,pos;

  if (live_user) {
    ansic(0);
    outchr(12);
  }
  if (strcmp(date(),status.date1)!=0) {
    if (live_user) {
      nl();
      pl("Please Wait, Updating System Records.");
    }
    beginday();
    if (live_user) pl("Thank You");
  }
    if (incom && live_user) {
    strcpy(s,syscfg.gfilesdir);
    i=printfile("LOGON");
    if ((!i) && (!(thisuser.sysstatus & sysstatus_pause_on_page)))
      pausescr();
  }

  if (strcmp(date(),thisuser.laston)==0)
    ++thisuser.ontoday;
  else {
    thisuser.ontoday=1;
    thisuser.timeontoday=0.0;
    thisuser.extratime=0.0;
    thisuser.posttoday=0;
    thisuser.etoday=0;
    thisuser.fsenttoday1=0;
  }
  ++thisuser.logons;
  cursub=0;
  msgreadlogon=0;
  if (udir[0].subnum==0)
    curdir=1;
  else
    curdir=0;
  curdloads=0;
  if (thisuser.sl!=255 || thisuser.res[5]) {
    ++status.callernum1;
    ++status.callstoday;
  }
  strcpy(s1,times());
  sprintf(s,"%ld: %s %s %s   %s - %d",
       status.callernum1,
       nam(&thisuser,usernum),
       s1,
       date(),
       curspeed,
       thisuser.ontoday);
  sprintf(s2,"%sLASTON.TXT",syscfg.gfilesdir);
  ss=get_file(s2,&len);
 pos=0;
 if (syscfg.sysconfig & sysconfig_lastfew) {
  if (ss!=NULL) {
    if (!cs())
      for (i=0; i<4; i++)
	copy_line(s1,ss,&pos,len);
    i=1;
    do {
      copy_line(s1,ss,&pos,len);
      if ((s1[0]) && live_user) {
	if (i) {
	  i=0;
	  nl();
      pl(get_string(34));
	  nl();
	}
	pl(s1);
      }
    } while (pos<len);
  }
}
  if ((thisuser.sl!=255) || (incom) ||thisuser.res[5]) {
    sl1(0,"");
    sl1(0,s);
    sl1(1,"");
    sprintf(s,"0%ld: 2%-31s   0[7%s0] Calls Today 4%d",
          status.callernum1,
          nam(&thisuser,usernum),
          curspeed,
          thisuser.ontoday);
    sprintf(s1,"%sUSER.LOG",syscfg.gfilesdir);
    f=open(s1,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
    lseek(f,0L,SEEK_END);
    i=strlen(s);
    s[i++]='\r';
    s[i++]='\n';
    s[i]=0;
    if (thisuser.sl!=255||!thisuser.res[5]) {
      write(f,(void *)s,i);
      close(f);
      f=open(s2,O_RDWR | O_BINARY | O_CREAT | O_TRUNC, S_IREAD | S_IWRITE);
      pos=0;
      copy_line(s1,ss,&pos,len);
      for (i=1; i<8; i++) {
        copy_line(s1,ss,&pos,len);
        strcat(s1,"\r\n");
        write(f,(void *)s1,strlen(s1));
      }
      write(f,(void *)s,strlen(s));
      close(f);
    } else
      close(f);
  }

  if (ss!=NULL)
    farfree(ss);

  if (live_user&&syscfg.sysconfig & sysconfig_automsg)
    read_automessage();
  timeon=timer();
  useron=1;
  if (live_user)
    topscreen();

  if ((syscfg.logon_c[0]) && live_user) {
    nl();
    ex("D1",syscfg.logon_c,"");
  }

  if (live_user) {
    nl();
    sprintf(s,"7[0Name           7]1  %s",nam(&thisuser,usernum));
    pla(s,&abort);
    i=(int)((nsl()+30)/60.0);
    itoa(i,s1,10);
    sprintf(s,"7[0Time for Logon 7]1  %s",s1);
    pla(s,&abort);
    if (thisuser.illegal) {
      itoa(thisuser.illegal,s1,10);
      sprintf(s,"7[0Illegal logons 7]1  %s",s1);
      pla(s,&abort);
    }
    if (thisuser.waiting) {
      itoa(thisuser.waiting,s1,10);
      sprintf(s,"7[0Mail waiting   7]1  %s",s1);
      pla(s,&abort); }
  sprintf(s1,"7[0Last on        7]1  %s",thisuser.laston);
  pla(s1,&abort);
  if (thisuser.ontoday==1) {
  itoa((int)thisuser.ontoday,s,10);
  sprintf("7[0On today       7]1  %s",s);
  pla(s1,&abort);
  }
        itoa((int)thisuser.logons,s,10);
  sprintf(s1,"7[0Times on       7]1  %s",s);
  pla(s1,&abort);
  sprintf(s1,"7[0System is      7]1  %s",VERSION_NUMBER);
  pla(s1,&abort);

    
     if (syscfg.systemnumber) {
      itoa(syscfg.systemnumber,s1,10);
      sprintf(s,"7[0NetWork node   7]1  %s",s1);
      pla(s,&abort);
    }
    nl();
    if (thisuser.forwardusr) {
      if (thisuser.forwardsys)
        sprintf(s1,"Forwarding mail to #%u @%u.",
            thisuser.forwardusr,thisuser.forwardsys);
      else
        sprintf(s1,"Forwarding mail to user #%u.",thisuser.forwardusr);
      pl(s1);
      nl();
    }
    fsenttoday=0;
    if (sysop2())
    pl(get_string(4));
    else pl(get_string(5));


    if(!thisuser.citystate[0]) {
    input_city(); }

    if (thisuser.year) {
      s[0]=years_old(thisuser.month,thisuser.day,thisuser.year);
      if (thisuser.age!=s[0]) {
        thisuser.age=s[0];
        printfile("BDAY");
        thisuser.credits+=nifty.bday;
        thisuser.filepoint+=nifty.bday;
        topscreen();
      }
    } else {
      nl();
      pl("Please enter the following information:");
      do {
        nl();
        input_age(&thisuser);
        sprintf(s,"%02d/%02d/%02d",(int) thisuser.month,
                                (int) thisuser.day,
                                (int) thisuser.year);
        nl();
        prompt("Birthdate: ",s,".  Correct? ","");
        if (!yn())
          thisuser.year=0;
      } while ((!hangup) && (thisuser.year==0));
      topscreen();
      nl();
    }

    rsm(usernum,&thisuser);
    if (thisuser.waiting) {
      prt(4,"Mail Is Waiting.  Read It? ");
      if (yn())
        readmail();
    }
  }
  nscandate=thisuser.daten;
  batchtime=0.0;
  batchsize=0.0;
  numbatchdl=numbatch=0;
  strcpy(xdate,date());
  i1=0;
  for (i=0; i<20; i++) {
    if (questused[i])
      if (thisuser.votes[i]==0)
	i1=1;
  }
  if (restrict_vote & thisuser.restrict)
    i1=0;
  if (i1 && live_user) {
    nl();
    if(!(nifty.nifstatus & nif_forcevote)) pl(get_string(21)); else ex("OV","","");
    nl();
  }
  save_status();
  create_chain_file("CHAIN.TXT");
}

void logoff()
{
  long l;
  int f,r,w,t;
  char s[81];
  mailrec m;
  shortmsgrec sm;
  double ton;

  dtr(0);
  hangup=1;
  thisuser.lastrate=modem_speed;
  strcpy(thisuser.laston,xdate);
  thisuser.sl=realsl;
  thisuser.illegal=0;
  if ((timer()-timeon)<-30.0)
    timeon-=24.0*3600.0;
  ton=timer()-timeon;
  thisuser.timeon += ton;
  thisuser.timeontoday += (ton-extratimecall);
  status.activetoday += (int) (ton/60.0);
  save_status();


  time(&l);
  thisuser.daten=l;
  close_user();
  write_user(usernum,&thisuser);
  close_user();

  sprintf(s,"Read: %u   Time on: %u ",msgreadlogon,
        (int)((timer()-timeon)/60.0));

  if ((incom) || (thisuser.sl!=255) || thisuser.res[5])
    sl1(0,s);

  if (mailcheck) {
    strcpy(s,syscfg.datadir);
    sprintf(s,"%sEMAIL.DAT",syscfg.datadir);
    f=open(s,O_BINARY | O_RDWR);
    if (f!=-1) {
      t=(int) (filelength(f)/sizeof(mailrec));
      r=0;
      w=0;
      while (r<t) {
        lseek(f,(long)(sizeof(mailrec)) * (long)(r),SEEK_SET);
        read(f,(void *)&m,sizeof(mailrec));
        if ((m.tosys!=0) || (m.touser!=0)) {
          if (r!=w) {
            lseek(f,(long)(sizeof(mailrec)) * (long)(w),SEEK_SET);
            write(f,(void *)&m,sizeof(mailrec));
          }
          ++w;
        }
        ++r;
      }
      chsize(f,(long)(sizeof(mailrec)) * (long)(w));
      close(f);
    }
  }

  if (smwcheck) {
    sprintf(s,"%sSMW.DAT",syscfg.datadir);
    f=open(s,O_BINARY | O_RDWR);
    if (f!=-1) {
      t=(int) (filelength(f)/sizeof(shortmsgrec));
      r=0;
      w=0;
      while (r<t) {
        lseek(f,(long)(sizeof(shortmsgrec)) * (long)(r),SEEK_SET);
        read(f,(void *)&sm,sizeof(shortmsgrec));
        if ((sm.tosys!=0) || (sm.touser!=0)) {
          if (r!=w) {
            lseek(f,(long)(sizeof(shortmsgrec)) * (long)(w),SEEK_SET);
            write(f,(void *)&sm,sizeof(shortmsgrec));
          }
          ++w;
        }
        ++r;
      }
      chsize(f,(long)(sizeof(shortmsgrec)) * (long)(w));
      close(f);
    }
  }
  remove_from_temp("*.*",0);
}


int so()
{
  if (thisuser.sl==255 || thisuser.res[5])
    return(1);
  else
    return(0);
}



int cs()
{
  slrec ss;

  ss=syscfg.sl[thisuser.sl];
  if (so())
    return(1);
  if (ss.ability & ability_cosysop)
    return(1);
  else
    return(0);
}


int lcs()
{
  slrec ss;

  ss=syscfg.sl[thisuser.sl];
  if (cs())
    return(1);
  if (ss.ability & ability_limited_cosysop) {
    if (thisuser.sysopsub==255)
      return(1);
    if (thisuser.sysopsub==usub[cursub].subnum)
      return(1);
    else
      return(0);
  } else
    return(0);
}


void checka(int *abort, int *next)
{
  char ch;

  while ((!empty()) && (!(*abort)) && (!hangup)) {
    checkhangup();
    ch=inkey();
    lines_listed=0;
    switch(ch) {
      case 14:
      case 'N':
      case 'n':
        *next=1;
        *abort=1;
        break;
      case 3:
      case 32:
      case 24:
        *abort=1;
        nl();
        pl(get_string(26));
        break;
      case 'P':
      case 'p':
      case 19:
        ch=getkey();
        break;
    }
  }
}


void pla(char *s, int *abort)
{
  int i,next;

  i=0;
  checkhangup();
  if (hangup)
    *abort=1;
  checka(abort,&next);
  while ((s[i]) && (!(*abort))) {
    if(s[i]==';') outchr(' '); else
    outchr(s[i]);
    checka(abort,&next);
    i++;
  }
  if (!(*abort))
  if((strstr(s,";"))==NULL) nl();

}


char *ctim(double d)
{
  static char ch[10];
  long h,m,s;

  h=(long) (d/3600.0);
  d-=(double) (h*3600);
  m=(long) (d/60.0);
  d-=(double) (m*60);
  s=(long) (d);
  sprintf(ch,"%02.2ld:%02.2ld:%02.2ld",h,m,s);

  return(ch);
}


int sysop2()
{
  int ok;

  ok=sysop1();
  if (restrict_chat & thisuser.restrict)
    ok=0;
  if (syscfg.sysoplowtime != syscfg.sysophightime) {
    if (syscfg.sysophightime>syscfg.sysoplowtime) {
      if ((timer()<=(syscfg.sysoplowtime*60.0)) || (timer()>=(syscfg.sysophightime*60.0)))
        ok=0;
    } else {
      if ((timer()<=(syscfg.sysoplowtime*60.0)) && (timer()>=(syscfg.sysophightime*60.0)))
        ok=0;
    }
  }
  return(ok);
}
int reqchat2(char reason[80]);
void reqchat(char reason[80])
{
  int ok;
  char s[81];

  nl();
  nl();
  ok=sysop2();
  if (restrict_chat & thisuser.restrict)
    ok=0;
  if (ok)
    if (chatcall) {chatcall=0; chatreason[0]=0;
                   pl("Chat Call Silenced");topscreen();}
    else reqchat2(reason);
    else {
        printfile("Nosysop");
    strcpy(irt,"Tried Chatting.");
    byline[0]=0;
    imail(1,0);
  }
}

int reqchat2(char reason[80])
{
      char s[81],times=0,chated=0,cx,cy,ok;
      int x;
      cx=wherex();
      cy=wherey();
      pl(reason);
      mpl(71);
      inputl(s,71);
      if(!s[0]) return 0;

     if(thisuser.res[5])   outchr('�');
      if(nifty.nifstatus & nif_chatbeep) {
        chatcall=1; pl("Chat Call On.  SysOp will break in if they wish.");
        sprintf(chatreason,"[31;1mChat: %s",s);
        for (ok=strlen(chatreason); ok<80; ok++)
          chatreason[ok]=32;
        chatreason[80]=0;
        topscreen();
        sysoplog(chatreason);
        printfile("chat");
        return 1;
      }
     if(topdata==2)
     printf("[5;1H[0;44;1mUser Pageing...<SPACE> to Accept, <CR> to Abort");
     else if(topdata==1)
     printf("[9;1H[0;44;1mUser Pageing...<SPACE> to Accept, <CR> to Abort");
     movecsr(cx,cy);
      while(times++<11) {
        if(kbhit())  {
             s[0]=getch();
             if(s[0]==13) times=11; else if(s[0]==' ')
             if (syscfg.sysconfig & sysconfig_2_way)
             chat1("",1);
               else
             chat1("",0); times=11; chated=1;
      }

      else {
      outstr(get_string(17));
      outcomch(7);
      for(x=0;x<2000;x+=5) {
      sound(x);
      delay(1); }
      for(x=2000;x>0;x-=10) {
      sound(x);
      delay(1); }
      nosound();
     }
    }
    topscreen();
    if(!chated) {
        strcpy(chatreason,s);
        for (ok=strlen(chatreason); ok<80; ok++)
          chatreason[ok]=32;
        chatreason[80]=0;
        topscreen();
        sysoplog(chatreason);
    printfile("chat");
    }
return 1;
}

void yourinfo()
{
  char s[81],s1[101];
  int abort=0;

  outchr(12);
  sprintf(s1,"7[0Your name      7]1 %s",nam(&thisuser,usernum));
  pla(s1,&abort);
  sprintf(s1,"7[0Phone number   7]1 %s",thisuser.phone);
  pla(s1,&abort);
  if (thisuser.waiting) {
    itoa((int)thisuser.waiting,s,10);
    print("7[0Mail waiting   7]1 ",s,"");
  }
  itoa((int)thisuser.sl,s,10);
  sprintf(s1,"7[0Sec Lev        7]1 %s",s);
  pla(s1,&abort);
  itoa((int)thisuser.dsl,s,10);
  sprintf(s1,"7[0Transfer SecLev7]1 %s",s);
  pla(s1,&abort);
  itoa((int)thisuser.credits,s,10);
  sprintf(s1,"7[0Credits        7]1 %s",s);
  pla(s1,&abort);
  sprintf(s1,"7[0Last on        7]1 %s",thisuser.laston);
  pla(s1,&abort);
  itoa((int)thisuser.logons,s,10);
  sprintf(s1,"7[0Times on       7]1 %s",s);
  pla(s1,&abort);
  itoa((int)thisuser.ontoday,s,10);
  sprintf("7[0On today       7]1 %s",s);
  pla(s1,&abort);
  itoa((int)thisuser.msgpost,s,10);
  sprintf(s1,"7[0Messages posted7]1 %s",s);
  pla(s1,&abort);
  itoa((int)(thisuser.emailsent+thisuser.feedbacksent+thisuser.emailnet),s,10);
  sprintf(s1,"7[0E-mail sent    7]1 %s",s);
  pla(s1,&abort);
  ltoa((long) ((thisuser.timeon+timer()-timeon)/60.0),s,10);
  sprintf(s1,"7[0Time spent on  7]1 %s Minutes",s);
  pla(s1,&abort);
  print("3domANSI is 2",thisuser.res[10]?"On":"Off","");
  nl();
}


void upload_post()
{
  char s[81],s1[21],ch;
  int i,i1,maxli,f;
  long l,l1;

  if (thisuser.sl<45)
    maxli=30;
  else
    if (thisuser.sl<60)
      maxli=50;
    else
      if (thisuser.sl<80)
        maxli=60;
      else
        maxli=80;
  sprintf(s,"%sINPUT.MSG",syscfg.tempdir);
  l1=250*(long)maxli;

  ltoa(l1,s1,10);
  nl();
  print("You may now upload a message, max ",s1," bytes.","");
  nl();
  receive_file(s,&i1,s1,0);
  f=open(s,O_RDWR | O_BINARY);
  if (f>0) {
    l=filelength(f);
    if (l>l1) {
      nl();
      pl("Sorry, your message is too long.  Not saved.");
      nl();
      close(f);
      unlink(s);
    } else {
      close(f);
      use_workspace=1;
      nl();
      pl("Message uploaded.  The next post or email will contain that text.");
      nl();
    }
  } else {
    nl();
    pl("Nothing saved.");
    nl();
  }
}


int checkcomp(char *s)
{
  if (strstr(ctypes[thisuser.comp_type],s))
    return(1);
  else
    return(0);
}

