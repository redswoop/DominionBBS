#include "vardec.h"
#include "fcns.h"
#include <string.h>
#include <fcntl.h>
#include <sys\stat.h>
#include <io.h>


extern userrec thisuser;
extern configrec syscfg;
extern int hangup,usernum;
extern double extratimecall;



void add_time(int limit)
{
int minutes;
char s[81];

  sprintf(s,"Time in Bank: %d",thisuser.timebank); pl(s);
  pl("3Depositing Time. 2T  left online.");
  print("How many minutes would you like to deposit?","");
  prompt(": ","");
  ansic(4);
  inputl(s,3);
  minutes = atoi(s);
  if (minutes<1) return;

  if (hangup) return;

  if (minutes > (int)((nsl() - 20.0)/60.0))
    {
    nl(); nl();
    prt(3, "You do not have enough time left to deposit that much.");
    nl(); nl();
    pausescr();
    return;
    }
  if ((minutes + thisuser.timebank) > limit)
    {
    nl(); nl();
    sprintf(s, "You may only have up to %d minutes in the account", limit);
    print(s,"");
    print("at one time.","");
    nl(); nl();
    pausescr();
    return;
    }
  thisuser.timebank += minutes;
  write_user(usernum,&thisuser);
  sprintf(s, "- Deposit %d minutes.", minutes);
  sysoplog(s);
  nl();
  sprintf(s, "%d minute%c deposited.", minutes,
    ((minutes > 1) ? 's' : ''));
  prt(4, s);
  nl();

  if (extratimecall > 0)
    {
    if (extratimecall >= (double)(minutes * 60))
      {
      extratimecall -= (double)(minutes * 60);
      return;
      }
    minutes -= (int)(extratimecall / 60.0);
    extratimecall = 0.0;
    }
  thisuser.extratime -= (float)(minutes * 60);
  pausescr();
}

void remove_time()
{
char s[81];
int minutes;

  nl(); nl();
  sprintf(s, "Time in account: %d minutes.", thisuser.timebank);
  print(s,"");
  nl();
  ansic(0);
  print("How many minutes would you like to withdraw?","");
  prompt(": ","");
  ansic(4);
  inputl(s,3);
  minutes = atoi(s);
  if (minutes<1) return;

  if (hangup) return;
  if (minutes > thisuser.timebank)
    {
    nl(); nl();
    prt(6, "You don't have that much time in the account!");
    nl();
    nl();
    pausescr();
    return;
    }
  sprintf(s, "- Withdrew %d minutes.", minutes);
  sysoplog(s);
  thisuser.extratime += (float)(minutes * 60);
  thisuser.timebank -= minutes;
  nl(); nl();
  sprintf(s, "%d minute%c withdrawn.", minutes,
    ((minutes > 1) ? 's' : ''));
  prt(4, s);
  nl(); nl();
  pausescr();
}

void bank2(int limit)
{
int done = 0;
char s[81], ch;

  sysoplog("!! Entered Time Bank");
  do
    {
    tleft(0);
    printmenu(21);
    nl();
    sprintf(s,"Time in Bank: %d",thisuser.timebank); pl(s);
      outstr("5[3D5]0eposite,5[3W5]0ithdraw, 5[3Q5]0uit: ");
    ch = onek("QDW?");
    switch (ch)
      {
      case 'Q': done = 1;
                break;
      case 'D': add_time(limit);
                break;
      case 'W': remove_time();
                break;
      case '?': printmenu(21);
                pausescr();
                break;
    }
  }
  while ((!hangup) && (!done));
  nl();
 }
