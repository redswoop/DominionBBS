#include "nifrec.h"
#include "fcns.h"
#include "vars.h"
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <dos.h>
#include <alloc.h>
#include <time.h>
#include <io.h>

unsigned _stklen=15360;
int lokb,label=0;

#define modem_time 3.5

int checkpw()
{
  char s[81];

  nl();
  if(wfc||thisuser.res[5]) return 1;
  prt(2,"System Password: ");
  echo=0;
  input(s,20);
  echo=1;
  if (strcmp(s,(syscfg.systempw))==0)
    return(1);
  else
    return(0);
}



void end_bbs(int lev)
{
  sl1(1,"");
  if (ok_modem_stuff)
    closeport();
  dtr(0);
  printf("Exiting BBS with ErrorLevel: %d",lev);
  exit(lev);
}


void holdphone(int d)
{

  if (!ok_modem_stuff)
    return;
  if ((no_hangup) && (d<2))
    return;
  if ((d==1) || (d==3)) {
    if (!global_xx) {
      if (syscfg.sysconfig & sysconfig_off_hook) {
        set_baud(syscfg.baudrate[syscfg.primaryport]);
        pr1(syscfg.pickupphone);
        xtime=timer();
        global_xx=1;
      }
    }
  } else {
    if (syscfg.sysconfig & sysconfig_off_hook) {
      if (global_xx) {
        dtr(1);
        if (fabs(xtime-timer())<modem_time)
          outs("\r\n\r\nInitilizing Modem");
        while (fabs(xtime-timer())<modem_time);
        pr1(syscfg.hangupphone);
        imodem();
        global_xx=0;
      }
    }
  }
}

void sublist()
{
  int i,abort;
  char s[80],s1[81];

  abort=0;
  nl();
  if(printfile("sublist")==999)
  {
  sprintf(s1,"0Message Areas Available: ");
  pla(s1,&abort);
  nl();
  i=0;
  while ((i<32) && (usub[i].subnum!=-1)) {
    strcpy(s,usub[i].keys);
    s[2]=0;
    if (s[1]==0)
      s[1]=32;
    if (usub[i].subnum<32) {
      if ((1L << (usub[i].subnum)) & thisuser.qscn)
      { sprintf(s1," 0 ");
    strcat(s,s1); }
      else {
        sprintf(s1," 1 ");
    strcat(s,s1); }
    }
    if (syscfg.systemnumber) {
      if (subboards[usub[i].subnum].type) {
        if (subboards[usub[i].subnum].anony & anony_val_net)
          strcat(s,"[NET] ");
        else
          strcat(s,"<NET> ");
      } else
        strcat(s,"      ");
    }
    strcat(s,subboards[usub[i].subnum].name);
    pla(s,&abort);
    i++;
  }
  if (i==0)
    pla("None.",&abort);
  nl();
  }
}

void dirlist()
{
  int i,abort;
  char s[80];

  abort=0;
  nl();
  if(printfile("Dirlist")==999) {
  pla("4File Areas Available:0",&abort);
  nl();
  i=0;
  while ((i<64) && (udir[i].subnum!=-1)) {
    strcpy(s,udir[i].keys);
    s[2]=0;
    if (s[1]==0)
      s[1]=32;
    strcat(s," - ");
    strcat(s,directories[udir[i].subnum].name);
    pla(s,&abort);
    i++;
  }
  if (i==0)
    pla("None.",&abort);
  nl();
  }
}



void send_email()
{
  char s1[81],*ss;
  int i,sy,un;

  nl();
  nl();
  pl("Enter user's name or number.");
  outstr(">");
  input(s1,30);
  irt[0]=0;
  byline[0]=0;
  un=0;
  sy=0;
  ss=strchr(s1,'@');
  if (ss==NULL) {
    un=finduser1(s1);
    if (un>0)
      email(un,sy,0,0);
    else
      pl("Unknown user.");
  } else {
    ss[0]=0;
    ss=&(ss[1]);
    i=strlen(s1);
    while ((i>0) && (s1[i-1]==' '))
      --i;
    s1[i]=0;
    un=atoi(s1);
    sy=atoi(ss);
    if ((un<0) || (sy<=0) || (sy==syscfg.systemnumber)) {
      un=finduser1(s1);
      if (un>0)
        email(un,0,0,0);
      else
        pl("Unknown user.");
    } else {
      if (un==0) {
        strcpy(net_email_name,s1);
        i=strlen(net_email_name);
        while ((i>0) && (net_email_name[i-1]==' '))
          --i;
        net_email_name[i]=0;
        if (net_email_name[0])
          email(un,sy,0,0);
      } else
        email(un,sy,0,0);
    }
  }
}


void imodem()
{
  int i,done;
  char ch;
  double d;

  if (!ok_modem_stuff) return;
  movecsr(0,2);
  printf("[33;47;1;m[KSending Modem Init String");
  rts(1);
  dtr(1);
  set_baud(syscfg.baudrate[syscfg.primaryport]);
  i=0;
  done=0;
  wait1(9);
  things(79,0,1);
  printf("[35;47;1m[KWaiting for Response");
  while (!done) {
    initport(syscfg.primaryport);
    pr1(syscfg.bbs_init_modem);
    d=timer();
    dump();
    ch=0;
    while ((fabs(timer()-d)<15.0) && (ch!=13))
      ch=get1c();
    ++i;
    if ((i>5) || (ch==13))
      done=1;
  }
  things(79,0,1);
  printf("[31;47;1m[KModem Ready");
  wait1(2);
}


void answer_phone()
{
  char ch,s[81],s1[81];
  int i,i1,done;
  double d;

  _setcursortype(2);
  things(79,0,1);
  printf("[31;47;1m[KIncoming Call");
  pr1(syscfg.answer);
  done=0;
  d=timer();
  com_speed=modem_speed=syscfg.baudrate[syscfg.primaryport];
  rts(1);
  do {
    if (fabs(timer()-d)>45.0) {
      pr1("AT{");
      wait1(9);
      dump();
      return;
    }
    get_modem_line(s,(double)45.0);
    if (s[0]==1) {
      if (fabs(timer()-d)<modem_time) {
        outcomch(' ');
        things(79,0,1);
        printf("Initilising Modem.");
        while (fabs(timer()-d)<modem_time);
      }
      pr1("AT{");
      wait1(9);
      dump();
      return;
    }
    for (i=0; (i<num_result_codes); i++)
      if (stricmp(s,result_codes[i].return_code)==0) {
        strcpy(curspeed,result_codes[i].curspeed);
        if (result_codes[i].modem_speed) {
          modem_speed=result_codes[i].modem_speed;
          com_speed=result_codes[i].com_speed;
          set_baud(com_speed);
          incom=1;
          outcom=1;
        } else
          outs(curspeed);
        done=1;
      }
  } while (!done);
  wait1(18);
  if (incom) wait1(27); else wfcs();
}


int date_changed()
{
  struct date today,today1;

  getdate(&today);
  getdate(&today1);
  if (today.da_day==today1.da_day)
    return(0);
  else
    return(1);
}


void print_local_file(char *ss, char *ss1)
{
  char s[81];
  char s1[81];

  if (syscfg.sysconfig & sysconfig_list) {
    sprintf(s,"LIST %s%s",syscfg.gfilesdir,ss);
    if (ss1[0]) {
      sprintf(s1,"%s %s%s",s,syscfg.gfilesdir,ss1);
      strcpy(s,s1);
    }
    do_remote(s,1);
  } else {
    printfile(ss);
    nl();
    nl();
    getkey();
  }
}



void getcaller()
{
  char s[81],s1[81],ch,done,s2[81],*ss;
  int i,i1,i2,i3;
  double d,d1;
  long l,l1;

  frequent_init();
  com_speed=modem_speed=syscfg.baudrate[syscfg.primaryport];
  sl1(1,"");
  wait1(9);
  read_user(1,&thisuser);
  fwaiting=thisuser.waiting;
  usernum=1;
  if (thisuser.inact & inact_deleted) {
    thisuser.screenchars=80;
    thisuser.screenlines=25;
  }
  screenlinest=defscreenbottom+1;
  d=(1.0+timer()) / 102.723;
  d-=floor(d);
  d*=10000.0;
  srand((unsigned int)d);
  wfcs();
  imodem();
  wfcs();
  _setcursortype(0);
  do {
    wfc=1;
    wfct();
    if (date_changed())
      if (date_changed()) {
        printf("\n\nClock Corrupted.\n\n");
        printf("Should put BBS in a batch file like:\n\n");
        printf("copy con: bbs.bat\n");
        printf(":top\n");
        printf("setclock\n");
        printf("bbs\n");
        printf("if errorlevel 1 goto top\n");
        printf("^Z\n");
        end_bbs(noklevel);
      }
    check_event();
    if (do_event)
      run_event();
    lokb=0;
    strcpy(curspeed,"KB");
    if (((rand() % 8000)==0) && (syscfg.systemnumber) && (ok_modem_stuff))
      attempt_callout();
    okskey=0;
    _setcursortype(0);
    ch=upcase(inkey());
    if (ch) {
        _setcursortype(2);
      switch(ch) {
        case 13: wfcs(); break;
        case '1':
        case '2':
        case '3':
        case '4':
        case '5':
        case '6':
        case '7':
        case '8':
        case '9':
        case '0':
           clrscrb();
           sprintf(s2,"wfcbat%c",ch);
           sprintf(s1,"%s.shk",s);
           strcat(s2,".bat");
           if(exist(s1)) shrink_out(s2,0,0,0,1); else run_external(s2);
         wfcs();
         break;

        case '?':
           clrscrb();
          if (ok_local()) {
            printmenu(7);
            nl();
            getkey();
          }wfcs();
          break;
        case ' ':
           clrscrb();
          outs("Log on? ");
          d=timer();
          while ((!kbhitb()) && (fabs(timer()-d)<60.0));
          if (kbhitb()) {
            ch=upcase(getchd1());
            if (ch=='Y') {
              outs("Yes\r\n");
              lokb=1;
              if ((syscfg.sysconfig & sysconfig_off_hook)==0)
                dtr(0);
            }
            if ((ch=='F') && (ok_local())) {
              outs("Fast\r\n\r\n\r\n\r\n\r\n\r\n");
              read_user(1,&thisuser);
              if (thisuser.inact & inact_deleted) {
                out1ch(12);
                break;
              }
              lokb=2;
              if ((syscfg.sysconfig & sysconfig_off_hook)==0)
                dtr(0);
            }
            if (ch==0)
              getchd1();
          }
          if (!lokb)
            wfcs();
            break;

        case 'A':
          if (!ok_modem_stuff)
            {wfcs();
            break;}
          answer_phone();
          if (!incom)
            imodem();
break;
        case 'B':
           clrscrb();
          okskey=1;
          if (ok_local()) {
            holdphone(1);
            boardedit();
            holdphone(0);
          }
          okskey=0;
          wfcs();
break;

        case 'F':
           clrscrb();
          okskey=1;
          if (ok_local()) {
            holdphone(1);
            dlboardedit();
            holdphone(0);
          }
          okskey=0;
          wfcs();
break;
        case 'X':
           clrscrb();
          okskey=1;
          if (ok_local()) {
            holdphone(1);
            protedit();
            holdphone(0);
          }
          okskey=0;
          wfcs();
break;

        case 'D':
           clrscrb();
          if (ok_local()) {
            holdphone(1);
            nl();
            printf("[0m");
            pl("0Type 7EXIT0 to return to the BBS");
            outstr("3Swap to Disk?0 ");
              if(!yn()) full_external(getenv("COMSPEC"),1,0);
               else shrink_out(getenv("COMSPEC"),0,0,0,1);
             out1ch(12);
             cleanup_net();
             holdphone(0);
         }
          wfcs();
break;
        case 'I':
           clrscrb();
          okskey=1;
            if (ok_local()) {
                holdphone(1);
                voteprint();
                holdphone(0);
            }
            okskey=0;
            wfcs();
break;
        case 'V':
           clrscrb();
          okskey=1;
          if (ok_local()) {
            holdphone(1);
            ivotes();
            holdphone(0);
          }
          okskey=0;
          wfcs();
break;
        case 'L':
           clrscrb();
          if (ok_local()) {
            sl1(3,s1);
            printf("[0m");
            print_local_file(s1,status.log1);
          }
          wfcs();
break;
        case '+':
         imodem();
break;
        case 'M':
           clrscrb();
          okskey=1;
          if (ok_local()) {
            holdphone(1);
            mailr();
            holdphone(0);
          }
          okskey=0;
          wfcs();
break;
        case 'N':
           clrscrb();
          if (ok_local())
            print_local_file("NET.LOG","");
          wfcs();
break;
        case 'P':
           clrscrb();
          print_pending_list();
          wfcs();
break;
        case 'Q':
           clrscrb();
          end_bbs(255);
          wfcs();
break;
        case 'R':
           clrscrb();
          if (ok_local()) {
            read_user(1,&thisuser);
            realsl=thisuser.sl;
            usernum=1;
            if (thisuser.waiting) {
              holdphone(1);
              okskey=1;
              readmail();
              okskey=0;
              write_user(1,&thisuser);
              close_user();
              cleanup_net();
              holdphone(0);
            }
          }
          wfcs();
break;
        case 'S':
           clrscrb();
          if (ok_local()) {
            prstatus();
            getkey();
          }
          wfcs();
break;
        case 'T':
           clrscrb();
        prompt("7Run Term Program? ","");
        if(yn()) {
          if ((ok_local()) && (syscfg.terminal[0])) {
            if (syscfg.sysconfig & sysconfig_shrink_term)
              shrink_out(syscfg.terminal,0,0,0,1);
            else
              run_external(syscfg.terminal);
            imodem();
          }
        }
break;
        case 'U':
           clrscrb();
          okskey=1;
          if (ok_local()) {
            holdphone(1);
            uedit(1,0);
            holdphone(0);
          }
          okskey=0;
          wfcs();
break;
        case 'W':
           clrscrb();
          if (ok_local()) {
            read_user(1,&thisuser);
            realsl=thisuser.sl;
            usernum=1;
            useron=1;
            holdphone(1);
            okskey=1;
            send_email();
            okskey=0;
            useron=0;
            close_user();
            usernum=1;
            cleanup_net();
            holdphone(0);
          }
          wfcs();
break;
        case '!':
           clrscrb();
          if (ok_local()) {
            read_user(1,&thisuser);
            realsl=thisuser.sl;
            usernum=1;
            useron=1;
            holdphone(1);
            okskey=1;
            slash_e();
            okskey=0;
            useron=0;
            close_user();
            usernum=1;
            cleanup_net();
            holdphone(0);
          }
          wfcs();
break;

        case 'Y':
           clrscrb();
          if (ok_local()) {
            sl1(3,s1);
            printf("[0m");
            print_local_file(status.log1,s1);
          }
          wfcs();
break;
        case 'Z':
           clrscrb();
          if (ok_local()) {
            zlog();
            nl();
            getkey();
          }
          wfcs();
break;
        case '/':
           clrscrb();
          if ((syscfg.systemnumber) && (ok_local()))
            force_callout();
          wfcs();
break;

      }
      if (!incom) {
        frequent_init();
        read_user(1,&thisuser);
        fwaiting=thisuser.waiting;
        usernum=1;
      }
      okskey=0;
    }
    if ((comhit()) && (ok_modem_stuff) && (!lokb)) {
      get_modem_line(s,1.0);
      if (stricmp(s,syscfg.ring)==0) {
        answer_phone();
        if (!incom) {
          out1ch(12);
          imodem();
          imodem();
        }
      }
    }
  } while ((!incom) && (!lokb) && (!endday));
  using_modem=incom;
  if (lokb==2)
    using_modem=-1;
  okskey=1;
  if (!endday) {
    outchr(12);
    sprintf(s,"Connection established at %s.\r\n",curspeed);
    outs(s);
  }
  wfc=0;
}


void gotcaller()
{
  char s[81];
  double d;

  frequent_init();
  com_speed=syscfg.baudrate[syscfg.primaryport];
  modem_speed=(unsigned int) atol(curspeed);
  sl1(1,"");
  incom=1;
  outcom=1;
  if (!high_speed) {
    com_speed=modem_speed;
    set_baud(com_speed);
  }
  read_user(1,&thisuser);
  usernum=1;
  if (thisuser.inact & inact_deleted) {
    thisuser.screenchars=80;
    thisuser.screenlines=25;
  }
  screenlinest=25;
  outchr(12);
  sprintf(s,"Connection Established at %s.\r\n",curspeed);
  outs(s);
  using_modem=1;
  d=(timer()) / 102.723;
  d-=floor(d);
  d*=10000.0;
  srand((unsigned int)d);
}


void main(int argc, char *argv[])
{
  char s[81],s1[81],ch;
  int i,i1,i2;
  unsigned int ui;
  double dt;

  randomize();
  strcpy(s,getenv("BBS"));
  if (strncmp(s,"BBS",4)==0) {
    printf("You are already in the BBS, type 'EXIT' instead.\n\n");
    abort();
  }
  daylight=0;
  already_on=0;
  endday=0;
  oklevel=0;
  noklevel=0;
  ooneuser=0;
  no_hangup=0;
  ok_modem_stuff=1;
  if (exist("restore.wwv"))
    restoring_shrink=1;
  else
    restoring_shrink=0;

  for (i=1; i<argc; i++) {
    strcpy(s,argv[i]);
    if ((s[0]=='-') || (s[0]=='/')) {
      ch=upcase(s[1]);
      switch(ch) {
        case '?':
          printf("/Bxxxx - Someone is on at xxxx baud\n");
          printf("/Nxxx  - Exit with level xxx\n");
          printf("/Axxx  - Abnormal level xxx\n");
          printf("/O     - Quit when user logs off\n");
          printf("/H     - Don't drop carrier when user logs off\n");
          printf("/M     - Do not use modem\n");
          printf("/Z     - User connected at your highest baud rate\n\n");
          exit(0);
        case 'B':
          ui=(unsigned int) atol(&(s[2]));
          if ((ui==300) || (ui==1200) || (ui==2400) || (ui==9600) || (ui==19200) ||
              (ui==38400) || (ui==57600)) {
            itoa(ui,curspeed,10);
            already_on=1;
          }
          break;
        case 'S': already_on=1; read_user(1,&thisuser);
                  lokb=2;
                  if ((syscfg.sysconfig & sysconfig_off_hook)==0)
                      dtr(0);
                  break;
        case 'Z': ui=syscfg.baudrate[syscfg.primaryport];
                 itoa(ui,curspeed,10);
                 already_on=1;
                 break;
        case 'N':
          oklevel=atoi(&(s[2]));
          break;
        case 'A':
          noklevel=atoi(&(s[2]));
          break;
        case 'O':
          ooneuser=1;
          break;
        case 'H':
          no_hangup=1;
          break;
        case 'M':
          ok_modem_stuff=0;
          break;
      }
    }
  }

  init(1);

    if (restoring_shrink) {
    restoring_shrink=0; label=1;
    switch(restore_data("restore.wwv")) {
      case 0: /* WFC */
        goto wfc_label;
      case 1: /* main menu */
        goto main_menu_label;
    }
  }

  do {

    wait1(9);
    if (already_on)
      gotcaller();
    else
      getcaller();
    if (using_modem>-1) {
      if (!using_modem)
        holdphone(1);
      getuser(matrix());
    } else {
      holdphone(1);
      using_modem=0;
      checkit=0;
      okmacro=1;
      usernum=1;
      realsl=thisuser.sl;
      changedsl();
    }
    if (!hangup) {
      logon();
      if(thisuser.sl>syscfg.newusersl) readmenu(nifty.firstmenu);
      else if(nifty.newusermenu[0]) readmenu(nifty.newusermenu);
main_menu_label:
      while (!hangup)
          menuman();
        while (numbatch>0)
        delbatch(0);

      clrscrb();
      logoff();
    }
    frequent_init();
    if ((!no_hangup) && (using_modem) && ok_modem_stuff) {
      dtr(0);
      wait1(6);
    }
    if ((cdet()) && (!no_hangup) && (ok_modem_stuff)) {
      i=0;
      dtr(1);
      while ((i++<2) && (cdet())) {
        wait1(27);
        pr1("\001\001\001");
        wait1(54);
        if (syscfg.hangupphone[0])
          pr1(syscfg.hangupphone);
        else
          pr1("ATH{");
        wait1(6);
      }
    }
wfc_label:
    cleanup_net();
    if (!using_modem)
      holdphone(0);
    if ((!no_hangup) && ok_modem_stuff)
      dtr(0);
    already_on=0;
    if (sysop_alert && (!kbhitb())) {
      dtr(1);
      wait1(2);
      holdphone(1);
      dt=timer();
      nl();
      movecsr(0,3);
      wfcs();
      pl(">> SYSOP ALERT ACTIVATED <<");
      nl();
      while ((!kbhitb()) && (fabs(timer()-dt)<60.0)) {
        setbeep(1);
        wait1(9);
        setbeep(0);
        wait1(18);
      }
      holdphone(0);
    }
    sysop_alert=0;
  } while ((!endday) && (!ooneuser));

  outs("\x0c");
  end_bbs(oklevel);
}

