#include "fcns.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <io.h>
#include <fcntl.h>
#include <sys\stat.h>
#include <time.h>


extern subboardrec subboards[32];
extern int num_subs,hangup,userfile,useron,wfc,userfile,usernum;
extern int incom,fwaiting;
extern configrec syscfg;
extern statusrec status;
extern char cdir[81];
extern userrec thisuser;
extern unsigned char agemin,agemax,slmin,slmax,dslmin,dslmax,ressex;
extern int daysmin,daysmax,lecho;
extern unsigned short arres,darres,resres;
extern int questused[20];

char *noc(char *s) {
int x=0;
char c;

while (s[x]) {if(s[x]==3) s[x]='|'; else if (s[x]==14) s[x]='#'; x++; }
return (s);
}

void boarddata(int n, char *s)
{
  char x,y,k,i,s1[81];
  subboardrec r;

  r=subboards[n];
  if (r.ar==0)
    x=32;
  else {
    for (i=0; i<16; i++)
      if ((1 << i) & r.ar)
        x='A'+i;
  }
  strcpy(s1,noc(r.name));
  sprintf(s,"3%2d 3%1c  3%-40s  3%-8s 3%-3d 3%-3d 3%-3d 3%-3d ",
            n,x,s1,r.filename,r.readsl,r.postsl,r.age,r.maxmsgs);
}

void showsubs()
{
  int abort,i;
  char s[180];

  outchr(12);
  abort=0;
  pla("0NN2�0AR2�0Name2��������������������������������������0FileName2�0Rsl2�0Psl2�0Age2�0Max",
      &abort);
  for (i=0; (i<num_subs) && (!abort); i++) {
    boarddata(i,s);
    pla(s,&abort);
  }
}




void modify_sub(int n)
{
  subboardrec r;
  char s[81],s1[81],ch,ch2;
  int i,i1,done;

  done=0;
  r=subboards[n];

  do {
    outchr(12);
    print("1. Name       : ",r.name,"");
    print("2. Filename   : ",r.filename,"");
    if (r.key==0)
      strcpy(s,"None");
    else {
      s[0]=r.key;
      s[1]=0;
    }
    print("3. Key        : ",s,"");
    itoa(r.readsl,s,10);
    print("4. Read SL    : ",s,"");
    itoa(r.postsl,s,10);
    print("5. Post SL    : ",s,"");
    switch(r.anony & 0x0f) {
      case 0: strcpy(s,"No."); break;
      case anony_enable_anony: strcpy(s,"Yes."); break;
      case anony_enable_dear_abby: strcpy(s,"Dear Abby."); break;
      case anony_force_anony: strcpy(s,"Forced."); break;
      case anony_real_name: strcpy(s,"Real Name."); break;
      default: strcpy(s,"Real screwed up."); break;
    }
    print("6. Anony      : ",s,"");
    itoa(r.age,s,10);
    print("7. Min. Age   : ",s,"");
    itoa(r.maxmsgs,s,10);
    print("8. Max Msgs   : ",s,"");
    strcpy(s,"None.");
    if (r.ar!=0) {
      for (i=0; i<16; i++)
        if ((1 << i) & r.ar)
          s[0]='A'+i;
      s[1]=0;
    }
    print("9. AR         : ",s,"");
    ltoa((unsigned long) r.type,s,10);
    print("A. Sub Type   : ",s,"");
    itoa(r.storage_type,s,10);
    print("B. Storage typ: ",s,"");
    if (r.anony & anony_val_net)
      strcpy(s,"Yes");
    else
      strcpy(s,"No");
    print("C. Val network: ",s,"");
    if (r.anony & anony_ansi_only)
      strcpy(s,"Yes");
    else
      strcpy(s,"No");
    print("D. Req ANSI   : ",s,"");


    nl();
    prt(7,"Which (1-9,A-D,Q,J,[,]) ? ");
    ch=onek("Q123456789ABCDJ[]");
    switch(ch) {
      case ']': if((n>=0) && (n<num_subs-1))
      { subboards[n++]=r;
        r=subboards[n];
        } break;

      case '[': if(n>0) { subboards[n--]=r;
                          r=subboards[n];
                          } break;
      case 'J': nl(); prompt("To Which Sub? ","");
                input(s,3);
                if(s[0]) {
                    i=atoi(s);
                    subboards[n]=r;
                    r=subboards[i];
                } break;
      case 'Q':done=1; break;
      case '1':
        nl();
        strcpy(s1,"");
        prt(7,"New Name? ");
        inli(s,s1,40,1);
        if (s[0])
          strcpy(r.name,s);
        break;
      case '2':
        nl();
        prt(7,"New Filename? ");
        input(s,8);
        if ((s[0]!=0) && (strchr(s,'.')==0))
          strcpy(r.filename,s);
        break;
      case '3':
        nl();
        prt(7,"New Key (spc=none) ? ");
        ch2=onek("@#$%^&()-_=+\\|][{};:'\",<>`~ ");
        if (ch2==32)
          r.key=0;
        else
          r.key=ch2;
        break;
      case '4':
        nl();
        prt(7,"New Read SL? ");
        input(s,3);
        i=atoi(s);
        if ((i>=0) && (i<256) && (s[0]))
          r.readsl=i;
        break;
      case '5':
        nl();
        prt(7,"New Post SL? ");
        input(s,3);
        i=atoi(s);
        if ((i>=0) && (i<256) && (s[0]))
          r.postsl=i;
        break;
      case '6':
        nl();
        prt(7,"New Anony (Y,N,D,F,R) ? ");
        ch2=onek("NYDFR");
        r.anony &= 0xf0;
        switch(ch2) {
          case 'N': break;
          case 'Y': r.anony |= anony_enable_anony; break;
          case 'D': r.anony |= anony_enable_dear_abby; break;
          case 'F': r.anony |= anony_force_anony; break;
          case 'R': r.anony |= anony_real_name; break;
        }
        break;
      case '7':
        nl();
        prt(7,"New Min Age? ");
        input(s,3);
        i=atoi(s);
        if ((i>=0) && (i<128) && (s[0]))
          r.age=i;
        break;
      case '8':
        nl();
        prt(7,"New Max Msgs? ");
        input(s,3);
        i=atoi(s);
        if ((i>0) && (i<255) && (s[0]))
          r.maxmsgs=i;
        break;
      case '9':
        nl();
        prt(7,"New AR (<SPC>=None) ? ");
        ch2=onek("ABCDEFGHIJKLMNOP ");
        if (ch2==32)
          r.ar=0;
        else
          r.ar=1 << (ch2-'A');
        break;
      case 'A':
        nl();
        prt(7,"New Sub Type? ");
        input(s,5);
        i=atoi(s);
        if (s[0])
          r.type=i;
        break;
      case 'B':
        nl();
        prt(7,"New Storage Type (0,1,2) ? ");
        input(s,4);
        i=atoi(s);
        if ((s[0]) && (i>=0) && (i<=2))
          r.storage_type=i;
        break;
      case 'C':
        nl();
        prt(7,"Require sysop validation for network posts? ");
        r.anony &= ~anony_val_net;
        if (yn())
          r.anony |= anony_val_net;
        break;
      case 'D':
        nl();
        prt(7,"Require ANSI to read this sub? ");
        r.anony &= ~anony_ansi_only;
        if (yn())
           r.anony |= anony_ansi_only;
        changedsl();
        break;
    }
  } while ((!done) && (!hangup));
  subboards[n]=r;
  if (!wfc)
    changedsl();
}


void insert_sub(int n)
{
  subboardrec r;
  int i,i1,nu;
  userrec u;
  long l1,l2,l3;

  for (i=num_subs-1; i>=n; i--)
    subboards[i+1]=subboards[i];
  strcpy(r.name,"** NEW SUB **");
  strcpy(r.filename,"NONAME");
  r.key=0;
  r.readsl=10;
  r.postsl=20;
  r.anony=0;
  r.age=0;
  r.maxmsgs=50;
  r.ar=0;
  r.type=0;
  r.storage_type=2;
  subboards[n]=r;
  ++num_subs;
  read_user(1,&u);
  nu=(int) (filelength(userfile) / sizeof(userrec));
  l1=0xffffffff >>(32-n);
  l2=0xffffffff <<(n+1);
  l3=1L << n;
  for (i=1; i<nu; i++) {
    read_user(i,&u);
    if (u.sysopsub!=255)
      if (u.sysopsub>=n)
        ++u.sysopsub;
    for (i1=num_subs-1; i1>n; i1--)
      u.qscnptr[i1]=u.qscnptr[i1-1];
    u.qscnptr[n]=0L;
    u.qscn=(u.qscn & l1) | ((u.qscn << 1) & l2) | l3;
    write_user(i,&u);
  }
  modify_sub(n);
}


void delete_sub(int n)
{
  int i,i1,nu;
  userrec u;
  long l1,l2;

  for (i=n; i<num_subs; i++)
    subboards[i]=subboards[i+1];
  --num_subs;
  read_user(1,&u);
  nu=(int) (filelength(userfile) / sizeof(userrec));
  l1=0xffffffff >>(32-n);
  l2=0xffffffff <<(n);
  for (i=1; i<nu; i++) {
    read_user(i,&u);
    if (u.sysopsub==n)
      u.sysopsub=255;
    else
      if ((u.sysopsub>n) && (u.sysopsub!=255))
        --u.sysopsub;
    for (i1=n; i1<num_subs; i1++)
      u.qscnptr[i1]=u.qscnptr[i1+1];
    u.qscnptr[31]=0L;
    u.qscn=(u.qscn & l1) | ((u.qscn >> 1) & l2);
    write_user(i,&u);
  }
  if (!wfc)
    changedsl();
}


void boardedit()
{
  int i,i1,i2,done,f;
  char s[81],s1[81],s2[81],ch;

  if (!checkpw())
    return;
  showsubs();
  done=0;
  do {
    nl();
    outstr("5[3D5]0elete, 5[3I5]0nsert, 5[3M5]0odify, 5[3Q5]0uit: ");
    ch=onek("QDIM?");
    switch(ch) {
      case '?':
        showsubs();
        break;
      case 'Q':
        done=1;
        break;
      case 'M':
        nl();
        prt(7,"Sub number? ");
        input(s,2);
        i=atoi(s);
        if ((s[0]!=0) && (i>=0) && (i<num_subs))
          modify_sub(i);
        break;
      case 'I':
        if (num_subs<32) {
          nl();
          prt(7,"Insert before which sub? ");
          input(s,2);
          i=atoi(s);
          if ((s[0]!=0) && (i>=0) && (i<=num_subs))
            insert_sub(i);
        }
        break;
      case 'D':
        nl();
        prt(7,"Delete which sub? ");
        input(s,2);
        i=atoi(s);
        if ((s[0]!=0) && (i>=0) && (i<num_subs)) {
          nl();
          sprintf(s1,"Delete %s? ",subboards[i].name);
          prt(7,s1);
          if (yn())
            delete_sub(i);
        }
        break;
    }
  } while ((!done) && (!hangup));
  sprintf(s,"%sSUBS.DAT",syscfg.datadir);
  f=open(s,O_RDWR | O_BINARY | O_CREAT | O_TRUNC, S_IREAD | S_IWRITE);
  write(f,(void *)&subboards[0], num_subs * sizeof(subboardrec));
  close(f);
}

