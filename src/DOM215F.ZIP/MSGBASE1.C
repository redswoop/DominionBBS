#include "fcns.h"
#include <fcntl.h>
#include <io.h>
#include <sys\stat.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <dos.h>
#include <alloc.h>
#include <stdio.h>
#include <dir.h>
#include "nifrec.h"

extern subboardrec subboards[32];
extern niftyrec nifty;
extern usersubrec usub[32];
extern int cursub,express,expressabort,num_sys_list,screenlinest;
extern int curlsub,nummsgs;
extern postrec *msgs;
extern configrec syscfg;
extern int bchanged;
extern userrec thisuser;
extern int hangup,incom;
extern int heymsg;
extern int usernum,using_modem,topline,defscreenbottom;
extern statusrec status;
extern char irt[81],cdir[81],net_email_name[81],byline[81];
extern messagerec menus[30];
extern int fwaiting,fsenttoday,msgreadlogon,useron,wfc,mailcheck,numed;
extern editorrec *editors,*backuped;
extern short gat[2048];
extern int reply,thread;     /*NEW*/
extern char gatfn[81];
extern int use_workspace;
extern int checked[50];
extern char *quote;                                        /* mod - add V3 */

#define ALLOW_FULLSCREEN 1
#define EMAIL_STORAGE 2

int deleted_flag;

/****************************************************************************/

void send_net_post(postrec *p, unsigned int type, char *extra)
{
  net_header_rec nh;
  char *b, *b1;
  long len1, len2;
  char s[81];
  int f,i;
  unsigned int *list;

  b=readfile(&(p -> msg),extra,&len1);
  if (b==NULL)
    return;
  nh.tosys=0;
  nh.touser=0;
  if (p -> ownersys)
    nh.fromsys=p -> ownersys;
  else
    nh.fromsys =syscfg.systemnumber;
  nh.fromuser=p -> owneruser;
  nh.main_type=main_type_post;
  nh.minor_type=type;
  nh.list_len=0;
  nh.daten=p -> daten;
  nh.length=len1+1+strlen(p -> title);
  nh.method=0;
  if ((b1=malloca(nh.length+100))==NULL) {
    farfree(b);
    return;
  }
  strcpy(b1,p -> title);
  memmove(&(b1[strlen(p -> title)+1]),b,(unsigned int) len1);
  farfree(b);
  if ((list=malloca(2*(num_sys_list+2)))==NULL) {
    farfree(b1);
    return;
  }
  sprintf(s,"%sN%u.NET",syscfg.datadir,type);
  f=open(s,O_RDONLY | O_BINARY);
  if (f>0) {
    len1=filelength(f);
    if ((b=malloca(len1+100L))==NULL) {
      farfree(list);
      farfree(b1);
      return;
    }
    lseek(f,0L,SEEK_SET);
    read(f,(void *)b,len1);
    b[len1]=0;
    close(f);
    len2=0;
    while (len2<len1) {
      while ((len2<len1) && ((b[len2]<'0') || (b[len2]>'9')))
        ++len2;
      if ((b[len2]>='0') && (b[len2]<='9') && (len2<len1)) {
        i=atoi(&(b[len2]));
        if ((i!=syscfg.systemnumber) && (i != p -> ownersys))
          list[nh.list_len++]=i;
        while ((len2<len1) && (b[len2]>='0') && (b[len2]<='9'))
          ++len2;
      }
    }
    farfree(b);
  }
  if (nh.list_len) {
    strcpy(s,syscfg.datadir);
    if (nh.fromsys!=syscfg.systemnumber)
      strcat(s,"P1.NET");
    else
      strcat(s,"P0.NET");
    f=open(s,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
    lseek(f,0L,SEEK_END);
    write(f,(void *)&nh,sizeof(net_header_rec));
    write(f,(void *)list,2*nh.list_len);
    write(f,(void *)b1,nh.length);
    close(f);
  }

  sprintf(s,"%sNN%u.NET",syscfg.datadir,subboards[curlsub].type);
  f=open(s,O_RDONLY | O_BINARY);
  nh.list_len=0;
  nh.main_type=main_type_pre_post;
  if (f>0) {
    len1=filelength(f);
    if ((b=malloca(len1+100L))==NULL) {
      farfree(b1);
      farfree(list);
      return;
    }
    lseek(f,0L,SEEK_SET);
    read(f,(void *)b,len1);
    b[len1]=0;
    close(f);
    len2=0;
    while (len2<len1) {
      while ((len2<len1) && ((b[len2]<'0') || (b[len2]>'9')))
        ++len2;
      if ((b[len2]>='0') && (b[len2]<='9') && (len2<len1)) {
        i=atoi(&(b[len2]));
        if ((i!=syscfg.systemnumber) && (i != p -> ownersys))
          list[nh.list_len++]=i;
        while ((len2<len1) && (b[len2]>='0') && (b[len2]<='9'))
          ++len2;
      }
    }
    farfree(b);
  }
  if (nh.list_len) {
    strcpy(s,syscfg.datadir);
    if (nh.fromsys!=syscfg.systemnumber)
      strcat(s,"P1.NET");
    else
      strcat(s,"P0.NET");
    f=open(s,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
    lseek(f,0L,SEEK_END);
    write(f,(void *)&nh,sizeof(net_header_rec));
    write(f,(void *)list,2*nh.list_len);
    write(f,(void *)b1,nh.length);
    close(f);
  }
  farfree(list);
  farfree(b1);
}

/****************************************************************************/

void post()
{
  messagerec m;
  postrec p;
  char s[121],*b,*b1;
  int i,dm,a,f;
  slrec ss;
  net_header_rec nh;
  long len1,len2;
  unsigned int *list;

  iscan(cursub);
  if (curlsub<0) {
    nl();
    pl("No subs available.");
    nl();
    return;
  }

  ss=syscfg.sl[thisuser.sl];

  if (freek1(syscfg.msgsdir)<10.0) {
    nl();
    pl("Sorry, not enough disk space left.");
    nl();
    return;
  }

  if ((restrict_post & thisuser.restrict) || (thisuser.posttoday>=ss.posts)) {
    nl();
    pl("Too many messages posted today.");
    nl();
    return;
  }

  if (thisuser.sl<subboards[curlsub].postsl) {
    nl();
    pl("You can't post here.");
    nl();
    return;
  }

  m.storage_type=subboards[curlsub].storage_type;
  a=subboards[curlsub].anony & 0x0f;
  if ((a==0) && (ss.ability & ability_post_anony))
    a=anony_enable_anony;
  if ((a==anony_enable_anony) && (thisuser.restrict & restrict_anony))
    a=0;
  if (subboards[curlsub].type) {
    a &= (anony_real_name);
    if (thisuser.restrict & restrict_net) {
      nl();
      pl("You can't post on networked sub-boards.");
      nl();
      return;
    }
    if (thisuser.restrict & (restrict_validate | restrict_auto_msg_delete)) {
      nl();
      pl("You can't post on networked sub-boards.");
      nl();
      return;
    }
    if (syscfg.systemnumber) {
      nl();
      pl(get_string(23));
      nl();
    }
  }
  inmsg(&m,p.title,&a,1,(subboards[curlsub].filename),ALLOW_FULLSCREEN);
  if (m.stored_as!=0xffffffff) {
    p.anony=a;
    p.msg=m;
    p.ownersys=0;
    p.owneruser=usernum;
    p.qscan=status.qscanptr++;
    time((long *)(&p.daten));
    if (thisuser.restrict & restrict_auto_msg_delete)
      p.status=status_delete;
    else
      if (thisuser.restrict & restrict_validate)
        p.status=status_unvalidated;
      else
        p.status=0;
    if ((subboards[curlsub].type) && (syscfg.systemnumber) &&
      (subboards[curlsub].anony & anony_val_net) && (!lcs())) {
      p.status |= status_pending_net;
      dm=1;
      for (i=1; i<=nummsgs; i++)
        if (msgs[i].status & status_pending_net)
          dm=0;
      if (dm) {
        sprintf(s,"Unvalidated net posts on %s.",subboards[curlsub].name);
        ssm(1,0,s);
      }
    }
    if (nummsgs>=subboards[curlsub].maxmsgs) {
      i=1;
      dm=0;
      while ((dm==0) && (i<=nummsgs)) {
        if ((msgs[i].status & status_no_delete)==0)
          dm=i;
        ++i;
      }
      if (dm==0)
        dm=1;
      delete(dm);
      deleted_flag=dm;
    }
    msgs[++nummsgs]=p;
    bchanged=1;
    savebase();
    ++thisuser.msgpost;
    ++thisuser.posttoday;
    ++status.msgposttoday;
    save_status();
    topscreen();
    sprintf(s,"+%s posted on %s",p.title,subboards[curlsub].name);
    sysoplog(s);
    sprintf(s,"Posted on %s",subboards[curlsub].name);
    save_status();
    pl(s);
    backspace();
    if ((subboards[curlsub].type) && (syscfg.systemnumber)) {
      ++thisuser.postnet;
      if (((subboards[curlsub].anony & anony_val_net)==0) || (lcs()))
        send_net_post(&p, subboards[curlsub].type, subboards[curlsub].filename);
    }
  }
}


void extract_out(char *b, long len)
{
  char s1[81],s2[81],ch=26,ch1;
  int i;

  do {
    prt(2,"Save under what filename? ");
    input(s1,12);
    if (s1[0]) {
      sprintf(s2,"%s%s",syscfg.gfilesdir,s1);
      if (exist(s2)) {
        nl();
        pl("Filename already in use.");
        nl();
        prt(2,"O)verwrite, A)ppend, N)ew name, Q)uit? ");
        ch1=onek("QOAN");
        switch(ch1) {
          case 'Q':
            s2[0]=0;
            s1[0]=0;
            break;
          case 'N':
            s1[0]=0;
            break;
          case 'A':
            break;
          case 'O':
            unlink(s2);
            break;
        }
        nl();
      }
    } else
      s2[0]=0;
  } while ((!hangup) && (s2[0]!=0) && (s1[0]==0));
  if ((s1[0]) && (!hangup)) {
    i=open(s2,O_RDWR | O_BINARY | O_CREAT , S_IREAD | S_IWRITE);
    lseek(i,0L,SEEK_END);
    write(i,(void *)b,len);
    write(i,&ch,1);
    close(i);
    print("Message written to: ",s2,".","");
  }
  farfree(b);
}

void grab_user_name(messagerec *m, char *fn)
{
  char *ss,*ss1;
  long len;

  ss=readfile(m,fn,&len);
  if (ss) {
    ss1=strchr(ss,'\r');
    if (ss1) {
      *ss1=0;
      strcpy(net_email_name,ss);
    } else
      net_email_name[0]=0;
    farfree(ss);
  } else
    net_email_name[0]=0;
}

void quote_message(messagerec *m1, char *aux)    /* mod - add entire void V3 */
{
  char *b,*c,s1[81];
  int cc,dq,lc,f,ok,mc;
  long l,l1,l2,l3,l4;
  messagerec m;

  m=*m1;
  b=readfile(&m,aux,&l);
  if (b==NULL)
    return;
  if ((c=malloca(l+1000L))==NULL) {
    farfree(b);
    return;
  }
  lc=0; l1=0; l2=0; ok=1;
  do {
    if (b[l1]==10)
      lc++;
    l1++;
  } while (lc<2);
  lc=0; dq=1; cc=48;
  do {
    if (lc==0) {
      for (f=0; f<dq; f++) {
        c[l2++]='>'; lc++;
      }
      if (dq==1) {
        c[l2++]=' '; lc++;
      }
      if (cc!=48) {
        c[l2++]=3;
        c[l2++]=cc;
      }
    }
    switch(b[l1]) {
      case 1:
        if (b[l1-1]!=32)
          c[l2++]=' ';
        l1+=3;
        break;
      case 3:
        l1++;
        cc=b[l1++];
        c[l2++]=3;
        c[l2++]=cc;
        break;
      case 4:
        l1+=2;
        break;
      case 13:
        if ((b[l1+2]>96) && (b[l1+2]<123)) {
          if (b[l1-1]!=32)
            c[l2++]=' ';
          l1+=2;
        } else {
          lc=0; l1+=2;
          if (dq==1) {
            cc=48;
            c[l2++]=3;
            c[l2++]=48;
          }
          dq=1;
          while (b[l1]=='>') {
            dq++; l1++;
          }
          if (dq>=6)
            ok=0;
          c[l2++]=13;
          c[l2++]=10;
        }
        break;
      default:
        c[l2++]=b[l1++];
        lc++;
        break;
    }
    if (dq==1)
      mc=72;
    else
      mc=78;
    if (lc>=mc) {
      l3=l1; l4=l2;
      while ((b[l1]!=32) && (lc>0)) {
        --l1; --l2; --lc;
        if ((b[l1]==3) || (b[l1]==4))
          lc+=2;
        if (b[l1]==1) {
          l2+=3; lc+=3;
        }
        if ((b[l1]==13) && (b[l1-1]>4)) {
          lc+=2;
        }
      }
      if (lc<=1) {
        l1=l3; l2=l4;
      } else {
        lc=0;
        l1++;
      }
      c[l2++]=13;
      c[l2++]=10;
    }
  } while ((l1<l) && (l2<l+998L) && (ok));
  c[l2++]=0;
  if (ok) {
    sprintf(s1,"%sQUOTE.MSG",syscfg.tempdir);
    f=open(s1,O_RDWR | O_BINARY | O_CREAT | O_TRUNC, S_IREAD | S_IWRITE);
    write(f,(void *)c,l2);
    close(f);
    farfree(b);
    farfree(c);
    f=open(s1,O_RDONLY | O_BINARY);
    l2=filelength(f);
    if ((quote=malloca(l2))!=NULL)
      read(f,(void *) quote,l2);
    close(f);
    unlink(s1);
  }
}

void scan(int msgnum, int optype, int *nextsub)
{
  char s[81],s1[81],s2[81],*b,*ss1;
  int i,i1,i2,done,quit,abort,next,val,realexpress;
  int tst,hold,hold1,numrply,hold2;         /*NEW*/
  char s3[81],s4[81],s5[81],s6[81];        /*NEW*/
  slrec ss;
  long l,len;
  postrec p,p1;


  irt[0]=0;
  byline[0]=0;
  thread=0;
  done=0;
  quit=0;
  val=0;
  realexpress=express;
  iscan(cursub);
  if (curlsub<0) {
    nl();
    pl("No subs available.");
    nl();
    return;
  }
  do {
    tleft(1);
    switch(optype) {
case 0: /* Read Prompt */
        strcpy(s,"");
        reply=1;                                   
        heymsg=msgnum;
        if (thread)                                    
        sprintf(s,"7Threading.M");
         if (thread)                                                 
          strcat(s,"3(0>3)1Forward 3(0<3)1Backward, 3<0Q3>1uitM");
         else {                                                      
           hold2=msgnum;
           numrply=0;
           abort=0;
            strcpy(s6,msgs[msgnum].title);
            if (strncmp(s,"5RE: 3",8)!=0) {
             strcpy(s4,"5RE: 3");
             strcat(s4,s6);
           }  else
             strcpy(s4,s6);
             strcpy(s1,s6);
             while ((!abort) && (!hangup) && (hold2<nummsgs)) {
              ++hold2;
              strcpy(s6,msgs[hold2].title);
              if ((strncmp(s6,s4,60)==0) || (strcmp(s6,s1)==0)) 
               ++numrply;
            }
         if (numrply) {
           sprintf(s1,"7>>0This Message has 3%d0 Replies",numrply);
           strcat(s,s1);
           numrply=0; hold2=0; abort=0;
           }
        }

        if (express) {
          s[0]=0;
          nl();
        } else {
          if(s[0]) pl(s);
          outstr(get_string(14));
          input(s,3);
      while (s[0]==32 &&!thread) {
	    strcpy(s1,&(s[1]));
	    strcpy(s,s1);
	  }
        }
        optype=0;
        i=atoi(s);
        if (s[0]==0&&!thread) {
          i=msgnum+1;
          if (i>=nummsgs+1)
            done=1;
        }
        if ((i!=0) && (i<=nummsgs) && (i>=1)&&!thread) {
          optype=2;
          msgnum=i;
        } else
          if (s[1]==0) {
            switch(s[0]) {
                case 'Q':
                 if(!thread) {
                   done=1;
                   quit=1;
                   *nextsub=0;
                   break; }
                   else {
                  pl("No Longer in thread system");
                   thread=0;
                  msgnum=hold1;
                 } break;

         case '>':                               /* thread forward */
            if (!thread) {            /*NEW*/
              hold1=msgnum;           /*NEW*/
              thread=1;               /*NEW*/
           }                          /*NEW*/
            hold=msgnum;
            tst=0;
            abort=0;
            if (msgnum>=nummsgs) {
             nl();
             prt(2,"That was the last message in this area!");
             nl();
             nl();
             abort=1;
           }
            strcpy(s,msgs[msgnum].title);
            if (strncmp(s,"5RE: 3",8)!=0) {
             strcpy(s4,"5RE: 3");
             strcat(s4,s);
           }  else
             strcpy(s4,s);
             while ((!abort) && (!hangup)) {
              ++msgnum;
              strcpy(s,msgs[msgnum].title);
              if (strncmp(s,s4,60)==0) {
               tst=2;
               abort=1;
             }
             if (msgnum>nummsgs) {
             nl();
             prt(2,"There are no more messages available in this thread.");
             nl();
             nl();
             msgnum=hold; 
             abort=1;
           }
         }
             optype=tst;
             break;

         case '<':                               /* thread reverse */
            if (!thread) {                   /*NEW*/
              hold1=msgnum;                  /*NEW*/
              thread=1;                      /*NEW*/
           }
            hold=msgnum;
            tst=0;
            abort=0;
            if (msgnum<=1) {
             nl();
             prt(2,"That are no messages before this one!");
             nl();
             nl();
             abort=1;
           }
            strcpy(s,msgs[msgnum].title);
            if (strncmp(s,"5RE: 3",8)!=0)   
             abort=1;                        
             strcpy(s4,s);
             memmove(s5,&s4[8],52);
             while ((!abort) && (!hangup)) {
              --msgnum;
              strcpy(s,msgs[msgnum].title);
              if ((strncmp(s,s4,60)==0) || (strncmp(s,s5,60)==0)) {
               tst=2;
               abort=1;
             }
             if (msgnum<1) {
             nl();
             prt(2,"That was the first message available in this thread.");
             nl();
             nl();
             msgnum=hold; 
             abort=1;
           }
         }
             optype=tst;
             break;

               case 'S':
               nl();
              outstr("Kill from Newscan?");
              if(yn()) {
                b=usub[cursub].keys;
                 for (i=0; i<32; i++) {
                 if (strcmp(usub[i].keys,b)==0)
                thisuser.qscn ^=((1L) << (usub[i].subnum));
                 }
              }
               if (*nextsub!=0&&!thread) {
                *nextsub=1;
                done=1;
                quit=1;
                 }
               else
                 if (*nextsub!=0) {
                 *nextsub=1;
                 done=1;
                 quit=1;
               }
               break;                 /* End MOD */

              case 'T':
              if(!thread)
                optype=1;
                break;
              case 'R':
                optype=2;
                break;
	      case 'A':
          prompt("Email Author? ","");
          if(!yn()) break;
	      byline[0]=0;
                   quote_message(&(msgs[msgnum].msg),(subboards[curlsub].filename));
		if ((msgs[msgnum].ownersys) && (!msgs[msgnum].owneruser))
		  grab_user_name(&(msgs[msgnum].msg),subboards[curlsub].filename);
		ss=syscfg.sl[thisuser.sl];
		if ((lcs()) || (ss.ability & ability_read_post_anony) || (msgs[msgnum].anony==0))
		  email(msgs[msgnum].owneruser,msgs[msgnum].ownersys,0,0);
		else
		  email(msgs[msgnum].owneruser,msgs[msgnum].ownersys,0,msgs[msgnum].anony);
				 if (quote!=NULL) {                           /* mod - add V3 */
		  farfree(quote);                            /* mod - add V3 */
		  quote=NULL;                                /* mod - add V3 */
		}                                            /* mod - add V3 */
                break;
              case 'P':
		irt[0]=0;
        reply=0;
		byline[0]=0;
	      case 'W':
		if (s[0]!='P')                               /* mod - add */
		  quote_message(&(msgs[msgnum].msg),         /* mod - add */
		    (subboards[curlsub].filename));          /* mod - add */
		deleted_flag=0;
		post();
				if (quote!=NULL) {                           /* mod - add V3 */
		  farfree(quote);                            /* mod - add V3 */
		  quote=NULL;                                /* mod - add V3 */
		}                                            /* mod - add V3 */
 
                if (deleted_flag && (deleted_flag<=msgnum))
                  --msgnum;
                break;
                      case '?':
		if (lcs())
		  printmenu(13);
		else
                  printmenu(1);
                break;
	      case '-':
		if ((msgnum>1) && (msgnum-1<nummsgs)) {
		  --msgnum;
		  optype=2;
		}
		break;
	      case 'C':
		express=1;
		break;
         case 'V':
                if ((cs()) && (msgs[msgnum].ownersys==0) && (msgnum>0) && (msgnum<=nummsgs))
                  valuser(msgs[msgnum].owneruser);
		else
                  if ((cs()) && (msgnum>0) && (msgnum<=nummsgs)) {
		    nl();
		    pl("Post from another system.");
		    nl();
		  }
                break;
	      case 'N':
		if ((lcs()) && (msgnum>0) && (msgnum<=nummsgs)) {
		  msgs[msgnum].status ^= status_no_delete;
                  bchanged=1;
		  nl();
		  if (msgs[msgnum].status & status_no_delete)
                    pl("Message is Not Permament");
		  else
            pl("Message is Permanent");
		  nl();
		}
		break;
              case 'X':
		if ((lcs()) && (msgnum>0) && (msgnum<=nummsgs)) {
                  msgs[msgnum].status ^= status_pending_net;
                  bchanged=1;
		  nl();
                  if (msgs[msgnum].status & status_pending_net) {
                    val |= 2;
                    pl("Will be sent out on net now.");
                  } else
                    pl("Not set for net pending now.");
		  nl();
		}
		break;
	      case 'U':
		if ((lcs()) && (msgnum>0) && (msgnum<=nummsgs)) {
		  msgs[msgnum].anony=0;
                  bchanged=1;
		  nl();
                  pl("Message is not anonymous now.");
		}
		break;
              case 'D':
                if (lcs()) {
                  if (msgnum) {
                    delete(msgnum);
                    if (msgnum>1)
                      msgnum--;
                  }
                }
                break;
	      case 'E':
		if (so()) {
                  if ((msgnum>0) && (msgnum<=nummsgs)) {
                    b=readfile(&(msgs[msgnum].msg),(subboards[curlsub].filename),&len);
                    extract_out(b,len);
                  }
		}
		break;
	      case 'M':
		if ((cs()) && (msgnum>0) && (msgnum<=nummsgs)) {
                  nl();
		  do {
                    prt(2,"Move to which sub? ");
                    ss1=mmkey(0);
		    if (ss1[0]=='?')
		      sublist();
		  } while ((!hangup) && (ss1[0]=='?'));
		  i=-1;
		  if (ss1[0]==0)
		    break;
                  for (i1=0; i1<32; i1++)
                    if (strcmp(usub[i1].keys,ss1)==0)
                      i=i1;
                  if (i!=-1) {
		    p=msgs[msgnum];
                    b=readfile(&(p.msg),(subboards[curlsub].filename),&len);
                    delete(msgnum);
		    savebase();
                    iscan(i);
		    p.msg.storage_type=subboards[curlsub].storage_type;
		    savefile(b,len,&(p.msg),(subboards[curlsub].filename));
                    p.qscan=status.qscanptr++;
		    if (nummsgs>=subboards[curlsub].maxmsgs) {
                      i1=1;
                      i2=0;
                      while ((i2==0) && (i1<=nummsgs)) {
                        if ((msgs[i1].status & status_no_delete)==0)
                          i2=i1;
                        ++i1;
                       }
                       if (i2==0)
                         i2=1;
                       p1=msgs[i2];
                       remove_link(&p1.msg,(subboards[curlsub].filename));
                       for (i1=i2; i1<nummsgs; i1++)
                         msgs[i1]=msgs[i1+1];
		       --nummsgs;
                     }
                     msgs[++nummsgs]=p;
                     bchanged=1;
                     savebase();
                     save_status();
                     iscan(cursub);
		     nl();
		     pl("Message moved.");
		     nl();
		  }
		}
		break;
/*************/
            }
	  } else {
	    if (strcmp(s,"CLS")==0)
	      outchr('\x0c');
	  }
        break;
      case 1: /* List Titles */
        i=0;
        abort=0;
        if (msgnum>=nummsgs)
          abort=1;
        while ((!abort) && (!hangup) && (++i<=10)) {
          ++msgnum;
          itoa(msgnum,s,10);
          if ((msgs[msgnum].ownersys==0) && (msgs[msgnum].owneruser==usernum))
            sprintf(s1,"[%s]",s);
          else
            sprintf(s1,"(%s)",s);
          for (i1=0; i1<5; i1++)
            s[i1]=32;
          if (msgs[msgnum].qscan>thisuser.qscnptr[curlsub])
            s[0]='*';
          strcpy(&s[7-strlen(s1)],s1);
          strcat(s," ");
                   strcpy(s1,msgs[msgnum].title);
     if ((subboards[curlsub].type) && (strlen(s1)==52)) {
          memmove(s2,&s1[44],8);
          sprintf(s3,"%-43.43s     %-8.8s",s1,s2);
          strcat(s,s3);
        } else
          strcat(s,s1);                           


          pla(s,&abort);
          if (msgnum>=nummsgs)
            abort=1;
        }
        optype=0;
        break;
      case 2: /* Read Message */
	if ((msgnum>0) && (msgnum<=nummsgs))
          read_message(msgnum,&next,&val);
	ansic(0);
        nl();
        if (next) {
          ++msgnum;
          if (msgnum>nummsgs)
            done=1;
          optype=2;
        } else
          optype=0;
        if (expressabort)
	  if (realexpress) {
            done=1;
            quit=1;
            *nextsub=0;
          } else {
	    expressabort=0;
	    express=0;
	    optype=0;
	  }
        break;
    }
  } while ((!done) && (!hangup));
  if (!realexpress) {
    express=0;
    expressabort=0;
  }
  if ((val & 1) && (lcs()) && (!express)) {
    nl();
    prt(5,"Validate messages here? ");
    if (yn()) {
      for (i=1; i<=nummsgs; i++)
        if (msgs[i].status & (status_unvalidated | status_delete))
          msgs[i].status &= (~(status_unvalidated | status_delete));
      bchanged=1;
    }
  }
  if ((val & 2) && (lcs()) && (!express)) {
    nl();
    prt(5,"Network validate here? ");
    if (yn()) {
      i1=0;
      for (i=1; i<=nummsgs; i++)
        if (msgs[i].status & status_pending_net) {
          send_net_post(msgs+i, subboards[curlsub].type,
            subboards[curlsub].filename);
          ++i1;
          msgs[i].status &= (~status_pending_net);
        }
      sprintf(s,"%d messages sent.",i1);
      nl();
      pl(s);
      nl();
      bchanged=1;
    }
  }
  if ((!quit) && (!express)) {
    nl();
    ss=syscfg.sl[thisuser.sl];
    if (
        ((restrict_post & thisuser.restrict)==0) &&
        (thisuser.posttoday<ss.posts) &&
        (thisuser.sl>=subboards[curlsub].postsl)) {
      sprintf(s,"Post on %s? ",subboards[curlsub].name);
      prt(5,s);
      irt[0]=0;
      byline[0]=0;
      if (yn())
        post();
    }
  }
  savebase();
  nl();
}


void qscan(int bn, int *ns)
{
  int i,nextsub,os;
  char s[81],s1[81];

  if (hangup)
    return;
  nextsub=*ns;
  os=cursub;
  cursub=bn;
  iscan(cursub);
  if (curlsub<0) {
    nl();
    pl("No subs available.");
    nl();
    return;
  }
  i=1;
  while ((i<=nummsgs) && (msgs[i].qscan<=thisuser.qscnptr[curlsub]))
    ++i;
  nl();
  pl(get_string(18));
  if ((nummsgs>0) && (msgs[nummsgs].qscan<=thisuser.qscnptr[curlsub]))
    thisuser.qscnptr[curlsub]=status.qscanptr-1;
  if ((nummsgs>0) && (i<=nummsgs))
    if (msgs[i].qscan>thisuser.qscnptr[curlsub])
      scan(i,2,&nextsub);
pl(get_string(19));
  cursub=os;
  *ns=nextsub;
}


void nscan(int ss)
{
  int i,nextsub,abort,next;

  nl();
  nextsub=1;
  pl(get_string(15));
  nl();
  for (i=ss; (usub[i].subnum!=-1) && (i<32) && (nextsub) && (!hangup); i++) {
    if (thisuser.qscn & (1L<<(usub[i].subnum)))
      qscan(i,&nextsub);
    abort=next=0;
    checka(&abort,&next);
    if (abort)
      nextsub=0;
  }
  nl();
  pl(get_string(16));
  nl();
}

void scan2()
{
  char s[81];
  int i,i1;

  iscan(cursub);
  nl();
  if (curlsub<0) {
    pl("No subs available.");
    nl();
    return;
  }
  print(itoa(nummsgs,s,10)," msgs on ",subboards[curlsub].name,"");
  if (nummsgs==0)
    return;
  prt(2,"Start listing at? ");
  input(s,4);
  i=atoi(s);
  if (i<1)
    i=0;
  else
    if (i>nummsgs)
      i=nummsgs;
    else
      i--;
  i1=0;
  if (strcmp(s,"S")==0)
    scan(0,0,&i1);
  else
    if (strcmp(s,"Q")) {
      if (strcmp(s,"N")==0) {
      } else
        scan(i,1,&i1);
    }
}


void printmenu(int i)
{
  char s[81],s1[81];
  int next;

  next=0;

  if ((thisuser.sysstatus & (sysstatus_color | sysstatus_ansi))
      == (sysstatus_color | sysstatus_ansi)) {
    sprintf(s1,"MENU%u.ANS", i);
    sprintf(s,"%s%s",syscfg.gfilesdir,s1);
    if (exist(s)) {
      printfile(s1);
      return;
    }
  }
  sprintf(s1,"MENU%u.MSG", i);
  sprintf(s,"%s%s",syscfg.gfilesdir,s1);
  if (exist(s)) {
    printfile(s1);
    return;
  }

      sprintf(s,"%sMENUS.MSG",syscfg.gfilesdir);
      if (menus[i].stored_as)
        read_message1(&menus[i],0,0,&next,s);
}


void delmail(int f, int loc)
{
  mailrec m,m1;
  userrec u;
  int rm,i,t,otf;

  lseek(f,((long) loc) * ((long) sizeof(mailrec)), SEEK_SET);
  read(f,(void *)&m,sizeof(mailrec));

  rm=1;
  if (m.status & status_multimail) {
    t=filelength(f)/sizeof(mailrec);
    otf=0;
    for (i=0; i<t; i++)
      if (i!=loc) {
        lseek(f,((long)i)*((long)sizeof(mailrec)),SEEK_SET);
        read(f,(void *)&m1,sizeof(mailrec));
        if ((m.msg.stored_as==m1.msg.stored_as) && (m.msg.storage_type==m1.msg.storage_type) && (m1.daten!=0xffffffff))
          otf=1;
      }
    if (otf)
      rm=0;
  }

  if (rm)
    remove_link(&m.msg,"EMAIL");

  if (m.tosys==0) {
    read_user(m.touser,&u);
    if (u.waiting) {
      --u.waiting;
      write_user(m.touser,&u);
      close_user();
    }
    if (m.touser==1)
      --fwaiting;
  }

  lseek(f,((long) loc) * ((long) sizeof(mailrec)), SEEK_SET);
  m.touser=0;
  m.tosys=0;
  m.daten=0xffffffff;
  m.msg.storage_type=0;
  m.msg.stored_as=0xffffffff;
  write(f,(void *)&m,sizeof(mailrec));
  mailcheck=1;
}

void readmail()
{
  int i,i1,i2,i3,f,mw,mloc[200],mfl,curmail,done,abort,next,okmail;
  unsigned short x,xx;
  char s[81],s1[81],s2[81],fn[81],*b;
  mailrec m;
  slrec ss;
  userrec u;

  char ch;
  long len,num_mail,num_mail1;

  ss=syscfg.sl[thisuser.sl];
  sprintf(fn,"%sEMAIL.DAT",syscfg.datadir);
  f=open(fn,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
  if (f<0) {
    nl();
    nl();
    pl("No mail file exists!");
    nl();
    return;
  }
  mfl=filelength(f)/sizeof(mailrec);
  mw=0;
  for (i=0; (i<mfl) && (mw<200); i++) {
    lseek(f,((long) (i)) * (sizeof(mailrec)), SEEK_SET);
    read(f,(void *)(&m),sizeof(mailrec));
    if ((m.tosys==0) && (m.touser==usernum))
      mloc[mw++]=i;
  }
  thisuser.waiting=mw;
  if (usernum==1)
    fwaiting=mw;
  if (mw==0) {
    nl();
    nl();
    pl("You have no mail.");
    nl();
    return;
  }
  if (mw==1)
    curmail=0;
  else {
    nl();
    nl();
    pl("You have mail from:");
    nl();
    for (i=0; i<mw; i++) {
      lseek(f,((long) mloc[i]) * sizeof(mailrec),SEEK_SET);
      read(f,(void *) (&m),sizeof(mailrec));
      itoa(i+1,s,10);
      strcat(s,"> ");
      if ((m.anony & anony_sender) && ((ss.ability & ability_read_email_anony)==0)) {
        strcat(s,">UNKNOWN<");
      } else {
        if (m.fromsys==0) {
	  if (m.fromuser==65535)
        strcat(s,"Network");
	  else {
            read_user(m.fromuser,&u);
            strcat(s,nam(&u,m.fromuser));
            strcpy(s2,">>");
            strcat(s2,m.title);
	  }
        } else {
          sprintf(s1,"User %u @%u",m.fromuser,m.fromsys);
          strcat(s,s1);
        }
      }
      pl(s);
      pl(s2);
    }
    nl();
    pl("Hit return, or enter number");
    outstr(":");
    input(s,3);
    if (strcmp(s,"Q")==0) {
      close(f);
      return;
    }
    i=atoi(s);
    if (i)
      if (i<=mw)
        curmail=i-1;
      else
        curmail=0;
    else
      curmail=0;
  }
  done=0;
  do {
    sprintf(s,"(%u/%u): ",curmail+1,mw);
    abort=0;
    nl();
    nl();
    osan(s,&abort,&next);
    next=0;
    ansic(MSG_COLOR);
    s[0]=0;
    if (mloc[curmail]<0) {
      strcat(s,">>> MAIL DELETED <<<");
      okmail=0;
      pl(s);
      nl();
      nl();
    } else {
      lseek(f,((long) (mloc[curmail])) * (sizeof(mailrec)), SEEK_SET);
      read(f,(void *)&m,sizeof(mailrec));
      if ((m.tosys!=0) || (m.touser!=usernum)) {
	mloc[curmail]=-1;
        strcat(s,">>> MAIL DELETED <<<");
        okmail=0;
        pl(s);
        nl();
        nl();
      } else {
        strcat(s,m.title);
        strcpy(irt,m.title);
        abort=0;
        i=((ability_read_email_anony & ss.ability)!=0);
        okmail=1;
        pla(s,&abort);
        if ((m.fromsys) && (!m.fromuser))
          grab_user_name(&(m.msg),"EMAIL");
        else
          net_email_name[0]=0;
        setorigin(m.fromsys);
        if (!abort)
          read_message1(&m.msg, (m.anony & 0x0f), i, &next, "EMAIL");
      }
    }
    do {
      i2=1;
      prt(0,"Mail [?]: ");
      if (!okmail)
    ch=onek("QVI?-+G");
      else
        if (so())
          ch=onek("QSRIDVAF?-+GZVUEO*");
        else
          if (cs())
            ch=onek("QSRIDAF?-+GZVUO");
          else
            ch=onek("QSRIDAF?+-G");
      switch (ch) {
	case 'E':
          if ((so()) && (okmail)) {
            b=readfile(&(m.msg),"EMAIL",&len);
            extract_out(b,len);
          }
          i2=0; break;


    case 'Q':
       done=1;
       break;

	case 'O':
	byline[0]=0;
	  if ((cs()) && (okmail) && (m.fromuser!=65535)) {
	    nl();
	    prt(2,"Which form letter? ");
            input(s,4);
            sprintf(s1,"%sFORM%s.MSG",syscfg.gfilesdir,s);
	    if (exist(s1)) {
              strcpy(s,nam(&thisuser,usernum));
	      if (m.anony & anony_receiver)
	        strcpy(s,">UNKNOWN<");
              strcat(s," read your mail on ");
              strcat(s,date());
	      if (m.fromsys==0)
                ssm(m.fromuser,m.fromsys,s);
              delmail(f,mloc[curmail]);
              mloc[curmail]=-1;
              ++curmail;
              if (curmail>=mw)
                done=1;
              if (!wfc)
                topscreen();
              close(f);
              load_workspace(s1,1);
              email(m.fromuser,m.fromsys,0,m.anony);
              f=open(fn,O_RDWR | O_BINARY);
	    } else {
	      nl();
	      pl("File not found.");
	      nl();
              i2=0;
	    }
	  }
	  break;
	case 'G':
          sprintf(s,"Go to which (1-%u) ? ",mw);
	  prt(2,s);
	  input(s,3);
	  i2=atoi(s);
	  if ((i2>0) && (i2<=mw)) {
	    curmail=i2-1;
	    i2=1;
	  } else
	    i2=0;
	  break;
        case 'I':
	case '+':
          ++curmail;
          if (curmail>=mw)
            done=1;
          break;
	case '-':
	  if (curmail)
            --curmail;
	  break;
        case 'R':
          break;
        case '?':
          printmenu(4);
          i2=0;
          break;
        case 'D':
	  if (!okmail)
	    break;
          strcpy(s,nam(&thisuser,usernum));
	  if (m.anony & anony_receiver)
	    strcpy(s,">UNKNOWN<");
          strcat(s," read your mail on ");
          strcat(s,date());
	  if ((m.fromsys==0) && (m.fromuser!=65535))
            ssm(m.fromuser,m.fromsys,s);
        case 'Z':
	  if (!okmail)
	    break;
          delmail(f,mloc[curmail]);
          mloc[curmail]=-1;
          ++curmail;
          if (curmail>=mw)
            done=1;
          if (!wfc)
            topscreen();
          break;
        case 'F':
	  if (m.status & status_multimail) {
	    nl();
	    pl("Can't forward multimail.");
	    nl();
	    break;
	  }
	  if (!okmail)
	    break;
          nl();
          nl();
          prt(2,"Forward to: ");
          input(s,30);
          x=finduser(s);
          if ((x==usernum) && (!cs())) {
            x=0;
            nl();
            pl("Can't forward to yourself.");
            nl();
          }
          xx=0;
          if ((x) && (forwardm(&x,&xx))) {
            nl();
            if (x)
              pl("Forwarded from there.");
            else
              pl("Can't forward to him.");
          }
	  if (x>0) {
	    read_user(x,&u);
            sprintf(s,"Forward to %s? ",nam(&u,x));
	    prt(5,s);
	    if (!yn())
	      x=0;
	  }
          if (x>0) {
            --thisuser.waiting;
            if (usernum==1)
              --fwaiting;
            m.touser=x;
            lseek(f,((long) (mloc[curmail])) * (sizeof(mailrec)), SEEK_SET);
            write(f,(void *)&m,sizeof(mailrec));
            read_user(x,&u);
            ++u.waiting;
            write_user(x,&u);
            if (x==1)
              ++fwaiting;
            strcpy(s,"\r\nForwarded from: ");
            strcat(s,nam(&thisuser,usernum));
            lineadd(&m.msg,s,"EMAIL");
            strcpy(s,nam(&thisuser,usernum));
            strcat(s," forwarded your mail to ");
            strcat(s,nam(&u,x));
	    if (m.fromsys==0)
              ssm(m.fromuser,m.fromsys,s);
            mloc[curmail]=-1;
            ++curmail;
            if (curmail>=mw)
              done=1;
            if (!wfc)
              topscreen();
            print("Forwarded to ",nam(&u,x),"");
          } else {
            nl();
            pl("Unknown user.");
            nl();
          }
          break;
        case 'A':
	case 'S':
	byline[0]=0;
	  if (!okmail)
	    break;
          close(f);
          quote_message(&(m.msg),"EMAIL");
          num_mail=((long) thisuser.feedbacksent) +
                   ((long) thisuser.emailsent) +
                   ((long) thisuser.emailnet);
	  if (m.fromuser!=65535)
            email(m.fromuser,m.fromsys,0,m.anony);
          if (quote!=NULL) {                                 /* mod - add V3 */
            farfree(quote);                                  /* mod - add V3 */
            quote=NULL;                                      /* mod - add V3 */
          }                                                  /* mod - add V3 */
          f=open(fn,O_RDWR | O_BINARY);
          num_mail1=((long) thisuser.feedbacksent) +
                    ((long) thisuser.emailsent) +
                    ((long) thisuser.emailnet);
          if (ch=='A') {
            if (num_mail!=num_mail1) {
              strcpy(s,nam(&thisuser,usernum));
              if (m.anony & anony_receiver)
                strcpy(s,">UNKNOWN<");
              strcat(s," read your mail on ");
              strcat(s,date());
              if ((m.fromsys==0) && (m.fromuser!=65535))
                ssm(m.fromuser,m.fromsys,s);
              delmail(f,mloc[curmail]);
              mloc[curmail]=-1;
              ++curmail;
              if (curmail>=mw)
                done=1;
              if (!wfc)
                topscreen();
            } else {
              nl();
              pl("No mail sent.");
              nl();
              i2=0;
            }
          } else {
            ++curmail;
            if (curmail>=mw)
              done=1;
            if (!wfc)
              topscreen();
          }
          break;
        case 'V':
      if (!okmail) break;
          if ((m.fromsys==0) && (cs()) && (m.fromuser!=65535))
              uedit(m.fromuser,0);
	  else
	    if (cs()) {
	      nl();
	      pl("Mail from another system.");
	      nl();
	    }
          i2=0;
          break;
      }
    } while ((!i2) && (!hangup));
  } while ((!hangup) && (!done));
  close(f);
}


void remove_post()
{
  int i,i1,any,abort;
  char s[161];

  iscan(cursub);
  if (curlsub<0) {
    nl();
    pl("No subs available.");
    nl();
    return;
  }
  any=0;
  abort=0;
  nl();
  nl();
  strcpy(s,"Posts by you on ");
  strcat(s,subboards[curlsub].name);
  pl(s);
  nl();
  for (i=1; (i<=nummsgs) && (!abort); i++) {
    if ((msgs[i].ownersys==0) && (msgs[i].owneruser==usernum)) {
      any=1;
      sprintf(s,"%u: %s",i,msgs[i].title);
      pla(s,&abort);
    }
  }
  if (!any) {
    pl("None.");
    if (!cs())
      return;
  }
  nl();
  prt(2,"Remove which? ");
  input(s,3);
  i=atoi(s);
  if ((i>0) && (i<=nummsgs)) {
    if (((msgs[i].ownersys==0) && (msgs[i].owneruser==usernum)) || (lcs())) {
      sprintf(s,"-%s removed from %s",msgs[i].title,subboards[curlsub].name);
      sysoplog(s);
      delete(i);
      savebase();
      nl();
      pl("Message removed.");
      if(nifty.nifstatus & nif_credit) thisuser.credits--;
      nl();
    }
  }
}



int external_edit(char *fn1, char *direc, int ednum, int numlines)
{
  char s[255],s1[128],fn[128],s2[128],s3[81],sx1[21],sx2[21],sx3[21],ch;
  int i,i1,i2,r,w,filethere,mod,newtl;
  struct ftime ftimep,ftimep1;

  if ((ednum>=numed) || (!okansi())) {
    nl();
    pl("You can't use that full screen editor.");
    nl();
    return(0);
  }
  i1=0;
  for (i2=0; i2<81; i2++) {
    i1+=editors[ednum].filename[i2];
    i1+=editors[ednum].filenamecon[i2];
  }
  if (i1!=checked[ednum]) {
    nl();
    pl("Editor record(s) corrupted... Aborting...");
    nl();
    closeport();
    sl1(1,"");
    abort();
  }
  if (incom)
    strcpy(s1,(editors[ednum].filename));
  else
    strcpy(s1,(editors[ednum].filenamecon));
  if (s1[0]==0) {
    nl();
    pl("You can't use that full screen editor.");
    nl();
    return(0);
  }
  strcpy(s3,fn1);
  stripfn1(s3);
  if (direc[0]) {
    cd_to(direc);
    get_dir(fn,1);
    cd_to(cdir);
  } else
    fn[0]=0;
  strcat(fn,s3);
  filethere=exist(fn);
  if (filethere) {
    i=open(fn,O_RDONLY | O_BINARY);
    getftime(i,&ftimep);
    close(i);
  }
  itoa(thisuser.screenchars,sx1,10);
  if (screenlinest>defscreenbottom-topline)
    newtl=0;
  else
    newtl=topline;
  if (using_modem)
    itoa(thisuser.screenlines,sx2,10);
  else
    itoa(defscreenbottom+1-newtl,sx2,10);
  itoa(numlines,sx3,10);
  stuff_in(s,s1,fn,sx1,sx2,sx3,"");
  full_external(s,0,1);
  if (!wfc)
    topscreen();
  mod=0;
  if (!filethere) {
    mod=exist(fn);
  } else {
    i=open(fn,O_RDONLY | O_BINARY);
    getftime(i,&ftimep1);
    close(i);
    if ((ftimep.ft_year!=ftimep1.ft_year) ||
        (ftimep.ft_month!=ftimep1.ft_month) ||
        (ftimep.ft_day!=ftimep1.ft_day) ||
        (ftimep.ft_hour!=ftimep1.ft_hour) ||
        (ftimep.ft_min!=ftimep1.ft_min) ||
        (ftimep.ft_tsec!=ftimep1.ft_tsec))
      mod=1;
  }
  return(mod);
}
