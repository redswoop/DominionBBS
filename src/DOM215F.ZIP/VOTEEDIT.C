#include "fcns.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <io.h>
#include <fcntl.h>
#include <sys\stat.h>
#include <time.h>


extern int hangup,useron,wfc,userfile,usernum;
extern int incom;
extern configrec syscfg;
extern statusrec status;
extern char cdir[81];
extern userrec thisuser;
extern unsigned char agemin,agemax,slmin,slmax,dslmin,dslmax,ressex;
extern int daysmin,daysmax,lecho;
extern unsigned short arres,darres,resres;
extern int questused[20];
extern unsigned char realsl;

extern smalrec *smallist;


void print_quests(int f)
{
  char s[100];
  int i,abort;
  votingrec v;

  abort=0;
  for (i=1; (i<=20) && (abort==0); i++) {
    lseek(f,((long) (i-1)) * sizeof(votingrec), SEEK_SET);
    read(f,(void *)&v,sizeof(votingrec));
    s[0]=32;
    if (i<10)
      itoa(i,&s[1],10);
    else
      itoa(i,&s[0],10);
    strcat(s,": ");
    if (v.numanswers)
      strcat(s,v.question);
    else
      strcat(s,">>> NO QUESTION <<<");
    pla(s,&abort);
  }
  nl();
  if (abort)
    nl();
}


void set_question(int f, int ii)
{
  votingrec v,v1;
  int i,i1,i2;
  char s[81];
  userrec u;
  voting_response vr;

  prompt("SL required for this Question: ","");
  input(s,4);
  if(s[0]) v.sl=atoi(s);
  pl("Enter new question, <C/R> for none.");
  outstr(": ");
  inputl(s,75);
  strcpy(v.question,s);
  v.numanswers=0;
  vr.numresponses=0;
  vr.response[0]='X';
  vr.response[1]=0;
  for (i=0; i<20; i++)
    v.responses[i]=vr;
  while ((v.numanswers<19) && (s[0])) {
    itoa(v.numanswers+1,s,10);
    strcat(s,": ");
    outstr(s);
    inputl(s,63);
    strcpy(vr.response,s);
    vr.numresponses=0;
    v.responses[v.numanswers]=vr;
    if (s[0])
      ++v.numanswers;
  }
  lseek(f,((long) (ii)) * sizeof(votingrec), SEEK_SET);
  write(f,(void *)(&v),sizeof(votingrec));
  lseek(f,((long) (ii)) * sizeof(votingrec), SEEK_SET);
  read(f,(void *)(&v1),sizeof(votingrec));
  close(f);
  if (v.numanswers)
    questused[ii]=1;
  else
    questused[ii]=0;

  read_user(1,&u);
  i1=(int) (filelength(userfile)/sizeof(userrec)) -1;
  for (i=1; i<=i1; i++) {
    read_user(i,&u);
    u.votes[ii]=0;
    write_user(i,&u);
  }
  close_user();
}


void ivotes()
{
  int i,f,abort,n,done;
  char s[81];
  votingrec v;

  close_user();
  sprintf(s,"%sVOTING.DAT",syscfg.datadir);
  f=open(s,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
  n=(int) (filelength(f) / sizeof(votingrec)) -1;
  if (n<20) {
    v.question[0]=0;
    v.numanswers=0;
    for (i=n; i<20; i++)
      write(f,(void *)&v,sizeof(votingrec));
  }
  done=0;
  do {
    print_quests(f);
    nl();
    prt(2,"Which (Q=Quit) ? ");
    input(s,2);
    if (strcmp(s,"Q")==0)
      done=1;
    i=atoi(s);
    if ((i>0) && (i<21)) {
      set_question(f,i-1);
      sprintf(s,"%sVOTING.DAT",syscfg.datadir);
      f=open(s,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
    }
  } while ((!done) && (!hangup));
  close(f);
}


void voteprint()
{
  int f,f1,i,i1,i2,i3,nu;
  char s[81],s1[81],s2[81];
  votingrec v;
  char *x;
  userrec u;

  read_user(1,&u);
  nu=filelength(userfile)/sizeof(userrec);
  if ((x=malloca(20*(2+nu)))==NULL)
    return;
  for (i=0; i<nu; i++) {
    read_user(i,&u);
    for (i1=0; i1<20; i1++)
      x[i1+i*20]=u.votes[i1];
  }
  close_user();
  sprintf(s,"%svoting.msg",syscfg.gfilesdir);
  f=open(s,O_RDWR | O_BINARY | O_CREAT | O_TRUNC, S_IREAD | S_IWRITE);
  sprintf(s,"%svoting.dat",syscfg.datadir);
  f1=open(s,O_RDWR | O_BINARY);
  sprintf(s,"Voting results as of %s\r\n\r\n",date());
  write(f,(void *)s,strlen(s));

  for (i=0; i<20; i++) {
    lseek(f1,((long)i)*sizeof(votingrec),SEEK_SET);
    read(f1,(void *)&v,sizeof(votingrec));
    if (v.numanswers) {
      pl(v.question);
      sprintf(s,"\r\n%s\r\n",v.question);
      write(f,s,strlen(s));
      for (i1=0; i1<v.numanswers; i1++) {
	sprintf(s,"     %s\r\n",v.responses[i1].response);
	write(f,s,strlen(s));
	for (i2=0; i2<status.users; i2++)
          if (x[i+20*smallist[i2].number]==i1+1) {
	    sprintf(s,"          %s #%d\r\n",smallist[i2].name,smallist[i2].number);
	    write(f,s,strlen(s));
	  }
      }
    }
  }

  close(f1);
  close(f);
  farfree(x);
}


