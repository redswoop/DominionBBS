#include "nifrec.h"
#include "doorutl.c"
#include <fcntl.h>
#include <sys\stat.h>
#include <alloc.h>
#include "\dom\vardec.h"


void main()
{
char *s,dirs[10][81];
int i,x;
directoryrec ddir;
subboardrec ssub;
configrec ss;
statusrec st;
niftyrec nifty;

pl("[2J|0Dominion |7BBS |4Initialization Utility");

pl("|7Countinue?");
if(!ny()) exit(0);

pl("[2J|4�|3Commensing with Installation");
    nifty.chatcolor=1;
    nifty.comments=1;
    nifty.fpts=1;
    nifty.fancyprompt=1;
    nifty.mciok=1;
    nifty.autochat=0;
    nifty.chatbeep=1;
    nifty.credits=1;
    nifty.echochar=240;
    strcpy(nifty.firstmenu,"main.mnu");
    nifty.col[0]=7;
    nifty.col[1]=0;
    nifty.col[2]=1;
    strcpy(nifty.newusermenu,"");
    nifty.postcredits=5;
    nifty.music=1;
    nifty.slowrate[0]=1;
    strcpy(nifty.menudir,"menus");

pl("|4�|3Creating Nstatus.dat");
    i=open("nstatus.dat",O_RDWR | O_BINARY | O_CREAT | S_IREAD|S_IWRITE);
    write(i,(void *)(&nifty), sizeof(niftyrec));
    close(i);
pl("|4�|3Creating Text Files");

s=malloc(81);

i=open("newuser.msg",O_WRONLY | O_TEXT | O_CREAT | S_IREAD|S_IWRITE);
   strcpy(s,"Welcome to this BBS.  Please leave your true info so you maybe validated");
   write(i,s,strlen(s));
close(i);

   i=open("welcome.msg",O_WRONLY | O_TEXT | O_CREAT | S_IREAD|S_IWRITE);
   strcpy(s,"Welcome.Msg");
   write(i,s,strlen(s));
   close(i);

   i=open("logon.msg",O_WRONLY | O_TEXT | O_CREAT | S_IREAD|S_IWRITE);
   strcpy(s,"This is Logon.msg");
   write(i,s,strlen(s));
   close(i);

i=open("Logoff.msg",O_WRONLY | O_TEXT | O_CREAT | S_IREAD|S_IWRITE);
   strcpy(s,"This is Logoff.Msg");
   write(i,s,strlen(s));
   close(i);

i=open("Chat.msg",O_WRONLY | O_TEXT | O_CREAT | S_IREAD|S_IWRITE);
   strcpy(s,"This is The SysOp Is not around");
   write(i,s,strlen(s));
   close(i);

i=open("Auto.msg",O_WRONLY | O_TEXT | O_CREAT | S_IREAD|S_IWRITE);
   strcpy(s,"Welcome, N, to this new Dominion BBS!");
   write(i,s,strlen(s));
   close(i);

i=open("Feedback.msg",O_WRONLY | O_TEXT | O_CREAT | S_IREAD|S_IWRITE);
   strcpy(s,"Please leave the SysOp Email informining him you've called.");
   write(i,s,strlen(s));
   close(i);


pl("|4�|3Creating Data Files");
strcpy(ddir.name,"SysOp");
strcpy(ddir.filename,"SYSOP");
strcpy(ddir.path,"DLS\\SYSOP");
ddir.dsl=255;
ddir.age=0;
ddir.maxfiles=50;
ddir.dar=0;
ddir.type=0;
ddir.mask=0;
i=open("Dirs.dat",O_WRONLY | O_BINARY | O_CREAT | S_IREAD|S_IWRITE);
write(i,(void *)&ddir,sizeof(directoryrec));
close(i);

strcpy(ssub.name,"General Talk");
strcpy(ssub.filename,"GENERAL");
ssub.key=0;
ssub.readsl=10;
ssub.postsl=20;
ssub.anony=0;
ssub.age=0;
ssub.maxmsgs=50;
ssub.ar=0;
ssub.type=0;
ssub.storage_type=2;
i=open("subs.dat",O_WRONLY|O_BINARY|O_CREAT|S_IREAD|S_IWRITE);
write(i,(void *)&ssub,sizeof(subboardrec));
close(i);


strcpy(ss.newuserpw,"");
strcpy(ss.systempw,"");
strcpy(ss.msgsdir,dirs[5]);
strcpy(ss.gfilesdir,dirs[1]);
strcpy(ss.datadir,dirs[2]);
strcpy(ss.dloadsdir,dirs[4]);
strcpy(ss.tempdir,dirs[3]);

strcpy(ss.msgsdir,"msgs\\");
strcpy(ss.gfilesdir,"gfiles\\");
strcpy(ss.datadir,"data\\");
strcpy(ss.dloadsdir,"dls\\");
strcpy(ss.tempdir,"temp\\");

strcpy(ss.bbs_init_modem,"ATS0=0V0E0S2=1S7=20H0{");
strcpy(ss.answer,"ATA{");
strcpy(ss.connect_300,"1");
strcpy(ss.connect_1200,"5");
strcpy(ss.connect_2400,"10");
strcpy(ss.connect_9600,"13");
strcpy(ss.connect_19200,"50");
strcpy(ss.no_carrier,"ATH0{");
strcpy(ss.ring,"2");
strcpy(ss.terminal,"TERM.bat");
strcpy(ss.systemname,"New domBBS");
strcpy(ss.systemphone,"800-555-1212");
strcpy(ss.sysopname,"SysOp");
ss.newuserdsl=20;
ss.newusersl=20;
ss.maxwaiting=20;
ss.com_base[2]=760;
ss.com_ISR[2]=3;
ss.comport[2]=1;
ss.primaryport=2;
ss.baudrate[2]=2400;
ss.com_base[1]=1016;
ss.com_ISR[1]=4;
ss.comport[1]=0;
ss.baudrate[1]=2400;
strcpy(ss.arcs[0].extension,"ZIP");
strcpy(ss.arcs[0].arca,"PKZIP %1 %2");
strcpy(ss.arcs[0].arce,"PKUNZIP %1 %2");
strcpy(ss.arcs[0].arcl,"PKZIP -V %1");
strcpy(ss.arcs[1].extension,"ARC");
strcpy(ss.arcs[1].arca,"PKpak %1 %2");
strcpy(ss.arcs[1].arce,"PKUNpak %1 %2");
strcpy(ss.arcs[1].arcl,"PKpak -V %1");
strcpy(ss.arcs[2].extension,"lhz");
strcpy(ss.arcs[2].arca,"lha a %1 %2");
strcpy(ss.arcs[2].arce,"lha e %1 %2");
strcpy(ss.arcs[2].arcl,"lha   %1");
strcpy(ss.arcs[3].extension,"arj");
strcpy(ss.arcs[3].arca,"arj a %1 %2");
strcpy(ss.arcs[3].arce,"ark e %1 %2");
strcpy(ss.arcs[3].arcl,"arj v %1");
ss.sysconfig=0;
ss.sysconfig |= sysconfig_two_color;
ss.sysconfig |= sysconfig_list;
ss.sysconfig |= sysconfig_2_way;
ss.sysconfig |= sysconfig_shrink_term;
ss.sysconfig |= sysconfig_free_phone;
for(x=0; x<256; x++) {
    ss.sl[x].time_per_day=x;
    ss.sl[x].time_per_logon=x;
    ss.sl[x].messages_read=x+20;
    ss.sl[x].emails=x+20;
    ss.sl[x].posts=x+20;
    ss.sl[x].ability=0;
    if(x>=50) ss.sl[x].ability |= ability_post_anony;
    if(x>=75) ss.sl[x].ability |= ability_email_anony;
    if(x>=100) ss.sl[x].ability |= ability_read_post_anony;
    if(x>=100) ss.sl[x].ability |= ability_read_email_anony;
    if(x>=150) ss.sl[x].ability |= ability_limited_cosysop;
    if(x>=200) ss.sl[x].ability |= ability_cosysop;
}
i=open("config.dat",O_WRONLY|O_BINARY|O_CREAT|S_IREAD|S_IWRITE);
write(i,(void *)&ss,sizeof(configrec));
close(i);

st.date1[0]=0;
st.date2[0]=0;
st.date3[0]=0;
st.log1[0]=0;
st.log2[0]=0;
st.gfiledate[0]=0;
st.users=0;
st.callernum=0;
st.callstoday=0;
st.msgposttoday=0;
st.emailtoday=0;
st.fbacktoday=0;
st.uptoday=0;
st.activetoday=0;
st.qscanptr=0;
st.amsganon=0;
st.amsguser=0;
st.callernum1=0;
st.net_edit_stuff=0;
st.wwiv_version=210;

i=open("status.dat",O_WRONLY|O_BINARY|O_CREAT|S_IREAD|S_IWRITE);
write(i,(void *)&st,sizeof(statusrec));
close(i);

#ifdef ack
pl("|4�|3Creating Directories");
#endif

pl("Your Dominion BBS is now Setup and ready to run.  At present, there is no");
pl("System password, so when prompted, simple hit enter on a blank line.");
pl("You may delete this Ini.exe now, as it is no longer needed.");
}

