#include <stdio.h>
#include <sys\stat.h>
#include <fcntl.h>
#include <time.h>
#include <dos.h>
#include <dir.h>
#include <string.h>
#include <io.h>
#include <alloc.h>
#include <stdlib.h>
#include "nifrec.h"
#include "fcns.h"

extern userrec thisuser;
extern niftyrec nifty;
extern directoryrec directories[64];
extern int num_dirs,hangup,userfile,echo,useron,userfile,usernum;
extern int incom,fwaiting;
extern configrec syscfg;
extern statusrec status;
extern int edlf,dlf,curdir,numf;
extern usersubrec udir[64];
extern long nscandate;
extern char curspeed[81],cdir[81],dszlog[81];
extern unsigned int modem_speed,com_speed;
extern float batchtime;
extern int numbatch, numbatchdl, num_listed;
extern batchrec batch;
extern double extratimecall;
extern unsigned char realsl;

#define SETREC(i)  lseek(dlf,((long) (i))*((long)sizeof(uploadsrec)),SEEK_SET);


/* How far to indent extended descriptions */
#define INDENTION 24

/* Max # of lines for extended description */
#define MAX_LINES 10

/* If its OK to use the FSED for editing extended descriptions */
#define FSED_OK ((okfsed()) && (0))

/* If this is defined, the system will put in "ASK" if a file isn't there */
#define CHECK_FOR_EXISTANCE

/* the archive type to use */
#define ARC_NUMBER 0

int okfn(char *s)
{
  int i,l,ok;
  unsigned char ch;

  ok=1;
  l=strlen(s);
  for (i=0; i<l; i++) {
    ch=s[i];
    if ((ch<=' ') || (ch=='/') || (ch=='\\') || (ch==':') ||
        (ch=='>') || (ch=='<') || (ch=='|')  || (ch=='+') ||
        (ch==',') || (ch==';') || (ch>126))
      ok=0;
  }
  return(ok);
}

void get_arc_cmd(char *out, char *arcfn, int cmd, char *ofn)
{
  char *ss,*ss1,s[161];
  int i;

  out[0]=0;
  ss=strchr(arcfn,'.');
  if (ss==NULL)
    return;
  ++ss;
  ss1=strchr(ss,'.');
  while (ss1!=NULL) {
    ss=ss1;
    ++ss1;
    ss1=strchr(ss,'.');
  }
  for (i=0; i<4; i++)
    if (stricmp(ss,syscfg.arcs[i].extension)==0) {
      switch(cmd) {
        case 0: strcpy(s,syscfg.arcs[i].arcl); break;
        case 1: strcpy(s,syscfg.arcs[i].arce); break;
        case 2: strcpy(s,syscfg.arcs[i].arca); break;
      }
      if (s[0]==0)
        return;
      stuff_in(out,s,arcfn,ofn,"","","");
      return;
    }
}


int list_arc_out(char *fn, char *dir)
{
  char s[161],s1[81];
  int i=0;

  strcpy(s1,dir);
  strcat(s1,fn);
  get_arc_cmd(s,s1,0,"");
  if (!okfn(fn))
    s[0]=0;
  if (exist(s1) && (s[0]!=0)) {
    nl();
    nl();
    print("Archive listing for ",fn,":","");
    nl();
    i=do_external(s,1);
    nl();
  } else {
    nl();
    outs("Unknown archive: ");
    pl(fn);
    nl();
    i=0;
  }
  return(i);
}


int ratio_ok()
{
  int ok=1;
  char s[101];

  if (!(thisuser.exempt & exempt_ratio) && !thisuser.res[5])
    if ((syscfg.req_ratio>0.0001) && (ratio()<syscfg.req_ratio)) {
      ok=0;
      nl();
      nl();
      sprintf(s,"Your up/download ratio is %-5.3f.  You need a ratio of %-5.3f to download.",
        ratio(), syscfg.req_ratio);
      pl(s);
      nl();
    }

  if (!(thisuser.exempt & exempt_post) && !thisuser.res[5])
    if ((syscfg.post_call_ratio>0.0001) && (post_ratio()<syscfg.post_call_ratio)) {
      ok=0;
      nl();
      nl();
      sprintf(s,"Your post/call ratio is %-5.3f.  You need a ratio of %-5.3f to download.",
        post_ratio(), syscfg.post_call_ratio);
      pl(s);
      nl();
    }

  return(ok);
}


int dcs()
{
  if (cs())
    return(1);
  if (thisuser.dsl>=100)
    return(1);
  else
    return(0);
}


void dliscan1(int dn)
{
  char s[81];
  int i;
  uploadsrec u;

  sprintf(s,"%s%s.DIR",syscfg.datadir,directories[dn].filename);
  dlf=open(s,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
  i=filelength(dlf)/sizeof(uploadsrec);
  if (i==0) {
    u.numbytes=0;
    SETREC(0);
    write(dlf,(void *)&u,sizeof(uploadsrec));
  } else {
    SETREC(0);
    read(dlf,(void *)&u,sizeof(uploadsrec));
  }
  numf=u.numbytes;

  sprintf(s,"%s%s.EXT",syscfg.datadir,directories[dn].filename);
  edlf=open(s,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
}


void dliscan()
{
  dliscan1(udir[curdir].subnum);
}


void closedl()
{
  if (dlf>0) {
    close(dlf);
    dlf=-1;
  }
  if (edlf>0) {
    close(edlf);
    edlf=-1;
  }
}

void add_extended_description(char *fn, char *desc)
{
  ext_desc_type ed;

  strcpy(ed.name,fn);
  ed.len=strlen(desc);
  lseek(edlf,0L,SEEK_END);
  write(edlf,&ed,sizeof(ext_desc_type));
  write(edlf,desc,ed.len);
}


void delete_extended_description(char *fn)
{
  ext_desc_type ed;
  long r,w,l1;
  char *ss=NULL;

  r=w=0;
  if ((ss=malloca(10240L))==NULL)
    return;
  l1=filelength(edlf);
  while (r<l1) {
    lseek(edlf,r,SEEK_SET);
    read(edlf,&ed,sizeof(ext_desc_type));
    if (ed.len<10000) {
      read(edlf,ss,ed.len);
      if (strcmp(fn,ed.name)) {
        if (r!=w) {
          lseek(edlf,w,SEEK_SET);
          write(edlf,&ed,sizeof(ext_desc_type));
          write(edlf,ss,ed.len);
        }
        w +=(sizeof(ext_desc_type) + ed.len);
      }
    }
    r += (sizeof(ext_desc_type) + ed.len);
  }
  farfree(ss);
  chsize(edlf,w);
}


char *read_extended_description(char *fn)
{
  ext_desc_type ed;
  long l,l1;
  char *ss=NULL;

  l=0;
  l1=filelength(edlf);
  while (l<l1) {
    lseek(edlf,l,SEEK_SET);
    l += (long) read(edlf,&ed,sizeof(ext_desc_type));
    if (strcmp(fn,ed.name)==0) {
      ss=malloca((long) ed.len+10);
      if (ss) {
        read(edlf,ss,ed.len);
        ss[ed.len]=0;
      }
      return(ss);
    } else
      l += (long) ed.len;
  }
  return(NULL);
}



void print_extended(char *fn, int *abort, unsigned char numlist, int indent)
{
  char *ss;
  int next=0;
  unsigned char numl=0;
  int cpos=0;
  char ch,s[81];
  int i;

  ss=read_extended_description(fn);
  if (ss) {
    ch=10;
    while ((ss[cpos]) && (!(*abort)) && (numl<numlist)) {
      if ((ch==10) && (indent)) {
        if (okansi())
          sprintf(s,"\x1b[%dC",INDENTION);
        else {
          for (i=0; i<INDENTION; i++)
            s[i]=32;
          s[INDENTION]=0;
        }
        osan(s,abort,&next);
        if ((thisuser.sysstatus & sysstatus_funky_colors) && (!(*abort)))
          ansic(5);
      }
      outchr(ch=ss[cpos++]);
      checka(abort,&next);
      if (ch==10)
        ++numl;
      else
        if ((ch!=13) && (wherex()>=78)) {
          osan("\r\n",abort,&next);
          ch=10;
        }
    }
    if (wherex())
      nl();
  }
  farfree(ss);
}



void modify_extended_description(char **sss)
{
  char s[161],s1[161];
  int f,ii,i,i1,i2;

  if (*sss)
    ii=1;
  else
    ii=0;
  do {
    if (ii) {
      nl();
      if (FSED_OK)
        prt(5,"Modify the extended description? ");
      else
        prt(5,"Enter a new extended description? ");
      if (!yn())
        return;
    } else {
      nl();
      prt(5,"Enter an extended description? ");
      if (!yn())
        return;
    }
    if (FSED_OK) {
      strcpy(s,syscfg.tempdir);
      strcat(s,"extended.dsc");
      if (*sss) {
        f=open(s,O_RDWR | O_BINARY | O_CREAT | O_TRUNC, S_IREAD | S_IWRITE);
        write(f,*sss,strlen(*sss));
        close(f);
        farfree(*sss);
        *sss=NULL;
      } else
        unlink(s);
      i=thisuser.screenchars;
      if (thisuser.screenchars>(76-INDENTION))
        thisuser.screenchars=76-INDENTION;
      i1=external_edit("extended.dsc",syscfg.tempdir,(int) thisuser.defed-1,MAX_LINES);
      thisuser.screenchars=i;
      if (i1) {
        if ((*sss=malloca(10240))==NULL)
          return;
        f=open(s,O_RDWR | O_BINARY);
        read(f,*sss,(int) filelength(f));
        close(f);
      }
    } else {
      if (*sss)
        farfree(*sss);
      if ((*sss=malloca(10240))==NULL)
        return;
      *sss[0]=0;
      i=1;
      nl();
      sprintf(s,"Enter up to %d lines, %d chars each.",MAX_LINES,78-INDENTION);
      pl(s);
      nl();
      s[0]=0;
      i1=thisuser.screenchars;
      if (thisuser.screenchars>(76-INDENTION))
        thisuser.screenchars=76-INDENTION;
      do {
        itoa(i,s1,10);
        strcat(s1,": ");
        prt(2,s1);
        s1[0]=0;
        inli(s1,s,90,1);
        i2=strlen(s1);
        if (i2 && (s1[i2-1]==1))
          s1[i2-1]=0;
        if (s1[0]) {
          strcat(s1,"\r\n");
          strcat(*sss,s1);
        }
      } while ((i++<10) && (s1[0]));
      thisuser.screenchars=i1;
      if (*sss[0]==0) {
        farfree(*sss);
        *sss=NULL;
      }
    }
    prt(5,"Is this what you want? ");
    i=!yn();
    if (i) {
      farfree(*sss);
      *sss=NULL;
    }
  } while (i);
}


void align(char *s)
{
  char f[40],e[40],s1[20],*s2;
  int i,i1,i2;

  i1=0;
  if (s[0]=='.')
    i1=1;
  for (i=0; i<strlen(s); i++)
    if ((s[i]=='\\') || (s[i]=='/') || (s[i]==':') || (s[i]=='<') ||
      (s[i]=='>') || (s[i]=='|'))
      i1=1;
  if (i1) {
    strcpy(s,"        .   ");
    return;
  }
  s2=strchr(s,'.');
  if (s2==NULL) {
    e[0]=0;
  } else {
    strcpy(e,&(s2[1]));
    e[3]=0;
    s2[0]=0;
  }
  strcpy(f,s);

  for (i=strlen(f); i<8; i++)
    f[i]=32;
  f[8]=0;
  i1=0;
  i2=0;
  for (i=0; i<8; i++) {
    if (f[i]=='*')
      i1=1;
    if (f[i]==' ')
      i2=1;
    if (i2)
      f[i]=' ';
    if (i1)
      f[i]='?';
  }

  for (i=strlen(e); i<3; i++)
    e[i]=32;
  e[3]=0;
  i1=0;
  for (i=0; i<3; i++) {
    if (e[i]=='*')
      i1=1;
    if (i1)
      e[i]='?';
  }

  for (i=0; i<12; i++)
    s1[i]=32;
  strcpy(s1,f);
  s1[8]='.';
  strcpy(&(s1[9]),e);
  strcpy(s,s1);
  for (i=0; i<12; i++)
    s[i]=upcase(s[i]);
}


int compare(char *s1, char *s2)
{
  int ok,i;

  ok=1;
  for (i=0; i<12; i++)
    if ((s1[i]!=s2[i]) && (s1[i]!='?') && (s2[i]!='?'))
      ok=0;
  return(ok);
}

void printinfo(uploadsrec *u, int *abort)
{
  char s[85],s1[40],s2[81],s3[80];
  int i,next,fc;


  ansic(2);
  strncpy(s,u->filename,8);
  s[8]=0;
  osan(s,abort,&next);
  strncpy(s,&((u->filename)[8]),4);
  s[4]=0;
    ansic(3);
  osan(s,abort,&next);
    ansic(5);
  osan(" [",abort,&next);

  if(!u->ats[0]) {
   strcpy(s,"UNVALIDATED");
   ansic(7);
   osan(s,abort,&next);
 } else {
     ltoa((((u->numbytes)+1023)/1024),s1,10);
     strcat(s1,"k");

     strcpy(s2,directories[udir[curdir].subnum].path);
     strcat(s2,u->filename);
     if (!exist(s2)) {
        ansic(7);
       strcpy(s1,"OffLine    ");
       osan(s1,abort,&next); }
   else {
   for (i=0; i<5-strlen(s1); i++)
     s[i]=32;
   s[i]=0;
   strcat(s,s1);
   ansic(9);
   osan(s,abort,&next);

   if(nifty.nifstatus & nif_fpts) {
   itoa((u->points),s1,10);
   for (i=0; i<3-strlen(s1); i++)
     s[i]=32;
   s[i]=0;
   strcat(s,s1);
   strcat(s,"pts");
   ansic(4);
   osan(s,abort,&next);
   }
  }
}
   ansic(5);
   osan("] ",abort,&next);
     ansic(0);
   pla(u->description,abort);
   if ((!*abort) && (thisuser.num_extended) && (u->mask & mask_extended))
     print_extended(u->filename,abort,thisuser.num_extended,1);
   if (!(*abort))
     ++num_listed;

}


void printtitle(int *abort)
{
  char s[81],s1[20];
  int i,i1;

  pla("",abort);
  pla("",abort);
  outchr(12);
  sprintf(s,"7<[0%s  4#0%s 5- 9%d files7]>",directories[udir[curdir].subnum].name,udir[curdir].keys,numf);
  i=strlenc(s);
  pla(s,abort);
  for (i1=0; i1<i; i1++)
    s[i1]='�';
  s[i]=0;
  ansic(5);
  pla(s,abort);
  pla("",abort);
}


void file_mask(char *s)
{
  nl();
  pl("7File mask: ");
  mpl(12);
  input(s,12);
  if (s[0]==0)
    strcpy(s,"*.*");
  if (strchr(s,'.')==NULL)
    strcat(s,".*");
  align(s);
  nl();
}


void listfiles()
{
  char s[81];
  int i,abort;
  uploadsrec u;

  dliscan();
  file_mask(s);
  abort=0;
  num_listed=0;
  printtitle(&abort);
  for (i=1; (i<=numf) && (!abort) && (!hangup); i++) {
    SETREC(i);
    read(dlf,(void *)&u,sizeof(uploadsrec));
    if (compare(s,u.filename))
      printinfo(&u,&abort);
  }
  closedl();
  if (!abort) {
    nl();
    nl();
    sprintf(s,"Files listed: %d",num_listed);
    pl(s);
    nl();
  }
}


void nscandir(int d, int *abort,int title)
{
  int i,od,did=0;
  uploadsrec u;
  char s[81];

  od=curdir;
  curdir=d;
  dliscan(); if(title) printtitle(abort);
  for (i=1; (i<=numf) && (!(*abort)) && (!hangup); i++) {
    SETREC(i);
    read(dlf,(void *)&u,sizeof(uploadsrec));
    if ((u.daten>=nscandate)||(!u.ats[0])) {
      printinfo(&u,abort);
      did=1;
    }
  }
  closedl();
  curdir=od;
  if(did) pausescr();
}


void nscanall()
{
  int abort,i,i1;
  char s[81];

  abort=0;
  num_listed=0;
  for (i=0; (i<64) && (!abort) && (udir[i].subnum!=-1); i++) {
    i1=udir[i].subnum;
    if (i1>=32) {
      if (thisuser.nscn2 & (1L << (i1-32)))
        nscandir(i,&abort,1);
    } else {
      if (thisuser.nscn1 & (1L << i1))
        nscandir(i,&abort,1);
    }
  }
  if ((num_listed) && (!abort)) {
    nl();
    nl();
    sprintf(s,"Files listed: %d",num_listed);
    pl(s);
    nl();
  }
}


void searchall()
{
  int i,i1,pts,abort,pty,ocd;
  char s[81],s1[81];
  uploadsrec u;

  abort=0;
  ocd=curdir;
  nl();
  nl();
  pl("Search all directories.");
  file_mask(s);
  num_listed=0;
  for (i=0; (i<64) && (!abort) && (!hangup) && (udir[i].subnum!=-1); i++) {
    i1=udir[i].subnum;
    pts=0;
    if (i1>=32) {
      if (thisuser.nscn2 & (1L << (i1-32)))
        pts=1;
    } else {
      if (thisuser.nscn1 & (1L << i1))
        pts=1;
    }
    pts=1;
    /* remove pts=1 to search only marked directories */
    if (pts) {
      curdir=i;
      dliscan();
      pty=1;
      for (i1=1; (i1<=numf) && (!abort) && (!hangup); i1++) {
        SETREC(i1);
        read(dlf,(void *)&u,sizeof(uploadsrec));
        if (compare(s,u.filename)) {
          if (pty) {
            printtitle(&abort);
            pty=0;
          }
          printinfo(&u,&abort);
        }
      }
      pausescr();
      closedl();
    }
  }
  curdir=ocd;
  if ((num_listed) && (!abort)) {
    nl();
    nl();
    sprintf(s,"Files listed: %d",num_listed);
    pl(s);
    nl();
  }
}


int recno(char *s)
{
  int i;
  uploadsrec u;

  i=1;
  if (numf<1)
    return(-1);
  SETREC(i);
  read(dlf,(void *)&u,sizeof(uploadsrec));
  while ((i<numf) && (compare(s,u.filename)==0)) {
    ++i;
    SETREC(i);
    read(dlf,(void *)&u,sizeof(uploadsrec));
  }
  if (compare(s,u.filename))
    return(i);
  else
    return(-1);
}


int nrecno(char *s,int i1)
{
  int i;
  uploadsrec u;

  i=i1+1;
  if ((numf<1) || (i1>=numf))
    return(-1);

  SETREC(i);
  read(dlf,(void *)&u,sizeof(uploadsrec));
  while ((i<numf) && (compare(s,u.filename)==0)) {
    ++i;
    SETREC(i);
    read(dlf,(void *)&u,sizeof(uploadsrec));
  }
  if (compare(s,u.filename))
    return(i);
  else
    return(-1);
}


int printfileinfo(uploadsrec *u, int dn)
{
  char s[81];
  double d;
  int i,abort;

  d=((double) (((u->numbytes)+127)/128)) *
    (1620.0) /
    ((double) (modem_speed));
  print("7[0Filename   7]1 ",stripfn(u->filename),"");
  print("7[0Description7]1 ",(u->description),"");
  ltoa(((u->numbytes)+1023)/1024,s,10);
  print("7[0File size  7]1 ",s,"k","");
  if(nifty.nifstatus & nif_fpts) { ltoa(u->points,s,10);
  print("7[0File Points7]1 ",s,""); }
  print("7[0Apprx. time7]1 ",ctim(d),"");
  nl();
  abort=0;
  if (u->mask & mask_extended) {
    pl("7[0Extended Description7]1 ");
    print_extended(u->filename,&abort,255,0);
  }
  sprintf(s,"%s%s",directories[dn].path,u->filename);
  if (!exist(s)) {
    nl();
    pl("->FILE NOT THERE<-");
    nl();
  }

  if (nsl()>=d)
    return(1);
  else
    return(0);

}

int printfileinfo2(uploadsrec *u, int dn)
{
  char s[81];
  double d;
  int i,abort;

  sprintf(s,"%s%s",directories[dn].path,u->filename);
  if (!exist(s)) {
  nl();
  print("7[0Filename   7]1 ",stripfn(u->filename),"");
  print("7[0Description7]1 ",(u->description),"");
  ltoa(((u->numbytes)+1023)/1024,s,10);
  print("7[0File size  7]1 ",s,"k","");
  pl("7[8OffLine   7]");
  return 0;
  }
  else return 1;
}


void upload(int dn)
{
  directoryrec d;
  uploadsrec u,u1;
  int i,i1,i2,ok,xfer,f;
  char s[255],s1[101],s3[21],*ss;
  long l;
  double ti;

  dliscan1(dn);
  d=directories[dn];
  if (numf>=d.maxfiles) {
    nl();
    nl();
    pl("This directory is currently full.");
    nl();
    closedl();
    return;
  }
  if (d.mask & mask_no_uploads) {
    nl();
    nl();
    pl("Uploads are not allowed to this directory.");
    nl();
    closedl();
    return;
  }
  nl();
  l=(long)freek1(d.path);
  sprintf(s,"Upload - %ldk free.",l);
  pl(s);
    if (l<100) {
    pl("Not enough disk space to upload here.");
    nl();
    closedl();
    return;
  }
  pl("7Filename: ");
  mpl(12);
  input(s,12);
  if (!okfn(s))
    s[0]=0;
  align(s);
  if (strchr(s,'?')) {
    closedl();
    return;
  }
  if (d.mask & mask_archive) {
    ok=0;
    s1[0]=0;
    for (i=0; i<4; i++) {
      if (syscfg.arcs[i].extension[0] && syscfg.arcs[i].extension[0]!=' ') {
        if (s1[0])
          strcat(s1,", ");
        strcat(s1,syscfg.arcs[i].extension);
        if (strcmp(s+9,syscfg.arcs[i].extension)==0)
          ok=1;
      }
    }
    if (!ok) {
      nl();
      pl("Sorry, all uploads to this dir must");
      pl("be archived.  Supported types are:");
      pl(s1);
      nl();
      closedl();
      return;
    }
  }
  strcpy(u.filename,s);
  u.ownerusr=usernum;
  u.ownersys=0;
  u.numdloads=0;
  u.filetype=0;
  u.mask=0;
  u.points=0;
  u.ats[0]=0;
  strcpy(u.upby,nam1(&thisuser,usernum,syscfg.systemnumber));
  strcpy(u.date,date());
  nl();
  ok=1;
  xfer=1;
  sprintf(s1,"Upload '%s' to %s? ",s,d.name);
  if (strcmp(s,"        .   "))
    prt(5,s1);
  else
    ok=0;
  if ((ok) && (yn())) {
    strcpy(s1,d.path);
    strcat(s1,s);
    if (exist(s1)) {
      if (dcs()) {
        xfer=0;
        nl();
        nl();
        pl("File already exists.");
        prt(5,"Add to database anyway? ");
        if (yn()==0)
          ok=0;
      } else {
        nl();
        nl();
        pl("That file is already here.");
        nl();
        ok=0;
      }
    } else
      if (!incom) {
        nl();
        pl("File isn't already there.");
        pl("Can't upload locally.");
        nl();
        ok=0;
      }
    if ((d.mask & mask_PD) && (ok)) {
      nl();
      prt(5,"Is this program PD/Shareware? ");
      if (!yn()) {
        nl();
        pl("This directory is for Public Domain/");
        pl("Shareware programs ONLY.  Please do not");
        pl("upload other programs.  If you have");
        pl("trouble with this policy, please contact");
        pl("the sysop.");
        nl();
        sprintf(s,"Wanted to upload '%s'",u.filename);
        add_ass(5,s);
        ok=0;
      } else
        u.mask=mask_PD;
    }
    if (ok) {
      nl();
      pl("Please enter a one line description.");
      outstr("> ");
      inputl(u.description,49);
      nl();
      ss=NULL;
      modify_extended_description(&ss);
      if (ss) {
        add_extended_description(u.filename,ss);
        u.mask |= mask_extended;
        farfree(ss);
      }
      nl();
      if (xfer) {
	ti=timer();
	strcpy(batch.batchdesc,u.description);
	batch.extdesc=u.mask;
    receive_file(s1,&ok,s3,0);
	ti=timer()-ti;
	if (ti<0)
	  ti += 24.0*3600.0;
	thisuser.extratime += ti;
      }
      if ((ok!=0) && (ok!=255)) {
      sprintf(s1,"%s\\%s",d.path,u.filename);
	f=open(s1,O_RDONLY | O_BINARY);    
	if (f<0) {
	  ok=0;
	  nl();
	  pl("DOS error - File not found.");
	  nl();
	  if (u.mask & mask_extended)
	    delete_extended_description(u.filename);
	}
	if (ok && syscfg.upload_c[0]) {
	  stuff_in(s,syscfg.upload_c,create_chain_file("CHAIN.TXT"),d.path,stripfn(u.filename),"","");
	  close(f);
      pl("4�3Testing File Integrity");
	  full_external(s,0,1);
      sprintf(s,"%s\\badfile",syscfg.datadir);
      if(exist(s)) {
         pl("Error in Upload.");
         outstr("7Save File for Resume Upload?");
         if(yn())
           u.ats[3]=0;
        }
	  f=open(s1,O_RDONLY | O_BINARY);
	  if (f<0) {
	    ok=0;
	    nl();
	    pl("File got removed.");
	    nl();
	    if (u.mask & mask_extended)
	      delete_extended_description(u.filename);
	  }
        }
        if (ok) {
          l=filelength(f);
          u.numbytes=l;
          close(f);
          ++thisuser.uploaded;
          thisuser.uk += ((l+1023)/1024);
      thisuser.filepoint += ((l+1023)/10240);
      if(nifty.nifstatus & nif_credit) thisuser.credits++;
	  time(&l);
	  u.daten=l;
	  for (i=numf; i>=1; i--) {
	    SETREC(i);
	    read(dlf,(void *)&u1,sizeof(uploadsrec));
	    SETREC(i+1);
	    write(dlf,(void *)&u1,sizeof(uploadsrec));
	  }
	  SETREC(1);
	  write(dlf,(void *)&u,sizeof(uploadsrec));
	  ++numf;
	  u1.numbytes=numf;
	  SETREC(0);
          write(dlf,(void *)&u1,sizeof(uploadsrec));
          ++status.uptoday;
	  save_status();
      sprintf(s,"+%s uploaded on %s using %s",u.filename,directories[dn].name,s3);
	  sysoplog(s);
	  nl();
	  nl();
	  pl("File uploaded.");
	  nl();
	  sprintf(s,"%-6.3f",ratio());
	  print("Your ratio is now: ",s,"");
	  nl();
	  nl();
	  if (useron)
	    topscreen();
	}
      } else if (!ok) {
        nl();
        nl();
        pl("Transfer aborted.");
        nl();
        if (u.mask & mask_extended)
          delete_extended_description(u.filename);
      }
    }
  }
  closedl();
}


/****************************************************************************/
int try_to_download(char *s, int dn,int title)
{
  int i,ok,sent,abort;
  uploadsrec u;
  directoryrec d;
  char s1[81],s2[21];

  dliscan1(dn);
  i=recno(s);
  if (i<=0) {
    closedl();
    return(0);
  }
  ok=1;
  while ((i>0) && (ok) && (!hangup)) {
    if(!d.mask & mask_no_ratio)
     if (!ratio_ok()) {
       closedl();
        return(-1);
     }
    tleft(1);
    SETREC(i);
    read(dlf,(void *)&u,sizeof(uploadsrec));
    nl();
    if (title)
      print("7[0Directory  7]1 ",directories[dn].name,"");
    if((printfileinfo(&u,dn)) || (strncmp(u.filename,"DOM",5)==0)) {
        if(nifty.nifstatus & nif_fpts)
          if(thisuser.filepoint<u.points)
            if(!(thisuser.exempt & exempt_ratio))
              if((!thisuser.res[5]) && (thisuser.sl<200)) {
                nl();
                prt(8,"You don't have enough File Points for this file");
                return(-1);
            }
        if((!u.ats[0]) && (thisuser.sl<100)) {
        prt(8,"Unvalidated files cannot be Downloaded");
        return(-1);
        }
        if((!u.ats[3]) && (thisuser.sl<100)) {
        prt(8,"Resume Files Cannot be Downloaded");
        return(-1);
        }
      strcpy(s1,(directories[dn].path));
      strcat(s1,u.filename);
      sent=0;
      abort=0;
      send_file(s1,&sent,&abort,s2,u.filename,dn,u.numbytes);
      if (sent) {
        ++thisuser.downloaded;
        thisuser.dk += (int) ((u.numbytes+1023)/1024);
        thisuser.filepoint-=(u.points+2)/2;
        ++u.numdloads;
        SETREC(i);
        write(dlf,(void *)&u,sizeof(uploadsrec));
        sprintf(s1,"Downloaded '%s'",u.filename);
        sysoplog(s1);
        nl();
        nl();
        sprintf(s1,"Your ratio is now: %-6.3f",ratio());
        pl(s1);
        sprintf(s1,"%s downloaded '%s' on %s",
          nam(&thisuser,usernum), u.filename, date());
        ssm(u.ownerusr,0,s1);
        if (useron)
          topscreen();
      }
    } else {
      nl();
      nl();
      pl("Not enough time left to D/L.");
      nl();
    }
    if (abort)
      ok=0;
    else
      i=nrecno(s,i);
  }
  closedl();
  if (abort)
    return(-1);
  else
    return(1);
}

/****************************************************************************/


void download()
{
  char *p;
  char s[162],s1[162];
  int dn,i,i1;

  nl();
  if(!ratio_ok()) return;
  pl("0Enter 7multiple 0filenames, seperated by spaces.");
  mpl(78);
  input(s,160);
  if (s[0]==0)
    return;
  strcpy(s1,s);
  p=strtok(s1," ,;");
  while (p) {
    i1=0;
    strcpy(s,p);
    if (!okfn(s))
      break;
    if ((strchr(s,'.')==NULL) && (s[7]))
      strcat(s,".*");
    else if((strchr(s,'.')==NULL) && (!s[7]))
      strcat(s,"*.*");
    align(s);
    if (!try_to_download(s,udir[curdir].subnum,0)) {
      nl();
      outstr("Searching for ");
      ansic(1);
      outstr(s);
      dn=0;
      while ((dn<64) && (udir[dn].subnum!=-1)) {
        i=try_to_download(s,udir[dn].subnum,1);
        if (i==1)
          i1=1;
        if (i<0)
          dn=100;
        else
          dn++;
      }
      if (!i1) {
        ansic(7);
        outstr(" Not Found");
        nl();
      }  
    }
    p=strtok(NULL," ,;");
  }
}

void setldate()
{
  struct date d;
  struct time t;
  char s[81];
  int m,dd,y;

  nl();
  nl();
  unixtodos(nscandate,&d,&t);
  nl();
  sprintf(s,"Current limiting date = %02d/%02d/%02d",d.da_mon,d.da_day,(d.da_year-1900));
  pl(s);
  nl();
  pl("Enter new limiting date in the format:");
  pl(" MM/DD/YY");
  outstr(":");
  input(s,8);
  m=atoi(s);
  dd=atoi(&(s[3]));
  y=atoi(&(s[6]))+1900;
  if ((strlen(s)==8) && (m>0) && (m<=12) && (dd>0) && (dd<32) && (y>=1980)) {
    t.ti_min=0;
    t.ti_hour=0;
    t.ti_hund=0;
    t.ti_sec=0;
    d.da_year=y;
    d.da_day=dd;
    d.da_mon=m;
    sprintf(s,"Current limiting date = %02d/%02d/%02d",m,dd,(y-1900));
    nl();
    pl(s);
    nl();
    nscandate=dostounix(&d,&t);
  }
}

void finddescription()
{
  uploadsrec u;
  int i,i1,i2,abort,pty,d,ocd,pts;
  char s[81],s1[81],s2[81];

  nl();
  pl("Enter string to search for in file description:");
  outstr(">");
  input(s1,58);
  if (s1[0]==0)
    return;

  ocd=curdir;
  abort=0;
  num_listed=0;
  for (i=0; (i<64) && (!abort) && (!hangup) && (udir[i].subnum!=-1); i++) {
    i1=udir[i].subnum;
    pts=0;
    if (i1>=32) {
      if (thisuser.nscn2 & (1L << (i1-32)))
        pts=1;
    } else {
      if (thisuser.nscn1 & (1L << i1))
        pts=1;
    }
    pts=1;
    /* remove pts=1 to search only marked directories */
    if (pts) {
      curdir=i;
      dliscan();
      pty=1;
      for (i1=1; (i1<=numf) && (!abort) && (!hangup); i1++) {
        SETREC(i1);
        read(dlf,(void *)&u,sizeof(uploadsrec));
        strcpy(s,u.description);
        for (i2=0; i2<strlen(s); i2++)
          s[i2]=upcase(s[i2]);
        if (strstr(s,s1)!=NULL) {
          if (pty) {
            printtitle(&abort);
            pty=0;
          }
          printinfo(&u,&abort);
        }
      }
      closedl();
    }
  }
  curdir=ocd;
  if ((num_listed) && (!abort)) {
    nl();
    nl();
    sprintf(s,"Files listed: %d",num_listed);
    pl(s);
    nl();
  }
}


void arc_l()
{
  char s[81],s1[81],s2[81];
  int i,abort,next,i1;
  uploadsrec u;

  nl();
  pl("7File for listing: ");
  mpl(12);
  input(s,12);
  if (strchr(s,'.')==NULL)
    strcat(s,".*");
  if (!okfn(s))
    s[0]=0;
  align(s);
  dliscan();
  abort=0;
  next=0;
  i=recno(s);
  do {
    if (i>0) {
      SETREC(i);
      read(dlf,(void *)&u,sizeof(uploadsrec));
      i1=list_arc_out(stripfn(u.filename),directories[udir[curdir].subnum].path);
      if (i1)
        abort=1;
      checka(&abort,&next);
      i=nrecno(s,i);
    }
  } while ((i>0) && (!hangup) && (!abort));
  closedl();
}


/****************************************************************************/


void yourinfodl()
{
  char s[81],s1[81],s2[81],s3[81];

  itoa(thisuser.uploaded,s,10);
  itoa(thisuser.downloaded,s1,10);
  ltoa(thisuser.uk,s2,10);
  ltoa(thisuser.dk,s3,10);
  nl();
  nl();
  print("7[0Uploads    7]1 ",s2,"k in ",s," files","");
  print("7[0Downloads  7]1 ",s3,"k in ",s1," files","");
  sprintf(s,"%-6.3f",ratio());
  print("7[0Ratio      7]1 ",s,"");
  if(nifty.nifstatus & nif_fpts) {
  itoa((int)thisuser.filepoint,s,10);
  print("7[0File Points7]1 ",s,""); }
  itoa(thisuser.dsl,s,10);
  print("7[0Your DSL   7]1 ",s,"");
  nl();
}

void l_config_nscan()
{
  int i,abort,i1;
  char s[81];

  abort=0;
  nl();
  pl("Dirs to n-scan marked with '*'");
  nl();
  for (i=0; (i<64) && (udir[i].subnum!=-1) && (!abort); i++) {
    i1=udir[i].subnum;
    if (i1<32) {
      if ((1L << (i1)) & thisuser.nscn1)
        strcpy(s,"* ");
      else
        strcpy(s,"  ");
    } else {
      if ((1L << (i1-32)) & thisuser.nscn2)
        strcpy(s,"* ");
      else
        strcpy(s,"  ");
    }
    strcat(s,(udir[i].keys));
    strcat(s,". ");
    strcat(s,directories[i1].name);
    pla(s,&abort);
  }
  nl();
  nl();
}

void config_nscan()
{
  char *s;
  int i,done,i1;

  l_config_nscan();
  done=0;
  do {
    nl();
    pl("Enter directory identifier, ? to list, or Q to Quit");
    prt(2,"Config: ");
    s=mmkey(1);
    if (s[0])
      for (i=0; i<64; i++)
        if (strcmp(udir[i].keys,s)==0) {
          i1=udir[i].subnum;
          if (i1<32)
            thisuser.nscn1 ^= ((1L) << i1);
          else
            thisuser.nscn2 ^= ((1L) << (i1-32));
        }
    if (strcmp(s,"Q")==0)
      done=1;
    if (strcmp(s,"?")==0)
      l_config_nscan();
  } while ((!done) && (!hangup));
}


/*void xfer_defaults()
{
  char s[81],s1[81],ch;
  int i,i1,i2,done;

  done=0;
  do {
    outchr(12);
    pl("1. Set NewScan Directories.");
    pl("2. Set Default Protocol.");
    sprintf(s,"3. Number of lines of extended description to print (%d line%s).",
      thisuser.num_extended,thisuser.num_extended==1?"":"s");
    pl(s);
    pl("Q. Quit.");
    nl();
    prt(2,"Which? ");
    ch=onek("Q123");
    switch(ch) {
      case 'Q':
        done=1;
        break;
      case '1':
        config_nscan();
        break;
      case '2':
        nl();
        nl();
        pl("Enter your default protocol, 0 for none.");
        nl();
	i=get_protocol(1,1);
        if (i>=0)
          thisuser.defprot=i;
        break;
      case '3':
        nl();
        nl();
        pl("How many lines of an extended description");
        pl("do you want to see when listing files (0-10)");
        itoa(thisuser.num_extended,s,10);
        print("(Currently set to ",s," lines)","");
        prt(5,"? ");
        input(s,3);
        if (s[0]) {
          i=atoi(s);
          if ((i>=0) && (i<=10))
            thisuser.num_extended=i;
        }
        break;
    }
  } while ((!done) && (!hangup));

}*/


void removefile()
{
  int i,i1,ok,rm,abort,rdlp;
  char ch,s[81],s1[81];
  uploadsrec u;
  userrec uu;

  dliscan();
  nl();
  pl("Enter filename to remove.");
  mpl(12);
  input(s,12);
  if (s[0]==0) {
    closedl();
    return;
  }
  if (strchr(s,'.')==NULL)
    strcat(s,".*");
  align(s);
  i=recno(s);
  abort=0;
  while ((!hangup) && (i>0) && (!abort)) {
    SETREC(i);
    read(dlf,(void *)&u,sizeof(uploadsrec));
    if ((dcs()) || ((u.ownersys==0) && (u.ownerusr==usernum))) {
      nl();
      printfileinfo(&u,udir[curdir].subnum);
      prt(2,"Remove (Y/N/Q) : ");
      ch=onek("QNY");
      if (ch=='Q')
        abort=1;
      if (ch=='Y') {
        rdlp=1;
        if (dcs()) {
          prt(5,"Delete file too? ");
          rm=yn();
          if (rm) {
            prt(5,"Remove DL filepoint? ");
            rdlp=yn();
          }
        } else
          rm=1;
        if (rm) {
          strcpy(s1,(directories[udir[curdir].subnum].path));
          strcat(s1,u.filename);
          unlink(s1);
          if ((rdlp) && (u.ownersys==0)) {
            read_user(u.ownerusr,&uu);
            if ((uu.inact & inact_deleted)==0) {
              --uu.uploaded;
              uu.uk -= ((u.numbytes+1023)/1024);
              uu.filepoint-=u.points;
              write_user(u.ownerusr,&uu);
            }
            close_user();
          }
        }
        if (u.mask & mask_extended)
          delete_extended_description(u.filename);
        sprintf(s1,"-%s Removed off of %s",u.filename,
                          directories[udir[curdir].subnum].name);
        sysoplog(s1);
        for (i1=i; i1<numf; i1++) {
          SETREC(i1+1);
          read(dlf,(void *)&u,sizeof(uploadsrec));
          SETREC(i1);
          write(dlf,(void *)&u,sizeof(uploadsrec));
        }
        --i;
        --numf;
        u.numbytes=numf;
        SETREC(0);
        write(dlf,(void *)&u,sizeof(uploadsrec));
      }
    }
    i=nrecno(s,i);
  }
  closedl();
}

void killoff()
{
  int i,i1,ok,rm,abort,rdlp;
  char ch,s[81],s1[81],s2[161];
  uploadsrec u;
  userrec uu;

  pl("7Killing OffLine files...");
  nl();
  dliscan();
  nl();
  strcpy(s,"*.*");
  align(s);
  i=recno(s);
  abort=0;
  while ((!hangup) && (i>0) && (!abort)) {
    SETREC(i);
    read(dlf,(void *)&u,sizeof(uploadsrec));
    if ((dcs()) && (!printfileinfo2(&u,udir[curdir].subnum)) ) {
      nl();
      prt(2,"Remove (Y/N/Q) : ");
      ch=onek("QNY");
      if (ch=='Q')
        abort=1;
      if (ch=='Y') {
        rdlp=1;
	if (dcs()) {
	  rm=1;
	  if (rm) {
            prt(5,"Remove DL filepoint? ");
            rdlp=yn();
          }
        } else
          rm=1;
        if (rm) {
          strcpy(s1,(directories[udir[curdir].subnum].path));
          strcat(s1,u.filename);
          unlink(s1);
          if ((rdlp) && (u.ownersys==0)) {
            read_user(u.ownerusr,&uu);
            if ((uu.inact & inact_deleted)==0) {
              --uu.uploaded;
              uu.uk -= ((u.numbytes+1023)/1024);
              uu.filepoint-=u.points;
              write_user(u.ownerusr,&uu);
            }
            close_user();
          }
        }
        if (u.mask & mask_extended)
          delete_extended_description(u.filename);
        sprintf(s1,"-%s Removed off of %s",u.filename,
                          directories[udir[curdir].subnum].name);
        sysoplog(s1);
        for (i1=i; i1<numf; i1++) {
          SETREC(i1+1);
          read(dlf,(void *)&u,sizeof(uploadsrec));
          SETREC(i1);
          write(dlf,(void *)&u,sizeof(uploadsrec));
        }
        --i;
        --numf;
        u.numbytes=numf;
        SETREC(0);
        write(dlf,(void *)&u,sizeof(uploadsrec));
      }
    }
    i=nrecno(s,i);
  }
  closedl();
}

