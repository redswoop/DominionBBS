void inputpl2(char *s, int maxlen)
/* This will input a line of data, maximum maxlen characters long, terminated
 * by a C/R.  Every first letter of each word is capitalized. Only allows
 * letters, spaces, quotes, dashes, peroids and commas. Stands for INPUT Proper
 * Line 2.
 */
 /* VERSION 1.0 8/17/88 by DOUG FIELDS voice: 203-661-2967 */
{
  int curpos, done, thisoneupper;
  unsigned char ch;

#define ISGOOD(c) ((c) == '-') || isalnum((c)) || ((c) == ',') || \
((c) == '.') || ((c) == ' ') || ((c) == '\'')

  curpos=0;
  done=0;
  while ((!done) && (!hangup))
    {
    /* Can't put the next two in together cause it would possibly cause a
       range error -- that would go undetected and possibly mess up
       important memory. */
    thisoneupper = (!curpos);
    if (!thisoneupper)
      thisoneupper = (s[curpos - 1] == ' ') || (s[curpos - 1] == '-') ||
        isdigit(s[curpos - 1]) || (s[curpos - 1] == ',') ||
        (s[curpos - 1] == '.');
    ch=getkey();
    if (ISGOOD(ch))
      {
      if (curpos < maxlen)
        {
        if (thisoneupper) ch = toupper(ch); else ch = tolower(ch);
        outchr(s[curpos++]=ch);
        }
      }
    else
      switch(ch)
        {
        case 14:
        case 13:
          done=1;
          s[curpos]=0;
          echo=1;
          nl();
          break;
        case 8:
          if (curpos)
            {
            curpos--;
            backspace();
            }
          break;
        case 24:
          while (curpos)
            {
            curpos--;
            backspace();
            }
        }
    }
  if (hangup) s[0]=0;
}