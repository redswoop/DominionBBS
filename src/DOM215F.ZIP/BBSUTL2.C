#include <stdio.h>
#include <sys\stat.h>
#include <string.h>
#include <stdlib.h>
#include <io.h>
#include <fcntl.h>
#include "fcns.h"
#include "nifrec.h"

extern configrec syscfg;
extern statusrec status;
extern int noklevel,niftyfile,hangup,configfile,usernum;
extern configrec syscfg;
extern niftyrec nifty;
extern userrec thisuser;
extern char cfilt[255],scfilt[255];
extern int com_speed;

typedef struct {
  unsigned char thestring[161];
} stringrec;

typedef struct {
  unsigned char thesaying[81];
} sayingrec;


char *get_string(int whichstring)
{
  static char s[161],s1[81];
  int i;
  stringrec astring;

    sprintf(s1,"%s\\strings.dat",syscfg.datadir);
    i=open(s1,O_RDWR | O_BINARY);
    if (i<0) {
      pl("String File is Missing,  Nothing can be shown.");
    }
  lseek(i,((long)(whichstring-1))*(sizeof(astring)),SEEK_SET);
  read(i,(void *)&astring,sizeof(astring));
  sprintf(s,"%s",&astring.thestring); 
  close(i);
  return(s);
}

char *get_say(int which)
{
  static char s[161],s1[81];
  int i,tot=0;
  sayingrec asaying;

    sprintf(s1,"%s\\sayings.dat",syscfg.datadir);
    if(!exist(s1)) return("Sorry, I have Nothing To Say.  Add a Rumour.");
    i=open(s1,O_RDWR | O_BINARY);

  if(which) {
    nl();
  lseek(i,0L,SEEK_SET);
  while(read(i,(void *)&asaying,sizeof(asaying))) {
    sprintf(s,"%s",&asaying.thesaying);
    pl(s);
    }
   return 0;
  }

  else {
  lseek(i,0L,SEEK_SET);
  while(read(i,(void *)&asaying,sizeof(asaying))) tot++;
  which=random(tot);
  lseek(i,((long)(which-1))*(sizeof(asaying)),SEEK_SET);
  read(i,(void *)&asaying,sizeof(asaying));
  sprintf(s,"%s",&asaying.thesaying);
  close(i);
  return(s);
  }
}

void liststring()
{
  static char s[161],s1[81];
  int i,num=1;
  stringrec astring;

    sprintf(s1,"%s\\strings.dat",syscfg.datadir);
    i=open(s1,O_RDWR | O_BINARY);

    nl();
  lseek(i,0L,SEEK_SET);
  while(read(i,(void *)&astring,sizeof(astring))) {
    sprintf(s,"%d>%s",num++,&astring.thestring);
    pl(s);
    }
}

void addsay(void)
{
    char s[71],s1[81];
    int i;
    sayingrec asaying;

  s[0]=0;
  pl("Enter something interesting to say.");
  mpl(71);
  inputl(s,70);
  if(!s[0]) return;
  strcpy(s1,"Added Rumour ");strcat(s1,s);
  sysoplog(s1);
  strcpy(asaying.thesaying,s);
  sprintf(s1,"%s\\sayings.dat",syscfg.datadir);
  i=open(s1,O_RDWR | O_CREAT | O_BINARY | S_IREAD | S_IWRITE);
  lseek(i,0L,SEEK_END);
  write(i,(void *)&asaying,sizeof(sayingrec));
  close(i);
}

void edstring(void)
{
    char s[161],s1[161];
    int i,ednum,m=1;
    stringrec astring;

      sprintf(s1,"%s\\strings.dat",syscfg.datadir);
      i=open(s1,O_RDWR | O_CREAT |O_BINARY | S_IREAD | S_IWRITE );
  nl();
  outstr("List Strings? ");
  if(yn())
      liststring();
  pl("Enter String # to edit.");
  input(s,3);
  ednum=atoi(s);
  lseek(i,((long)(ednum-1))*(sizeof(astring)),SEEK_SET);
  read(i,(void *)&astring,sizeof(astring));
  lseek(i,((long)(ednum-1))*(sizeof(astring)),SEEK_SET);
  pl("7Current Value:");
  pl(astring.thestring);
  nl();
  outstr("4:");
  strcpy(s,"");
  strcpy(s1,s);
  inli(s,astring.thestring,160,1);
  if(!s[0]) { close(i); return;}
  strcpy(astring.thestring,"");
  strcpy(astring.thestring,s);
   write(i,(void *)&astring,161L);
  close(i);
}

void readfilter(char fn[15],char fn2[15])
{
   char s[100];
   int i;
   sprintf(s,"%s%s",syscfg.gfilesdir,fn);
   i=open(s,O_RDONLY|O_BINARY);
   read(i,cfilt,255);
   close(i);
   sprintf(s,"%s%s",syscfg.gfilesdir,fn2);
   i=open(s,O_RDONLY|O_BINARY);
   read(i,scfilt,255);
   close(i);
}

char *matrix()
{
    char s[31];
    int i,done,ans;

    if(!(nifty.nifstatus & nif_matrix)) return("");
    outstr("Welcome to "); pl(syscfg.systemname);
    thisuser.sysstatus &= ~sysstatus_ansi;
    ans=check_ansi();
    printfile(ans ? "welcome.ans":"welcome.msg");
    if(ans) read_user(1,&thisuser);

    do {
        nl();
        prompt("NN:[Matrix Menu] [?\Help]>","");
        input(s,31);
        if(s[0]) if(!strcmp(s,"DOM")) return("");
        else if(!strcmp(s,get_string(30))) {
            i=com_speed;
            if(i==2400) exit(100); else
            if(i==1200) exit(101); else
            if(i==300) exit(102);
        }
        else if(!strcmp(s,"!-@NETWORK@-!")) return(s);
        else if(!strcmp(s,"?")) printfile("matrix");
        else if(!strcmp(s,"CHAT")) reqchat("Matrix Chat");
        else if(!strcmp(s,"LOGOFF")) hangup=1;
    } while(!hangup);
return("");
}

char *get_file(char *fn, long *len)
{
  int i;
  char *s;

  i=open(fn,O_RDWR | O_BINARY);
  if (i<0) {
    *len=0L;
    return(NULL);
  }
  if ((s=malloca(filelength(i)+50))==NULL) {
    *len=0L;
    close(i);
    return(NULL);
  }
  *len=(long) read(i,(void *)s, filelength(i));
  close(i);
  return(s);
}

void fixshit(void)
{
    userrec u;
    int x,uu;

  for(x=0;x<status.users;x++) {
     read_user(x,&u);
     pl(nam(&u,x));
        for(uu=0;uu<33;uu++)
              u.qscnptr[uu]=status.qscanptr;
    write_user(x,&u);
  }
}

void glocolor(void)
{
    userrec u,u2;
    int x,uu;

    read_user(1,&u2);

  for(x=0;x<status.users;x++) {
     read_user(x,&u);
     pl(nam(&u,x));
        for(uu=0;uu<20;uu++)
              u.colors[uu]=u2.colors[uu];
    write_user(x,&u);
  }
}
