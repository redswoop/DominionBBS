#include <stdio.h>
#include <sys\stat.h>
#include <fcntl.h>
#include <time.h>
#include <dos.h>
#include <dir.h>
#include <string.h>
#include <io.h>
#include <alloc.h>
#include <stdlib.h>
#include "fcns.h"

extern userrec thisuser;
extern directoryrec directories[64];
extern int num_dirs,hangup,userfile,echo,useron,userfile,usernum;
extern int incom,fwaiting;
extern configrec syscfg;
extern statusrec status;
extern int edlf,dlf,curdir,numf;
extern usersubrec udir[64];
extern long nscandate;
extern char curspeed[81],cdir[81],dszlog[81];
extern unsigned int modem_speed,com_speed;
extern float batchtime;
extern int numbatch, numbatchdl, num_listed;
extern batchrec *batch;
extern double extratimecall;
extern unsigned char realsl;

#define SETREC(i)  lseek(dlf,((long) (i))*((long)sizeof(uploadsrec)),SEEK_SET);

void move_file()
{
  char sx[81],s[81],s1[81],s2[81],ch,*ss;
  int i,i1,ok,d1,d2,done,cp;
  uploadsrec u,u1,u2;
  char *b;

  ok=0;
  nl();
  nl();
  prt(2,"Filename to move: ");
  input(sx,12);
  if (strchr(sx,'.')==NULL)
    strcat(sx,".*");
  align(sx);
  dliscan();
  i=recno(sx);
  if (i<0) {
    nl();
    pl("File not found.");
    closedl();
    return;
  }
  done=0;
  while ((!hangup) && (i>0) && (!done)) {
    cp=i;
    SETREC(i);
    read(dlf,(void *)&u,sizeof(uploadsrec));
    nl();
    printfileinfo(&u,udir[curdir].subnum);
    nl();
    prt(5,"Move this (Y/N/Q)? ");
    ch=onek("QNY");
    if (ch=='Q')
      done=1;
    if (ch=='Y') {
      strcpy(s1,directories[udir[curdir].subnum].path);
      strcat(s1,u.filename);
      do {
        nl();
        nl();
        prt(2,"To which directory? ");
        ss=mmkey(1);
        if (ss[0]=='?')
          dirlist();
      } while ((!hangup) && (ss[0]=='?'));
      d1=-1;
      if (ss[0])
        for (i1=0; (i1<64) && (udir[i1].subnum!=-1); i1++)
          if (strcmp(udir[i1].keys,ss)==0)
            d1=i1;
      if (d1!=-1) {
        ok=1;
        d1=udir[d1].subnum;
        closedl();
        dliscan1(d1);
        if (recno(u.filename)>0) {
          ok=0;
          nl();
          pl("Filename already in use in that directory.");
        }
        if (numf>=directories[d1].maxfiles) {
          ok=0;
          nl();
          pl("Too many files in that directory.");
        }
        if (freek1(directories[d1].path)<((double)(u.numbytes/1024L)+3)) {
          ok=0;
          nl();
          pl("Not enough disk space to move it.");
        }
        closedl();
        dliscan();
      } else
        ok=0;
    } else
      ok=0;
    if (ok) {
      --cp;
      for (i1=i; i1<numf; i1++) {
        SETREC(i1+1);
        read(dlf,(void *)&u1,sizeof(uploadsrec));
        SETREC(i1);
        write(dlf,(void *)&u1,sizeof(uploadsrec));
      }
      --numf;
      u1.numbytes=numf;
      SETREC(0);
      write(dlf,(void *)&u1,sizeof(uploadsrec));
      ss=read_extended_description(u.filename);
      if (ss)
        delete_extended_description(u.filename);
      closedl();

      strcpy(s2,directories[d1].path);
      strcat(s2,u.filename);
      dliscan1(d1);
      for (i=numf; i>=1; i--) {
        SETREC(i);
        read(dlf,(void *)&u1,sizeof(uploadsrec));
        SETREC(i+1);
        write(dlf,(void *)&u1,sizeof(uploadsrec));
      }
      SETREC(1);
      write(dlf,(void *)&u,sizeof(uploadsrec));
      ++numf;
      u1.numbytes=numf;
      SETREC(0);
      write(dlf,(void *)&u1,sizeof(uploadsrec));
      if (ss) {
        add_extended_description(u.filename,ss);
        farfree(ss);
      }
      closedl();

      if ((strcmp(s1,s2)!=0) && (exist(s1))) {
        d2=0;
        if ((s1[1]!=':') && (s2[1]!=':'))
          d2=1;
        if ((s1[1]==':') && (s2[1]==':') && (s1[0]==s2[0]))
          d2=1;
        if (d2) {
          rename(s1,s2);
          unlink(s1);
        } else {
          if ((b=malloca(16400))==NULL)
            return;
          d1=open(s1,O_RDONLY | O_BINARY);
          d2=open(s2,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
          i=read(d1,(void *)b,16384);
          while (i>0) {
            write(d2,(void *)b,i);
            i=read(d1,(void *)b,16384);
          }
          close(d1);
          close(d2);
          unlink(s1);
          farfree(b);
        }
      }
      nl();
      pl("File moved.");
    } else
      closedl();
    dliscan();
    i=nrecno(sx,cp);
  }
  closedl();
}

void move_off()
{
  char sx[81],s[81],s1[81],s2[81],ch,*ss;
  int i,i1,ok,d1,d2,done,cp;
  uploadsrec u,u1,u2;
  char *b;

  ok=0;
  pl("7Moving Offline Files...");
  strcpy(sx,"*.*");
  align(sx);
  dliscan();
  i=recno(sx);
  if (i<0) {
    nl();
    pl("File not found.");
    closedl();
    return;
  }
  done=0;
  while ((!hangup) && (i>0) && (!done)) {
    cp=i;
    SETREC(i);
    read(dlf,(void *)&u,sizeof(uploadsrec));
    if(!printfileinfo2(&u,udir[curdir].subnum)) {
    prt(5,"Move this (Y/N/Q)? ");
    ch=onek("QNY"); }
    else  ch='N';
    if (ch=='Q')
      done=1;
    if (ch=='Y') {
      strcpy(s1,directories[udir[curdir].subnum].path);
      strcat(s1,u.filename);
      do {
        nl();
        nl();
        prt(2,"To which directory? ");
        ss=mmkey(1);
        if (ss[0]=='?')
          dirlist();
      } while ((!hangup) && (ss[0]=='?'));
      d1=-1;
      if (ss[0])
        for (i1=0; (i1<64) && (udir[i1].subnum!=-1); i1++)
          if (strcmp(udir[i1].keys,ss)==0)
            d1=i1;
      if (d1!=-1) {
        ok=1;
        d1=udir[d1].subnum;
        closedl();
        dliscan1(d1);
        if (recno(u.filename)>0) {
          ok=0;
          nl();
          pl("Filename already in use in that directory.");
        }
        if (numf>=directories[d1].maxfiles) {
          ok=0;
          nl();
          pl("Too many files in that directory.");
        }
        if (freek1(directories[d1].path)<((double)(u.numbytes/1024L)+3)) {
          ok=0;
          nl();
          pl("Not enough disk space to move it.");
        }
        closedl();
        dliscan();
      } else
        ok=0;
    } else
      ok=0;
    if (ok) {
      --cp;
      for (i1=i; i1<numf; i1++) {
        SETREC(i1+1);
        read(dlf,(void *)&u1,sizeof(uploadsrec));
        SETREC(i1);
        write(dlf,(void *)&u1,sizeof(uploadsrec));
      }
      --numf;
      u1.numbytes=numf;
      SETREC(0);
      write(dlf,(void *)&u1,sizeof(uploadsrec));
      ss=read_extended_description(u.filename);
      if (ss)
        delete_extended_description(u.filename);
      closedl();

      strcpy(s2,directories[d1].path);
      strcat(s2,u.filename);
      dliscan1(d1);
      for (i=numf; i>=1; i--) {
        SETREC(i);
        read(dlf,(void *)&u1,sizeof(uploadsrec));
        SETREC(i+1);
        write(dlf,(void *)&u1,sizeof(uploadsrec));
      }
      SETREC(1);
      write(dlf,(void *)&u,sizeof(uploadsrec));
      ++numf;
      u1.numbytes=numf;
      SETREC(0);
      write(dlf,(void *)&u1,sizeof(uploadsrec));
      if (ss) {
        add_extended_description(u.filename,ss);
        farfree(ss);
      }
      closedl();

      if ((strcmp(s1,s2)!=0) && (exist(s1))) {
        d2=0;
        if ((s1[1]!=':') && (s2[1]!=':'))
          d2=1;
        if ((s1[1]==':') && (s2[1]==':') && (s1[0]==s2[0]))
          d2=1;
        if (d2) {
          rename(s1,s2);
          unlink(s1);
        } else {
          if ((b=malloca(16400))==NULL)
            return;
          d1=open(s1,O_RDONLY | O_BINARY);
          d2=open(s2,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
          i=read(d1,(void *)b,16384);
          while (i>0) {
            write(d2,(void *)b,i);
            i=read(d1,(void *)b,16384);
          }
          close(d1);
          close(d2);
          unlink(s1);
          farfree(b);
        }
      }
      nl();
      pl("File moved.");
    } else
      closedl();
    dliscan();
    i=nrecno(sx,cp);
  }
  closedl();
}


int comparedl(uploadsrec *x, uploadsrec *y, int type)
{
  switch(type) {
    case 0:
      return(strcmp(x->filename,y->filename));
    case 1:
      if (x->daten < y->daten)
        return(-1);
      else
        if (x->daten > y->daten)
          return(1);
        else
          return(0);
    case 2:
      if (x->daten < y->daten)
        return(1);
      else
        if (x->daten > y->daten)
          return(-1);
        else
          return(0);
  }
  return(0);
}


void quicksort(int l,int r,int type)
{
  register int i,j;
  uploadsrec a,a2,x;

  i=l; j=r;
  SETREC(((l+r)/2));
  read(dlf, (void *)&x,sizeof(uploadsrec));
  do {
    SETREC(i);
    read(dlf, (void *)&a,sizeof(uploadsrec));
    while (comparedl(&a,&x,type)<0) {
      SETREC(++i);
      read(dlf, (void *)&a,sizeof(uploadsrec));
    }
    SETREC(j);
    read(dlf, (void *)&a2,sizeof(uploadsrec));
    while (comparedl(&a2,&x,type)>0) {
      SETREC(--j);
      read(dlf, (void *)&a2,sizeof(uploadsrec));
    }
    if (i<=j) {
      if (i!=j) {
        SETREC(i);
        write(dlf,(void *)&a2,sizeof(uploadsrec));
        SETREC(j);
        write(dlf,(void *)&a,sizeof(uploadsrec));
      }
      i++;
      j--;
    }
  } while (i<j);
  if (l<j)
    quicksort(l,j,type);
  if (i<r)
    quicksort(i,r,type);
}


void sortdir(int dn, int type)
{
  dliscan1(dn);
  if (numf>1)
    quicksort(1,numf,type);
  closedl();
}


void sort_all(int type)
{
  int i;

  for (i=0; (i<64) && (udir[i].subnum!=-1) && (!kbhitb()); i++) {
    nl();
    ansic(1);
    print("Sorting ",directories[udir[i].subnum].name,".","");
    sortdir(i,type);
  }
}


void rename_file()
{
  char s[81],s1[81],s2[81],*ss,s3[81],ch;
  int i,cp;
  uploadsrec u;

  nl();
  nl();
  prt(2,"File to Edit: ");
  input(s,12);
  if (s[0]==0)
    return;
  if (strchr(s,'.')==NULL)
    strcat(s,".*");
  align(s);
  dliscan();
  nl();
  strcpy(s3,s);
  i=recno(s);
  while (i>0) {
    cp=i;
    SETREC(i);
    read(dlf,(void *)&u,sizeof(uploadsrec));
    nl();
    printfileinfo(&u,udir[curdir].subnum);
    nl();
    prt(5,"Change info for this file (Y/N/Q)? ");
    ch=onek("QNY");
    if (ch=='Q')
      break;
    else if (ch=='N') {
      i=nrecno(s3,cp);
      continue;
    }
    nl();
    prt(2,"New filename? ");
    input(s,12);
    if (!okfn(s))
      s[0]=0;
    if (s[0]) {
      align(s);
      if (strcmp(s,"        .   ")) {
        strcpy(s1,directories[udir[curdir].subnum].path);
        strcpy(s2,s1);
        strcat(s1,s);
        if (exist(s1))
          pl("Filename already in use; not changed.");
        else {
          strcat(s2,u.filename);
          rename(s2,s1);
          if (exist(s1)) {
            ss=read_extended_description(u.filename);
            if (ss) {
              delete_extended_description(u.filename);
              add_extended_description(s,ss);
              farfree(ss);
            }
            strcpy(u.filename,s);
          } else
            pl("Bad filename.");
        }
      }
    }
    nl();
    pl("New description:");
    prt(2,": ");
    inputl(s,58);
    if (s[0]) {
      strcpy(u.description,s);
    }
    nl(); outstr("7Validated? 1");
    u.ats[0]=ny();
    nl(); prompt("7File Points? ","");
    input(s,3); u.points=s[0]?atoi(s):u.points;
    ss=read_extended_description(u.filename);
    nl();
    nl();
    prt(5,"Modify extended description? ");
    if (yn()) {
      nl();
      if (ss) {
        prt(5,"Delete it? ");
        if (yn()) {
          farfree(ss);
          delete_extended_description(u.filename);
          u.mask &= ~mask_extended;
        } else {
          u.mask |= mask_extended;
          modify_extended_description(&ss);
          if (ss) {
            delete_extended_description(u.filename);
            add_extended_description(u.filename,ss);
            farfree(ss);
          }
        }
      } else {
        modify_extended_description(&ss);
        if (ss) {
          add_extended_description(u.filename,ss);
          farfree(ss);
          u.mask |= mask_extended;
        } else
          u.mask &= ~mask_extended;
      }
    } else
      if (ss) {
        farfree(ss);
        u.mask |= mask_extended;
      } else
        u.mask &= ~mask_extended;
    SETREC(i);
    write(dlf,(void *)&u,sizeof(uploadsrec));
    i=nrecno(s3,cp);
  }
  closedl();
}

void valfiles()
{
  char s[81],s1[81],s2[81],*ss,s3[81],ch;
  int i,cp;
  uploadsrec u;
  userrec uu;

  strcpy(s,"*.*");
  align(s);
  dliscan();
  nl();
  strcpy(s3,s);
  i=recno(s);
  while (i>0) {
    cp=i;
    SETREC(i);
    read(dlf,(void *)&u,sizeof(uploadsrec));
    if(!u.ats[0]) {
    nl();
    printfileinfo(&u,udir[curdir].subnum);
    outstr("7Validate? 1");
    if(ny()) {
        u.ats[0]=1;
        u.points=((u.numbytes+1023)/10240);
        }
        else u.ats[0]=0;
    SETREC(i);
    write(dlf,(void *)&u,sizeof(uploadsrec));
     read_user(u.ownerusr,&uu);
        uu.filepoint+=u.points;
	    write_user(u.ownerusr,&uu);
        close_user();
    }
    i=nrecno(s3,cp);
  }
  closedl();
}

void comfiles()
{
  char s[81],s1[81],s2[81],*ss,s3[81];
  int i,cp;
  uploadsrec u;

  strcpy(s,"*.*");
  align(s);
  dliscan();
  nl();
  strcpy(s3,s);
  i=recno(s);
  while (i>0) {
    cp=i;
    SETREC(i);
    read(dlf,(void *)&u,sizeof(uploadsrec));
    sprintf(s,"pkzip -z %s<zipcom.txt",u.filename);
    if(strstr(u.filename,"ZIP")) ex("D1",s,"");
    SETREC(i);
    write(dlf,(void *)&u,sizeof(uploadsrec));
    i=nrecno(s3,cp);
    }
  closedl();
}




int upload_file(char *fn, int dn)
{
  directoryrec d;
  uploadsrec u,u1;
  int i,i1,i2,ok,f;
  char s[81],s1[81],ff[81];
  long l;
  double ti;

  d=directories[dn];
  strcpy(s,fn);
  align(s);
  strcpy(u.filename,s);
  u.ownerusr=usernum;
  u.ownersys=0;
  u.numdloads=0;
  u.filetype=0;
  u.mask=0;
  u.points=0;
  u.ats[0]=1;
  strcpy(ff,d.path);
  strcat(ff,s);
  f=open(ff,O_RDONLY | O_BINARY);
  l=filelength(f);
  u.numbytes=l;
  close(f);
  strcpy(u.upby,nam1(&thisuser,usernum,syscfg.systemnumber));
  strcpy(u.date,date());
  if (d.mask & mask_PD)
    d.mask=mask_PD;
  strcpy(s,u.filename);
  strcat(s,": ");
  ltoa((((u.numbytes)+1023)/1024),s1,10);
  strcat(s1,"k");
  for (i=0; i<5-strlen(s1); i++)
    strcat(s," ");
  strcat(s,s1);
  strcat(s," :");
  outstr(s);
  inputl(u.description,49);
  if (u.description[0]=='.') return 0;
  if (u.description[0]==0)
   strcpy(u.description,"No Description Given at Upload");
    thisuser.filepoint+=atoi(s);
  ++thisuser.uploaded;
  u.points=((l+1023)/10240);
  thisuser.uk += ((l+1023)/1024);
  time(&l);
  u.daten=l;
  for (i=numf; i>=1; i--) {
    SETREC(i);
    read(dlf,(void *)&u1,sizeof(uploadsrec));
    SETREC(i+1);
    write(dlf,(void *)&u1,sizeof(uploadsrec));
  }
  SETREC(1);
  write(dlf,(void *)&u,sizeof(uploadsrec));
  ++numf;
  u1.numbytes=numf;
  SETREC(0);
  write(dlf,(void *)&u1,sizeof(uploadsrec));
  ++status.uptoday;
  save_status();
  sprintf(s,"+%s uploaded on %s",u.filename,d.name);
  sysoplog(s);
  return(1);
}


int uploadall(int dn)
{
  int i,i1,f1,maxf,ok,ocd;
  char s[81],s1[81];
  struct ffblk ff;
  uploadsrec u;

  dliscan1(dn);
  ocd=curdir;
  curdir=dn;
  nl();
  nl();
  strcpy(s,"*.*");
  strcpy(s1,(directories[dn].path));
  maxf=directories[dn].maxfiles;
  strcat(s1,s);
  f1=findfirst(s1,&ff,0);
  ok=1;
  i1=0;
  while ((f1==0) && (!hangup) && (numf<maxf) && (ok) && (!i1)) {
    strcpy(s,(ff.ff_name));
    align(s);
    i=recno(s);
    if (i==-1) {
      if (!upload_file(s,dn))
        ok=0;
    } else {
      SETREC(i);
      read(dlf,(void *)&u, sizeof(uploadsrec));
    }
    f1=findnext(&ff);
  }
  curdir=ocd;
  closedl();
  if (!ok)
    pl("Aborted.");
  if (numf>=maxf)
    pl("directory full.");
  return(i1);
}


