#include "fcns.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <io.h>
#include <fcntl.h>
#include <sys\stat.h>
#include <time.h>


extern subboardrec subboards[32];
extern directoryrec directories[64];
extern int num_subs, num_dirs,hangup,userfile,echo,useron,wfc,userfile,usernum;
extern int incom,fwaiting;
extern configrec syscfg;
extern statusrec status;
extern char ctypes[NUM_CTYPES][18];
extern char cdir[81];
extern userrec thisuser;
extern int numextrn;
extern externalrec *externs;
extern unsigned char agemin,agemax,slmin,slmax,dslmin,dslmax,ressex;
extern int topline;
extern int daysmin,daysmax,lecho;
extern unsigned short arres,darres,resres;
extern int questused[20];
extern unsigned char realsl;



void deluser(int un)
{
  userrec u;
  int i,i1,f,n;
  mailrec m;
  char fn[81];
  votingrec v;
  voting_response vr;

  read_user(un,&u);
  if ((u.inact & inact_deleted)==0) {
    rsm(un,&u);
    dsr(u.name);
    u.inact |= inact_deleted;
    u.waiting=0;
    write_user(un,&u);
    sprintf(fn,"%sEMAIL.DAT",syscfg.datadir);
    f=open(fn,O_RDWR | O_BINARY, S_IREAD | S_IWRITE);
    if (f>0) {
      i1=filelength(f)/sizeof(mailrec);
      for (i=0; i<i1; i++) {
        lseek(f,((long) i) * sizeof(mailrec), SEEK_SET);
        read(f,(void *)(&m),sizeof(mailrec));
        if (((m.tosys==0) && (m.touser==un)) ||
            ((m.fromsys==0) && (m.fromuser==un))) {
          delmail(f,i);
        }
      }
    }
    close(f);
    sprintf(fn,"%sVOTING.DAT",syscfg.datadir);
    f=open(fn,O_RDWR | O_BINARY, S_IREAD | S_IWRITE);
    n=(int) (filelength(f) / sizeof(votingrec)) -1;
    for (i=0; i<20; i++)
      if (u.votes[i]) {
        if (i<=n) {
          lseek(f,((long) i) * sizeof(votingrec), SEEK_SET);
          read(f,(void *)&v,sizeof(votingrec));
          vr=v.responses[u.votes[i]-1];
          vr.numresponses--;
          v.responses[u.votes[i]-1]=vr;
          lseek(f,((long) i) * sizeof(votingrec), SEEK_SET);
          write(f,(void *)&v,sizeof(votingrec));
        }
        u.votes[i]=0;
      }
    write_user(un,&u);
    close(f);
  }
}


void print_data(int un, userrec *u)
{
  char s[255],s1[81],s2[81],s3[81],s4[81];
  int i;

  outchr(12);
  if ((u->inact) & inact_deleted) {
    pl("6>>> DELETED <<<");
    nl();
  }
  sprintf(s,"3Name0: %-30s, 3Realname:0 %-30s",nam(u,un),(u->realname));
  pl(s);
  print("3Address:0 ",(u->citystate),"");
  sprintf(s,"3Phone:0 %s,3 Age:0 %d,3 Sex:0 %c",(u->phone),u->age,u->sex);
  pl(s);
  strcpy(s,"Password: ");
  strcat(s,(u->pw));
  strcat(s,"\r\n");
  if (lecho)
    outs(s);
  if ((incom) && (realsl==255) || thisuser.res[5])
    pr1(s);
  print("3Computer: 0",&(ctypes[u->comp_type][0]),"");
  print("3Last on:0 ",(u->laston),"  3 First On 0",(u->firston),"");
  itoa(u->msgpost,s1,10);
  itoa(u->emailsent,s2,10);
  itoa(u->feedbacksent,s3,10);
  itoa(u->waiting,s,10);
  itoa(u->emailnet,s4,10);
  if (u->emailnet)
    print("Msgs: P=",s1," E=",s2," F=",s3," W=",s," O=",s4,"");
  else
    print("Msgs: P=",s1," E=",s2," F=",s3," W=",s,"");
  itoa(u->logons,s1,10);
  if (strcmp((u->laston),date())==0)
    itoa(u->ontoday,s2,10);
  else
    itoa(0,s2,10);
  itoa(u->illegal,s3,10);
  sprintf(s,"3Logons:0 %s,3 Today:0 %s",s1,s2);
  pl(s);
  sprintf(s,"3Uploads/Downloads:0 %d/%d Files, %d/%dK",u->uploaded,u->downloaded,u->uk,u->dk);
  pl(s);
  if (u->note[0])
    print("3Note:0 ",(u->note),"");
  itoa(u->credits,s1,10);
  itoa(u->filepoint,s,10);
  print("3File Points: ",s,", 3Credits: ",s1,"");
    if (u->ass_pts){
    itoa(u->ass_pts,s,10);
    print("3AssWipe Level:0 ",s,"");
  }
  nl();
  itoa(u->sl,s,10);
  itoa(u->dsl,s1,10);
  print("3Security Level:0 ",s," 3 Download Security Level: 0",s1,"");
  if ((u->sysopsub)!=255){
    itoa(u->sysopsub,s,10);
    print("3SysOp of Sub:0 ",s,"");
  }
  if (u->exempt) {
    itoa(u->exempt,s,10);
    print("3Exemeptions: 0",s,"");
  }
  strcpy(s3,restrict_string);
  for (i=0; i<=15; i++) {
    if (u->ar & (1 << i))
      s[i]='A'+i;
    else
      s[i]=32;
    if (u->dar & (1 << i))
      s1[i]='A'+i;
    else
      s1[i]=32;
    if (u->restrict & (1 << i))
      s2[i]=s3[i];
    else
      s2[i]=32;
  }
  s[16]=0;
  s1[16]=0;
  s2[16]=0;
  if ((u->ar)!=0)
    print("3Access Restrictions:0 ",s,"");
  if ((u->dar)!=0)
    print("3Download Access Restrictions:0 ",s1,"");
  if ((u->restrict)!=0)
    print("Rest: ",s2,"");
}


void print_short(int un, userrec *u)
{
  char s[81],s1[81],s2[81],s3[81];
  int i;

  outchr(12);
  if ((u->inact) & inact_deleted) {
    pl("8>>> DELETED <<<0");
    nl();
  }
  sprintf(s,"Name: %-30s, Realname: %s",nam(u,un),u->realname);
  pl(s);
  print("Phone: ",(u->phone),"");
  itoa(u->age,s,10);
  s1[0]=32;
  s1[1]=u->sex;
  s1[2]=0;
  sprintf(s2,"Age: %s, Sex: %s",s,s1); pl(s2);
  if (u->note[0])
    print("Note: ",(u->note),"");
  nl();
  itoa(u->sl,s,10);
  itoa(u->dsl,s1,10);
  print("Security Levels: ",s,"/",s1,"");
  if (u->exempt) {
    itoa(u->exempt,s,10);
    print("Exemeptionts: ",s,"");
  }
  strcpy(s3,restrict_string);
  for (i=0; i<=15; i++) {
    if (u->ar & (1 << i))
      s[i]='A'+i;
    else
      s[i]=32;
    if (u->dar & (1 << i))
      s1[i]='A'+i;
    else
      s1[i]=32;
    if (u->restrict & (1 << i))
      s2[i]=s3[i];
    else
      s2[i]=32;
  }
  s[16]=0;
  s1[16]=0;
  s2[16]=0;
  if ((u->ar)!=0)
    print("ARs/DARs: ",&s,"/",&s1,"");
  if ((u->restrict)!=0)
    print("Restrictions: ",&s2,"");
}


char search_pattern[81] = {""};
char *sp;


int matchuser(int un)
{
  userrec u;

  read_user(un,&u);
  sp=search_pattern;
  return(match_user(&u));
}


int match_user(userrec *u)
{
  int ok=1,not=0,done=0,less=0,cpf=0,cpp=0,and=1,gotfcn=0,evalit=0,tmp,tmp1,tmp2;
  char fcn[12],parm[12];
  long l;

  do {
    if (*sp==0)
      done=1;
    else {
      if (strchr("()|&!<>",*sp)) {
        switch(*sp++) {
          case '(':
            evalit=2;
            break;
          case ')':
            done=1;
            break;
          case '|':
            and=0;
            break;
          case '&':
            and=1;
            break;
          case '!':
            not=1;
            break;
          case '<':
            less=1;
            break;
          case '>':
            less=0;
            break;
        }
      } else if (*sp=='[') {
        gotfcn=1;
        sp++;
      } else if (*sp==']') {
        evalit=1;
        ++sp;
      } else if (*sp!=' ') {
        if (gotfcn) {
          if (cpp<10)
            parm[cpp++]=*sp++;
        } else {
          if (cpf<10)
            fcn[cpf++]=*sp++;
        }
      } else
        ++sp;
      if (evalit) {
        if (evalit==1) {
          fcn[cpf]=0;
          parm[cpp]=0;
          tmp=1;
          tmp1=atoi(parm);

          if (!strcmp(fcn,"SL")) {
            if (less)
              tmp=(tmp1>u->sl);
            else
              tmp=(tmp1<u->sl);
          } else if (!strcmp(fcn,"DSL")) {
            if (less)
              tmp=(tmp1>u->dsl);
            else
              tmp=(tmp1<u->dsl);
          } else if (!strcmp(fcn,"AR")) {
            if ((parm[0]>='A') && (parm[0]<='P')) {
              tmp1=1 << (parm[0]-'A');
              if (u->ar & tmp1)
                tmp=1;
              else
                tmp=0;
            } else
              tmp=0;
          } else if (!strcmp(fcn,"DAR")) {
            if ((parm[0]>='A') && (parm[0]<='P')) {
              tmp1=1 << (parm[0]-'A');
              if (u->dar & tmp1)
                tmp=1;
              else
                tmp=0;
            } else
              tmp=0;
          } else if (!strcmp(fcn,"SEX")) {
            tmp=parm[0]==u->sex;
          } else if (!strcmp(fcn,"AGE")) {
            if (less)
              tmp=(tmp1>u->age);
            else
              tmp=(tmp1<u->age);
          } else if (!strcmp(fcn,"LASTON")) {
            time(&l);
            tmp2=(unsigned int)( (l-u->daten)/24.0/3600.0 );
            if (less)
              tmp=tmp2<tmp1;
            else
              tmp=tmp2>tmp1;
          } else if (!strcmp(fcn,"AREACODE")) {
            tmp=(!strncmp(parm,u->phone,3));
          } else if (!strcmp(fcn,"RESTRICT")) {
            ;
          }

        } else
          tmp=match_user(u);

        if (not)
          tmp=!tmp;
        if (and)
          ok = ok && tmp;
        else
          ok = ok || tmp;

        not=less=cpf=cpp=gotfcn=evalit=0;
        and=1;
      }
    }
  } while (!done);
  return(ok);
}

/****************************************************************************/

void changeopt()
{
  outchr(12);
  pl("Current search string:");
  if (search_pattern[0])
    pl(search_pattern);
  else
    pl("-NONE-");
  nl();
  nl();
  prt(5,"Change it? ");
  if (yn()) {
    pl("Enter new search pattern:");
    prt(4,":");
    input(search_pattern,75);
  }
}


/****************************************************************************/


#pragma warn -par

void uedit(int usern, int other)
{
  char s[81],s1[81],s2[81],ch,ch1;
  int i,i1,i2,i3,un,done,nu,done1,full,temp_full,tempu,top;
  userrec u;

  top=topline;
  topline=0;
  if (incom)
    full=0;
  else
    full=1;
  un=usern;
  done=0;
  read_user(un,&u);
  nu=(int) (filelength(userfile) / sizeof(userrec)) - 1;
  do {
    read_user(un,&u);
    done1=0;
    temp_full=0;
    do {
      if ((full) || (temp_full))
        print_data(un,&u);
      else
        print_short(un,&u);
      nl();
      prt(4,"Uedit : ");
      if ((realsl==255) || (wfc))
        ch=onek("Q[]{}/,.?UDRNLCP|OGMSTEYZAI~:$*^#|T_");
      else
        ch=onek("Q[]{}/,.?UDRNLCPO|GMSTEYZAIX$^#_");
      switch(ch) {
        case 'T': nl(); prt(4,"Add how much time? ");
                  input(s,5);
                  if(s[0]) {
                    i=atoi(s);
                    u.res[2]+=i;
                    write_user(un,&u);
                } break;
        case '_': readform("newuser",u.name); break;
        case '|':
        nl();
        outstr("Set Access to which Defualt Level? ");
        input(s,4);
        i=atoi(s);
        if(s[0]) {
        i--;
        u.sl=syscfg.autoval[i].sl;
        u.dsl=syscfg.autoval[i].dsl;
        u.ar=syscfg.autoval[i].ar;
        u.dar=syscfg.autoval[i].dar;
        u.restrict=syscfg.autoval[i].restrict;
        write_user(un,&u); }
        break;

        case 'Q':
          done=1;
          done1=1;
          topline=top;
          break;
        case '*':
          nl();
          prt(7,"New User Password? ");
          input(s,21);
          if(s[0]) {
            prt(7,"Are you sure? ");
            if(yn()) strcpy(u.pw,s); }
            write_user(un,&u);
          break;
        case '#':
          nl();
          prt(4,"New Credits? ");
          input(s,5);
          if(s[0]) {
          i=atoi(s);
          u.credits=i;
          write_user(un,&u);
        } break;
        case '$':
                  nl();
          prt(4,"New File Points? ");
          input(s,5);
          if(s[0]) {
          i=atoi(s);
          u.filepoint=i;
          write_user(un,&u);
        } break;
        case ']':
          ++un;
          if (un>nu)
            un=1;
          done1=1;
          break;
        case '[':
          --un;
          if (un==0)
            un=nu;
          done1=1;
          break;
        case '/':
          changeopt();
          break;
        case '}':
          tempu=un;
          ++un;
          if (un>nu)
            un=1;
          while ((un!=tempu) && (!matchuser(un))) {
            ++un;
            if (un>nu)
              un=1;
          }
          done1=1;
          break;
        case '{':
          tempu=un;
          --un;
          if (un<1)
            un=nu;
          while ((un!=tempu) && (!matchuser(un))) {
            --un;
            if (un<1)
              un=nu;
          }
          done1=1;
          break;
        case '.':
          full=(!full);
          temp_full=full;
          break;
        case ',':
          temp_full=(!temp_full);
          break;

        case '?':
          printmenu(6);
          getkey();
          break;

        case '^':
          if ((u.inact & inact_deleted)==0) {
            prt(5,"Delete? ");
            if (yn()) {
              deluser(un);
              read_user(un,&u);
            }
          } else
          if (u.inact & inact_deleted) {
            u.inact ^= inact_deleted;
            isr(un,u.name);
            write_user(un,&u);
          }
          break;

        case 'U':
          nl();
          prt(4,"User name/number: ");
          input(s,30);
          i=finduser1(s);
          if (i>0) {
            un=i;
            done1=1;
          }
          break;
        case 'N':
          nl();
          prt(4,"New name? ");
          input(s,30);
          if (s[0]) {
              dsr(u.name);
              strcpy(u.name,s);
              isr(un,u.name);
              write_user(un,&u);
          }
          break;

        case 'R':
          nl();
          prt(4,"New real name? ");
          inputl(s,20);
          if (s[0]) {
            strcpy(u.realname,s);
            write_user(un,&u);
          }
          break;
        case 'C':
          nl();
          prt(4,"City: ");
          inputl(s,31);
          if (s[0]) {
            strcpy(u.citystate,s);
            write_user(un,&u);
          }
          break;
        case 'P':
          nl();
          prt(4,"New phone number? ");
          input(s,12);
          if (s[0]) {
            strcpy(u.phone,s);
            write_user(un,&u);
          }
          break;
        case 'O':
          nl();
          prt(4,"New note? ");
          inputl(s,39);
          strcpy(u.note,s);
          write_user(un,&u);
          break;
        case 'G':
          nl();
          sprintf(s,"Current birthdate: %02d/%02d/%02d",(int) u.month,
	         (int) u.day,
                 (int) u.year);
          pl(s);
          input_age(&u);
          write_user(un,&u);
          break;
        case 'M':
          nl();
          pl("Known computer types:");
          nl();
          for (i=0; i<NUM_CTYPES; i++)
            print(itoa(i+1,s,10),". ",ctypes[i],"");
          nl();
          prt(4,"Enter new computer type: ");
          input(s,2);
          i=atoi(s);
          if ((i>0) && (i<NUM_CTYPES+1)) {
            u.comp_type=i-1;
            if (checkcomp("Ami"))
              u.colors[0]=4;
            else
              u.colors[0]=7;
            write_user(un,&u);
          }
          break;
        case 'S':
          nl();
          prt(4,"New SL? ");
          input(s,4);
          u.sl=atoi(s);
          write_user(un,&u);
          break;

        case 'D':
          prt(4,"New DSL? ");
          input(s,4);
          i=atoi(s);
          u.dsl=i;
          write_user(un,&u);
          break;

        case 'E':
          nl();
          prt(4,"New Exemption? ");
          input(s,3);
          i=atoi(s);
          if ((i>=0) && (i<=255) && (s[0])) {
            u.exempt=i;
            write_user(un,&u);
          }
          break;
        case 'Y':
          nl();
          prt(4,"New sysop sub? ");
          input(s,3);
          i=atoi(s);
          if ((i>=0) && (i<=255) && (s[0])) {
            u.sysopsub=i;
            write_user(un,&u);
          }
          break;
        case 'Z':
          nl();
          print( "        ",restrict_string,"");
	  do {
            prt(4,"Toggle? ");
            s[0]=13;
	    s[1]='?';
            strcpy(&(s[2]),restrict_string);
            ch1=onek(s);
            if (ch1==32)
              ch1=13;
	    if (ch1=='?')
	      printmenu(10);
            if ((ch1!=13) && (ch1!='?')) {
              i=-1;
              for (i1=0; i1<16; i1++)
                if (ch1==s[i1+2])
                  i=i1;
              if (i>-1) {
                u.restrict ^= (1 << i);
                write_user(un,&u);
              }
            }
	  } while ((!hangup) && (ch1=='?'));
          break;
        case 'A':
          nl(); do {
          prt(4,"Toggle which AR? ");
          ch1=onek("\rABCDEFGHIJKLMNOPQ");
          if (ch1!=13&&ch1!='Q') {
            ch1-='A';
            if ((wfc) || (thisuser.ar & (1 << ch1))) {
              u.ar ^= (1 << ch1);
              write_user(un,&u);
            }
          } } while(ch1!='Q'&&!hangup);
          break;
        case 'I':
          nl(); do {
          prt(4,"Toggle which DAR? ");
          ch1=onek("\rABCDEFGHIJKLMNOPQ");
          if (ch1!=13&&ch1!='Q') {
            ch1-='A';
            if ((wfc) || (thisuser.dar & (1 << ch1))) {
              u.dar ^= (1 << ch1);
              write_user(un,&u);
            }
          } } while (ch1!='Q'&&!hangup);
          break;
        case '~':
          u.ass_pts=0;
          write_user(un,&u);
          break;
	case ':':
	  u.year=0;
	  write_user(un,&u);
	  break;
      }
    } while ((!done1) && (!hangup));
  } while ((!done) && (!hangup));
  close_user();
  if (!wfc)
    topscreen();
}

#pragma warn +par



