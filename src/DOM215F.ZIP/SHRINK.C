#include "fcns.h"
#include <stdio.h>
#include <io.h>
#include <fcntl.h>
#include <sys\stat.h>
#include <process.h>
#include <dos.h>
#include <stdlib.h>
#include <dir.h>


#define READ(x) read(f,&(x),sizeof(x))

#define WRITE(x) write(f,&(x),sizeof(x))
extern int noklevel,oklevel,ooneuser,no_hangup,ok_modem_stuff,topdata;
extern int sysop_alert,do_event,incom,outcom,defscreenbottom,global_handle;
extern long last_time_c;
extern char *xenviron[50];

extern unsigned char andwith;

extern int usernum,chatcall,cursub,curdir,curdloads,msgreadlogon,mailcheck;
extern int numbatch, numbatchdl;
extern int smwcheck,use_workspace,using_modem,fsenttoday,base,global_xx;
extern long nscandate;
extern unsigned char andwith,realsl,actsl;
extern double timeon,extratimecall,last_time,xtime;
extern unsigned int modem_speed,com_speed,useron;
extern char chatreason[81],curspeed[80];
extern userrec thisuser;

extern int flow_control,async_irq;

extern char xdate[9];
/****************************************************************************/

int restore_data(char *s)
{
  int f,stat;

  f=open(s,O_RDONLY | O_BINARY);
  if (f<0)
    return(-1);

  READ(stat);
  READ(oklevel);
  READ(noklevel);
  READ(ooneuser);
  READ(no_hangup);
  READ(ok_modem_stuff);
  READ(topdata);
  READ(last_time_c);
  READ(sysop_alert);
  READ(do_event);

  if (stat) {
    READ(andwith);
    READ(usernum);
    READ(chatcall);
    READ(chatreason);
    READ(timeon);
    READ(extratimecall);
    READ(curspeed);
    READ(modem_speed);
    READ(com_speed);
    READ(cursub);
    READ(curdir);
    READ(curdloads);
    READ(msgreadlogon);
    READ(nscandate);
    READ(mailcheck);
    READ(smwcheck);
    READ(use_workspace);
    READ(using_modem);
    READ(last_time);
    READ(fsenttoday);
    READ(global_xx);
    READ(xtime);
    READ(xdate);
    READ(incom);
    READ(outcom);
    READ(global_handle);
    READ(numbatch);                                        /* mod - add */
    READ(numbatchdl);                                      /* mod - add */

    if (global_handle) {
      global_handle=0;
      set_global_handle(1);
    }

    read_user(usernum,&thisuser);
    useron=1;
    realsl=actsl=thisuser.sl;
    changedsl();
    topscreen();
    set_baud(com_speed);
  }

  close(f);
  unlink(s);
  unlink("stat.wwv");
  return(stat);
}

/****************************************************************************/

void save_state(char *s, int state,int ctc)
{
  int f;

  save_status();

  f=open(s,O_RDWR | O_BINARY | O_CREAT | O_TRUNC, S_IREAD | S_IWRITE);
  if (f<0)
    return;

  WRITE(state);
  WRITE(oklevel);
  WRITE(noklevel);
  WRITE(ooneuser);
  WRITE(no_hangup);
  WRITE(ok_modem_stuff);
  WRITE(topdata);
  WRITE(last_time_c);
  WRITE(sysop_alert);
  WRITE(do_event);

  if (state) {
    WRITE(andwith);
    WRITE(usernum);
    WRITE(chatcall);
    WRITE(chatreason);
    WRITE(timeon);
    WRITE(extratimecall);
    WRITE(curspeed);
    WRITE(modem_speed);
    WRITE(com_speed);
    WRITE(cursub);
    WRITE(curdir);
    WRITE(curdloads);
    WRITE(msgreadlogon);
    WRITE(nscandate);
    WRITE(mailcheck);
    WRITE(smwcheck);
    WRITE(use_workspace);
    WRITE(using_modem);
    WRITE(last_time);
    WRITE(fsenttoday);
    WRITE(global_xx);
    WRITE(xtime);
    WRITE(xdate);
    WRITE(incom);
    WRITE(outcom);
    WRITE(global_handle);
    READ(numbatch);                                        /* mod - add */
    READ(numbatchdl);                                      /* mod - add */


    set_global_handle(0);
  }

  close(f);

  if (state) {
    f=open("stat.wwv",O_RDWR | O_BINARY | O_CREAT | O_TRUNC, S_IREAD | S_IWRITE);
    if (f<0)
      return;

    WRITE(incom);
    WRITE(outcom);
    WRITE(thisuser);
    WRITE(flow_control);
    WRITE(async_irq);
    WRITE(com_speed);
    WRITE(base);
    WRITE(andwith);
    WRITE(ctc);
    WRITE(defscreenbottom);
    WRITE(ok_modem_stuff);

    close(f);
  }


}

/****************************************************************************/

void do_it_1(char *cl)
{
  int i,i1,l;
  char *ss,*ss1;
  char t[81];

  sl1(1,"");
  ss=cl;
  while ((*ss) && (*ss!=' '))
    ++ss;
  if (*ss==' ') {
    *ss=0;
    ss++;
  }
  ss1=(char far *) getvect(0x6b);
  if (ok_modem_stuff)
    closeport();
  close_user();
  *ss1=1;
  ss1++;
  strcpy(ss1,searchpath(cl));
  ss1=MK_FP(FP_SEG(ss1),0x0080);
  strcpy(t," ");
  strcat(t,ss);
  strcat(t,"\r");
  *ss1=strlen(t)-1;
  ++ss1;
  strcpy(ss1,t);
  exit(0);
}

/****************************************************************************/

void shrink_out(char *command, int state, int intercept,int ctc,int ccc)
{
  char s[81],s1[10],*ss1;
  int ok_shrink;

  ok_shrink=1;
  ss1=(char far *) getvect(0x6b);
  if (*ss1) {
    ok_shrink=0;
    nl();
    pl("Can't shrink: No BBS.COM");
    nl();
  }
  if (!searchpath("RETURN.EXE")) {
    ok_shrink=0;
    nl();
    pl("Can't shrink: No RETURN.EXE");
    nl();
  }

  if (ok_shrink) {
    if (state) {
      thisuser.sl=realsl;
      write_user(usernum,&thisuser);
    }
    save_state("restore.wwv",state,ctc);
    sprintf(s,"RETURN.EXE %d %d %s",intercept,ccc,command);
    set_protect(0);
    do_it_1(s);
  } else {
    if (intercept)
      full_external(command,ctc,ccc);
    else
      do_remote(command,ccc);
  }
}
