#include <dos.h>
#include <stdio.h>
#include <stdlib.h>
#include <dir.h>
#include <process.h>
#include <math.h>
#include <string.h>
#include <io.h>
#include <sys\stat.h>
#include <fcntl.h>
#include "fcns.h"


extern configrec syscfg;
extern char cdir[81];
extern int abortext,nextext,hangup,lines_listed,usernum,incom,okskey,arcling;
extern volatile int head,tail;
extern volatile char buffer[1024];
extern userrec thisuser;
extern double timeon;
extern long hanguptime1;
extern int in_extern,input_extern,wfc,charbufferpointer,async_irq,base;
extern char charbuffer[161],curspeed[81];
extern unsigned int modem_speed,com_speed;
extern char *xenviron[50];
extern int screenbottom,defscreenbottom,curatr,topline,ok_modem_stuff,screenlinest;
extern unsigned char andwith;
extern int using_modem;
extern char *quote;
extern int bquote,equote;

#define SCROLL_UP(t,b,l) \
  _CH=t;\
  _DH=b;\
  _BH=curatr;\
  _AL=l;\
  _CL=0;\
  _DL=79;\
  _AH=6;\
  my_video_int();



unsigned char getkeyext()
{
  unsigned char ch;
  static int holding=0;
  static char held=0;

  if (holding) {
    holding=0;
    return(held);
  }
  ch=getkey();
  if ((charbufferpointer==0) && (bquote==0)) {
    if (ch==16) {
      ch=getkey();
      if ((ch==17) && (charbufferpointer==0)                /* mod - add V3 */
        && (quote!=NULL)) {                                 /* mod - add V3 */
        get_quote(1);                                       /* mod - add V3 */
        if (bquote)                                         /* mod - add V3 */
          return(0);                                        /* mod - add V3 */
        else                                                /* mod - add V3 */
          return(getkeyext());                              /* mod - add V3 */
      }                                                     /* mod - add V3 */
      if ((ch==1) && (charbufferpointer==0)) {
        strcpy(charbuffer,&(thisuser.macros[2][0]));
        ch=charbuffer[0];
        if (ch) {
          charbufferpointer=1;
	  return(ch);
        } else
	  return(getkeyext());
      } else
        if ((ch==4) && (charbufferpointer==0)) {
          strcpy(charbuffer,&(thisuser.macros[0][0]));
          ch=charbuffer[0];
          if (ch) {
            charbufferpointer=1;
	    return(ch);
          } else
	    return(getkeyext());
        } else
          if ((ch==6) && (charbufferpointer==0)) {
            strcpy(charbuffer,&(thisuser.macros[1][0]));
            ch=charbuffer[0];
            if (ch) {
              charbufferpointer=1;
	      return(ch);
            } else
	      return(getkeyext());
          } else {
            holding=1;
	    held=ch;
            return(16);
          }
    }
  }
  return(ch);
}


void cd_to(char *s)
{
  char s1[81];
  int i,db;

  strcpy(s1,s);
  i=strlen(s1)-1;
  db=(s1[i]=='\\');
  if (i==0)
    db=0;
  if ((i==2) && (s1[1]==':'))
    db=0;
  if (db)
    s1[i]=0;
  chdir(s1);
  if (s[1]==':')
    setdisk(s[0]-'A');
}

void get_dir(char *s, int be)
{
  strcpy(s,"X:\\");
  s[0]='A'+getdisk();
  getcurdir(0,&(s[3]));
  if (be) {
    if (s[strlen(s)-1]!='\\')
      strcat(s,"\\");
  }
}


void initporte(int port_num)
/* This function initializes the com buffer, setting up the interrupt,
 * and com parameters
 */
{
  int temp;

  if (!ok_modem_stuff)
    return;
  temp=port_num;
  setvect(8+async_irq,async_isr);
  head=tail=0;
  outportb(base+3,0x03);
  disable();
  temp=inportb(base+5);
  temp=inportb(base);
  temp=inportb(0x21);
  temp=temp & ((1 << async_irq) ^ 0x00ff);
  outportb(0x21,temp);
  outportb(base+1,0x01);
  temp=inportb(base+4);
  outportb(base+4,temp | 0x0A);
  enable();
  dtr(1);
}



int do_it(char *cl)
{
  int i,i1,l;
  char s[160];
  char *ss[30];

  sl1(1,"");
  strcpy(s,cl);
  ss[0]=s;
  i=1;
  l=strlen(s);
  for (i1=1; i1<l; i1++)
    if (s[i1]==32) {
      s[i1]=0;
      ss[i++]=&(s[i1+1]);
    }
  ss[i]=NULL;
  i=spawnvpe(P_WAIT,ss[0],ss,xenviron);
  return(i);
}



int do_remote(char *s, int ccc)
{
  int rc,xx;
  char x[161];

  sl1(1,"");
  close_user();
  checkhangup();
  if (hangup)
    return(32767);
  strcpy(x,getenv("COMSPEC"));
  strcat(x," /C ");
  strcat(x,s);
  if (ccc)
    rc=do_it(x);
  else
    rc=do_it(s);
  initporte(syscfg.primaryport);
  chdir(cdir);
  setdisk(cdir[0]-'A');
  return(rc);
}

void checka1()
{
  char ch;
  long d1;

  while ((!empty()) && (!(abortext)) && (!hangup)) {
    ch=inkey();
    switch(ch) {
      case 3:
      case 32:
      case 24:
        abortext=1;
        break;
      case 'P':
      case 'p':
      case 19:
        d1=timer1();
        while ((inkey()==0) && (labs(timer1()-d1)<3276L) && (!hangup))
          checkhangup();
        lines_listed=0;
        break;
    }
  }
}

void checka2()
{
  union REGS r;
  int pause,ctrl_c;
  long d1;

  pause=0;
  ctrl_c=0;
  r.h.ah=1;
  int86(0x16,&r,&r);
  if ((r.x.flags & 64)==0) {
    if (r.x.ax==11779)
      ctrl_c=1;
    if (r.x.ax==7955)
      pause=1;
  }
  if (head!=tail) {
    if (buffer[tail]==3)
      ctrl_c=1;
    if (buffer[tail]==19)
      pause=1;
  }
  if (pause) {
    while (inkey()!=0)
      ;
    d1=timer1();
    while ((inkey()==0) && (labs(timer1()-d1)<3276L) && (!hangup))
      checkhangup();
    lines_listed=0;
  }
  if ((ctrl_c) && (nextext)) {
    while (inkey()!=0)
      ;
    pl("^C");
    r.x.ax=0x4c00;
    int86(0x69,&r,&r);
  }
}




void run_external(char *s)
{
  do_remote(s,1);
}



int run_external1(char *s)
{
  int i;

  i=do_remote(s,0);
  return(i);
}



void outdosstr(char *s)
/* This function outputs a string of characters to the screen (and remotely
 * if applicable).  The com port is also checked first to see if a remote
 * user has hung up
 */
{
  int i;

  checkhangup();
  if (hangup==0) {
    i=0;
    while ((s[i] !='$') && (i<1024)) {
      checka2();
      outchr(s[i++]);
    }
  }
}



#pragma warn -par

                   #define INT_SAVE_21 0x69

union REGS ni_r;
struct SREGS ni_s;
unsigned ni_n;
char ni_ch,ni_ch1,ni_ss[10],ni_ch2;
unsigned char *ni_st;

static unsigned short ni_stack[100];


#pragma warn -par

void far interrupt newintr1(unsigned bp, unsigned di, unsigned si,
                           unsigned ds, unsigned es, unsigned dx,
                           unsigned cx, unsigned bx, unsigned ax,
                           unsigned ip, unsigned cs, unsigned flags)
{

  unsigned short ni_SS, ni_SP;
#define NEW_STK() { _BX=FP_OFF(&ni_stack[98]); _SS=_DS; _SP=_BX; }
#define OLD_STK() { _AX=ni_SS; _BX=ni_SP; _SS=_AX; _SP=_BX; }



  ni_r.x.ax=ax;
  ni_r.x.bx=bx;
  ni_r.x.cx=cx;
  ni_r.x.dx=dx;
  ni_r.x.si=si;
  ni_r.x.di=di;
  ni_r.x.flags=flags;
  ni_s.ds=ds;
  ni_s.es=es;

  ni_SS=_SS;
  ni_SP=_SP;

  ni_ch=ni_r.h.ah;
  ni_ch1=0;

  switch(ni_ch) {
    case 0x01:
      NEW_STK();
      ni_ch=getkeyext();
      outchr(ni_ch);
      if (hangup)
        ni_ch=3;
      ni_r.h.al=ni_ch;
      ni_ch1=1;
      OLD_STK();
      break;
    case 0x02:
      NEW_STK();
      outchr(ni_r.h.dl);
      ni_ch1=1;
      checka2();
      OLD_STK();
      break;
    case 0x06:
      NEW_STK();
      if (ni_r.h.dl!=0xff) {
        outchr(ni_r.h.dl);
        ni_ch1=1;
      } else {
        if (empty()) {
          ni_r.x.flags |= 64;
        } else {
          ni_r.x.flags &= (0xffff ^ 64);
          ni_r.h.al=getkeyext();
        }
      }
      OLD_STK();
      break;
    case 0x07:
      NEW_STK();
      ni_ch1=1;
      ni_r.h.al=getkeyext();
      OLD_STK();
      break;
    case 0x08:
      NEW_STK();
      ni_ch1=1;
      ni_r.h.al=getkeyext();
      OLD_STK();
      break;
    case 0x09:
      NEW_STK();
      outdosstr((char *) MK_FP(ni_s.ds, ni_r.x.dx));
      ni_ch1=1;
      OLD_STK();
      break;
    case 0x0a:
      NEW_STK();
      ni_st=(char *) MK_FP(ni_s.ds,ni_r.x.dx);
      ni_n=(unsigned int)(ni_st[0]);
      if (in_extern==2)
        getkeyext();
      in_extern=0;
      input_extern=1;
      input1(&(ni_st[2]),ni_n-3,1,0);
      input_extern=0;
      in_extern=1;
      ni_st[1]=strlen(&(ni_st[2]));
      strcat(&(ni_st[2]),"\r");
      if ((hangup)) {
        strcpy(&(ni_st[2]),"EXIT\r");
        ni_st[1]=4;
        outs("Exiting...");
      }
      ni_ch1=1;
      OLD_STK();
      break;
    case 0x0b:
      NEW_STK();
      if (empty())
        ni_r.h.al=0x00;
      else
        ni_r.h.al=0xff;
      ni_ch1=1;
      OLD_STK();
      break;
    case 0x0c:
      ni_r.h.ah=ni_r.h.al;
      int86x(0x21,&ni_r,&ni_r,&ni_s);
      ni_ch1=1;
      break;
    case 0x3f:
      if (ni_r.x.bx==0x0000) {
        NEW_STK();
        ni_st=(char *)MK_FP(ni_s.ds,ni_r.x.dx);
        inputl(ni_st,ni_r.x.cx);
        strcat(ni_st,"\r\n");
        ni_r.x.ax=strlen(ni_st);
        if (hangup)
          ni_r.x.ax=0;
        ni_r.x.flags &=(0xffff ^ 1);
        ni_ch1=1;
        OLD_STK();
      } else
        int86x(INT_SAVE_21,&ni_r,&ni_r,&ni_s);
      break;
    case 0x40:
      if ((ni_r.x.bx==0x0001) || (ni_r.x.bx==0x0002)) {
        NEW_STK();
        ni_st=(char *)MK_FP(ni_s.ds,ni_r.x.dx);
        for (ni_n=0; ni_n<ni_r.x.cx; ni_n++) {
          outchr(ni_st[ni_n]);
          checka2();
        }
        ni_r.x.ax=ni_r.x.cx;
        ni_r.x.flags &=(0xffff ^ 1);
        ni_ch1=1;
        OLD_STK();
      } else
        int86x(INT_SAVE_21,&ni_r,&ni_r,&ni_s);
      break;
    default:
      int86x(INT_SAVE_21,&ni_r,&ni_r,&ni_s);
      break;
  }

  if (ni_ch1) {
    if (arcling) {
      if ((nextext) && (!abortext)) {
        checka1();
        if (abortext) {
          ni_r.x.ax=0x4c00;
          int86x(INT_SAVE_21,&ni_r,&ni_r,&ni_s);
        }
      }
    }
    checkhangup();
    if (hangup) {
      if (hanguptime1<0L) {
        hanguptime1=timer1();
        outs("Aborting...\r\n");
        ni_r.x.ax=0x4c00;
        int86x(INT_SAVE_21,&ni_r,&ni_r,&ni_s);
      } else {
        if (labs(timer1()-hanguptime1)>36L) {
          hanguptime1=timer1();
          outs("Aborting...\r\n");
          ni_r.x.ax=0x4c00;
          int86x(INT_SAVE_21,&ni_r,&ni_r,&ni_s);
        }
      }
    }
  }

  ax=ni_r.x.ax;
  bx=ni_r.x.bx;
  cx=ni_r.x.cx;
  dx=ni_r.x.dx;
  si=ni_r.x.si;
  di=ni_r.x.di;
  flags=ni_r.x.flags;
  ds=ni_s.ds;
  es=ni_s.es;
}


#pragma warn +par



int do_external(char *s, int enab)
{
  unsigned short sav;

  checkhangup();
  if (hangup)
    return(0);
  in_extern=1;
  hanguptime1=-1L;
  abortext=0;
  nextext=enab;
  arcling=1;
  sav=syscfg.sysconfig;
  if ((syscfg.sysconfig & sysconfig_no_local)==0)
    syscfg.sysconfig |= sysconfig_no_local;
  setvect(0x69,getvect(0x21));

  set_global_handle(0);

  setvect(0x21,newintr1);

  do_remote(s,1);

  setvect(0x21,getvect(0x69));

  if (abortext) {
    nl();
    nl();
  }

  syscfg.sysconfig=sav;
  if (in_extern==2)
    getkey();
  in_extern=0;
  return(abortext);
}


int full_external(char *s, int ctc, int ccc)
{
  unsigned short sav;
  int ookskey,xx,cy,cx,xxx;

  sl1(1,"");
  checkhangup();
  if (hangup)
    return(0);
  in_extern=1;
  ookskey=okskey;
  okskey=0;
  hanguptime1=-1L;
  arcling=0;
  if (screenlinest>defscreenbottom-topline)
    set_protect(0);
  abortext=0;
  nextext=ctc;
  sav=syscfg.sysconfig;
  if ((syscfg.sysconfig & sysconfig_no_local)==0)
    syscfg.sysconfig |= sysconfig_no_local;

  setvect(0x69,getvect(0x21));

  set_global_handle(0);

  setvect(0x21,newintr1);

  if ((screenlinest<=defscreenbottom) && (screenlinest>20)) {
    screenbottom=screenlinest-1+topline;
    cy=wherey();
    cx=wherex();
    xxx=cy-screenbottom+topline;
    if (xxx>0) {
      SCROLL_UP(topline,defscreenbottom,xxx);
      movecsr(cx,screenbottom);
    }
  }

  do_remote(s,ccc);

  screenbottom=defscreenbottom;

  setvect(0x21,getvect(0x69));

  if (abortext) {
    nl();
    nl();
  }

  syscfg.sysconfig=sav;
  okskey=ookskey;
  if (in_extern==2)
    getkey();
  in_extern=0;
  if (!wfc)
    topscreen();
  return(abortext);
}

void alf(int f, char *s)
{
  char s1[100];

  strcpy(s1,s);
  strcat(s1,"\r\n");
  write(f,(void *)s1,strlen(s1));
}

char *create_chain_file(char *fn)
{
  int i,i1,f;
  char s[81],s1[81],gd[81],dd[81];
  static char fpn[81];
  long l;

  cd_to(syscfg.gfilesdir);
  get_dir(gd,1);
  cd_to(cdir);
  cd_to(syscfg.datadir);
  get_dir(dd,1);
  cd_to(cdir);

  unlink(fn);
  f=open(fn,O_RDWR | O_CREAT | O_BINARY, S_IREAD | S_IWRITE);
  itoa(usernum,s,10);
  alf(f,s);
  alf(f,thisuser.name);
  alf(f,thisuser.realname);
  alf(f,thisuser.citystate);
  itoa(thisuser.age,s,10);
  alf(f,s);
  s[0]=thisuser.sex;
  s[1]=0;
  alf(f,s);
  sprintf(s,"%10.2f",thisuser.credits);
  alf(f,s);
  alf(f,thisuser.laston);
  itoa(thisuser.screenchars,s,10);
  alf(f,s);
  itoa(thisuser.screenlines,s,10);
  alf(f,s);
  itoa(thisuser.sl,s,10);
  alf(f,s);
  if (cs())
    alf(f,"1");
  else
    alf(f,"0");
  if (so())
    alf(f,"1");
  else
    alf(f,"0");
  if (okansi())
    alf(f,"1");
  else
    alf(f,"0");
  if (incom)
    alf(f,"1");
  else
    alf(f,"0");
  sprintf(s,"%10.2f",nsl());
  alf(f,s);
  alf(f,gd);
  alf(f,dd);
  sl1(3,s);
  alf(f,s);
  sprintf(s,"%u",modem_speed);
  if (!using_modem)
    strcpy(s,"KB");
  alf(f,s);
  itoa(syscfg.primaryport,s,10);
  alf(f,s);
  alf(f,syscfg.systemname);
  alf(f,syscfg.sysopname);
  l=(long) (timeon);
  if (l<0)
    l += 3600*24;
  ltoa(l,s,10);
  alf(f,s);
  l=(long) (timer()-timeon);
  if (l<0)
    l += 3600*24;
  ltoa(l,s,10);
  alf(f,s);
  ltoa(thisuser.uk,s,10);
  alf(f,s);
  itoa(thisuser.uploaded,s,10);
  alf(f,s);
  ltoa(thisuser.dk,s,10);
  alf(f,s);
  itoa(thisuser.downloaded,s,10);
  alf(f,s);
  if (andwith==0x7f)
    alf(f,"7E1");
  else
    alf(f,"8N1");
  close(f);
  get_dir(fpn,1);
  strcat(fpn,fn);
  dorinfo_def();
  return(fpn);
}

void get_quote(int fsed)                         /* mod - add entire void V3 */
{
  static char s[141];
  static int i,i1,i2,abort,next,rl;

  if (fsed) {
    disable();
    setvect(0x6a,getvect(0x21));
    setvect(0x21,getvect(0x69));
    enable();
  }
  rl=1;
  do {
    if (fsed)
      outstr("\x0c");
    if (rl) {
        i=1; i2=0; abort=0; next=0;
      do {
        itoa(i++,s,10);
        osan(s,&abort,&next);
        i1=0;
        do {
          s[i1++]=quote[i2++];
        } while ((quote[i2]!=13) && (i2<strlen(quote)));
        s[i1]=0; i2+=2;
        pla(s,&abort);
      } while (i2<strlen(quote));
      --i;
    }
    nl();
    i1=0; i2=0; s[0]=0;
    while (!s[0]) {
      sprintf(s,"Quote from line 1-%d? (?=relist,Q=quit) ",i);
      prt(2,s);
      input(s,3);
    }
    if (s[0]=='Q')
      rl=0;
    else if (s[0]!='?') {
      i1=atoi(s);
      if (i1==i)
        i2=i1;
      else {
        s[0]=0;
        while (!s[0]) {
          sprintf(s,"through line %d-%d? (Q=quit) ",i1,i);
          prt(2,s);
          input(s,3);
        }
        if (s[0]=='Q')
          rl=0;
        else if (s[0]!='?')
          i2=atoi(s);
      }
    }
    if (i2) {
      sprintf(s,"Quote line(s) %d-%d? ",i1,i2);
      prt(5,s);
      if (!ny())
        i2=0;
    }
  } while ((!abort) && (!hangup) && (rl) && (!i2));
  if (fsed) {
    outstr("\x0c");
    disable();
    setvect(0x21,getvect(0x6a));
    enable();
    if (rl)
      charbufferpointer=1;
  } else
    charbufferpointer=0;
  if ((i1>0) && (i2>=i1) && (i2<=i) && (i2-i1<50) && (rl)) {
    bquote=i1;
    equote=i2;
  }
}


