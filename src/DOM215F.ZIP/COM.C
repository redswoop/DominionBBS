#include <dos.h>
#include <string.h>
#include <conio.h>
#include <stdarg.h>
#include <stdio.h>
#include <math.h>
#include <time.h>
#include <io.h>
#include "fcns.h"
#include "nifrec.h"

int inputblue;
extern int listing,mciok;
extern configrec syscfg;
extern niftyrec nifty;
extern volatile int head,tail;
extern volatile char buffer[max_buf];
extern int base,async_irq,useron,lokb,mci;
extern int outcom,incom,using_modem,okskey,chatting,screenlinest;
extern int tempio,chatcall,okmacro;
extern long timelastchar1;
extern char charbuffer[161],endofline[81];
extern int charbufferpointer;
extern int hangup,hungup;
extern int checkit;
extern unsigned char andwith;
extern int topline;
extern int curatr,curdloads;
extern int ansiptr,global_handle;
extern int oldx,oldy,high_speed,flow_control;
extern char ansistr[81];
extern int change_color, change_ecolor;
extern userrec thisuser;
extern int echo,lecho,lastcon,lines_listed,in_extern,input_extern,no_hangup;
extern double timeon;
extern char far *scrn;
extern char *quote;
extern int bquote,equote;

#define frequency 500


void savel(char *cl, char *atr, char *xl, char *cc)
{
  int i, i1;

  *cc = curatr;
  strcpy(xl, endofline);
  i = ((wherey() + topline) * 80) * 2;
  for (i1 = 0; i1 < wherex(); i1++) {
    cl[i1]  = scrn[i + (i1 * 2)];
    atr[i1] = scrn[i + (i1 * 2) + 1];
  }
  cl[wherex()]  = 0;
  atr[wherex()] = 0;
}


void restorel(char *cl, char *atr, char *xl, char *cc)
{
  int i;

  if (wherex())
    nl();
  for (i = 0; cl[i] != 0; i++) {
    setc(atr[i]);
    outchr(cl[i]);
  }
  setc(*cc);
  strcpy(endofline, xl);
}


void ptime()
{
  char xl[81], cl[81], atr[81], cc, s[81];
  long l;

  savel(cl, atr, xl, &cc);

  ansic(0);
  nl();
  nl();
  time(&l);
  strcpy(s, ctime(&l));
  s[strlen(s) - 1] = 0;
  pl(s);
  if (useron) {
    print("Time on   = ", ctim(timer() - timeon), "");
    print("Time left = ", ctim(nsl()), "");
  }
  nl();

  restorel(cl, atr, xl, &cc);
}


void reprint()
{
  char xl[81], cl[81], atr[81], cc, ansistr_1[81];
  int ansiptr_1;

  ansiptr_1=ansiptr;
  ansiptr=0;
  ansistr[ansiptr_1]=0;
  strcpy(ansistr_1,ansistr);

  savel(cl, atr, xl, &cc);
  nl();
  restorel(cl, atr, xl, &cc);

  strcpy(ansistr,ansistr_1);
  ansiptr=ansiptr_1;
}

void domansihigh(char c)
{
outcomch(235);
outcomch(c);
}

void domansilow(char c)
{
outcomch(234);
outcomch(c);
}



void setbeep(int i)
{
  int i1,i2;

  if (i) {
    i1 = 0x34DD / frequency;
    i2 = inportb(0x61);
    if (!(i2 & 0x03)) {
      outportb(0x61, i2 | 0x03);
      outportb(0x43, 0xB6);
    }
    outportb(0x42, i1 & 0x0F);
    outportb(0x42, i1 >> 4);
  } else
    outportb(0x61, inportb(0x61) & 0xFC);
}

void far interrupt async_isr ()
/* This function is called every time a char is received on the com port.
 * The character is stored in the buffer[] array, and the head pointer is
 * updated.
 */
{
  buffer[head++] = inportb(base);
  if (head == max_buf)
    head = 0;
  outportb(0x20, 0x20);
}



void outcomch(char ch)
/* This function outputs one character to the com port */
{
  while (!(inportb(base + 5) & 0x20))
    ;
  if (flow_control)
    while (!(inportb(base + 6) & 0x10))
      ;
  outportb(base, ch);
}



void pr1(char *s)
/* This function ouputs a string to the com port.  This is mainly used
 * for modem commands
 */
{
  int i;

  for (i = 0; s[i] > 0; i++)
    if (s[i] == '{')
      outcomch(13);
    else if (s[i] == '~')
      wait1(9);
    else
      outcomch(s[i]);
}



char get1c()
/* This function returns one character from the com port, or a zero if
 * no character is waiting
 */
{
  char c1;

  if (head != tail) {
    disable();
    c1 = buffer[tail++];
    if (tail == max_buf)
      tail = 0;
    enable();
    return(c1);
  } else
    return(0);
}



int comhit()
/* This returns a value telling if there is a character waiting in the com
 * buffer.
 */
{
  return(head != tail);
}



void dump()
/* This function clears the com buffer */
{
  disable();
  head = tail = 0;
  enable();
}



void set_baud(unsigned int rate)
/* This function sets the com speed to that passed */
{
  float rl;

  if ((rate > 49) && (rate < 57601)) {
    rl   = 115200.0 / ((float) rate);
    rate = (int) rl;
    outportb(base + 3, inportb(base + 3) | 0x80);
    outportb(base,     (rate & 0x00FF));
    outportb(base + 1, ((rate >> 8) & 0x00FF));
    outportb(base + 3, inportb(base + 3) & 0x7F);
  }
}


void initport(int port_num)
/* This function initializes the com buffer, setting up the interrupt,
 * and com parameters
 */
{
  int temp;

  base = syscfg.com_base[port_num];
  async_irq = syscfg.com_ISR[port_num];
  setvect(8 + async_irq, async_isr);
  head = tail = 0;
  outportb(base + 3, 0x03);
  disable();
  temp = inportb(base + 5);
  temp = inportb(base);
  temp = inportb(0x21);
  temp = temp & ((1 << async_irq) ^ 0x00FF);
  outportb(0x21, temp);
  outportb(base + 1, 0x01);
  temp=inportb(base + 4);
  outportb(base + 4, temp | 0x0A);
  enable();
  set_baud(syscfg.baudrate[port_num]);
  dtr(1);
}



void closeport()
/* This function closes out the com port, removing the interrupt routine,
 * etc.
 */
{
  int temp;

  disable();
  temp = inportb(0x21);
  temp = temp | ((1 << async_irq));
  outportb(0x21, temp | 0x10);
  outportb(base + 2, 0);
  outportb(base + 4, 1);
  enable();
}

void dtr(int i)
/* This function sets the DTR pin to the status given */
{
  int i1;

  i1 = inportb(base + 4) & 0x00FE;
  outportb(base + 4, (i || no_hangup) ? (i1 + 1) : i1);
}


void rts(int i)
/* This function sets the RTS pin to the status given */
{
  int i1;

  i1 = inportb(base + 4) & 0x00FD;
  outportb(base + 4, (i) ? (i1 + 2) : i1);
}


int cdet()
/* This returns the status of the carrier detect lead from the modem */
{
  return((inportb(base + 6) & 0x80) ? 1 : 0);
}



void checkhangup()
/* This function checks to see if the user logged on to the com port has
 * hung up.  Obviously, if no user is logged on remotely, this does nothing.
 * If carrier detect is detected to be low, it is checked 100 times
 * sequentially to make sure it stays down, and is not just a quirk.
 */
{
  int i, ok;
  char s[81];

  if (!hangup && using_modem && !cdet()) {
    ok = 0;
    for (i = 0; (i < 500) && !ok; i++)
      if (cdet())
        ok = 1;
    if (!ok) {
      hangup = hungup = 1;
      if (useron && !in_extern) {
        sprintf(s,"Hung Up at %s",times());
        sysoplog(s); }
    }
  }
}




void addto(char *s, int i)
{
  char temp[20];

  if (s[0])
    strcat(s, ";");
  else
    strcpy(s, "\x1B[");
  itoa(i, temp, 10);
  strcat(s, temp);
}


void makeansi(unsigned char attr, char *s)
/* Passed to this function is a one-byte attribute as defined for IBM type
 * screens.  Returned is a string which, when printed, will change the
 * display to the color desired, from the current function.
 */
{
  unsigned char catr;
  char *temp = "04261537";

  catr = curatr;
  s[0] = 0;
  if (attr != catr) {
    if ((catr & 0x88) ^ (attr & 0x88)) {
      addto(s, 0);
      addto(s, 30 + temp[attr & 0x07] - '0');
      addto(s, 40 + temp[(attr & 0x70) >> 4] - '0');
      catr = attr & 0x77;
    }
    if ((catr & 0x07) != (attr & 0x07))
      addto(s, 30 + temp[attr & 0x07] - '0');
    if ((catr & 0x70) != (attr & 0x70))
      addto(s, 40 + temp[(attr & 0x70) >> 4] - '0');
    if ((catr & 0x08) ^ (attr & 0x08))
      addto(s, 1);
    if ((catr & 0x80) ^ (attr & 0x80)) {
      if (checkcomp("Mac"))     /*This is the code for Mac's underline*/
        addto(s, 4);            /*They don't have Blinking or Italics*/
      else {
        if (checkcomp("Ami"))   /*Some Amiga terminals use 3 instead of*/
          addto(s, 3);          /*5 for italics.  Using both won't hurt*/
        addto(s, 5);            /*anything, only italics will be generated*/
      }
    }
  }
  if (s[0])
    strcat(s, "m");
  if (!okansi())
    s[0]=0;
}



void setfgc(int i)
/* This sets the foreground color to that passed.  It is called only from
 * execute_ansi
 */
{
  curatr = (curatr & 0xf8) | i;
}



void setbgc(int i)
/* This sets the background color to that passed.  It is called only from
 * execute_ansi
 */
{
  curatr = (curatr & 0x8f) | (i << 4);
}


void execute_ansi()
/* This function executes an ANSI string to change color, position the
 * cursor, etc.
 */
{
  int args[10], argptr, count, ptr, tempptr, ox, oy;
  char cmd, temp[10], teol[81], *clrlst = "04261537";

  if (ansistr[1] != '[') {

    /* do nothing if invalid ANSI string. */

  } else {
    argptr = tempptr = 0;
    ptr = 2;
    for (count = 0; count < 10; count++)
      args[count] = temp[count] = 0;
    cmd = ansistr[ansiptr - 1];
    ansistr[ansiptr - 1] = 0;
    while (ansistr[ptr]) {
      if (ansistr[ptr] == ';') {
        temp[tempptr] = 0;
        tempptr = 0;
        args[argptr++] = atoi(temp);
      } else
        temp[tempptr++] = ansistr[ptr];
      ++ptr;
    }
    if (tempptr) {
      temp[tempptr]  = 0;
      args[argptr++] = atoi(temp);
    }
    if ((cmd >= 'A') && (cmd <= 'D') && !args[0])
      args[0] = 1;
    switch (cmd) {
        case 'f':
        case 'H':
          movecsr(args[1] - 1, args[0] - 1);
          break;
        case 'A':
          movecsr(wherex(), wherey() - args[0]);
          break;
        case 'B':
          movecsr(wherex(), wherey() + args[0]);
          break;
        case 'C':
          movecsr(wherex() + args[0], wherey());
          break;
        case 'D':
          movecsr(wherex() - args[0], wherey());
          break;
        case 's':
          oldx = wherex();
          oldy = wherey();
          break;
        case 'u':
          movecsr(oldx, oldy);
          break;
        case 'J':
          if (args[0] == 2)
            clrscrb();
          break;
        case 'k':
        case 'K':
          ox = wherex();
          oy = wherey();
          _CX = 80 - ox;
          _AH = 0x09;
          _BH = 0x00;
          _AL = 32;
          _BL = curatr;
          my_video_int();
          movecsr(ox, oy);
          break;
        case 'm':
          if (!argptr) {
            argptr = 1;
            args[0] = 0;
          }
          for (count = 0; count < argptr; count++)
            switch (args[count]) {
              case 0: curatr = 0x07; break;
              case 1: curatr = curatr | 0x08; break;
              case 4: break;
              case 5: curatr = curatr | 0x80; break;
              case 7:
                ptr = curatr & 0x77;
                curatr = (curatr & 0x88) | (ptr << 4) | (ptr >> 4);
                break;
              case 8: curatr = 0; break;
              default:
                if ((args[count] >= 30) && (args[count] <= 37))
                  setfgc(clrlst[args[count] - 30] - '0');
                else if ((args[count] >= 40) && (args[count] <= 47))
                  setbgc(clrlst[args[count] - 40] - '0');
            }
          break;
      }
    }
  ansiptr = 0;
}


void outchr(char c)
/* This function outputs one character to the screen, and if output to the
 * com port is enabled, the character is output there too.  ANSI graphics
 * are also trapped here, and the ansi function is called to execute the
 * ANSI codes
 */
{
  int i, i1;

  if (change_color) {
    change_color = 0;
    if ((c >= '0') && (c <= '9'))
      if(!thisuser.res[10]) ansic(c - '0');
      else domansihigh(c);
    else if ((c >= 'A') && (c <= 'Z'))
      prinfo(c);
    else if ((c >= 'a') && (c <= 'z')) {
      c=upcase(c);
      prinfo(c);
     }
    return;
  }

  if(mci) {
    mci=0;
    if((c>='A')&&(c<='Z')) prinfo(c);
    else  if ((c >= 'a') && (c <= 'z')) {
      c=upcase(c);
      prinfo(c);
     }
   else prinfo(c);
   return;
}

  if (change_ecolor) {
    change_ecolor = 0;
    if ((c >= '0') && (c <= '9'))
    if(!thisuser.res[10]){ c+=10;
      ansic(c - '0'); }
      else domansilow(c);
    else if ((c >= 'A') && (c <= 'Z'))
      prinfo(c);
    else if ((c >= 'a') && (c <= 'z')) {
      c=upcase(c);
      prinfo(c);
     }
    return;
  }

  if(c=='`') {
     if(mciok) {
       mci=1;
       return; }
     }

  if (c == 3) {
    change_color = 1;
    return;
  }

  if (c == 14) {
    change_ecolor = 1;
    return;
  }

  if (chatcall && !(syscfg.sysconfig & sysconfig_no_beep))
    setbeep(1);
  if ((c == 10) && endofline[0]) {
    if (!in_extern)
      outstr(endofline);
    endofline[0] = 0;
  }

  if (global_handle)
    if (echo)
      write(global_handle,&c,1);

  if (outcom && (c != 9))
    outcomch(echo ? c : nifty.echochar);
  if (ansiptr) {
    ansistr[ansiptr++] = c;
    ansistr[ansiptr]   = 0;
    if ((((c < '0') || (c > '9')) && (c!='[') && (c!=';')) ||
        (ansistr[1] != '[') || (ansiptr>75))
      execute_ansi();
  } else if (c == 27) {
    ansistr[0] = 27;
    ansiptr = 1;
    ansistr[ansiptr]=0;
  } else if (c == 9) {
    i1 = wherex();
    for (i = i1; i< (((i1 / 8) + 1) * 8); i++)
      outchr(32);
  } else if (echo || lecho) {
    out1ch(c);
    if (c == 10) {
      ++lines_listed;
      if ((sysstatus_pause_on_page & thisuser.sysstatus) &&
          (lines_listed >= screenlinest - 1)) {
        pausescr();
        lines_listed = 0;
      }                     }
  } else
    out1ch('�');
  if (chatcall)
    setbeep(0);
}

int strlenc(char *s)
{
    int len=0,x=0;
    while(s[x]) {
        if(s[x]!=3&&s[x]!=14) {len++; x++;}
        else if(s[x]==3||s[x]==14) x+=2;
    }
return len;
}

void outmstr(char *s)
{
    int i=0;

checkhangup();
if(!hangup)
     while(s[i]) outcomch(s[i++]);
}

void outstr(char *s)
{
  int i=0;
  int slen,x;

    checkhangup();

   if(!hangup)
    if(s[0]=='�') { i++;
    slen=strlenc(s);
    x=79;
    x-=slen;
    x/=2;
    for(slen=0;slen<x-2;slen++) outchr(' '); }

    while (s[i]&&!hangup)
      outchr(s[i++]);
}


void nl()
{
  if (endofline[0]) {
    outstr(endofline);
    endofline[0] = 0;
  }
  outstr("\r\n");
}



void backspace()
/* This function executes a backspace, space, backspace sequence. */
{
  int i;

  i = echo;
  echo = 1;
  outstr("\b \b");
  echo = i;
}



void setc(unsigned char ch)
{
  char s[30];

  makeansi(ch, s);
  outstr(s);
}

void pausescr()
{
int i;
//if(listing) { askbatch(); return; }
i = curatr;
if((nifty.nifstatus & nif_fancyprompt) &&okansi())
   magicprompt();
else {
  outstr(get_string(20));
  getkey();
  outchr('\r');
  nl();
  }
setc(i);
}

void prompt(char *msg, ...)
{
  va_list ap;
  char *str, str1[160];

  va_start(ap, msg);
  strcpy(str1, msg);
  str = va_arg(ap, char *);
  while (str[0]) {
    strcat(str1, str);
    str = va_arg(ap, char *);
  }
  va_end(ap);
  outstr(str1);
}

void print(char *msg, ...)
{
  va_list ap;
  char *str, str1[160];

  va_start(ap, msg);
  strcpy(str1, msg);
  str = va_arg(ap, char *);
  while (str[0]) {
    strcat(str1,str);
    str = va_arg(ap, char *);
  }
  va_end(ap);
  outstr(str1);
  nl();
}


void pl(char *s)
{
  outstr(s);
  nl();
}

void pl2(char *s,int times)
{
    int x=1;
    outstr(s);
    while(x<times) nl();
}


int kbhitb()
{
  union REGS r;

  r.h.ah = 1;
  int86(0x16, &r, &r);
  return((r.x.flags & 64) == 0);
}


int empty()
{
  if (kbhitb() || (incom && (head != tail)) ||
      (charbufferpointer && charbuffer[charbufferpointer]) ||
      (in_extern == 2) || (bquote))
    return(0);
  return(1);
}



void skey1(char *ch)
{
  char c;

  c = *ch;
  if (c == 127)
    c = 8;
  if (okskey)
    switch(c) {
      case 1:
      case 4:
      case 6:
        if (okmacro && !charbufferpointer) {
          if (c == 1)
            c = 2;
          else if (c == 4)
            c = 0;
          else if (c == 6)
            c = 1;
          else if (c == 18 )
            c = 3;
          strcpy(charbuffer, &(thisuser.macros[c][0]));
          c = charbuffer[0];
          if (c)
            charbufferpointer = 1;
        }
        break;
      case 20:
        if (echo)
          ptime();
        break;
      case 18:
        if (echo)
          reprint();
        break;
    }
  *ch = c;
}

char getchd()
{
  union REGS r;

  r.h.ah = 0x07;
  int86(0x69, &r, &r);
  return(r.h.al);
}


char getchd1()
{
  union REGS r;

  r.h.ah = 0x06;
  r.h.dl = 0xFF;
  int86(0x69, &r, &r);
  return((r.x.flags & 0x40) ? 255 : r.h.al);
}


char inkey()
{
  char ch=0;
  static int qpointer=0,cpointer;

  if (bquote) {
    if (!qpointer) {
      charbuffer[1]=0;
      cpointer=0;
      qpointer=1;
      while (qpointer<bquote) {
        if (quote[cpointer++]==10)
          ++qpointer;
      }
      if (charbufferpointer)
        return(62);
      else
       charbufferpointer=1;
    }
    if (quote[cpointer]==10) {
      ++qpointer;
      if (qpointer>equote) {
        qpointer=0; bquote=0; equote=0;
        farfree(quote);
        quote=NULL;
        return(13);
      } else
        ++cpointer;
    }
    if (quote[cpointer]==3)
      quote[cpointer]=16;
    return(quote[cpointer++]);
  }

  if (charbufferpointer) {
    if (!charbuffer[charbufferpointer])
      charbufferpointer = charbuffer[0] = 0;
    else {
       if ((charbuffer[charbufferpointer])==3)
         charbuffer[charbufferpointer]=16;
       if ((charbuffer[charbufferpointer])==5)
         charbuffer[charbufferpointer]=14;
      return(charbuffer[charbufferpointer++]);
    }
  }
  if (kbhitb() || (in_extern == 2)) {
    ch = getchd1();
    lastcon = 1;
    if (!ch) {
      if (in_extern)
        in_extern = 2;
      else {
        ch = getchd1();
        skey(ch);
        ch = (((ch == 68) || (ch==103)) ? 2 : 0);
      }
    } else if (in_extern)
      in_extern = 1;
    timelastchar1=timer1();
  } else if (incom && comhit()) {
    ch = (get1c() & andwith);
    lastcon = 0;
  }
  skey1(&ch);
  return(ch);
}


void mpl(int i)
{
  int i1;
  char s[20];

  if (okansi() && thisuser.sysstatus & sysstatus_color) {
    if(thisuser.res[10]) {
        if(i<10)
        sprintf(s,"�0%d",i);
        else sprintf(s,"�%d",i);
        outmstr(s);
        return;
    }
    inputblue=1;
    makeansi(15,s);
    outstr(s);
    for (i1 = 0; i1 < i; i1++)
      outchr('�');
    nl();
    makeansi(121,s);
    outstr(s);
    for (i1 = 0; i1 < i; i1++)
      outchr(' ');
    makeansi(0,s);
    outstr(s);
    nl();
    makeansi(8,s);
    outstr(s);
    for (i1 = 0; i1 < i; i1++)
      outchr('�');
    makeansi(0,s);
    outstr(s);
    sprintf(s," \b\bU\x1b[%dD",i);
    outstr(s);
  }
}


char upcase(char ch)
/* This converts a character to uppercase */
{
  if ((ch > '`') && (ch < '{'))
    ch = ch - 32;
  return(ch);
}


unsigned char getkey()
/* This function returns one character from either the local keyboard or
 * remote com port (if applicable).  After 1.5 minutes of inactivity, a
 * beep is sounded.  After 3 minutes of inactivity, the user is hung up.
 */
{
  unsigned char ch;
  int beepyet;
  long dd,tv,tv1;

  beepyet = 0;
  timelastchar1=timer1();

  if (so())
    tv=10920L;
  else
    tv=3276L;

  tv1=tv/2;

  lines_listed = 0;
  do {
    while (empty() && !hangup) {
      dd = timer1();
      if (labs(dd - timelastchar1) > 65536L)
        timelastchar1 -= 1572480L;
      if (((dd - timelastchar1) > tv1) && (!beepyet)) {
        beepyet = 1;
        outchr(7);
      }
      if (labs(dd - timelastchar1) > tv) {
        nl();
        outstr("Call back later when you are there.");
        nl();
        hangup = 1;
      }
      checkhangup();
    }
    ch = inkey();
  } while (!ch && !in_extern && !hangup);
  if (checkit && (ch > 127)) {
    checkit = 0;
    ch = ch & (andwith = 0x7F);
  }
  return(ch);
}



void inputold(char *s, int maxlen, int lc, int crend)
/* This will input a line of data, maximum maxlen characters long, terminated
 * by a C/R.  if (lc) is non-zero, lowercase is allowed, otherwise all
 * characters are converted to uppercase.
 */
{
  int curpos=0, done=0;
  unsigned char ch;

  while (!done && !hangup) {
    ch = getkey();
    if (ch > 31) {
      if (curpos < maxlen) {
        if (!lc)
          ch = upcase(ch);
        s[curpos++] = ch;
        outchr(ch);
      }
    } else
      switch(ch) {
        case 14:
        case 13:
          s[curpos] = 0;
          done = echo = 1;
          if (crend)
            nl();
          break;
        case 26:
          if (input_extern) {
            s[curpos++] = 26;
            outstr("^Z");
          }
          break;
        case 8:
          if (curpos) {
            curpos--;
            backspace();
            if (s[curpos] == 26)
              backspace();
          }
          break;
        case 21:
        case 24:
          while (curpos) {
            curpos--;
            backspace();
            if (s[curpos] == 26)
              backspace();
          }
          break;
      }
  }
  if (hangup)
    s[0] = 0;
}

void input1(char *s, int maxlen, int lc, int crend)
/* This will input a line of data, maximum maxlen characters long, terminated
 * by a C/R.  if (lc) is non-zero, lowercase is allowed, otherwise all
 * characters are converted to uppercase.
 */
{
  int curpos=0, done=0;
  unsigned char ch,s1[20];
  if(!inputblue) {inputblue=0; inputold(s,maxlen,lc,crend); return;}
  if(echo && okansi()) {makeansi(121,s1);  outstr(s1);}
  while (!done && !hangup) {
    ch = getkey();
    if (ch > 31) {
      if (curpos < maxlen) {
        if (!lc)
          ch = upcase(ch);
        s[curpos++] = ch;
        outchr(ch);
      }
    } else
      switch(ch) {
        case 14:
        case 13:
          s[curpos] = 0;
          done = echo = 1;
          if (crend)
          break;
        case 26:
          if (input_extern) {
            s[curpos++] = 26;
            outstr("^Z");
          }
          break;
        case 8:
          if (curpos) {
            curpos--;
            backspace();
            if (s[curpos] == 26)
              backspace();
          }
          break;
        case 21:
        case 24:
          while (curpos) {
            curpos--;
            backspace();
            if (s[curpos] == 26)
              backspace();
          }
          break;
      }
  }
  if (hangup)
    s[0] = 0;
  makeansi(15,s1);
  outstr(s1);
  inputblue=0;
  nl();
  nl();
}


void input(char *s, int len)
/* This will input an upper-case string */
{
  input1(s, len, 0, 1);
}



void inputl(char *s, int len)
/* This will input an upper or lowercase string of characters */
{
  input1(s, len, 1, 1);
}



int yn()
/* The keyboard is checked for either a Y, N, or C/R to be hit.  C/R is
 * assumed to be the same as a N.  Yes or No is output, and yn is set to
 * zero if No was returned, and yn() is non-zero if Y was hit.
 */
{
  char ch=0;

  ansic(4);
  while (!hangup && ((ch = upcase(getkey())) != 'Y') && (ch != 'N') && (ch != 13))
  ;
  outstr((ch == 'Y') ? "Yes" : "No");
  nl();
  return(ch == 'Y');
}

int ny()
/* This is the same as yn(), except C/R is assumed to be "Y" */
{
  char ch=0;

  ansic(4);
  while (!hangup && ((ch = upcase(getkey())) != 'Y') && (ch != 'N') && (ch != 13))
  ;
  outstr((ch == 'N') ? "No" : "Yes");
  nl();
  return((ch == 'Y') || (ch==13));
}

int nyques(char *msg, int x)
{
    prt(x,msg); return ny();
}

int ynques(char *msg, int x)
{
    prt(x,msg); return yn();
}

void tcolor(int n)
{
    char *s;
    makeansi(n,s);
    printf("%s",s);
}

void ansic(int n)
{
  char s[81], c;


     c = ((thisuser.sysstatus & sysstatus_color) ? thisuser.colors[n] :
        thisuser.bwcolors[n]);
  if(c == curatr) return;

  if(thisuser.res[10]&&!lokb) {
    if(n<10) {
        sprintf(s,"%d",n);
        domansihigh(s[0]);
    } else {
        sprintf(s,"%d",n-10);
        domansilow(s[0]);
    }
  } else {
  makeansi(c, s);
  outstr(s);
    makeansi((thisuser.sysstatus & sysstatus_color) ? thisuser.colors[0] :
        thisuser.bwcolors[0],endofline);
  }
  strcpy(endofline,"[0;1m");
}                                       


char onek(char *s)
{
  char ch;

  while (!strchr(s, ch = upcase(getkey())) && !hangup)
    ;
  if (hangup)
    ch = s[0];
  outchr(ch);
  nl();
  return(ch);
}


void get_modem_line(char *s, double d)
{
  int i=0;
  char ch=0, ch1;
  double t;

  t = timer();
  do {
    ch = get1c();
    if (kbhitb()) {
      ch1 = getchd();
      if (upcase(ch1) == 'H') {
        ch = 13;
        s[0] = i = 1;
      }
    }
    if (ch >= 32)
      s[i++] = upcase(ch);
  } while ((ch != 13) && (fabs(timer() - t) < d) && (i<=30));
  s[i] = 0;
}


void prt(int i, char *s)
{
  ansic(i);
  outstr(s);
  ansic(0);
}
