#include "nifrec.h"
#include "fcns.h"
#include <fcntl.h>
#include <io.h>
#include <sys\stat.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <dos.h>
#include <alloc.h>
#include <stdio.h>
#include <mem.h>

extern subboardrec subboards[32];
extern niftyrec nifty;
extern usersubrec usub[32];
extern int cursub,express,expressabort,topline,topdata;
extern int curlsub,nummsgs;
extern postrec *msgs;
extern configrec syscfg;
extern int bchanged;
extern userrec thisuser;
extern int reply,thread;     /*NEW*/
extern int hangup,incom,mciok;
extern int usernum,useron,screenbottom;
extern statusrec status;
extern char irt[81],cdir[81],net_email_name[81],byline[81];
extern messagerec menus[30];
extern int fwaiting,fsenttoday,msgreadlogon,wfc,mailcheck,numed;
extern editorrec *editors,*backuped;
extern short gat[2048];
extern char gatfn[81],charbuffer[161];
extern int use_workspace,charbufferpointer,lines_listed;
extern int checked[50];
extern int num_sys_list;
extern char *quote;


#define ALLOW_FULLSCREEN 1
#define EMAIL_STORAGE 2

/****************************************************************************/
void describe_area_code(int areacode, char *description)
{
  int f,done=0,i;
  char s[81],*ss,*ss1;

  description[0]=0;
  sprintf(s,"%sREGIONS.DAT",syscfg.datadir);
  f=open(s,O_RDWR | O_TEXT);
  if (f<1)
    return;
  ss=malloca(filelength(f));
  i=read(f,ss,filelength(f));
  ss[i]=0;
  close(f);
  ss1=strtok(ss,"\n");
  while (ss1 && (!done)) {
    i=atoi(ss1);
    if (i) {
      if (i==areacode)
        done=1;
    } else
      strcpy(description,ss1);
    ss1=strtok(NULL,"\n");
  }

  farfree(ss);
}



/****************************************************************************/
static char origin_str[81];

void setorigin(int sysnum)
{
  int i;
  char s[81],ch;
  net_system_list_rec *csne;

  origin_str[0]=0;

  if (sysnum) {
    csne=next_system(sysnum);
    if (csne) {
      if (csne->other & other_net_coord)
        ch='&';
      else if (csne->other & other_group_coord)
        ch='%';
      else if (csne->other & other_coordinator)
        ch='^';
      else
        ch=' ';

      describe_area_code(atoi(csne->phone),s);
      if (s[0])
        sprintf(origin_str,"%c%s (%s)",ch,csne->name,s);
      else
        sprintf(origin_str,"%c%s [%s]",ch,csne->name,csne->phone);


    } else
      strcpy(origin_str," Unknown System");
  }
}



/****************************************************************************/
int check_editors()
{
  static int ed_ok=1;
  int i,i1,ce;

  for (i=0; i<numed; i++) {
    ce=0;
    for (i1=0; i1<81; i1++) {
      ce+=editors[i].filename[i1];
      ce+=editors[i].filenamecon[i1];
    }
    if (ce!=checked[i])
      ed_ok=0;
  }
  if (!ed_ok) {
    nl();
    print("Full-Screen editor data corrupted; FSED's off-line.");
    nl();
  }
  return(ed_ok);
}

int okfsed()
{
  int ok;

  ok=ALLOW_FULLSCREEN;
  if (!okansi())
    ok=0;
  if (!thisuser.defed)
    ok=0;
  if (thisuser.defed>numed)
    ok=0;
  if (!check_editors())
    ok=0;
  return(ok);
}


void remove_link(messagerec *m1, char *aux)
{
  messagerec m;
  char s[81],s1[81];
  int f;
  long csec,nsec;

  m=*m1;
  strcpy(s,syscfg.msgsdir);
  switch(m.storage_type) {
    case 0:
    case 1:
      ltoa(m.stored_as,s1,16);
      if (m.storage_type==1) {
        strcat(s,aux);
        strcat(s,"\\");
      }
      strcat(s,s1);
      unlink(s);
      break;
    case 2:
      f=open_file(aux);
      csec=m.stored_as;
      while ((csec>0) && (csec<2048)) {
        nsec=(long) gat[csec];
	gat[csec]=0;
	csec=nsec;
      }
      lseek(f,0L,SEEK_SET);
      write(f,(void *)gat,4096);
      close(f);
      break;
    default:
      /* illegal storage type */
      break;
  }
}


int open_file(char *fn)
{
  int f,i;
  char s[81];

  sprintf(s,"%s%s.DAT",syscfg.msgsdir,fn);
  f=open(s,O_RDWR | O_BINARY);
  if (f<0) {
    f=open(s,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
    for (i=0; i<2048; i++)
      gat[i]=0;
    write(f,(void *)gat,4096);
    strcpy(gatfn,fn);
    chsize(f,4096L + (75L * 1024L));
  }
  if (strcmp(gatfn,fn)) {
    lseek(f,0L,SEEK_SET);
    read(f,(void *)gat,4096);
    strcpy(gatfn,fn);
  }
  return(f);
}



void savefile(char *b, long l1, messagerec *m1, char *aux)
{
  int f,gatp,i5,i4,gati[128];
  messagerec m;
  char s[81],s1[81];

  m=*m1;
  switch(m.storage_type) {
    case 0:
    case 1:
      m.stored_as=status.qscanptr++;
      save_status();
      ltoa(m.stored_as,s1,16);
      strcpy(s,syscfg.msgsdir);
      if (m.storage_type==1) {
        strcat(s,aux);
        strcat(s,"\\");
      }
      strcat(s,s1);
      f=open(s,O_RDWR | O_CREAT | O_BINARY,S_IREAD | S_IWRITE);
      write(f, (void *)b,l1);
      close(f);
      break;
    case 2:
      f=open_file(aux);
      gatp=0;
      i5=(int) ((l1 + 511L)/512L);
      i4=1;
      while ((gatp<i5) && (i4<2048)) {
        if (gat[i4]==0)
          gati[gatp++]=i4;
        ++i4;
      }
      gati[gatp]=-1;
      for (i4=0; i4<i5; i4++) {
        lseek(f,4096L + 512L * (long)(gati[i4]),SEEK_SET);
        write(f,(void *)(&b[i4*512]),512);
        gat[gati[i4]]=gati[i4+1];
      }
      lseek(f,0L,SEEK_SET);
      write(f,(void *)gat,4096);
      close(f);
      m.stored_as=(long) gati[0];
      break;
    case 255:
      f=open(aux,O_RDWR | O_CREAT | O_BINARY,S_IREAD | S_IWRITE);
      write(f, (void *)b,l1);
      close(f);
      break;
    default:
      sprintf(s,"Illegal storage type of %u on save!",m.storage_type);
      pl(s);
      break;
  }
  farfree((void *)b);
  *m1=m;
}


char *readfile(messagerec *m1, char *aux, long *l)
{
  int f,i,i1,csec;
  long l1,l2;
  char *b,s[81],s1[81];
  messagerec m;

  *l=0L;
  m=*m1;
  switch(m.storage_type) {
    case 0:
    case 1:
      strcpy(s,syscfg.msgsdir);
      ltoa(m.stored_as,s1,16);
      if (m.storage_type==1) {
        strcat(s,aux);
        strcat(s,"\\");
      }
      strcat(s,s1);
      f=open(s,O_RDONLY | O_BINARY);
      if (f==-1) {
	*l=0L;
        return(NULL);
      }
      l1=filelength(f);
      if ((b=malloca(l1))==NULL) {
        close(f);
        return(NULL);
      }
      read(f,(void *)b,l1);
      close(f);
      *l=l1;
      break;
    case 2:
      f=open_file(aux);
      csec=m.stored_as;
      l1=0;
      while ((csec>0) && (csec<2048)) {
	l1+=512L;
	csec=gat[csec];
      }
      if (!l1) {
        nl();
        pl("No message found.");
        nl();
        return(NULL);
      }
      if ((b=malloca(l1))==NULL)
        return(NULL);
      csec=m.stored_as;
      l1=0;
      while ((csec>0) && (csec<2048)) {
        lseek(f,4096L + 512L*csec,SEEK_SET);
        l1+=(long)read(f,(void *)(&(b[l1])),512);
	csec=gat[csec];
      }
      close(f);
      l2=l1-512;
      while ((l2<l1) && (b[l2]!=26))
	++l2;
      *l=l2;
      break;
    case 255:
      f=open(aux,O_RDONLY | O_BINARY);
      if (f==-1) {
	*l=0L;
        return(NULL);
      }
      l1=filelength(f);
      if ((b=malloca(l1+256L))==NULL)
        return(NULL);
      read(f,(void *)b,l1);
      close(f);
      *l=l1;
      break;
    default:
      /* illegal storage type */
      *l=0L;
      b=NULL;
      break;
  }
  return(b);
}


void change_storage(messagerec *oldm, char *olda, messagerec *newm, char *newa)
{
  long len;
  char *b;

  b=readfile(oldm,olda,&len);
  remove_link(oldm,olda);
  savefile(b,len,newm,newa);
}


void load_workspace(char *fnx, int no_edit)
{
  int i,i5;
  long l;
  char *b,s[81];

  i5=open(fnx,O_RDONLY | O_BINARY);
  if (i5<1) {
    nl();
    pl("File not found.");
    nl();
    return;
  }
  l=filelength(i5);
  if ((b=malloca(l+1024))==NULL) {
    close(i5);
    return;
  }
  read(i5, (void *) b,l);
  close(i5);
  if (b[l-1]!=26)
    b[l++]=26;
  sprintf(s,"%sINPUT.MSG",syscfg.tempdir);
  i5=open(s,O_RDWR | O_CREAT | O_BINARY,S_IREAD | S_IWRITE);
  write(i5, (void *)b,l);
  close(i5);
  farfree(b);
  if ((no_edit) || (!okfsed()))
    use_workspace=1;
  else
    use_workspace=0;
  nl();
  pl("File loaded into workspace.");
  nl();
  if (!use_workspace)
    pl("Editing will be allowed.");

}


void osan(char *s, int *abort, int *next)
{
  int i;

  i=0;
  checkhangup();
  if (hangup)
    *abort=1;
  checka(abort,next);
  while ((s[i]) && (!(*abort))) {
    outchr(s[i++]);
    checka(abort,next);
  }
}



void addline(char *b, char *s, long *ll)
{
  strcpy(&(b[*ll]),s);
  *ll +=strlen(s);
  strcpy(&(b[*ll]),"\r\n");
  *ll += 2;
}


#define LEN 161

void stuff(char *s, char *old, char *new)
{
  char s1[LEN],*ss;

  if (strlen(s)-strlen(old)+strlen(new)>=LEN)
    return;
  ss=strstr(s,old);
  if (ss==NULL)
    return;
  ss[0]=0;
  strcpy(s1,s);
  strcat(s1,new);
  strcat(s1,&(ss[strlen(old)]));
  strcpy(s,s1);
}


int ttchk(char *ttl)
{
  int reval,abort,ct;
  char s[81],s1[81];

    ct=0;
    reval=0;
    abort=0;
    strcpy(s,ttl);
    while ((!abort) && (!hangup) && (ct<nummsgs)) {
    ++ct;
    strcpy(s1,msgs[ct].title);
    if (strncmp(s,s1,60)==0) {
      nl();
      nl();
      prt(2,"Sorry, that title is already in use. Please use a different one.");
      nl();
      nl();

      reval=1;
      abort=1;
     }
   }
   return(reval);
}



int checkreply()                                   
{
  char s1[20];

  strncpy(s1,irt,9);
  if (strncmp(s1,"5RE: 3",8) ==0) {    /* DO NOT CHANGE THESE COLORS!! */
   return(1);
 } else {
   return(0);
  }
}


void inmsg(messagerec *m1, char *title, int *anony, int needtitle, char *aux, int fsed)
{
  char s[LEN],s1[LEN],s2[LEN],ro[81],fnx[81],chx,*ss,*ss1,*c,towho[81],s3[71],s4[255];
  int maxli,curli,done,save,savel,i,i1,i2,i3,i4,i5,f,setanon,gati[50],gatp,n,begx;
  messagerec m;
  long ll,l1;
  char *lin, *b;
  int real_name=0;
  strcpy(towho,"");
  if ((fsed!=0) && (!okfsed()))
    fsed=0;
  sprintf(fnx,"%sINPUT.MSG",syscfg.tempdir);
  if (fsed)
    fsed=1;
  if (use_workspace) {
    if (!exist(fnx))
      use_workspace=0;
    else
      fsed=2;
  }
  done=0;
  setanon=0;
  save=0;
  curli=0;
  m=*m1;
  if (thisuser.sl<45)
    maxli=30;
  else
    if (thisuser.sl<60)
      maxli=50;
    else
      if (thisuser.sl<80)
        maxli=60;
      else
        maxli=80;
  if (!fsed) {
    if ((lin=malloca((long)(maxli+10)*LEN))==NULL) {
      m1->stored_as=0xffffffff;
      return;
    }
    for (i=0; i<maxli; i++)
      lin[i*LEN]=0;
    ro[0]=0;
  }

  nl();

  if (okansi()) {

    pl("Title: ");
    if ((reply==0) || (strlen(irt) ==0)) {
        mpl(43);
     inputl(title,43);
     if (subboards[curlsub].type && (aux != "EMAIL"))  {
       sprintf(s3,"%-43.43s 2<%d>",title,syscfg.systemnumber);
       strcpy(title,s3);
   }
      if (ttchk(title))
       title[0]=0;
 } else {
    if (checkreply()) {
    pl("2[4CR2] 0to use: ");
    pl(irt);
    mpl(43);
    inputl(title,43);
    if(!title[0])
    strcpy(title,irt);
    else {
        sprintf(s3,"%-43.43s 2<%d>",title,syscfg.systemnumber);
        strcpy(title,s3);
    }
 } else {
    sprintf(s3,"5RE: 3%s",irt);
    pl("2[4CR2] 0to use: ");
    pl(s3);
    mpl(43);
    inputl(title,43);
    if(!title[0])
    strcpy(title,s3);
    else { sprintf(s3,"%-43.43s 2<%d>",title,syscfg.systemnumber);
    strcpy(title,s3); }
      }
   pl(title);
  }

 } else {
    pl("       (---=----=----=----=----=----=----=----=--)");
    outstr("Title: ");
    if ((reply==0) || (strlen(irt) ==0)) {        
     inputl(title,43);
     if (subboards[curlsub].type && (aux != "EMAIL"))  {
       sprintf(s3,"%-43.43s 2<%d>",title,syscfg.systemnumber);
       strcpy(title,s3);
   }
      if (ttchk(title))
       title[0]=0;
 } else {
    if (checkreply()) {
    strcpy(title,irt);
 } else {
    sprintf(s3,"5RE: 3%s",irt);
    strcpy(title,s3);
      }
   pl(title);
  }
}


  if ((title[0]==0) && (needtitle)) {
    pl("Aborted.");
    m.stored_as=0xffffffff;
    *m1=m;
    if (!fsed)
      farfree((void *)lin);
    return;
  }
  nl();
  if((strcmp(aux,"EMAIL"))==0);
  else { if(!byline[0]){
  pl("Who do you want to address this to? ");
  mpl(41);
  inputl(towho,40);
  if(!towho[0]) strcpy(towho,"7[0Address  7]1 All");
  else sprintf(towho,"7[0Address  7]1 %s",towho);
  nl();
  } else strcpy(towho,byline); }

  if (!fsed) {
    pl(get_string(11));
    pl(get_string(12));
    strcpy(s4,"2[0���7�0����7�0����7�0����7�0����7�0����7�0����7�0����5]0����7�0����7�0����7�0����7�0����7�0����7�0����7�0����2]");
    pl(s4);

    while (!done) {
      while(inli2(s,ro,160,1,curli)) {
         --curli;
         strcpy(ro,&(lin[(curli)*LEN]));
         if(strlen(ro)>thisuser.screenchars-1)
         ro[thisuser.screenchars-2]=0;
        }
        mciok=1;
      if (hangup)
        done=1;
      savel=1;
      if (s[0]=='/') {
        if (stricmp(s,"/?")==0) {
          savel=0;
          printmenu(2);
        }
      if (stricmp(s,"/MCI")==0) {
          savel=0;
          printmenu(15);
        }
      if (stricmp(s,"/COL")==0) {
          savel=0;
          printmenu(16);
        }
       if (stricmp(s,"/Q")==0) {
          savel=0;
          if (quote!=NULL)
            get_quote(0);
        }
        if (stricmp(s,"/L")==0) {
          savel=0;
          prt(5,"With line numbers? ");
          i1=yn();
          i2=0;
          for (i=0; (i<curli) && (!i2); i++) {
            if (i1) {
              itoa(i+1,s1,10);
              strcat(s1,":");
              pl(s1);
            }
            strcpy(s1,&(lin[i*LEN]));
            i3=strlen(s1);
            if (s1[i3-1]==1)
              s1[i3-1]=0;
            if (s1[0]==2) {
              strcpy(s1,&(s1[1]));
              i5=0;
              for(i4=0; i4<strlen(s1); i4++)
                if ((s1[i4]==8) || (s1[i4]==3))
                  --i5;
                else
                  ++i5;
              for (i4=0; (i4<(thisuser.screenchars-i5)/2) && (!i2); i4++)
                osan(" ",&i2,&i1);
            }
            pla(s1,&i2);
          }
          nl();
          pl("Continue...");
        }
            if (stricmp(s,"/DEL")==0) {
	  savel=0;
	  itoa(curli,s1,10);
	  prt(2,"Delete which line (1-");
	  prt(2,s1);
	  prt(2,") : ");
	  input(c,2);
	  n=atoi(c);
	  if ((n>0) && (n<=curli)) {
	    n=n-1;
	    i=&(lin[curli*LEN])+LEN-&(lin[(n+1)*LEN]);
	    memmove(&lin[(n)*LEN],&lin[(n+1)*LEN],&(lin[curli*LEN])+LEN-&(lin[(n+1)*LEN]));
	    --curli;
	    }
	  prt(1,"Done. Continue Message...");
	  nl();
	}
    if (stricmp(s,"/I")==0) {
	  savel=0;
	  if (curli==maxli) {
	    prt(5,"No room to insert a line");
	    nl();
	 } else {
	     itoa(curli,s1,10);
	     prt(2,"Insert before which line (1-");
	     prt(2,s1);
	     prt(2,") : ");
	     input(c,2);
	     n=atoi(c);
	     if((n>0) && (n<=curli)) {
	       memmove(&lin[(n)*LEN],&lin[(n-1)*LEN],&(lin[curli*LEN])+LEN-&(lin[(n)*LEN]));
	       curli++;
	       prt(2,"Enter line to insert:");
	       nl();
	       inli(s,ro,160,1);
	       strcpy(&(lin[(n-1)*LEN]),s);
	     }
	   }
	 prt(1,"Done. Continue message...");
	 nl();
	}
        if ((stricmp(s,"/S")==0) || (stricmp(s,"/S")==0)) {
          save=1;
          done=1;
          savel=0;
        }
        if ((stricmp(s,"/SY")==0) || (stricmp(s,"/SY")==0)) {
          save=1;
          done=1;
          savel=0;
          setanon=1;
        }
        if ((stricmp(s,"/SN")==0) || (stricmp(s,"/SN")==0)) {
          save=1;
          done=1;
          savel=0;
          setanon=-1;
        }
        if (stricmp(s,"/A")==0) {
          done=1;
          savel=0;
        }
        if (stricmp(s,"/C")==0) {
          savel=0;
          curli=0;
          pl("Message cleared... Start over...");
          nl();
        }
        if (stricmp(s,"/R")==0) {
          savel=0;
          if (curli) {
            --curli;
            pl("Replace:");
          } else {
            pl("Nothing to replace.");
          }
        }
        if (stricmp(s1,"/C:")==0) {
          s1[0]=2;
          strcpy((&s1[1]),&(s[3]));
          strcpy(s,s1);
        }
	if ((stricmp(s1,"/SU")==0) && (s[3]=='/') && (curli)) {
	  strcpy(s1,&(s[4]));
          ss=strstr(s1,"/");
	  ss1=&(ss[1]);
	  ss[0]=0;
	  stuff(&(lin[(curli-1)*LEN]),s1,ss1);
	  pl("Last line:");
	  pl(&(lin[(curli-1)*LEN]));
	  pl("Continue...");
	  savel=0;
	}
      }
      if (savel) {
        strcpy(&(lin[(curli++)*LEN]),s);
        if (curli==maxli) {
          nl();
          pl("-= No more lines =-");
          pl("/S to save");
          nl();
          --curli;
        }
      }
    }
    if (curli==0)
      save=0;
  } else {
    if (fsed==1) {
      save=external_edit("INPUT.MSG",syscfg.tempdir,(int) (thisuser.defed)-1,maxli);
    } else {
      save=exist(fnx);
      if (save) {
	pl("Reading in file...");
      }
      use_workspace=0;
    }
  }


  if (save) {
    switch(*anony) {
      case 0: /* no anony */
	*anony=0;
        break;
      case anony_enable_anony:
        if (setanon) {
          if (setanon==1)
            *anony=anony_sender;
          else
            *anony=0;
        } else {
          prt(5,"Anonymous? ");
          if (yn())
            *anony=anony_sender;
          else
            *anony=0;
        }
        break;
      case anony_enable_dear_abby:
	nl();
	print("1. ",nam(&thisuser,usernum),"");
	pl("2. Abby");
	pl("3. Problemed Person");
	nl();
	prt(5,"Which? ");
        chx=onek("\r123");
	switch(chx) {
	  case '\r':
	  case '1':
	    *anony=0;
	    break;
	  case '2':
	    *anony=anony_sender_da;
	    break;
	  case '3':
	    *anony=anony_sender_pp;
	}
        break;
      case anony_force_anony:
        *anony=anony_sender;
        break;
      case anony_real_name:
        real_name=1;
        *anony=0;
        break;
    }
    begx=wherex();
    outstr("Saving...");
    if(nifty.nifstatus & nif_credit) thisuser.credits+=nifty.postcredits;
    if (fsed) {
      i5=open(fnx,O_RDONLY | O_BINARY);
      l1=filelength(i5);
    } else {
      l1=0;
      for (i5=0; i5<curli; i5++) {
	l1 += strlen(&(lin[i5*LEN]));
	l1 += 2;
      }
    }
    l1 += 1024;
    if ((b=malloca(l1))==NULL) {
      farfree(lin);
      pl("Out of memory.");
      m1->stored_as=0xffffffff;
      return;
    }

    l1=0;
    if (real_name)
      addline(b,thisuser.realname,&l1);
    else
      addline(b,nam1(&thisuser,usernum,syscfg.systemnumber),&l1);
    time(&ll);
    strcpy(s,ctime(&ll));
    s[strlen(s)-1]=0;
    addline(b,s,&l1);
    if (towho[0]) {
      addline(b,towho,&l1);
      towho[0]=0;
    }

    addline(b,"",&l1);

    if (fsed) {
      ll=filelength(i5);
      read(i5, (void *) (& (b[l1]) ),ll);
      l1 += ll;
      close(i5);
    } else {
      for (i5=0; i5<curli; i5++)
	addline(b,&(lin[i5*LEN]),&l1);
    if ((subboards[curlsub].type) && (syscfg.systemnumber))
      {
        addline(b,"",&l1); /* Blank line, leave this alone! */
        if(strcmp(aux,"EMAIL")) {
        addline(b,get_string(31),&l1);
        addline(b,get_string(32),&l1); }
      }

    }
    if (b[l1-1]!=26)
      b[l1++]=26;
    savefile(b,l1,&m,aux);
    if (fsed)
      unlink(fnx);
  } else {
    if (fsed)
      unlink(fnx);
    pl("Aborted.");
    m.stored_as=0xffffffff;
  }
  *m1=m;
  if (!fsed) {
    farfree((void *)lin);
  }
  charbufferpointer=0;
  charbuffer[0]=0;
  while(wherex()>begx) backspace();
}


int forwardm(unsigned short *u, unsigned short *s)
{
  userrec ur;
  char *ss;
  int i,i1,cu;

  if (*s)
    return(0);
  read_user(*u,&ur);
  if (ur.inact & inact_deleted)
    return(0);
  if ((ur.forwardusr==0) && (ur.forwardsys==0))
    return(0);
  if (ur.forwardsys) {
    if ((ur.forwardusr>0) && (ur.forwardusr<32767)) {
      *u=ur.forwardusr;
      *s=ur.forwardsys;
      return(1);
    } else {
      *u=0;
      *s=0;
      return(0);
    }
  }
  cu=ur.forwardusr;
  if ((ss=malloca((long) syscfg.maxusers+ 300L))==NULL)
    return(0);
  for (i=0; i<syscfg.maxusers+300; i++)
    ss[i]=0;
  ss[*u]=1;
  read_user(cu,&ur);
  while ((ur.forwardusr) || (ur.forwardsys)) {
    if (ur.forwardsys) {
      *u=ur.forwardusr;
      *s=ur.forwardsys;
      farfree(ss);
      return(1);
    }
    if (ss[cu]) {
      farfree(ss);
      return(0);
    }
    ss[cu]=1;
    cu=ur.forwardusr;
    read_user(cu,&ur);
  }
  farfree(ss);
  *s=0;
  *u=cu;
  return(1);
}


void email(unsigned short un, unsigned short sy, int forceit, int anony)
{
  int i,i1,f,len,an;
  mailrec m,m1;
  char s[81],s1[81],s2[81],t[81],*b,*b1;
  userrec ur;
  slrec ss;
  long len1;
  float fl;
  net_header_rec nh;
  unsigned int ui;
  net_system_list_rec *csne;


  if (freek1(syscfg.msgsdir)<10.0) {
    nl();
    pl("Not enough Free Disk Space");
    nl();
    return;
  }
  nl();
  sprintf(s,"%sEMAIL.DAT",syscfg.datadir);
  ss=syscfg.sl[thisuser.sl];
  if (forwardm(&un,&sy)) {
    nl();
    pl("Mail Forwarded.");
    nl();
    if ((un==0) && (sy==0)) {
      pl("Forwarded to unknown user.");
      return;
    }
  }
  if ((sy!=0) && (syscfg.systemnumber==0)) {
    nl();
    pl("Sorry, this system is not a part of a net.");
    nl();
    return;
  }
  if (sy==0) {
    read_user(un,&ur);
    if (((ur.sl==255) && (ur.waiting>(syscfg.maxwaiting * 5))) ||
        ((ur.sl!=255) && (ur.waiting>syscfg.maxwaiting)) ||
        (ur.waiting>200)) {
      nl();
      pl("Mailbox full.");
      nl();
      return;
    }
    if (ur.inact & inact_deleted) {
      nl();
      pl("Deleted user.");
      nl();
      return;
    }
  } else {
    if ((csne=next_system(sy))==NULL) {
      nl();
      pl("Unknown system number.");
      nl();
      return;
    }
    if (thisuser.restrict & restrict_net) {
      nl();
      pl("You can't send mail off the system.");
      return;
    }
  }
  if (forceit==0) {
    if ((((un==1) && ((fsenttoday>=5) || (thisuser.fsenttoday1>=10))) ||
	 ((un!=1) && (thisuser.etoday>=ss.emails))) && (!cs())) {
      nl();
      pl("Too much mail sent today.");
      nl();
      return;
    }
    if ((restrict_email & thisuser.restrict) && (un!=1)) {
      nl();
      pl("You can't send mail.");
      nl();
      return;
    }
  }
  if (ss.ability & ability_read_email_anony)
    an=1;
  else
    if (anony & (anony_sender | anony_sender_da | anony_sender_pp))
      an=0;
    else
      an=1;
  if (sy==0) {
    if (an) {
      read_user(un,&ur);
      strcpy(s2,nam(&ur,un));
    } else
      strcpy(s2,">UNKNOWN<");
  } else {
    if (un==0)
      sprintf(s2,"%s @%u",net_email_name,sy);
    else
      sprintf(s2,"User %u @%u",un,sy);
  }
  print("E-mailing ",s2,"");
  if (ss.ability & ability_email_anony)
    i=anony_enable_anony;
  else
    i=0;
  if (anony & (anony_receiver_pp | anony_receiver_da))
    i=anony_enable_dear_abby;
  if (anony & anony_receiver)
    i=anony_enable_anony;
  if ((i==anony_enable_anony) && (thisuser.restrict & restrict_anony))
    i=0;
  if (sy!=0) {
    i=0;
    anony=0;
    nl();
    sprintf(s,"Name of system: '%s'",csne -> name);
    pl(s);
    sprintf(s,"Number of hops: %u",csne->numhops);
    pl(s);
    nl();
  }
  m.msg.storage_type=EMAIL_STORAGE;
  inmsg(&m.msg,t,&i,!forceit,"EMAIL",ALLOW_FULLSCREEN);
  if (m.msg.stored_as==0xffffffff)
    return;
  strcpy(m.title,t);
  if (anony & anony_sender)
    i|=anony_receiver;
  if (anony & anony_sender_da)
    i|=anony_receiver_da;
  if (anony & anony_sender_pp)
    i|=anony_receiver_pp;
  m.anony=i;
  m.fromsys=0;
  m.fromuser=usernum;
  m.tosys=sy;
  m.touser=un;
  m.status=0;
  time((long *)&(m.daten));
  if (sy==0) {
    f=open(s,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
    len=(int) filelength(f)/sizeof(mailrec);
    if (len==0)
      i=0;
    else {
      i=len-1;
      lseek(f,((long) (i))*(sizeof(mailrec)), SEEK_SET);
      read(f,(void *)&m1,sizeof(mailrec));
      while ((i>0) && (m1.tosys==0) && (m1.touser==0)) {
        --i;
        lseek(f,((long) (i))*(sizeof(mailrec)), SEEK_SET);
        i1=read(f,(void *)&m1,sizeof(mailrec));
        if (i1==-1)
          pl("DIDN'T READ RIGHT.");
      }
      if ((m1.tosys) || (m1.touser))
        ++i;
    }
    lseek(f,((long) (i))*(sizeof(mailrec)), SEEK_SET);
    i1=write(f,(void *)&m,sizeof(mailrec));
    if (i1==-1) {
      pl("DIDN'T SAVE RIGHT!");
    }
    close(f);
  } else {
    if ((b=readfile(&(m.msg),"EMAIL",&len1))==NULL)
      return;
    remove_link(&(m.msg),"EMAIL");
    nh.tosys=sy;
    nh.touser=un;
    nh.fromsys=syscfg.systemnumber;
    nh.fromuser=usernum;
    nh.main_type=main_type_email;
    nh.minor_type=0;
    nh.list_len=0;
    nh.daten=m.daten;
    nh.method=0;
    if ((b1=malloca(len1+300))==NULL) {
      farfree(b);
      return;
    }
    i=0;
    if (un==0) {
      nh.main_type=main_type_email_name;
      strcpy(&(b1[i]),net_email_name);
      i+= strlen(net_email_name)+1;
    }
    strcpy(&(b1[i]),m.title);
    i += strlen(m.title)+1;
    memmove(&(b1[i]),b,(unsigned int) len1);
    nh.length=len1+(long)i;
    strcpy(s,syscfg.datadir);
    sprintf(s,"%sP0.NET",syscfg.datadir);
    f=open(s,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
    lseek(f,0L,SEEK_END);
    write(f,(void *)&nh,sizeof(net_header_rec));
    write(f,(void *)b1,nh.length);
    close(f);
    farfree(b);
    farfree(b1);
  }
  s2[0]=0;
  strcpy(s,"Mail sent to ");
  if (sy==0) {
    read_user(un,&ur);
    ++ur.waiting;
    write_user(un,&ur);
    close_user();
    if (un==1)
      ++fwaiting;
    if (an) {
      strcat(s,nam(&ur,un));
      sysoplog(s);
    } else {
      strcpy(s1,s);
      strcat(s1,nam(&ur,un));
      sysoplog(s1);
      strcat(s,">UNKNOWN<");
    }
  } else {
    if (un==0)
      sprintf(s1,"%s @%u",net_email_name,sy);
    else
      sprintf(s1,"User %u @%u",un,sy);
    strcat(s,s1);
    sysoplog(s);
  }
  if ((un==1) && (sy==0)) {
    ++status.fbacktoday;
    ++thisuser.feedbacksent;
    ++thisuser.fsenttoday1;
    ++fsenttoday;
  } else {
    ++status.emailtoday;
    ++thisuser.etoday;
    if (sy==0) {
      ++thisuser.emailsent;
    } else {
      ++thisuser.emailnet;
      /* len1=nh.length+sizeof(net_header_rec); */
      /* fl = (csne->cost) * ((float)len1) / 1024.0; */
      /* sprintf(s2,"Total cost: $%6.2f",fl); */
    }
  }
  save_status();
  if (!wfc)
    topscreen();
  pl(s);
  if (s2[0])
    pl(s2);
}

void imail(unsigned short u, unsigned short s)
{
  char s1[81],s2[81];
  int i;
  userrec ur;

  if (forwardm(&u,&s))
    pl("Mail forwarded.");

  i=1;
  if (s==0) {
    read_user(u,&ur);
    if ((ur.inact & inact_deleted)==0) {
      sprintf(s1,"E-mail %s? ",nam(&ur,u));
      prt(5,s1);
      if (yn()==0)
        i=0;
    } else
      i=0;
  } else {
    sprintf(s1,"E-mail User %u @%u ? ",u,s);
    prt(5,s1);
    if (yn()==0)
      i=0;
  }
  if (i)
    email(u,s,0,0);
}


void iscan(int b)
{
  int f;
  char s[81];

  if (usub[b].subnum==curlsub)
    return;
  curlsub=usub[b].subnum;
  bchanged=0;
  nummsgs=0;
  if (curlsub<0)
    return;

  sprintf(s,"%s%s.SUB",syscfg.datadir,subboards[curlsub].filename);
  f=open(s,O_BINARY | O_RDWR);
  if (f==-1) {
    f=open(s,O_BINARY | O_RDWR | O_CREAT,S_IREAD | S_IWRITE);
    msgs[0].owneruser=0;
    write(f,(void *) (&msgs[0]),sizeof(postrec));
  }
  lseek(f,0L,SEEK_SET);
  nummsgs=(read(f,(void *) (&msgs[0]),255*sizeof(postrec)) / sizeof(postrec))-1;
  nummsgs=msgs[0].owneruser;
  close(f);
}


void savebase()
{
  int f;
  char s[81];

  if (bchanged==0)
    return;


  sprintf(s,"%s%s.SUB",syscfg.datadir,subboards[curlsub].filename);
  f=open(s,O_BINARY | O_RDWR);
  lseek(f,0L,SEEK_SET);
  msgs[0].owneruser=nummsgs;
  write(f,(void *) (&msgs[0]), ((nummsgs+1) * sizeof(postrec)));
  close(f);
  bchanged=0;
}


void plan(char *s, int *abort, int *next)
{
  int i;

  i=0;
  checkhangup();
  if (hangup)
    *abort=1;
  checka(abort,next);
  while ((s[i]) && (!(*abort))) {
    outchr(s[i++]);
    checka(abort,next);
  }
  if (!(*abort))
    nl();
}


#define buf_size 512

void read_message1(messagerec *m1, char an, int readit, int *next, char *fn)
{
  char n[81],d[81],s[161],s1[81],s2[81],*sss,*ss,ch;
  int f,abort,done,end,cur,p,p1,printit,ctrla,centre,i,i1,ansi,ctrld;
  messagerec m;
  char *buf;
  long csec,len,l1,l2;

  if ((buf=malloca(buf_size))==NULL)
    return;
  ss=NULL;
  ansi=0;
  m=*m1;
  *next=0;
  f=-1;
  done=0;
  cur=0;
  end=0;
  abort=0;
  ctrld=0;
  switch(m.storage_type) {
    case 0:
    case 1:
    case 2:
      ss=readfile(&m,fn,&len);
      if (m.storage_type!=2) {
        strcpy(s,syscfg.msgsdir);
        ltoa(m.stored_as,s1,16);
        if (m.storage_type==1) {
          strcat(s,fn);
          strcat(s,"\\");
        }
        strcat(s,s1);
        strcpy(s2,"FN  : ");
        strcat(s2,s1);
        if (so())
          pl(s2);
        else {
          strcat(s2,"\r\n");
          outs(s2);
        }
      }
      if (ss==NULL) {
        plan("File Not Found.",&abort,next);
        nl();
	farfree(buf);
        return;
      }
      p=0;
      while ((ss[p]!=13) && ((long)p<len) && (p<60))
        n[p]=ss[p++];
      n[p]=0;
      ++p;
      p1=0;
      if (ss[p]==10)
        ++p;
      while ((ss[p+p1]!=13) && ((long)p+p1<len) && (p<60))
        d[p1]=ss[(p1++)+p];
      d[p1]=0;
      cur=p+p1+1;
      break;
    case 255:
      strcpy(s,fn);
      f=open(s,O_RDONLY | O_BINARY);
      if (f==-1) {
        plan("File Not Found.",&abort,next);
        nl();
	farfree(buf);
        return;
      }
      lseek(f,m.stored_as,SEEK_SET);
      end=read(f,(void *)buf,buf_size);
      break;
    default:
      /* illegal storage type */
      nl();
      pl("->ILLEGAL STORAGE TYPE<-");
      nl();
      farfree(buf);
      return;
  }

  if (m.storage_type!=255) switch(an) {
    default:
    case 0:
      strcpy(s,"7[0Name     7]1 ");
      osan(s,&abort,next);
      strcpy(s,n);
      strcpy(byline,"7[0Reply To 7]1 ");
      strcat(byline,n);
      plan(s,&abort,next);
      strcpy(s,"7[0Date     7]1 ");
      osan(s,&abort,next);
      strcpy(s,d);
      plan(s,&abort,next);
      if (origin_str[0]) {
        osan("7[0From     7]1",&abort,next);
        plan(origin_str,&abort,next);
      }
      break;
    case anony_sender:
      if (readit) {
        strcpy(s,"7[0Name     7]1 ");
	osan(s,&abort,next);
        strcpy(s," 1<<< ");
        strcat(s,n);
	strcat(s," >>>");
    strcpy(byline,"7[0By7       ]1 8UnKnown");
	plan(s,&abort,next);
    strcpy(s,"7[0Date     7]1 ");
	osan(s,&abort,next);
        strcpy(s,d);
        plan(s,&abort,next);
      } else {
    osan("7[0Name     7]1 ",&abort,next);
	plan("8Anonymous",&abort,next);
    strcpy(byline,"7[0Reply To7]1 8UnKnown");
    osan("7[0Date     7]1 ",&abort,next);
	plan("8Anonymous",&abort,next);
      }
      break;
    case anony_sender_da:
    case anony_sender_pp:
      if (an==anony_sender_da) {
        osan("7[0Name     7]1 ",&abort,next);
	plan("Abby",&abort,next);
    strcpy(byline,"7[0Reply To 7]1 8UnKnown");
      } else {
        osan("7[0Name     7]1 ",&abort,next);
	plan("Problemed Person",&abort,next);
      }
      if (readit) {
        strcpy(s,"7[0Name     7]1 ");
	osan(s,&abort,next);
        strcpy(s,n);
	plan(s,&abort,next);
    strcpy(byline,"7[0Reply To 7]1 ");
	strcat(byline,n);
    strcpy(s,"7[0Date     7]1 ");
	osan(s,&abort,next);
        strcpy(s,d);
        plan(s,&abort,next);
      } else {
        osan("7[0Date     7]1 ",&abort,next);
    plan("8Anonymous",&abort,next);
      }
      break;
  }
  p=0;
  p1=0;
  done=0;
  printit=0;
  ctrla=0;
  centre=0;
  l1=(long) cur;

  while ((!done) && (!abort) && (!hangup)) {
    switch(m.storage_type) {
      case 0:
      case 1:
      case 2:
	ch=ss[l1];
	if (l1>=len)
          ch=26;
        break;
      case 255:
        if (cur>=end) {
          cur=0;
          end=read(f,(void *)buf,buf_size);
          if (end==0)
            buf[0]=26;
        }
        if ((buf[cur]=='`') && (m.stored_as))
          buf[cur]=26;
	ch=buf[cur];
        break;
    }
    if (ch==26)
      done=1;
    else
      if (ch!=10) {
        if ((ch==13) || (!ch)) {
          if (ch==13)
            ctrld=0;
          printit=1;
        } else if (ch==1)
          ctrla=1;
        else if (ch==2)
          centre=1;
        else if (ch==4)
          ctrld=1;
        else if (ctrld==1) {
          if ((ch>='0') && (ch<='9')) {
            if (thisuser.optional_val<(ch-'0'))
              ctrld=0;
            else
              ctrld=-1;
          } else
            ctrld=0;
        } else {
          if (ch==27) {
            if ((topline) && (screenbottom==24) && (!ansi))
              set_protect(0);
            ansi=1;
            lines_listed=0;
          }
          s[p++]=ch;
          if ((ch==3) || (ch==8))
            --p1;
          else
            ++p1;
          if ((ch==32) && (!centre))
            printit=1;
        }

        if ((printit) || (ansi) || (p>=80)) {
          printit=0;
          if (centre && (ctrld!=-1)) {
            i1=(thisuser.screenchars-wherex()-p1)/2;
            for (i=0; (i<i1) && (!abort) && (!hangup); i++)
              osan(" ",&abort,next);
          }
          if (p) {
            if (ctrld!=-1) {
              if ((wherex() + p1 >= thisuser.screenchars) && (!centre) && (!ansi))
                nl();
              s[p]=0;
              osan(s,&abort,next);
              if ((ctrla) && (s[p-1]!=32) && (!ansi))
                outchr(32);
            }
            p1=0;
            p=0;
          }
          centre=0;
        }
        checka(&abort,next);
        if (ch==13)
          if (ctrla==0) {
            if (ctrld!=-1)
              nl();
          } else
            ctrla=0;
      } else
        ctrld=0;
    ++cur;
    ++l1;
  }
  if ((!abort) && (p)) {
    s[p]=0;
    pl(s);
  }
  nl();
  if (f!=-1)
    close(f);
  if ((m.storage_type==255) && (abort))
    *next=1;
  if ((express) && (abort) && (!(*next)))
    expressabort=1;
  farfree(buf);
  if (ss!=NULL)
    farfree(ss);
  if ((ansi) && (topdata) && (useron))
    topscreen();
}


int printfile(char *fn)
{
  char s[81],s1[81],s2[81];
  messagerec m;
  int next;

  m.stored_as=0L;
  m.storage_type=255;
  strcpy(s,syscfg.gfilesdir);
  strcat(s,fn);
  if (strchr(s,'.')==NULL) {
    if (thisuser.sysstatus & sysstatus_ansi) {

          if(thisuser.res[10]) {
               strcpy(s1,s);
               strcat(s1,".DAN");
               if(exist(s1))
                 strcpy(s,".DAN");
               else {
                 strcpy(s1,s);
                 strcat(s1,".ANS");
                 if(exist(s1))
                   strcat(s,".ANS");
                 else
                   strcat(s,".MSG");
              }
}

   else
      if (thisuser.sysstatus & sysstatus_color) {
    strcpy(s1,s);
	strcat(s1,".ANS");
	if (exist(s1))
	  strcat(s,".ANS");
      }
      if (strchr(s,'.')==NULL) {
	strcpy(s1,s);
	strcat(s1,".B&W");
	if (exist(s1))
	  strcat(s,".B&W");
	else
	  strcat(s,".MSG");
      }
    } else
      strcat(s,".MSG");
  }
  if(!exist(s)) return 999;
  read_message1(&m,0,0,&next,s);
  return(next);
}


void read_message(int n, int *next, int *val)
{
  char s[100],s1[80];
  postrec p;
  int abort,a;
  slrec ss;

  nl();
  abort=0;
  *next=0;
  if(thisuser.sysstatus & sysstatus_clr_scrn) outchr(12);
  sprintf(s1,"%u:%u",n,nummsgs);
  sprintf(s,"7[0%-9s7]1 ",s1);
  osan(s,&abort,next);
  p=msgs[n];
  if (p.status & (status_unvalidated | status_delete)) {
    strcpy(s1,"<<< NOT VALIDATED YET >>>");
    plan(s1,&abort,next);
    if (!lcs())
      return;
    *val |= 1;
    osan(s,&abort,next);
  }
  strcpy(s,p.title);
  sprintf(irt,"%s",s);
  plan(s,&abort,next);
  if ((p.status & status_no_delete) && (lcs())) {
    plan("||||> Permanent Message",&abort,next);
  }
  if (p.status & status_pending_net) {
    plan("----> Not Network Validated",&abort,next);
    *val |= 2;
  }
  if (!abort) {
    ss=syscfg.sl[thisuser.sl];
    if ((lcs()) || (ss.ability & ability_read_post_anony))
      a=1;
    else
      a=0;
    setorigin(p.ownersys);


    read_message1(&(p.msg),(p.anony & 0x0f),a,next,(subboards[curlsub].filename));
    ++thisuser.msgread;
    ++msgreadlogon;
  } else
        if ((express) && (!(*next)))
      expressabort=1;
  if (p.qscan>thisuser.qscnptr[curlsub]&&!thread) //here!!
    thisuser.qscnptr[curlsub]=p.qscan;
}


void lineadd(messagerec *m1, char *sx, char *aux)
{
  messagerec m;
  char s1[81],s[81],s2[81],*b;
  int f,i,j,new;

  strcpy(s2,sx);
  strcat(s2,"\r\n\0x1a");
  m=*m1;
  strcpy(s,syscfg.msgsdir);
  switch(m.storage_type) {
    case 0:
    case 1:
      ltoa(m.stored_as,s1,16);
      if (m.storage_type==1) {
        strcat(s,aux);
        strcat(s,"\\");
      }
      strcat(s,s1);
      f=open(s,O_RDWR | O_BINARY);
      if (f>0) {
        lseek(f,-1L,SEEK_END);
        write(f,(void *)s2,strlen(s2));
        close(f);
      }
      break;
    case 2:
      strcpy(s,sx);
      strcat(s,"\x1a");
      f=open_file(aux);
      new=1;
      while ((new<2048) && (gat[new]!=0))
	++new;
      i=(int)m.stored_as;
      while (gat[i]!=-1)
	i=gat[i];
      if ((b=malloca(2048))==NULL)
        return;
      lseek(f,4096L+((long)i)*512L,SEEK_SET);
      read(f,(void *)b,512);
      j=0;
      while ((j<512) && (b[j]!=26))
	++j;
      strcpy(&(b[j]),s);
      lseek(f,4096L+((long)i)*512L,SEEK_SET);
      write(f,(void *)b,512);
      if ((j+strlen(s))>512) {
	strcpy(b,&(s[512-j]));
	lseek(f,4096L+((long)new)*512L,SEEK_SET);
	write(f,(void *)b,512);
	gat[new]=-1;
	gat[i]=new;
	lseek(f,0L,SEEK_SET);
	write(f,(void *)gat,4096);
      }
      farfree((void *)b);
      close(f);
      break;
    default:
      /* illegal storage type */
      break;
  }
}


void delete(int mn)
{
  postrec p1;
  int i;

  iscan(cursub);
  if ((mn>0) && (mn<=nummsgs)) {
    p1=msgs[mn];
    remove_link(&p1.msg,(subboards[curlsub].filename));
    for (i=mn; i<nummsgs; i++)
      msgs[i]=msgs[i+1];
    nummsgs--;
    bchanged=1;
  }
}


