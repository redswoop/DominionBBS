#include "fcns.h"
#include <stdio.h>
#include "nifrec.h"

typedef struct {
    char desc[50],
         key[8],
         type[2],
         at,
         line[40],
         ms[80];
    char sl[8];
} menurec;

typedef struct {
    char prompt[100],
         title1[80],
         title2[80],
         altmenu[15],
         fallback[15],
         slneed[10],
         pausefile[10];
     int helplevel;
} mmrec;
menurec tg;
mmrec pp;
char avail[50][8],maxcmd,menuat[15],lastmenu[15];
extern directoryrec directories[64];
extern int hangup,express,expressabort,cursub,curdir,num_dirs,i1,com_speed;
extern int usernum,reply;
extern usersubrec usub[32];
extern usersubrec udir[64];
extern userrec thisuser;
extern niftyrec nifty;
extern configrec syscfg;
extern char irt[81],byline[81];
extern statusrec status;


void showmenu(void);
void menuman(void);

char *filter(char *s)
{
 char c='\n';
 int x=0;
 while(s[x++]!=c);
 s[x-1]='';
return s;
}

void magicprompt(void) {
FILE *ff;
char x=0,y,s[81];
char prompt[8][81];
sprintf(s,"%s\\%s.ani",nifty.menudir,pp.pausefile);
if(!exist(s)) sprintf(s,"%s\\pause.scr",nifty.menudir);
ff=fopen(s,"rt");
while(fgets(s,81,ff)!=NULL) strcpy(prompt[x++],filter(s));
y=x;
x=0;
outstr("[K\r");
while(inkey()<11) {
       outstr(prompt[x++]); if(x<y); else x=0;
       outstr("\r"); }
outstr("[K");
fclose(ff);
}

int slok(char s[81],char menu)
{
 char c=1,c1=0,s1[81],ok=1;
 int i;

if(thisuser.sl==255 || thisuser.res[5]) return 1;
 switch(toupper(s[0]))
   {
    case 'A': c1=s[1]; c=c1-'A';
              if(!thisuser.ar & (1 << c)) ok=0;
              break;

    case 'C': if(thisuser.sl>=200) ok=1;
              strcpy(s1,s+1);
              c1=atoi(s1); if(thisuser.credits<c1) ok=2;
              else { if(!menu) thisuser.credits-=c1; ok= 1; }
              break;

    case 'S': strcpy(s1,s+1); i=atoi(s1);
              if(thisuser.sl<i) ok=0;
              break;

    case 'D': strcpy(s1,s+1); i=atoi(s1);
              if(thisuser.dsl<i) ok=0;
              break;

    case 'B': strcpy(s1,s+1);
              i=atoi(s1); if(com_speed<i) ok= 0;
              else ok= 1;
              break;

   }          
   return ok;
}

int readmenu(char fn[15])
{
    FILE *menu;
    char s[255];
    int x=0,stillok=1,c;
    sprintf(s,"%s\\%s",nifty.menudir,fn);
    if((menu=fopen(s,"rt"))==NULL) { pl("Menu Not Found!!!"); return 0; }

    maxcmd=0;
    fgets(s,151,menu);
    strcpy(pp.prompt,filter(s));
    fgets(s,81,menu);
    strcpy(pp.title1,filter(s));
    fgets(s,81,menu);
    strcpy(pp.title2,filter(s));
    fgets(s,16,menu);
    strcpy(pp.fallback,filter(s));
    fgets(s,16,menu);
    strcpy(pp.altmenu,filter(s));
    fgets(s,10,menu);
    strcpy(pp.slneed,filter(s));
    if(!slok(pp.slneed,1)) return 0;
    fgets(s,10,menu);
    pp.helplevel=atoi(s);
    fgets(s,10,menu);
    strcpy(pp.pausefile,filter(s));

    strcpy(menuat,fn);

while((x<51) && stillok) {
    if((fgets(s,51,menu))==NULL) stillok=0;
    else {
    fgets(s,5,menu);
    fgets(s,9,menu);
    strcpy(avail[x],filter(s));
    fgets(s,10,menu);
    c=atoi(s);
    if(thisuser.sl>=c); else strcpy(avail[x],"");
    fgetc(menu); fgetc(menu);
    fgets(s,41,menu);
    fgets(s,81,menu);
    x++; maxcmd++;
    }
 }
    if((x<50) && maxcmd<50)
       while(x<51) strcpy(avail[x++],"");
    fclose(menu);
    return 1;
}

void readcmd(int y)
{
    FILE *menu;
    char s[255];
    int x=0,stillok=1;
    sprintf(s,"%s\\%s",nifty.menudir,menuat);
    menu=fopen(s,"rt");
    fgets(s,151,menu);
    fgets(s,81,menu);
    fgets(s,81,menu);
    fgets(s,15,menu);
    fgets(s,15,menu);
    fgets(s,10,menu);
    fgets(s,10,menu);
    fgets(s,10,menu);

while((x<=y) && stillok) {
    if((fgets(s,51,menu))==NULL) stillok=0;
    else {
    strcpy(tg.desc,filter(s));
    fgets(s,5,menu);
    strcpy(tg.type,filter(s));
    fgets(s,9,menu);
    strcpy(tg.key,filter(s));
    strcpy(avail[x],tg.key);
    fgets(s,10,menu);
    strcpy(tg.sl,filter(s));
    tg.at=fgetc(menu); fgetc(menu);
    fgets(s,41,menu);
    strcpy(tg.line,filter(s));
    fgets(s,81,menu);
    strcpy(tg.ms,filter(s));
    x++;
    }
 }
    fclose(menu);
}

int ex(char type[2],char ms[81],char line[81])
{
  int abort,i,i1;
  long l;
  char s[255],s1[81],s2[81];
  pl(line);
  switch(type[0])
    {
    case 'J':
            switch(type[1])
               {
                case 'W': write_automessage1(); break;
                case 'R': read_automessage(); break;
                case 'A': if(status.amsguser)
                          email(status.amsguser,0,0,status.amsganon);
                          break;
              }
              break;
    case 'B': switch(type[1]) {
               case 'R': printfile("BBSLIST"); break;
            }
    case 'A':
            switch(type[1])
               {
                case 'D': download_temp_arc(); break;
                case 'V': list_temp_arc(); break;
                case 'A': add_temp_arc(); break;
                case 'R': del_temp(); break;
                case 'L': list_temp_dir(); break;
                case 'T': list_temp_text(); break;
                case 'E': temp_extract(); break;
            } break;
    case 'D':
        create_chain_file("CHAIN.TXT");
        sprintf(s,"Command.com /C %s %s",ms,"");
        set_protect(0);
        strcpy(status.lastmenu,menuat);
        save_status();
        switch(type[1])
	    {
        case '1':
        run_external(s);
	    break;
        case '2':
        shrink_out(s,1,0,1,1);
        break;
        case '3':
	    full_external(s,0,1);
	    break;
	    case '4':
        shrink_out(s,1,1,1,1);
	    break;
        }
        sprintf(s2,"!Ran Door %s",ms);
        sysoplog(s2);
        topscreen();
        break;
    case 'M':
         switch(type[1])
            {
        case 'P': irt[0]=0; byline[0]=0; reply=0; post(); break;
            case 'E': if(ms[0]) imail(atoi(ms),0); else
                      send_email(); break;
            case 'N': express=0; expressabort=0;
                      if(ms[0]=='G') nscan(0);
                      else if (ms[0]=='C') qscan(cursub,0);
                      else if (!ms[0]) { nl();
                        outstr("7Global Scan? ");
                        if(ny()) nscan(0); else
                        qscan(cursub,0);
                        }
                      break;
            case 'R': remove_post(); break;
            case 'S': express=0; expressabort=0; scan2(); break;
            case 'M': if(thisuser.waiting>0) readmail();
                      else pl("You have no Mail waiting"); break;
            case 'F': find_subject(); break;
            case 'K': kill_old_email(); break;
            case 'L': slash_e(); break;
            case 'U': upload_post(); break;
            case 'Z': express=1; expressabort=0; l=thisuser.sysstatus;
                     if (l & sysstatus_pause_on_page)
                     thisuser.sysstatus ^= sysstatus_pause_on_page;
                     nscan(0); express=0; expressabort=0; thisuser.sysstatus=l;
                     break;
            } break;
    case 'F':
         switch(type[1])
            {
            case 'L': listfiles(); break;
            case 'Y': yourinfodl(); break;
            case 'D': download(); break;
            case 'V': arc_l(); break;
            case 'S': searchall(); break;
            case 'R': removefile(); break;
            case 'P': setldate(); break;
            case 'F': finddescription(); break;
            case 'B': batchdl(); break;
            case '1':  outstr("Upload to All Dirs? ");
                  if(yn()) {
                   i1=0;
                   for (i=0; (i<64) && (udir[i].subnum>=0) && (!i1); i++) {
                     nl();
                     nl();
                     outstr("Now uploading files for: ");
                     pl(directories[udir[i].subnum].name);
                     nl();
                     i1=uploadall(udir[i].subnum);
                   }
                }
                     else
                       uploadall(udir[curdir].subnum); break;
            case '2': rename_file(); break;
            case '3': valfiles(); break;
            case '4': killoff(); break;
            case '5': move_off(); break;
            case '7': move_file(); break;
            case '9': comfiles(); break;
            case '6':
                    nl();
                    prt(2,"Sort all dirs? ");
                    i=yn();
                    nl();
                    prt(2,"Sort by date? ");
                    if (yn())
                      i1=2;
                    else
                      i1=0;
                    if (i)
                      sort_all(i1);
                    else
                      sortdir(udir[curdir].subnum,i1); break;
            case 'Z': upload(atoi(ms)); break;
            case 'U':
              if ((thisuser.restrict & (restrict_validate | restrict_upload)) ||
                      (syscfg.sysconfig & sysconfig_all_sysop)) {
                      if (syscfg.newuploads<num_dirs)
                       upload((int) syscfg.newuploads);
                       else
                       upload(0);
                       } else
                       upload(udir[curdir].subnum);
                       break;
            case 'N':
                        nl();
                        abort=0;
                        if(ms[0]=='G')
                          nscanall();
                        else {
                        prompt("7Global NewScan? ","");
                        if(ny())
                        nscanall();
                        else
                          nscandir(curdir,&abort,0);
                        }
                        break;
            } break;
    case 'S':
          switch(type[1])
          {
            case '~': nl();
                      prt(2,"Filename? ");
                     input(s1,50);
                    if (s1[0]) {
                      nl();
                      prt(5,"Allow editing? ");
                      if (yn()) {
                        nl();
                        load_workspace(s1,0);
                      } else {
                        nl();
                        load_workspace(s1,1);
                      }
                    }
            break;
            case 'B': boardedit(); break;
            case '-': glocolor(); break;
            case 'F': dlboardedit(); break;
            case 'M': mailr(); break;
            case 'H': chuser(); break;
            case 'C': pl(((*(char far *)0x00000417L ^= 0x10) & 0x10) ?
                     "Sysop now unavailable" :
                     "Sysop now available");
                      sysoplog("@ Changed sysop avail status");
                      topscreen();
                      break;
           case 'I': voteprint(); break;
           case 'U': uedit(usernum,0); break;
           case 'V': ivotes(); break;
           case 'Z': zlog(); break;
           case '+': read_new_stuff(); break;
           case 'E': edstring(); break;
           case 'R': reset_files(); break;
           case 'X': protedit(); break;
        } break;
    case 'O':
          switch(type[1])
          {
            case 'G': infoform(ms); break;
            case 'R': pl("Which User's responses do you want to see?");
                      prompt(": ","");
                      input(s,31);
                      if(s[0]) readform(ms,s); break;
            case 'C': reqchat(ms); break;
            case 'U': list_users(); break;
            case 'L': pl(ms); break;
            case 'F': printfile(ms); break;
            case 'B': bbslist(); break;
            case 'I': nl();
                      pl(VERSION_NUMBER);
                      nl();
                      printfile("SYSTEM");
                      break;
           case 'O': if (sysop2())
                     pl(get_string(4));
                     else pl(get_string(5)); break;
           case 'V': vote(); break;
           case 'Y': yourinfo(); break;
           case '|': addsay(); break;
           case 'S': get_say(1); break;
           case 'P':
                 switch(ms[0])
                   {
                   case '1': input_screensize(); break;
                   case '2': input_ansistat(); break;
                   case '3':  if (thisuser.sysstatus & sysstatus_pause_on_page)
                              thisuser.sysstatus ^= sysstatus_pause_on_page;
                              nl();
                              prt(7,"Pause each screenfull? ");
                              if (yn())
                              thisuser.sysstatus |= sysstatus_pause_on_page;
                              break;
                   case '4': modify_mailbox(); break;
                   case '5': config_qscan(); break;
                   case '6': input_pw1(); break;
                   case '7': make_macros(); break;
                   case '8': change_colors(); break;
                   case 'G': change_ecolors(); break;
                   case '9': select_editor(); break;
                   case 'B': optional_lines(); break;
                   case 'F': nl();
                   prompt("Use full line input?","");
                   if(yn()) thisuser.res[0]=1; else thisuser.res[0]=0;
                   break;
                   case 'C':  if (thisuser.sysstatus & sysstatus_clr_scrn)
                              thisuser.sysstatus ^= sysstatus_clr_scrn;
                              nl();
                              prt(7,"Clear Screen Before Each Message? ");
                              if (yn())
                              thisuser.sysstatus |= sysstatus_clr_scrn;
                              break;
                   case 'D': if(thisuser.sysstatus & sysstatus_expert) {
                             pl("Engaging Idiot Mode");
                             thisuser.sysstatus ^= sysstatus_expert; }
                             else { pl("Engaging Expert Mode");
                             thisuser.sysstatus |= sysstatus_expert; }
                             break;
                   case 'E': config_nscan(); break;
                   case 'A': pl("Enter your Default Protocol, 0 for none.");
                             i=get_protocolold(1,1); if(i>=0) thisuser.defprot=i;
                             break;
           }
         } break;
    case 'I':
          switch(type[1])
          {
            case 'H':  hangup=1; break;
            case 'A': nl(); prompt(ms," ",""); if(yn()) { printfile("logoff");

                                           hangup=1; } break;
            case 'C': nl(); prompt(ms," ",""); if(yn()) {
                            prompt("Leave Feedback to SysOp? ","");
                            if(yn()) {
                            strcpy(irt,"LogOff Feedback.");
                            email(1,0,0,0); }
                            printfile("logoff");

                            hangup=1; } break;
          } break;
    case 'T': switch(type[1])
              {
                case 'T': bank2(atoi(ms)); break;
                case 'D': add_time(atoi(ms)); break;
                case 'W': remove_time(); break;
            } break;
    case '=':
         switch(type[1])
           {
             case '/':  nl(); strcpy(lastmenu,menuat);
                              if(!readmenu(ms)) readmenu(pp.fallback);
                              return 0;
             case '\\':  nl(); if(readmenu(lastmenu))
                              readmenu(menuat);
                              return 0;
             case '^':  nl(); if(!readmenu(ms))
                              readmenu(pp.fallback);
                                      return 0;
             case '*':  if(ms[0]=='M') sublist(ms[0],ms[1],ms[2]);
                        else if(ms[0]=='F') dirlist(ms[0],ms[1],ms[2]);
                        break;
             case '+':  if(ms[0]=='M') {
                        if ((cursub<30) && (usub[cursub+1].subnum>=0))
                        ++cursub;
                        else
                        cursub=0; }
                        else if(ms[0]=='F') {
                        if ((curdir<62) && (udir[curdir+1].subnum>=0))
                        ++curdir;
                        else
                        curdir=0; }
                        break;
             case '-': if(ms[0]=='M') {
                          if (cursub>0)
                          --cursub;
                          else {
                          while ((usub[cursub+1].subnum>=0) && (cursub<31))
                          ++cursub;
                          }
                        } else if(ms[0]=='F') {
                        if (curdir>0)
                           --curdir;
                          else {
                          while ((udir[curdir+1].subnum>=0) && (curdir<63))
                          ++curdir;
                 }
              }
              break;
        } break;
    }
return 1;
}



void showmenu(void)
{
  int x=0,abort=0;
  char s[81];
  nl();
  if(printfile(pp.altmenu)!=999) { nl(); return; }
  pl(pp.title1);
  pl(pp.title2);
  for(x=0;x<maxcmd;x++) {
    if(!abort) {
    readcmd(x);
    if(slok(tg.sl,1)) if(tg.at=='H'); else pla(tg.desc,&abort);
    else if(tg.at=='U') pla(tg.desc,&abort);
     }
   }
 nl();
}


void menuman(void)
{
    char cmd,c,*s,x,begx;
    nl();
    tleft(1);
    if(usub[cursub].subnum==-1) cursub=0;
    if(thisuser.sysstatus & sysstatus_expert);
    else showmenu();
    prompt(pp.prompt,"");
    begx=wherex();
    s=mmkey(0);
    if(!thisuser.res[5]) sysopchar(s);
    if(!s[0]) nl();
    if(s[0])
    if((!strcmp(s,"RELOAD"))) readmenu(nifty.firstmenu); else
    if((!strcmp(s,"VER"))) {
        nl();
              pl(VERSION_NUMBER);
              pl("Compiled 12/24/91, Released 12/25/91");
              pl("Standard Release for General Distribution.");
              nl();
        } else
    if((!strcmp(s,"DOMANSI"))) {
        if(thisuser.res[10]) thisuser.res[10]=0; else
        thisuser.res[10]=1; }
        else
    if((!strcmp(s,"CLS"))) outchr(12); else
    if((!strcmp(s,"||")) && (thisuser.sl==255 || thisuser.res[5])) {
        nl();
        prompt("Type: ",""); input(tg.type,2);
        prompt("MS: ",""); input(tg.ms,40);
        ex(tg.type,tg.ms,""); }
        else
    if((!strcmp(s,"HANGUP"))) hangup=1; else
    if(s[0]=='?') showmenu(); else
    for(cmd=0;cmd<maxcmd;cmd++)
      if(!strcmp(avail[cmd],s)) {
        readcmd(cmd);
        c=slok(tg.sl,0);
        if(c)
          if(c==2) pl("Not enough Credits. Please Post to Gain Credits");
          else { while (wherex()>begx) backspace(); outstr(tg.line); nl(); nl();
          if(!ex(tg.type,tg.ms,"")) cmd=51; }
        }
      else
      if(!strcmp(avail[cmd],"#"))
      {
        if(s[0]>=0 && s[0]<=64) {
        readcmd(cmd); if(tg.ms[0]=='M')
         { for(x=0; x<32; x++) if(!strcmp(usub[x].keys,s)) cursub=x; }
            else if(tg.ms[0]=='F')
         { for(x=0; x<64; x++) if(!strcmp(udir[x].keys,s)) curdir=x; } }
      }
}
