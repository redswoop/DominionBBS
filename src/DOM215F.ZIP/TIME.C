#include "vardec.h"
#include "fcns.h"
#include <string.h>
#include <fcntl.h>
#include <sys\stat.h>
#include <io.h>

/* WWIV BANK version 1.2 8/17/88 by Doug Fields
                                    100 Midwood Road
Bug Fix: No negative numbers        Greenwich, CT 06830
allowed now.                        voice: 203-661-2967
                                    Feel free to call. */

/* Copyright 1988 by DOUG FIELDS. No distribition allowed except by me, no modified copies
of this souce code allowed to be distributed. Please read the accompanying documentation
file, WBNKSRC.DOC, for more information. */

typedef struct {
   char         uname[31];                   /* name */
   int          timeinacct;                  /* amount of minutes in account */
   } wwivbankrec;

extern userrec thisuser;
extern configrec syscfg;
extern int hangup;
extern double extratimecall;

wwivbankrec bankee;
int bankeenum;

#define maxminsinacct 90

void find_acct()
{
int bankeefile;
char s[81];

  strcpy(s, syscfg.datadir);
  strcat(s, "WWIVBANK.DAT");
  if ((bankeefile = open(s, (O_RDONLY | O_BINARY))) == -1)
    {
    /* Check for new file. */
    bankeenum = 0;
    nl();
    prt(3, "Making bank data file. Please hold..."); nl();
    bankeefile = open(s, (O_RDWR | O_BINARY | O_CREAT), (S_IREAD | S_IWRITE));
    close(bankeefile);
    prt(3, "Finished."); nl();
    nl();
    bankee.timeinacct = 0;
    strcpy(bankee.uname, thisuser.name);
    return;
    }
  bankeenum = 0;
  do
    {
    /* Find the user. */
    lseek(bankeefile, (bankeenum * sizeof(wwivbankrec)), SEEK_SET);
    read(bankeefile, (void *)&bankee, sizeof(wwivbankrec));
    /* If found, then return. */
    if (strcmp(bankee.uname, thisuser.name)==0)
      {
      close(bankeefile);
      return;
      }
    bankeenum++;
    }
  while (!(eof(bankeefile)));
  /* Not found, make new user. */
  nl();
  prt(5, "You are a new bankee. Creating your account.");
  nl();
  strcpy(bankee.uname, thisuser.name);
  bankee.timeinacct = 0;
  pausescr();
  close(bankeefile);
}

void save_acct()
{
int bankeefile;
char s[81];

  strcpy(s, syscfg.datadir);
  strcat(s, "WWIVBANK.DAT");
  bankeefile = open(s, (O_BINARY | O_WRONLY));
  lseek(bankeefile, (bankeenum * sizeof(wwivbankrec)), SEEK_SET);
  write(bankeefile, (void *)&bankee, sizeof(wwivbankrec));
  close(bankeefile);
}

void add_time()
{
int minutes;
char s[81];

  nl(); nl();
  prt(1, "Deposit time, time left: ");
  print(ctim(nsl()), ".","");
  nl();
  ansic(0);
  print("How many minutes would you like to deposit?","");
  prompt(": ","");
  ansic(4);
  inputl(s,3);
  minutes = atoi(s);
  if (minutes<1) return;

  if (hangup) return;

  if (minutes > (int)((nsl() - 20.0)/60.0))
    {
    nl(); nl();
    prt(3, "You do not have enough time left to deposit that much.");
    nl(); nl();
    pausescr();
    return;
    }
  if ((minutes + bankee.timeinacct) > maxminsinacct)
    {
    nl(); nl();
    sprintf(s, "You may only have up to %d minutes in the account", maxminsinacct);
    print(s,"");
    print("at one time.","");
    nl(); nl();
    pausescr();
    return;
    }
  if (so())
    {
    nl(); nl();
    prt(6, "Sysops not allowed!");
    nl(); nl();
    pausescr();
    return;
    }
  /* Actually remove the time now. */
  bankee.timeinacct += minutes;
  save_acct();
  sprintf(s, "- Deposit %d minutes.", minutes);
  sysoplog(s);
  nl();
  sprintf(s, "%d minute%c deposited.", minutes,
    ((minutes > 1) ? 's' : ''));
  prt(4, s);
  nl();

  if (extratimecall > 0)
    {
    if (extratimecall >= (double)(minutes * 60))
      {
      extratimecall -= (double)(minutes * 60);
      return;
      }
    minutes -= (int)(extratimecall / 60.0);
    extratimecall = 0.0;
    }
  thisuser.extratime -= (float)(minutes * 60);
  pausescr();
}

void remove_time()
{
char s[81];
int minutes;

  nl(); nl();
  sprintf(s, "Withdraw time, time in account: %d minutes.", bankee.timeinacct);
  print(s,"");
  nl();
  ansic(0);
  print("How many minutes would you like to withdraw?","");
  prompt(": ","");
  ansic(4);
  inputl(s,3);
  minutes = atoi(s);
  if (minutes<1) return;

  if (hangup) return;
  if (so())
    {
    nl(); nl();
    prt(6, "Sysops not allowed!!");
    nl(); nl();
    pausescr();
    return;
    }
  if (minutes > bankee.timeinacct)
    {
    nl(); nl();
    prt(6, "You don't have that much time in the account!");
    nl();
    nl();
    pausescr();
    return;
    }
  sprintf(s, "- Withdrew %d minutes.", minutes);
  sysoplog(s);
  thisuser.extratime += (float)(minutes * 60);
  bankee.timeinacct -= minutes;
  save_acct();
  nl(); nl();
  sprintf(s, "%d minute%c withdrawn.", minutes,
    ((minutes > 1) ? 's' : ''));
  prt(4, s);
  nl(); nl();
  pausescr();
}

void wwivbank()
{
int done = 0;
char s[81], ch;

  sysoplog("- Went to the WWIV Bank.");
  find_acct();
  do
    {
    tleft(0);
    prt(0, "\x0c");
    prt(4, "+----------------------------------+"); nl();
    prt(4, "|        WWIV TIME BANK 1.2        |"); nl();
    prt(4, "|          by DOUG FIELDS          |"); nl();
    prt(4, "|                                  |"); nl();
    sprintf(s, "|        Time in account: %-4d     |", bankee.timeinacct);
    prt(4, s); nl();
    prt(4, "|                                  |"); nl();
    prt(4, "| A) Add time to account           |"); nl();
    prt(4, "| R) Remove time from account      |"); nl();
    prt(4, "| Q) Leave the bank                |"); nl();
    prt(4, "| ?) Get help                      |"); nl();
/*    prt(4, "|          ");
    prt(6, "UNREGISTERED");
    prt(4, "            |"); nl();*/
    prt(4, "|                                  |"); nl();
    prt(4, "+----------------------------------+"); nl();
    if (so() && strcmp("DOUG FIELDS",thisuser.name))
      {
      nl();
      print("To register your copy, send the amount of money you believe this program","");
      print("is worth to: Doug Fields","");
      print("             100 Midwood Road, Greenwich, CT 06830-3837","");
      print("             voice: 203-661-2967, feel free to call!","");
      print("Registering will get you the full source code and WWIV tech support.","");
      }
    nl();
    ansic(3);
    print("T - ",ctim(nsl()),"");
    ansic(2);
    prompt("[WWIV Bank] : ", "");
    ch = onek("QAR?");
    switch (ch)
      {
      case 'Q': done = 1;
                break;
      case 'A': add_time();
                break;
      case 'R': remove_time();
                break;
      case '?': printfile("WWIVBANK.MSG");
                pausescr();
                break;
    }
  }
  while ((!hangup) && (!done));
  nl();
  prt(3, "Thank you for banking at the WWIV Bank.");
  nl();
}