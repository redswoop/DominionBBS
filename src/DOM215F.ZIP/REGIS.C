#include <fcntl.h>
#include <sys\stat.h>
#include <stdlib.h>
#include "vardec.h"
#include "doorutl.c"

regrec reg;

void main(void)
{
    int i,i1,i2,i3;
    char s[81],s1[81];

    randomize();
    pl("[2J|4Dominion Registration Utility");
    nl();
    outstr("Name: ");
    gets(s);
    if(s[0]) {
    i=s[0]+s[1];
    i1=random(i);
    i2=i-i1;
    s1[0]=i1;
    s1[1]=i2;
    }
strcpy(reg.name,s);
strcpy(reg.regto,s1);
i=open("regis.dat",O_CREAT|O_WRONLY|S_IREAD|S_IWRITE);
write(i,(void *)&reg,sizeof(regrec));
close(i);
}
