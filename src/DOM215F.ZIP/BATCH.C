#include <stdio.h>
#include <sys\stat.h>
#include <fcntl.h>
#include <time.h>
#include <dos.h>
#include <dir.h>
#include <string.h>
#include <io.h>
#include <alloc.h>
#include <stdlib.h>
#include "fcns.h"

extern userrec thisuser;
extern directoryrec directories[64];
extern int num_dirs,hangup,userfile,echo,useron,userfile,usernum;
extern int incom,fwaiting;
extern configrec syscfg;
extern statusrec status;
extern int edlf,dlf,curdir,numf;
extern usersubrec udir[64];
extern long nscandate;
extern char curspeed[81],cdir[81],dszlog[81];
extern unsigned int modem_speed,com_speed;
extern float batchtime;
extern int numbatch, numbatchdl, num_listed;
extern batchrec batch;
extern double extratimecall;
extern unsigned char realsl;
extern float batchsize;
extern int batchdir;

#define SETREC(i)  lseek(dlf,((long) (i))*((long)sizeof(uploadsrec)),SEEK_SET);

void batrec(int rw, int bnum)               /* mod - add entire void */
{
  int f;
  char s[81];

  sprintf(s,"%sBATREC.DAT",syscfg.datadir);
  f=open(s,O_RDWR | O_CREAT | O_BINARY,S_IREAD | S_IWRITE);
  lseek(f,(bnum)*(long)sizeof(batchrec),SEEK_SET);
  switch (rw) {
  case 0: write(f,(void *)(&batch),sizeof(batchrec));
          break;
  case 1: read(f,(void *)(&batch),sizeof(batchrec));
          break;
  }
  close(f);
}

void verify_hangup(int *had)                /* mod - add entire void */
{
  int abtlog,i,count;
  char s[81],ch;

  nl();
  pl("\x03""3Press [SPACE] to stay on-line.");
  nl();
  prt(1,"Disconnecting in ");
  abtlog=0;
  count=10;
  while ((count>0) && (!abtlog)) {
    itoa(count,s,10);
    strcat(s,".. ");
    prt(1,s);
    ch=inkey();
    switch (ch) {
      case 3:
      case 24:
      case 32:
        abtlog=1;
        break;
    }
    delay(1000);
    --count;
  }
  nl(); nl();
  if (abtlog)
    *had=0;
  else
    sprintf(s,"\x03""5Thanks for calling %s.",syscfg.systemname);
    pl(s);
    delay(3000);
}


void listbatch()                            /* mod - replace entire void */
{
  char s[81];
  int abort,i;

  abort=0;
  nl();
  sprintf(s,"Files - %d  DL Size - %-1.0fk  DL Time - %s",
    numbatch,batchsize,ctim(batchtime));
  pl(s);
  nl();
  for (i=0; (i<numbatch) && (!abort) && (!hangup); i++) {
    batrec(1,i);
    if (batch.sending)
      sprintf(s,"%d. (D) %s  %-1.0fk  %s",i+1,batch.filename,
        batch.size,ctim(batch.time));
    else
      sprintf(s,"%d. (U) %s: %s",i+1,batch.filename,
        batch.batchdesc);
      pla(s,&abort);
  }
}

void delbatch(int i)                        /* mod - replace entire void */
{
  int f,i1;
  char s[81];

  if (i<numbatch) {
    batrec(1,i);
    batchtime -= batch.time;
    batchsize -= batch.size;
    if (batch.sending)
      --numbatchdl;
    --numbatch;
    sprintf(s,"%sBATREC.DAT",syscfg.datadir);
    f=open(s,O_RDWR | O_CREAT | O_BINARY,S_IREAD | S_IWRITE);
    for (i1=i; i1<=numbatch; i1++) {
      lseek(f,(i1+1)*(long)sizeof(batchrec),SEEK_SET);
      read(f,(void *)(&batch),sizeof(batchrec));
      lseek(f,(i1)*(long)sizeof(batchrec),SEEK_SET);
      write(f,(void *)(&batch),sizeof(batchrec));
      /* mod - delete batch[i1]=batch[i1+1]; */
    }
    close(f);
  }
}

void downloaded(char *fn)
{
  int i,i1;
  uploadsrec u;
  char s[81];

  for (i1=0; i1<numbatch; i1++) {
  batrec(1,i1);                                            /* mod - add */
    if ((strcmp(fn,batch.filename)==0) && (batch.sending)) { /* mod - change */
      dliscan1(batch.dir);                                   /* mod - change */
      i=recno((batch.filename));                             /* mod - change */     
      if (i>0) {
        SETREC(i);
        read(dlf,(void *)&u,sizeof(uploadsrec));
        ++thisuser.downloaded;
        thisuser.dk += (int) ((u.numbytes+1023)/1024);
        ++u.numdloads;
        SETREC(i);
        write(dlf,(void *)&u,sizeof(uploadsrec));
        sprintf(s,"Downloaded '%s'",u.filename);
        sysoplog(s);
        sprintf(s,"%s downloaded '%s' on %s",
          nam(&thisuser,usernum), u.filename, date());
        ssm(u.ownerusr,0,s);
      }
      closedl();
      delbatch(i1);

      return;
    }
  }
  sprintf(s,"!!! Couldn't find '%s' in DL batch queue.",fn);
  sysoplog(s);
}

void upload_batch_file()                    /* mod - add entire void v2 */
{
  int f,i;
  uploadsrec u,u1;
  directoryrec d;
  char *ss,s[81];
  long l;

  d=directories[batchdir];
  time(&l);
  u.daten=l;
  strcpy(u.filename,batch.filename);
  strcpy(u.description,batch.batchdesc);
  u.ownerusr=usernum;
  u.ownersys=0;
  u.numdloads=0;
  u.filetype=0;
  u.mask=0;
  u.points=0;
  u.ats[0]=0;
  if (!hangup) {
    ss=NULL;
    modify_extended_description(&ss);
    if (ss) {
      add_extended_description(u.filename,ss);
      u.mask |= mask_extended;
      farfree(ss);
    }
  }
  strcpy(u.upby,nam1(&thisuser,usernum,syscfg.systemnumber));
  strcpy(u.date,date());
  sprintf(s,"%s%s",d.path,u.filename);
  f=open(s,O_RDONLY | O_BINARY);
  u.numbytes=filelength(f);
  close(f);
  for (i=numf; i>=1; i--) {
    SETREC(i);
    read(dlf,(void *)&u1,sizeof(uploadsrec));
    SETREC(i+1);
    write(dlf,(void *)&u1,sizeof(uploadsrec));
  }
  SETREC(1);
  write(dlf,(void *)&u,sizeof(uploadsrec));
  ++numf;
  u1.numbytes=numf;
  u1.daten=l;
  SETREC(0);
  write(dlf,(void *)&u1,sizeof(uploadsrec));
  ++thisuser.uploaded;
  thisuser.uk += (int) ((u.numbytes+1023)/1024);

    /* remove the following line if you do not have my gold for xfers mod */

  ++status.uptoday;
  save_status();
  sprintf(s,"+%s uploaded on %s",u.filename,d.name);
  sysoplog(s);

  closedl();
  i=curdir;
  if (batchdir==0)
    curdir=0;

}

void uploaded(char *fn)                     /* mod - replace entire void v2 */
{
  int i,i1;
  char *ss,s[81];

  dliscan1(batchdir);
  for (i1=0; i1<numbatch; i1++) {
    batrec(1,i1);
    if ((strcmp(fn,batch.filename)==0) && (!batch.sending)) {
      i=recno(batch.filename);
      if (i==-1)
        upload_batch_file();
      closedl();
      delbatch(i1);
      return;
    }
  }
  ansic(2);
  strcpy(batch.filename,fn);
  sprintf(s,"Enter a description for %s -",fn);
  do {
    pl(s);
    outstr(": ");
    inputl(batch.batchdesc,58);
  } while ((!hangup) && (batch.batchdesc[0]==0));
  if (batch.batchdesc[0]==0) {
    strcpy(batch.batchdesc,"[*> User Hung Up <*]");
    sprintf(s,"%s needs a description!",fn);
    ssm(usernum,0,s);
  }
  upload_batch_file();
  closedl();
}


int check_aborted_upload(char *fn)          /* mod - add entire void v2 */
{
  directoryrec d;
  char s[81];

  dliscan1(batchdir);
  if (recno(fn)!=-1) {
    closedl();
    return(1);
  }
  d=directories[batchdir];
  sprintf(s,"%s%s",d.path,fn);
  if (!exist(s)) {
    closedl();
    return(1);
  }
  closedl();
  uploaded(fn);
  return(0);
}


void handle_dszline(char *l)
{
  char *ss;
  int i;
  char s[161];

  /* find the filename */
  ss=strtok(l," \t");
  for (i=0; (i<10) && (ss); i++)
    ss=strtok(NULL," \t");

  if (ss) {
    strcpy(s,stripfn(ss));
    align(s);

    switch(*l) {
      case 'Z':
      case 'X':
      case 'R':
      case 'B':
        /* received a file */
        uploaded(s);
        break;

      case 'z':
      case 'x':
      case 'b':
      case 'S':
      case 'Q':
	/* sent a file */
	downloaded(s);
	break;

      case 'E':
      case 'e':
      case 'L':
      case 'U':
	/* error */
	if(check_aborted_upload(s)) {
	sprintf(s,"Error transferring '%s'",ss);
	sysoplog(s);
	}
        break;
    }
  }
}

int ratio1(long a)                          /* mod - replace entire void v2 */
{
  double r;
  char s[81];

  if ((thisuser.exempt & exempt_ratio) || (syscfg.req_ratio<=0.0001))
    return(1);
  if ((thisuser.dk==0) && (a==0))
    r=99.999;
  else
    r=((float) thisuser.uk) / ((float) (thisuser.dk + a));
  if (r<syscfg.req_ratio) {
    nl();
    sprintf(s,"Your up/download ratio is %-5.3f.  You need a ratio of %-5.3f to download.",
      r,syscfg.req_ratio);
    pl(s);
    return(0);
  }

return 1;
}

void process_dszlog()                       /* mod - replace entire void v2 */
{
  FILE *f;
  char s[140];

  if ((f=fopen(dszlog,"rt"))!=0) {
    while (fgets(s,138,f))
      handle_dszline(s);
    fclose(f);
  }
}

void dszbatchul(int t, int *had)            /* mod - add entire void v2 */
{
  int f,i;
  char s[81],s1[81];
  double ti;
  long l;
  directoryrec d;

  if (!incom) {
    *had=2;
    return;
  }
  dliscan1(batchdir);
  d=directories[batchdir];
  if (numf>=d.maxfiles) {
    nl();
    pl("This directory is currently full.");
    nl();
    closedl();
    *had=2;
    return;
  }
  if (d.mask & mask_no_uploads) {
    nl();
    pl("Uploads are not allowed to this directory.");
    nl();
    closedl();
    *had=2;
    return;
  }
  closedl();
  l=(long)freek1(d.path);
  sprintf(s,"Batch Upload - %ldk free.",l);
  pl(s);
  nl();
  sprintf(s,"Perform batch upload to %s? ",d.name);
  prt(5,s);
  if (!ny()) {
    *had=2;
    return;
  }
  nl();
  sprintf(s,"Batch Upload:  Files - %d",numbatch-numbatchdl);
  pl(s);
  if (numbatch) {
    nl();
    prt(5,"Receive @LST file for upload(s)? ");
    i=yn();
  } else
    i=0;
  if (i) {
    sprintf(s,"%s\\BATCH.LST",cdir);
    f=open(s,O_RDWR | O_BINARY | O_CREAT | O_TRUNC, S_IREAD | S_IWRITE);
    if (f<0)
      pl("Unable to create LST file.");
    else {
      for (i=0; i<numbatch; i++) {
        batrec(1,i);
        if (!batch.sending) {
          write(f,stripfn(batch.filename),strlen(stripfn(batch.filename)));
          write(f,"\r\n",2);
        }
      }
      close(f);
      i=get_protocol(1,0);
      pl("Sending BATCH.LST file..");
      extern_prot(i,s,1);
      unlink(s);
    }
  }
  ti=timer();
  switch (t) {
    case -1: sprintf(s1,"DSZ port %u ha slow rx %s",syscfg.primaryport,d.path);
             break;
    case 0:  sprintf(s1,"DSZ port %u ha slow rz %s",syscfg.primaryport,d.path);
             break;
    case 1:  sprintf(s1,"LYNX r /%u /S /H %s",syscfg.primaryport,d.path);
             break;
    case 2:  sprintf(s1,"MPT P%u L%s R %s",syscfg.primaryport,dszlog,d.path);
             break;
    case 3:  sprintf(s1,"DSZ port %u ha slow rb -g %s",syscfg.primaryport,d.path);
             break;
  }
  _chmod(dszlog,1,0);
  unlink(dszlog);
  outs("\r\n*> Current user: ");
  outs(nam(&thisuser,usernum));
  outs("\r\n\r\n");
  outs(s1);
  outs("\r\n");
  run_external1(s1);
  process_dszlog();
  ti=timer()-ti;
  if (ti<0)
    ti += 24.0*3600.0;
  thisuser.extratime += ti;
}
void dszbatchdl(int t, int *had)
{
int ok,f,i;
  char s[81],s1[81];

  if (!incom) {
    *had=2;
    return;
  }
  if (nsl()<=batchtime) {
    nl();
    pl("Not enough time to D/L batch.");
    *had=2;
    return;
  }
  if (!ratio1(batchsize)) {
     *had=2;
     return;
  }
  sprintf(s,"%s\\BATCH.LST",cdir);
  unlink(s);
  f=open(s,O_RDWR | O_BINARY | O_CREAT | O_TRUNC, S_IREAD | S_IWRITE);
  if (f<0) {
    pl("Unable to create LST file.");
    return;
  }
  for (i=0; i<numbatch; i++) {
    batrec(1,i);
    if (batch.sending) {
      sprintf(s1,"%s%s\r\n",directories[batch.dir].path,stripfn(batch.filename));
      write(f,s1,strlen(s1));
    }
  }
  close(f);
  sprintf(s1,"Batch Download:  Files - %d  Size - %-1.0fk  Time - %s",
    numbatchdl,batchsize,ctim(batchtime));
  pl(s1);
  switch (t) {
    case -1: sprintf(s1,"DSZ port %u ha slow sb @%s",syscfg.primaryport,s);
             break;
    case 0:  sprintf(s1,"DSZ port %u ha slow sz @%s",syscfg.primaryport,s);
             break;
    case 1:  sprintf(s1,"LYNX s /%u /S /H @%s",syscfg.primaryport,s);
             break;
    case 2:  sprintf(s1,"MPT P%u L%s S @%s",syscfg.primaryport,dszlog,s);
             break;
    case 3:  sprintf(s1,"DSZ port %u ha slow sb -g @%s",syscfg.primaryport,s);
             break;
  }
  _chmod(dszlog,1,0);
  unlink(dszlog);
  outs("\r\n*> Current user: ");
  outs(nam(&thisuser,usernum));
  outs("\r\n\r\n");
  outs(s1);
  outs("\r\n");
  run_external1(s1);
  process_dszlog();
}

void bidl(int *had)                         /* mod - add entire void v2 */
{
  char s[141],listfn[81],sx1[21],sx2[21],dl[100];
  int i,i1,f;
  double ti;
  long l;
  unsigned long ouk, odk;
  bimodrec bilist;
  bicfgrec bicfg;
  directoryrec d;

  if (!incom) {
    *had=2;
    return;
  }
  if (nsl()<=batchtime) {
    nl();
    pl("Not enough time for Bimodem D/L.");
    *had=2;
    return;
  }
  if (!ratio1(batchsize)) {
     *had=2;
     return;
  }
  dliscan1(batchdir);
  d=directories[batchdir];
  if (numf>=d.maxfiles) {
    nl();
    pl("This upload directory is currently full.");
    nl();
    closedl();
    *had=2;
    return;
  }
  if (d.mask & mask_no_uploads) {
    nl();
    pl("Uploads are not allowed to this directory.");
    nl();
    closedl();
    *had=2;
    return;
  }
  closedl();
  l=(long)freek1(d.path);
  sprintf(s,"BiModem Transfer - %ldk upload free.",l);
  pl(s);
  sprintf(s,"Perform Bimodem transfer to %s? ",d.name);
  prt(5,s);
  if (!ny()) {
    *had=2;
    return;
  }
  nl();
  sprintf(s,"BiModem Files - %d  DL Size - %-1.0fk  DL Time - %s",
    numbatch,batchsize,ctim(batchtime));
  sysoplog(dl);
  sprintf(listfn,"%s\\BIMODEM.CFG",cdir);
  f=open(listfn,O_RDWR | O_BINARY);
  if (f>0) {
    read(f,(void *) &bicfg, sizeof(bicfgrec));
    for (i1=0;i1<80;i1++)
      bicfg.uppath[i1]=32;
    sprintf(bicfg.uppath,"%-70s",d.path);
    lseek(f,0L,SEEK_SET);
    write(f,(void *) &bicfg, sizeof(bicfgrec));
    close(f);
  }
  sprintf(listfn,"%s\\BIMODEM.PTH",cdir);
  _chmod(listfn,1,0);
  unlink(listfn);
  _chmod(dszlog,1,0);
  unlink(dszlog);
  f=open(listfn,O_RDWR | O_BINARY | O_CREAT | O_TRUNC, S_IREAD | S_IWRITE);
  if (f<0) {
    *had=2;
    pl("Unable to create Bimodem list file.");
    nl();
    return;
  }
  for (i=0; i<numbatch; i++) {
    batrec(1,i);
    bilist.refresh=' ';
    bilist.replace='N';
    bilist.verify='Y';
    bilist.delete='N';
    bilist.unused=' ';
    bilist.fulldir='N';
    bilist.subdir='Y';
    if (batch.sending) {
      bilist.direction='U';
      sprintf(s,"%s%s",directories[batch.dir].path,stripfn(batch.filename));
    } else {
      bilist.direction='D';
      sprintf(s,"%s%s",d.path,stripfn(batch.filename));
    }
    strupr(s);
    strupr(batch.filename);
    for (i1=0;i1<80;i1++) {
      bilist.sourcepath[i1]=32;
      bilist.descr[i1]=32;
      bilist.destpath[i1]=32;
    }
    if (batch.sending) {
      sprintf(bilist.sourcepath,"%-70s",s);
      sprintf(bilist.destpath,"%-70s",stripfn(batch.filename));
    } else {
      sprintf(bilist.sourcepath,"%-70s",stripfn(batch.filename));
      sprintf(bilist.destpath,"%-70s",s);
    }
    write(f,(void *) &bilist, sizeof(bimodrec));
  }
  close(f);
  ultoa(com_speed,sx1,10);
  sx2[0]='0'+syscfg.primaryport;
  sx2[1]=0;
  sprintf(s,"BIMODEM /B%s /CBIMODEM.CFG /L%s /PBIMODEM.PTH",sx1,sx2);
  if (s[0]) {
    ti=timer();
    clrscrb();
    pl("Execute BiModem From Your Computer Now");
    nl();
    outs(dl);
    outs("\r\n");
    outs(s);
    outs("\r\n");
    outs("\r\n*> Current user: ");
    outs(nam(&thisuser,usernum));
    outs("\r\n\r\n");
    run_external1(s);
    ouk=thisuser.uk;
    odk=thisuser.dk;
    process_dszlog();
    ti=timer()-ti;
    if (ti<0)
      ti += 24.0*3600.0;
    odk=thisuser.dk-odk;
    ouk=thisuser.uk-ouk;
    if (odk<=ouk)
      thisuser.extratime += ti;
    else
      thisuser.extratime += ti*(((float) ouk)/((float) odk));
  }
}


void batchdl()                              /* mod - replace entire void v2 */
{
  int i,abort,done,i1,i2,had;
  char s[81],ch,ch1;
  long l;

  done=0;
  do {
    nl();
    strcpy(s,"Batch: L,R,C,");
    if (numbatchdl)
      strcat(s,"D,");
    strcat(s,"U,Z,B,Q,? : ");
    prt(2,s);
    strcpy(s,"Q?CLRUZB");
    if (numbatchdl)
      strcat(s,"D");
    ch=onek(s);
    switch(ch) {
      case '?':
        printmenu(9);
        break;
      case 'Q':
        done=1;
        break;
      case 'L':
        listbatch();
        break;
      case 'R':
        nl();
        if (numbatch==0)
          pl("No files in batch queue.");
        else {
          prt(2,"Remove which? ");
          input(s,2);
          i=atoi(s);
          if ((i>0) && (i<=numbatch))
            delbatch(i-1);
        }
        break;
      case 'C':
        prt(5,"Clear queue? ");
        if (yn()) {
          while (numbatch>0)
            delbatch(0);
          done=1;
          nl();
          pl("Queue cleared.");
        }
        break;
      case 'D':
      case 'U':
      case 'Z':
        nl();
        nl();
        pl("Batch Transfer -");
        nl();
        strcpy(s,"Batch Protocol: Y,Z,L,P,G,Q,? : ");
        prt(2,s);
        do {
          ch1=onek("Q?YZLPGQ");
          switch(ch1) {
             case '?': i2=999;
                       printmenu(19);
                       prt(2,s);
                       break;
             case 'Y': i2=-1;        /* Ymodem batch */
                       break;
             case 'Z': i2=0;         /* Zmodem batch */
                       break;
             case 'L': i2=1;         /* Lynx batch */
                       break;
             case 'P': i2=2;         /* MPt batch */
                       break;
             case 'G': i2=3;         /* Ymodem-G batch */
                       break;
             case 'Q': i2=999;
                       done=1;
                       break;
          }
          if (i2!=999) {
            nl();
            if (numbatch!=0) {
              prt(5,"Hang up after transfer? ");
              had=yn();
            } else
              had=0;
            l=thisuser.sysstatus;
            if (l & sysstatus_pause_on_page)
              thisuser.sysstatus ^= sysstatus_pause_on_page;
            nl();
            batchdir=udir[curdir].subnum;
            if (ch=='D')
              dszbatchdl(i2,&had);
            else {
              if ((ch=='Z') || (syscfg.sysconfig & sysconfig_all_sysop) ||
                (thisuser.restrict & (restrict_validate | restrict_upload)))
                batchdir=0;
              dszbatchul(i2,&had);
            }
            nl();
            if (had==2)
              had=0;
                else {
              sprintf(s,"Your ratio is now %-6.3f",ratio());
              pl(s);
            }
if (had)
              verify_hangup(&had);
            if (had)
              hangup=1;
            done=1;
            thisuser.sysstatus=l;
          }
        } while ((!done) && (!hangup));
        break;
      case 'B':
        nl();
        nl();
        pl("Bimodem Transfer -");
        nl();
        prt(5,"Hang up after transfer? ");
        had=yn();
        nl();
        batchdir=udir[curdir].subnum;
        if ((syscfg.sysconfig & sysconfig_all_sysop) ||
           (thisuser.restrict & (restrict_validate | restrict_upload)))
           batchdir=0;
        if (batchdir) {
          prt(5,"Make uploads private to sysop? ");
          if (yn())
            batchdir=0;
        }
        nl();
        l=thisuser.sysstatus;
        if (l & sysstatus_pause_on_page)
          thisuser.sysstatus ^= sysstatus_pause_on_page;
        bidl(&had);
        nl();
        if (had==2)
          had=0;
else {
          sprintf(s,"Your ratio is now %-6.3f",ratio());
          pl(s);
	}
	 if (had)
          verify_hangup(&had);
        if (had)
          hangup=1;
        done=1;
        thisuser.sysstatus=l;
        break;
    }
    if (useron)
      topscreen();
  } while ((!done) && (!hangup));
}
