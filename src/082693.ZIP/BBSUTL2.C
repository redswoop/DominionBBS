#include "vars.h"
#pragma hdrstop
#include <conio.h>

#define frequency 500

int begxx,begyy;
extern char menuat[15];



int rc;

void prdata(char *str,char *what,int xcoord, int ycoord)
{
    char s[81],i;

    movecsr(xcoord,ycoord);
    sprintf(s,"[%-8s] ",str);
    i=curatr;
    curatr=9;
    outs(s);
    curatr=11;
    sprintf(s,"%-24s",what);
    outs(s);
    curatr=i;
}

void prdata2(char *str,char *what,int xcoord,int ycoord)
{
    char s[81],i;

    movecsr(xcoord,ycoord);
    sprintf(s,"[%-8s] ",str);
    i=curatr;
    curatr=9;
    outs(s);
    curatr=11;
    sprintf(s,"%s",what);
    outs(s);
    curatr=i;

}

void editdata(char *str,int len,int xcoord,int ycoord)
{
    int i;

    movecsr(xcoord+11,ycoord);
    editline(str,len,ALL,&rc,"");
    for(i=strlen(str)-1;i>=0 && str[i]==32;i--);
    str[i+1]=0;
}

int editdig(char *str,int len,int xcoord,int ycoord)
{
    int real;

    movecsr(xcoord+11,ycoord);
    editline(str,len,NUM_ONLY,&rc,"");
    real=atoi(str);
    return(real);
}



int so()
{
    if (checkacs(9))
        return(1);
    else
        return(0);
}

int cs()
{
    slrec ss;

    ss=syscfg.sl[actsl];
    if (so())
        return(1);
    if ((ss.ability & ability_cosysop)||checkacs(8))
        return(1);
    else
        return(0);
}


int lcs()
{
    slrec ss;

    ss=syscfg.sl[actsl];
    if (cs())
        return(1);
    if (ss.ability & ability_limited_cosysop) {
        if (thisuser.sysopsub==255)
            return(1);
        if (thisuser.sysopsub==usub[cursub].subnum)
            return(1);
        else
            return(0);
    } 
    else
        return(0);
}

void makewindow(int x, int y, int xlen, int ylen)
{
    int i,xx,yy,old;
    unsigned char s[81];

    old=curatr;
    if (xlen>80)
        xlen=80;
    if (ylen>(screenbottom+1-topline))
        ylen=(screenbottom+1-topline);
    if ((x+xlen)>80)
        x=80-xlen;
    if ((y+ylen)>screenbottom+1)
        y=screenbottom+1-ylen;

    xx=wherex();
    yy=wherey();
    directvideo=1;
    textcolor(8);
    for (i=1; i<xlen-1; i++)
        s[i]=196;
    s[0]=194;
    s[xlen-1]=194;
    s[xlen]=0;
    movecsr(x,y);
    cprintf(" ");
    cprintf("�");
    cprintf(s);
    cprintf("�");
    cprintf(" ");
    s[0]=193;
    s[xlen-1]=193;
    movecsr(x,y+ylen-1);
    cprintf(" ");
    cprintf("�");
    cprintf(s);
    cprintf("�");
    cprintf(" ");
    movecsr(x+1,y+1);
    for (i=1; i<xlen-1; i++)
        s[i]=32;
    s[0]=179;
    s[xlen-1]=179;
    for (i=1; i<ylen-1; i++) {
        movecsr(x,i+y);
        cprintf(" ");
        cprintf("�");
        cprintf(s);
        cprintf("�");
        cprintf(" ");
    }
    movecsr(xx,yy);
    curatr=old;
}

void editline(char *s, int len, int status, int *returncode, char *ss)
{
    int i,j,k,oldatr,cx,cy,pos,ch,done,insert,i1;

    oldatr=curatr;
    cx=wherex();
    cy=wherey();
    for (i=strlen(s); i<len; i++)
        s[i]=32;
    s[len]=0;
    curatr=31;
    outs(s);
    movecsr(cx,cy);
    done=0;
    pos=0;
    insert=0;
    do {
        ch=getchd();
        if (ch==0) {
            ch=getchd();
            switch (ch) {
            case 59:
                done=1;
                *returncode=DONE;
                break;
            case 71: 
                pos=0; 
                movecsr(cx,cy); 
                break;
            case 79: 
                pos=len; 
                movecsr(cx+pos,cy); 
                break;
            case 77: 
                if (pos<len) {
                    pos++;
                    movecsr(cx+pos,cy);
                }
                break;
            case 75: 
                if (pos>0) {
                    pos--;
                    movecsr(cx+pos,cy);
                }
                break;
            case 72:
            case 15:
                done=1;
                *returncode=PREV;
                break;
            case 80:
                done=1;
                *returncode=NEXT;
                break;
            case 82:
                if (status!=SET) {
                    if (insert)
                        insert=0;
                    else
                        insert=1;
                }
                break;
            case 83:
                if (status!=SET) {
                    for (i=pos; i<len; i++)
                        s[i]=s[i+1];
                    s[len-1]=32;
                    movecsr(cx,cy);
                    outs(s);
                    movecsr(cx+pos,cy);
                }
                break;
            }
        } 
        else {
            if (ch>31) {
                if (status==UPPER_ONLY)
                    ch=toupper(ch);
                if (status==SET) {
                    ch=toupper(ch);
                    if (ch!=' ') {
                        i1=1;
                        for (i=0; i<len; i++)
                            if ((ch==ss[i]) && (i1)) {
                                i1=0;
                                pos=i;
                                movecsr(cx+pos,cy);
                                if (s[pos]==' ')
                                    ch=ss[pos];
                                else
                                    ch=' ';
                            }
                        if (i1)
                            ch=ss[pos];
                    }
                }
                if ((pos<len)&&((status==ALL) || (status==UPPER_ONLY) || (status==SET) ||
                    ((status==NUM_ONLY) && (((ch>='0') && (ch<='9')) || (ch==' '))))) {
                    if (insert) {
                        for (i=len-1; i>pos; i--)
                            s[i]=s[i-1];
                        s[pos++]=ch;
                        movecsr(cx,cy);
                        outs(s);
                        movecsr(cx+pos,cy);
                    } 
                    else {
                        s[pos++]=ch;
                        out1ch(ch);
                    }
                }
            } 
            else {
                ch=ch;
                switch(ch) {
                case 13:
                case 9:
                    done=1;
                    *returncode=NEXT;
                    break;
                case 27:
                    done=1;
                    *returncode=DONE;
                    break;
                case 8:
                    if (pos>0) {
                        if (insert) {
                            for (i=pos-1; i<len; i++)
                                s[i]=s[i+1];
                            s[len-1]=32;
                            pos--;
                            movecsr(cx,cy);
                            outs(s);
                            movecsr(cx+pos,cy);
                        } 
                        else {
                            pos--;
                            movecsr(cx+pos,cy);
                        }
                    }
                    break;
                }
            }
        }
    } 
    while (done==0);
    movecsr(cx,cy);
    curatr=oldatr;
    outs(s);
    movecsr(cx,cy);
}





void reprint()
{
    char xl[81], cl[81], atr[81], cc, ansistr_1[81];
    int ansiptr_1;

    ansiptr_1=ansiptr;
    ansiptr=0;
    ansistr[ansiptr_1]=0;
    strcpy(ansistr_1,ansistr);

    savel(cl, atr, xl, &cc);
    nl();
    restorel(cl, atr, xl, &cc);

    strcpy(ansistr,ansistr_1);
    ansiptr=ansiptr_1;
}


void setbeep(int i)
{
    int i1,i2;

    if (i) {
        i1 = 0x34DD / frequency;
        i2 = inportb(0x61);
        if (!(i2 & 0x03)) {
            outportb(0x61, i2 | 0x03);
            outportb(0x43, 0xB6);
        }
        outportb(0x42, i1 & 0x0F);
        outportb(0x42, i1 >> 4);
    } 
    else
        outportb(0x61, inportb(0x61) & 0xFC);
}



void pr_wait(int i1)
{
    int i;

    if(i1) {
        outstr(get_string(24)); 
        begxx=wherex(); 
        begyy=wherey();
    }
    else {
        for(i=0;i<strlenc(get_string(24));i++) backspace();
    }
}

void set_autoval(int n)
{
    valrec v;

    v=syscfg.autoval[n];

    thisuser.sl=v.sl;
    thisuser.dsl=v.dsl;
    thisuser.ar=v.ar;
    thisuser.dar=v.dar;
    thisuser.restrict=v.restrict;
    reset_act_sl();
    changedsl();
}

extern int rc;

void val_cur_user(int wait)
{
    char sl[4],dsl[4],ar[17],dar[17],restrict[17],ex[17],delff[3];
    char dk[34],uk[34],ndl[33],nul[33],fpts[34],psts[5],lgns[5],timebank[5];
    int cp,i,done;
    char nsave[41];


    char exempt_str[]="RTUP";

    strcpy(nsave,thisuser.name);

    if(wait) pr_wait(1);
    thisuser.sl=actsl;
    savescreen(&screensave);
    curatr=11;
    ansic(3);
    makewindow(0,0,75,14);
    itoa((int)thisuser.sl,sl,10);
    itoa((int)thisuser.dsl,dsl,10);
    itoa((int)thisuser.dk,dk,10);
    itoa((int)thisuser.uk,uk,10);
    itoa((int)thisuser.downloaded,ndl,10);
    itoa((int)thisuser.uploaded,nul,10);
    itoa((int)thisuser.fpts,fpts,10);
    itoa((int)thisuser.msgpost,psts,10);
    itoa((int)thisuser.logons,lgns,10);
    itoa((int)thisuser.timebank,timebank,10);
    strcpy(ex,"");

    for (i=0; i<=15; i++) {
        if (thisuser.ar & (1 << i))
            ar[i]='A'+i;
        else
            ar[i]=32;
        if (thisuser.dar & (1 << i))
            dar[i]='A'+i;
        else
            dar[i]=32;
        if (thisuser.exempt & (1 << i))
            ex[i]=exempt_str[i];
        else
            ex[i]=32;
        if (thisuser.restrict & (1 << i))
            restrict[i]=restrict_string[i];
        else
            restrict[i]=32;
    }
    delff[0]=0;
    delff[1]=0;
    delff[2]=0;
    if(thisuser.inact & inact_deleted) delff[0]='D';
    if(thisuser.inact & inact_lockedout) delff[0]='L';
    dar[16]=0;
    ar[16]=0;
    restrict[16]=0;
    ex[5]=0;
    cp=1;
    done=0;

    prdata("Handle",thisuser.name,3,1);
    prdata("RealName",thisuser.realname,40,1);
    prdata("SL",sl,3,2);
    prdata("DSL",dsl,40,2);
    prdata("AR's",ar,3,3);
    prdata("DAR's",dar,40,3);
    prdata("Exempt",ex,3,4);
    prdata("Restrict",restrict,40,4);
    prdata("# Uled",nul,3,5);
    prdata("# Dled",ndl,40,5);
    prdata("Uled K",uk,3,6);
    prdata("Dled K",dk,40,6);
    prdata("Logons",lgns,3,7);
    prdata("Posts",psts,40,7);
    prdata("Fpts",fpts,3,8);
    prdata("TimeBank",timebank,40,8);
    prdata("Deletion",delff,3,9);

    prdata2("Comment",thisuser.comment,3,11);
    prdata2("Note",thisuser.note,3,12);

    while (done==0) {
        switch(cp) {
        case 1: 
            editdata(thisuser.name,25,3,1);
            strupr(thisuser.name);
            break;
        case 2: 
            editdata(thisuser.realname,25,40,1);
            break;
        case 3: 
            thisuser.sl=editdig(sl,3,3,2);  
            actsl=thisuser.sl; 
            break;
        case 4: 
            thisuser.dsl=editdig(dsl,3,40,2);           
            break;
        case 5: 
            movecsr(3+11,3);
            editline(ar,16,SET,&rc,"ABCDEFGHIJKLMNOP");
            thisuser.ar=0;
            for (i=0; i<=15; i++)
                if (ar[i]!=' ') thisuser.ar |= (1 << i);
            break;
        case 6: 
            movecsr(40+11,3);
            editline(dar,16,SET,&rc,"ABCDEFGHIJKLMNOP");
            thisuser.dar=0;
            for (i=0; i<=15; i++)
                if (dar[i]!=' ') thisuser.dar |= (1 << i);
            break;
        case 7: 
            movecsr(3+11,4);
            editline(ex,4,SET,&rc,exempt_str);
            thisuser.exempt=0;
            for (i=0; i<=4; i++)
                if (ex[i]!=' ') thisuser.exempt |= (1 << i);
            break;
        case 8: 
            movecsr(40+11,4);
            editline(restrict,16,SET,&rc,restrict_string);
            thisuser.restrict=0;
            for (i=0; i<=15; i++)
                if (restrict[i]!=' ') thisuser.restrict |= (1 << i);
            break;
        case 17: 
            movecsr(3+11,9);
            editline(delff,2,SET,&rc,"DL");
            thisuser.inact=0;
            if(delff[0]!=' ') thisuser.inact |= inact_deleted;
            if(delff[1]!=' ') thisuser.inact |= inact_lockedout;
            break;
        case 9: 
            thisuser.uploaded=editdig(nul,5,3,5);        
            break;
        case 10: 
            thisuser.downloaded=editdig(ndl,5,40,5);     
            break;
        case 11: 
            thisuser.uk=editdig(uk,5,3,6);               
            break;
        case 12: 
            thisuser.dk=editdig(dk,5,40,6);             
            break;
        case 13: 
            thisuser.logons=editdig(lgns,5,3,7);        
            break;
        case 14: 
            thisuser.msgpost=editdig(psts,5,40,7);      
            break;
        case 15: 
            thisuser.fpts=editdig(fpts,5,3,8);          
            break;
        case 16: 
            thisuser.timebank=editdig(timebank,3,40,8); 
            break;
        case 18: 
            editdata(thisuser.comment,40,3,11);         
            break;
        case 19: 
            editdata(thisuser.note,40,3,12);            
            break;
        }
        switch(rc) {
        case DONE: 
            done=1; 
            break;
        case NEXT: 
            if (cp<20) cp++; 
            else cp=1; 
            break;
        case PREV: 
            if (cp>1) cp--; 
            else cp=19; 
            break;

        }
    }
    restorescreen(&screensave);
    changedsl();
    if(strcmp(nsave,thisuser.name))
        reset_files(0);

    if(wait) pr_wait(0);
}

void bbsCRC(void)
{
    int i,i1=0;

    for(i=0;i<strlen(wwiv_version);i++)
        i1+=wwiv_version[i];

    if(i1!=CRCVal) {
        clrscr();
        textattr(128+12);
        cprintf("\n\nExecutable Integrity has been compromised. %d\r\n",i1);
        textattr(15);
        cprintf("Please Report this to the Innocents as soon as possible.\n");
        exit(0);
    }
}
