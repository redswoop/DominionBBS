#include "vars.h"
#pragma hdrstop

void create_nuv(char *fn)
{
    char s[81];
    FILE *nuvfile;

    sprintf(s,"%s%s",syscfg.datadir,fn);
    nuvfile = fopen(s,"rb");

    if (nuvfile <= 0) {
        nuvfile = fopen(s,"wb");
        fclose(nuvfile);
    }
    else
        fclose(nuvfile);
}

int num_nuv(char *fn)
{
    char s[81];
    FILE *nuvfile;
    nuvdata nnu;
    int nn;

    nn = 0;
    sprintf(s,"%s%s",syscfg.datadir,fn);
    create_nuv(fn);
    nuvfile = fopen(s,"rb");

    while (!feof(nuvfile)) {
        fread(&nnu,sizeof(nuvdata),1,nuvfile);
        if (!feof(nuvfile)) nn++;
    }

    fclose(nuvfile);

    return nn;
}

void read_nuv(unsigned int user, char *fn, nuvdata *newuser)
{
    FILE *nuvfile;
    long pos;
    nuvdata rn;
    char s[81];

    pos = ( (long) (sizeof(nuvdata) * (user-1)) );
    sprintf(s,"%s%s",syscfg.datadir,fn);
    nuvfile = fopen(s,"rb");
    fseek(nuvfile,pos,SEEK_SET);

    fread(&rn,sizeof(nuvdata),1,nuvfile);

    fclose(nuvfile);

    *newuser = rn;
}

void write_nuv(unsigned int user, char *fn, nuvdata *newuser)
{
    FILE *nuvfile;
    long pos;
    nuvdata wn;
    char s[81];

    wn = *newuser;
    pos = ( (long) (sizeof(nuvdata) * (user-1)) );

    sprintf(s,"%s%s",syscfg.datadir,fn);
    if (user <= num_nuv(fn)) {
        nuvfile = fopen(s,"rb+");
        fseek(nuvfile,pos,SEEK_SET);
    } 
    else {
        nuvfile = fopen(s,"ab+");
    }

    fwrite(&wn,sizeof(nuvdata),1,nuvfile);

    fclose(nuvfile);
}

void upd_nuv()
{
    FILE *nuvfile, *bakfile;
    char s[81],upn;

    sprintf(s,"%sNUV.DAT",syscfg.datadir);
    nuvfile = fopen(s,"wb");

    create_nuv("NUV.BAK");
    sprintf(s,"%sNUV.BAK",syscfg.datadir);
    bakfile = fopen(s,"rb");

    while (!feof(bakfile))
    {
        upn = fgetc(bakfile);
        if (!feof(bakfile)) fputc(upn,nuvfile);
    }

    fclose(nuvfile);
    fclose(bakfile);

    sprintf(s,"%sNUV.BAK",syscfg.datadir);
    if (remove(s) != 0) pl("Unable to Delete File NUV.BAK");
}

void del_nuv(unsigned int user)
{
    FILE *nuvfile, *bakfile;
    char s[81];
    nuvdata dn;
    int dnc,nnu;

    nnu = num_nuv("NUV.DAT");

    for (dnc = 1; dnc <= nnu; dnc++) {
        if (dnc != user) {
            read_nuv(dnc,"NUV.DAT",&dn);
            write_nuv(dnc,"NUV.BAK",&dn);
        }
    }
    upd_nuv();
}

int nuv_num(char *fn, unsigned int user)
{
    int nnu,nnc,nnr;
    nuvdata nnam;

    nnr = 0;
    nnu = num_nuv(fn);

    for (nnc = 1; nnc <= nnu; nnc++) {
        read_nuv(nnc,fn,&nnam);
        if (nnam.num == user) {
            nnr = nnc;
            nnc = nnu + 1;
        }
    }
    return(nnr);
}

int enter_nuv(userrec tu,int un)
{
    char s[81];
    int i;
    nuvdata nu;

    nu.num = un;
    nu.age = tu.age;
    strcpy(nu.name,tu.name);
    strcpy(nu.firston,tu.firston);

    nu.vote_total = 0;
    nu.vote_no = 0;
    nu.vcmt_num = -1;
    strcpy(nu.snote,"");

    if(tu.res[26]) {
        pl("Already in NUV");
        return tu.res[26];
    }

    for (i = 1; i <= nifty.nuvtotal; i++) {
        strcpy(nu.vote_comment[i].name,"");
        nu.vote_comment[i].vote = 0;
        nu.vote_comment[i].counts = 0;
        nu.vote_comment[i].sl = 0;
        strcpy(nu.vote_comment[i].say,"");
    }

    i=num_nuv("NUV.DAT")+1;
    write_nuv(num_nuv("NUV.DAT")+1,"NUV.DAT",&nu);
    if(incom) {
        ex("OG",nifty.nuvinf);
        printfile("nuvmsg");
    }
    logtypes(2,"%s added to NUV",nam(&tu,un));
    return i;
}


int avoted(unsigned int user)
{
    nuvdata av;
    int avr,avc;
    char s[81];

    avr = -1;

    read_nuv(user,"NUV.DAT",&av);

    for (avc=0; avc <= av.vcmt_num; avc++)
        if (!strcmp(av.vote_comment[avc].name,nam(&thisuser,usernum)))
            avr = 1;
    return(avr);
}

void prn_afv(nuvdata pa)
{
    char s[151];
    int aftvc;
    char at1[31],us[31];
    userrec u;

    read_user(pa.num,&u);
    outchr(12);
    pl("0Vote Results:");
    npr("Name: %s, Number Of Votes: %d\r\n",nam(&u,pa.num),pa.vote_total);
    nl();
    for (aftvc = 0; aftvc <= pa.vcmt_num; aftvc=aftvc+1) {
        if ( (strlen(pa.vote_comment[aftvc].say) > 0) ||
            (pa.vote_comment[aftvc].counts > 1) ) {
            npr("5%-33s 0Vote: %s \r\n",pa.vote_comment[aftvc].name,pa.vote_comment[aftvc].vote?"Yay":"Nay");
            npr("2Comment: 0%s\r\n",pa.vote_comment[aftvc].say);
        }
    }
}

char *cmnt_nuv()
{
    char s[101];

    npr("3Enter Your Comment On This New User\r\n5: ");
    mpl(41);
    inputl(s,41);
    return(s);
}

void vote_nuv(unsigned int user, nuvdata *resn)
{
    nuvdata vn;
    char s[81];
    int vmax,vv,vc,cnt;
    userrec u;

    read_nuv(user,"NUV.DAT",&vn);


    npr("5See Infoform? ");
    if(ny()) {
        read_user(vn.num,&u);
        readform(nifty.nuvinf,u.name);
    }

    npr("5Vote Yay or Nay? ");
    vv=ny();

    if(so()) {
        nl();
        pl("0SysOp's Note");
        sprintf(s,"5%s",vn.snote); 
        pl(s);
        prt(5,"Change SysOp's Note? ");
        if (yn()) {
            inputl(vn.snote,65);
            nl();
        } 
        else nl();
    }

    vn.vote_total++;

    if(!vv)
        vn.vote_no++;

    vn.vcmt_num++;
    strcpy(vn.vote_comment[vn.vcmt_num].name,nam(&thisuser,usernum));
    vn.vote_comment[vn.vcmt_num].vote = vv;
    vn.vote_comment[vn.vcmt_num].counts = vc;
    vn.vote_comment[vn.vcmt_num].sl = thisuser.sl;
    strcpy(vn.vote_comment[vn.vcmt_num].say,"");

    nl();
    prt(5,"Would You Like To Comment On This New User? ");
    if (yn()) strcpy(vn.vote_comment[vn.vcmt_num].say,cmnt_nuv());

    write_nuv(user,"NUV.DAT",&vn);
    *resn = vn;
}

void val_nuv(unsigned int user)
{
    int i,i1;
    nuvdata valn;
    userrec u;
    int work;


    read_nuv(user,"NUV.DAT",&valn);
    del_nuv(user);
    i1 = valn.num;
    read_user(i1,&u);
    if (valn.vote_no >= nifty.nuvbad) {
        pl("7Deleting User");
        deluser(i1);
        logtypes(3,"NUV Deleted %s",nam(&u,i1));
        nl();
    } 
    else {
        pl("7Validating User");
        u.sl=syscfg.autoval[nifty.nuvlevel-1].sl;
        u.dsl=syscfg.autoval[nifty.nuvlevel-1].dsl;
        u.ar=syscfg.autoval[nifty.nuvlevel-1].ar;
        u.dar=syscfg.autoval[nifty.nuvlevel-1].dar;
        u.restrict=syscfg.autoval[nifty.nuvlevel-1].restrict;
        logtypes(3,"NUV Validated %s",nam(&u,i1));
        u.res[26]=0;
        write_user(i1,&u);
    }
}

void nuv(void)
{
    nuvdata newuser;
    userrec u;
    char s[81];
    int i,cnt,done=0,sh=0;

    strcpy(s,nifty.nuvsl);
    if (slok(s,0)) {
        i = 1; 
        cnt = num_nuv("NUV.DAT");
        if (cnt > 0) {
            do {
                outchr(12);
                npr("5Number of New Users: 2%d",cnt);
                nl();
                nl();
                npr(get_string(57));
                s[0]=onek("?LVQ!\r");
                switch(s[0]) {
                case '!': 
                    if(!so()) break;
                    nl();
                    inputdat("Remove Which? ",s,3,0);
                    if(!s[0]) break;
                    del_nuv(atoi(s));
                    cnt = num_nuv("NUV.DAT");
                    break;
                case '?': 
                    printmenu(31);
                    pausescr();
                    break;
                case 'L':
                    nl();
                    for(i=1;i<=cnt;i++) {
                        read_nuv(i,"NUV.DAT",&newuser);
                        read_user(newuser.num,&u);
                        npr("1<1%d1> 0%-35s 3[3%.3s3] 5[5%s5]\r\n",i,nam(&u,newuser.num),u.phone,u.comment);
                    }
                    nl();
                    pausescr();
                    break;
                case '\r':
                case 'Q':
                    done=1;
                    break;
                case 'V':
                    i=1;
                    sh=0;
                    while (i <= cnt && !hangup) {
                        read_nuv(i,"NUV.DAT",&newuser);
                        nl();
                        if (avoted(i) < 0) {
                            sh=1;
                            prn_afv(newuser);
                            nl();
                            npr("5Vote On This New User? (Y/N/Q) : ");
                            switch(onek("YNQ")) {
                            case 'Y' : 
                                vote_nuv(i,&newuser);
                                if (newuser.vote_total >= nifty.nuvtotal || newuser.vote_no >= nifty.nuvbad) {
                                    val_nuv(i);
                                    i--;
                                    cnt--;
                                }
                                break;
                            case 'Q' : 
                                i = cnt+1;
                                break;

                            }
                        } 
                        i++;
                    }
                    if(!sh) {
                        pl("Sorry, but you have already voted on all the users");
                        pausescr();
                    }
                }
            } 
            while(!done&&!hangup);
        } 
        else {
            nl();
            pl(get_string(58));
            nl();
        }
    } 
    else {
        nl();
        pl(get_string(59));
        nl();
    }
}
