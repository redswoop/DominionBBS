#include "vars.h"
#pragma hdrstop
extern char menuat[15];
#include <stdarg.h>

#ifdef PD

char menutitles[4][20],ml[4][20];
int curitem=0,curtitle=0,numtitles=0,numitems[4],usepldns=0;
extern mmrec pp;
extern menurec tg[50];
extern char maxcmd;

void popup(void);
int usepop;
#endif


void logtypes(char type,char *fmt, ...)
{
    va_list ap;
    char s[512],s1[81];

    va_start(ap, fmt);
    vsprintf(s, fmt, ap);
    va_end(ap);

    switch(type) {
    case 0: 
        strcpy(s1,"7�7>"); 
        break;
    case 1: 
        strcpy(s1,"5�5�"); 
        break;
    case 2: 
        strcpy(s1,"1�1>"); 
        break;
    case 3: 
        strcpy(s1,"2�2�"); 
        break;
    case 4: 
        strcpy(s1,"3�3>"); 
        break;
    case 5: 
        strcpy(s1,"9#9#9#"); 
        break;
    }

    strcat(s1,"0 ");
    strcat(s1,s);
    if(type==5) sl1(0,s1);
    else
        sysoplog(s1);
}



void badcommand(char onf,char tw)
{
    char s[81];

    nl();
    sprintf(s,"2�2� 0Invalid Command Type %c%c",onf,tw);
    sysoplog(s);
    pl(s);
    nl();
}


void matrixcmd(char type)
{
       switch(type) {
                      case 'C': checkmatrixpw(); break;
                      case 'L': getmatrixpw(); break;
                      case 'N': nl();
                                npr("5Logon as New? ");
                                if(yn())
                                    newuser();
                                break;
                     default: badcommand('W',type);
            }
}

void amsgcommand(char type)
{
    switch(type) {
    case 'W': 
        write_automessage(); 
        break;
    case 'R': 
        read_automessage();
#ifdef PD
        if(usepldns) pausescr();
#endif
        break;
    case 'A': 
        if(status.amsguser)
            email(status.amsguser,0,0,status.amsganon);
        break;
    default: 
        badcommand('J',type);
    }
}



void hangupcmd(char type,char ms[40])
{
    if(numbatchdl) {
        outstr(get_string(78));
        if(!yn()) return;
    }
    switch(type) {
    case 'H': 
        hangup=1; 
        break;
    case 'A':
    case 'L':
    case 'C': 
        nl();
        outstr(ms);
        if(yn()) {
            if(type=='C'||type=='L') {
                outstr("5Leave Feedback to SysOp? ");
                if(yn()) {
                    strcpy(irt,"LogOff Feedback.");
                    nmail(1,0);
                }
                nl();
                if(type=='L') {
                    outstr("5Leave Message to Next User? ");
                    if(yn()) {
                        amsgcommand('W');
                    }
                }
            }
            printfile("logoff");
            hangup=1;
        }
        break;
    default: 
        badcommand('I',type);
    }
}

void sysopcmd(char type,char ms[41])
{
    switch(type)
    {
    case 'B': 
        logtypes(3,"Edited Message Areas");
        boardedit(); 
        break;
    case '-': 
        glocolor(); 
        break;
    case 'P': 
        logtypes(3,"Edited Configuration");
        config(); 
        break;
    case 'F': 
        logtypes(3,"Edited Directories");
        diredit(); 
        break;
    case 'M': 
        logtypes(3,"Read All Mail");
        mailr(); 
        break;
    case 'H': 
        logtypes(3,"Changed Users");
        chuser(); 
        break;
    case 'C': 
        pl(((*(char far *)0x00000417L ^= 0x10) & 0x10) ?
        "Sysop now unavailable" : "Sysop now available");
        logtypes(3,"Changed Chat Availability");
        topscreen();
        break;
    case 'I':
//        voteprint();
        break;
    case 'U': 
        logtypes(3,"Edited Users");
        uedit(usernum); 
        break;
    case 'V': 
        logtypes(3,"Editing Voting");
        //                     ivotes(); 
        break;
    case 'Z': 
        zlog(); 
        break;
    case 'E': 
        logtypes(3,"Edited Strings");
        if(ms[0]) edstring(atoi(ms));
        else edstring(0); 
        break;
    case 'R': 
        reset_files(1); 
        break;
    case 'X': 
        logtypes(3,"Edited Protocols");
        protedit(); 
        break;
    case 'L': 
        logtypes(3,"Edited Conferences");
        confedit(); 
        break;
    case 'O': 
        viewlog(); 
        break;
    case '#': 
        logtypes(3,"Edited Menus");
        if(ms[0]=='!') menued(menuat);
        else menu("");
        break;
    default: 
        badcommand('S',type);
    }
}

#ifdef PD

char *retfrompldn;
#define myxy(x,y) npr("[%d;%dH",x,y)

int pmmkey(char *s)
{
    static unsigned char cmd1[10],cmd2[81],ch;
    int i,i1,i2,p;

    do {
        do {
            ch=getkey();
            if(ch==';') ch=0;
        } 
        while ((((ch<27) && (ch!=13)) || (ch>126)) && (hangup==0));
        if(ch=='2') return -2;
        else if(ch=='8') return -1;
        else if(ch=='4') return -4;
        else if(ch=='6') return -3;
        else if(ch==27) {
            ch=getkey();
            ch=getkey();
            switch(ch) {
            case 'A': 
                return -1;
            case 'B': 
                return -2;
            case 'C': 
                return -3;
            case 'D': 
                return -4;
            case 'H': 
                return -5;
            case 'K': 
                return -6;
            default: 
                return 0;
            }
        }
        ch=toupper(ch);
        outchr(ch);
        if (ch==13)
            cmd1[0]=0;
        else
            cmd1[0]=ch;
        cmd1[1]=0;
        p=0;
        if (p) {
            do {
                ch=getkey();
            } 
            while ((((ch<' ') && (ch!=13) && (ch!=8)) || (ch>126)) && (hangup==0));
            ch=toupper(ch);
            if (ch==13) {
                strcpy(s,cmd1);
                return(0);
            } 
            else
                if (ch==8) {
                backspace();
            } 
            else {
                cmd1[1]=ch;
                cmd1[2]=0;
                outchr(ch);
                if (ch=='/') {
                    outstr("\b\b  \b\b");
                    input(cmd2,50);
                    strcpy(s,cmd2);
                    return 0;
                }
                strcpy(s,cmd1);
                return(0);
            }
        } 
        else {
            strcpy(s,cmd1);
            return 0;
        }
    } 
    while (hangup==0);

    cmd1[0]=0;
    strcpy(s,cmd1);
    return 0;
}


void readmenup()
{
    int i=0;
    int comn=0,done;


    numtitles=0;
    for(i=0;i<5;i++) numitems[i]=0;
    curitem=0;
    curtitle=0;

    i=0;
    strcpy(menutitles[i++],tg[0].desc);

    do {
        if(!(tg[i].attr & command_pulldown)&&!(tg[i].attr & command_title)&&!(tg[i].attr & command_hidden)&&comn<20) {
            ml[numtitles][comn++]=i;
        } 
        else if(!(tg[i].attr & command_hidden)&&numtitles<4) {
            numitems[numtitles]=comn;
            comn=0;
            numtitles++;
            strcpy(menutitles[numtitles],tg[i].desc);
        }
    } 
    while(i++<maxcmd);

    numitems[numtitles]=comn-1;
    numtitles++;
}

void btop()
{
    int i;

    outchr(218);
    for(i=0;i<20;i++) outchr(196);
    outchr(191);
}

void bbottom()
{
    int i;

    outchr('�');
    for(i=0;i<20;i++) outchr(205);
    outchr('�');
}

void bar(int where)
{
    int i;

    myxy(where,1);
    outstr("[K�[79C�");
}

void drawheader(void)
{
    int i;

    bar(1);
    myxy(1,2);
    for(i=0;i<numtitles;i++) {
        if(i==curtitle) npr(""); 
        else npr("");
        npr("%-19.19s�",menutitles[i]);
    }
    ansic(0);
}


void pldn(void)
{
    int done=0,draw=4,lastnum=0;
    int i,ch,x,y,r;
    char s[81];

    do {
        if(draw==1||draw==4) {
            if(draw==4)
                outchr(12);
            drawheader();
            myxy(2,1);
            if(draw!=4)
                for(i=0;i<lastnum+2;i++)
                    pl("[K");
            y=20*curtitle;
            if(curtitle==3) y--;
            myxy(2,y);
            ansic(11);
            btop();
            x=3;
            for(i=0;i<numitems[curtitle];i++) {
                myxy(x,y);
                if(i==curitem)
                    npr("1�_%-20.20s1�",tg[ml[curtitle][i]].desc);
                else
                    npr("1�0%-20.20s1�",tg[ml[curtitle][i]].desc);
                x++;
            }
            myxy(x,y);
            bbottom();
            if(draw==4) {
                bar(22);
                myxy(21,0);
                ansic(0);
                outstr(pp.prompt2);
                draw=0;
            }
        }
        if(draw==2||draw==3) {
            if(draw==2) i=-1; 
            else i=1;
            x=3+curitem;
            y=20*curtitle;
            y++;
            if(curtitle==0) y=2;
            if(curtitle==3) y--;
            myxy(x+i,y);
            npr("0%-20.20s",tg[ml[curtitle][curitem+i]].desc);
            myxy(x,y);
            npr("_%-20.20s",tg[ml[curtitle][curitem]].desc);
            myxy(22,2);
            npr("%-40s",noc2(tg[ml[curtitle][curitem]].line));
        }
        r=pmmkey(retfrompldn);
        if(r<0) {
            switch(r) {
            case -2: 
                if(curitem<numitems[curtitle]-1) {
                    curitem++;
                    draw=2;
                }
                break;
            case -1: 
                if(curitem>0) {
                    curitem--;
                    draw=3;
                }
                break;
            case -4: 
                if(curtitle>0) {
                    lastnum=numitems[curtitle];
                    curtitle--;
                    curitem=0;
                    draw=1;
                }
                break;
            case -3: 
                if(curtitle<numtitles-1) {
                    lastnum=numitems[curtitle];
                    curtitle++;
                    curitem=0;
                    draw=1;
                }
                break;
            }
        } 
        else {
            if(!retfrompldn[0]) {
                npr("[24;1H");
                nl();
                strcpy(retfrompldn,tg[ml[curtitle][curitem]].key);
                ansic(0);
                return;
            } 
            else if(retfrompldn[0]=='~') {
                usepldns=0;
                strcpy(retfrompldn,"");
                done=1;
            } 
            else {
                npr("[24;1H");
                nl();
                ansic(0);
                return;
            }
        }
    } 
    while(!done&&!hangup);
    ansic(0);
    return;
}


#endif

void configpldn(int config)
{
#ifdef PD
    if(config==1) {
        nl();
        npr("5Do you want Pulldowns automatically when you logon? ");
        if(yn())
            thisuser.sysstatus |= sysstatus_clr_scrn;
        else
            thisuser.sysstatus ^= sysstatus_clr_scrn;
        return;
    }

    if(config==2||config==3) {
        if(thisuser.sysstatus & sysstatus_clr_scrn) {
            if(!incom) {
                topdata=0;
                topscreen();
            }
            usepldns=1;
            return;
        }
        if(config==3) return;
    }

    if(okansi()) {
        printfile("PullDown");
        nl();
        outstr(get_string(31));
        usepldns=yn();
    }
#endif
}


#ifdef PD
void makerembox(int x,int y,int xlen,int ylen);

void makerembox(int x,int y,int xlen,int ylen)
{
    int i,xx,yy,old;
    unsigned char s[81];

    for (i=1; i<xlen-1; i++)
        s[i]=196;
    s[0]=194;
    s[xlen-1]=194;
    s[xlen]=0;

    npr("[%d;%dH�%s�",y,x,s);

    s[0]=193;
    s[xlen-1]=193;

    npr("[%d;%dH�%s�",y+ylen-1,x,s);

    npr("[%d;%dH",y+1,x+1);
    for (i=1; i<xlen-1; i++)
        s[i]=32;
    s[0]=179;
    s[xlen-1]=179;

    for (i=1; i<ylen-1; i++) {
        npr("[%d;%dH�%s�",i+y,x,s);
    }

}



void popup(void)
{
    int done=0,draw=4;
    int i,ch,x,y,r;
    char s[81];

    npr("|31");


    x=50;
    y=24-numitems[0];


    makerembox(x-3,y-1, 24, (24-y)+2 );

    curtitle=0;

    myxy(y,x);

    for(i=0;i<numitems[curtitle];i++) {
        myxy(y+i,x);
        if(i==curitem)
            npr("0%-20.20s|31",tg[ml[curtitle][i]].desc);
        else
            npr("|31%-20.20s",tg[ml[curtitle][i]].desc);
    }

    do {
        if(draw==2||draw==3) {
            if(draw==2) i=-1; 
            else i=1;
            myxy(curitem+y+i,x);
            npr("|31%-20.20s",tg[ml[curtitle][curitem+i]].desc);
            myxy(curitem+y,x);
            npr("0%-20.20s|31",tg[ml[curtitle][curitem]].desc);
        }
        r=pmmkey(retfrompldn);
        if(r<0) {
            switch(r) {
            case -2: 
                if(curitem<numitems[curtitle]-1) {
                    curitem++;
                    draw=2;
                }
                break;
            case -1: 
                if(curitem>0) {
                    curitem--;
                    draw=3;
                }
                break;
            }
        } 
        else {
            if(!retfrompldn[0]) {
                strcpy(retfrompldn,tg[ml[curtitle][curitem]].key);
                ansic(0);
                return;
            } 
            else if(retfrompldn[0]=='~') {
                usepldns=0;
                strcpy(retfrompldn,"");
                done=1;
            } 
            else {
                ansic(0);
                return;
            }
        }
    } 
    while(!done&&!hangup);
    ansic(0);

    return;
}
#endif
