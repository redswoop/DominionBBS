#include "vars.h"
#pragma hdrstop


void dirdata(int n, char *s)
{
  char x,y,k,i,s1[81];
  directoryrec r;

  r=directories[n];
  if (r.dar==0)
    x=32;
  else {
    for (i=0; i<16; i++)
      if ((1 << i) & r.dar)
        x='A'+i;
  }

  noc(s1,r.name);
  sprintf(s,"3%2d  3%1c  3%-40s  3%-8s 3%-7s 3%-3d 3%-9.9s",
            n,x,s1,r.filename,r.acs,r.maxfiles,r.dpath);
}

void showdirs()
{
  int abort,i;
  char s[180];

  outchr(12);
  abort=0;
  pla("0NN2�0Dar2�0Name2��������������������������������������0Filename2�0Dsl2�0AGE2�0Max2�0Path2����",
      &abort);
  for (i=0; (i<num_dirs) && (!abort); i++) {
    dirdata(i,s);
    pla(s,&abort);
  }
}



void modify_dir(int n)
{
  directoryrec r;
  char s[81],s1[81],ch,ch2,*ss;
  int i,i1,done;

  done=0;
  r=directories[n];
  do {
    outchr(12);
    npr("31. Name       :0 %s\r\n",r.name);
    npr("32. Filename   :0 %s\r\n",r.filename);
    npr("33. Path       :0 '%s'\r\n",r.dpath);
    npr("34. Access ACS :0 %s\r\n",r.acs);
    npr("35. Confernce  :0 %c",r.confnum); nl();
    npr("36. Max Files  :0 %d\r\n",r.maxfiles);
    strcpy(s,"None.");
    if (r.dar!=0) {
      for (i=0; i<16; i++)
        if ((1 << i) & r.dar)
          s[0]='A'+i;
      s[1]=0;
    }    
    npr("37. DAR        :0 %s\r\n",s);
    npr("38. Cmnt File  :0 %s\r\n",r.upath);
    npr("39. List ACS   :0 %s\r\n",r.vacs);
    if (r.mask & mask_no_uploads) s[0]='U'; else s[0]='�';
    if (r.mask & mask_archive)  s[1]='A'; else s[1]='�';
    if (r.mask & mask_autocredit) s[2]='C'; else s[2]='�';
    if (r.mask & mask_no_ratio) s[3]='R'; else s[3]='�';
    if (r.mask & mask_FDN) s[4]='N'; else s[4]='�';
    if (r.mask & mask_PD) s[5]='G'; else s[5]='�';
    s[6]=0;
    npr("3Flags         :0 %s\r\n",s);
    nl();
    prt(5,"File Base Edit (?=Help)0 ");
    ch=onek("Q123456789UGACRJN[]?");
    switch(ch) {
      case '?': printmenu(26); pausescr(); break;
      case 'U': r.mask ^= mask_no_uploads; break;
      case 'A': r.mask ^= mask_archive; break;
      case 'C': r.mask ^= mask_autocredit; break;
      case 'R': r.mask ^= mask_no_ratio; break;
      case 'N': togglebit(&r.mask,mask_FDN); break;
      case 'G': togglebit(&r.mask,mask_PD); break;
      case 'Q': done=1; break;
      case ']': if((n>=0) && (n<num_dirs-1))  { directories[n++]=r; r=directories[n];}break;
      case '[': if(n>0 ){ directories[n--]=r; r=directories[n];} break;
      case 'J': nl(); prt(4,"Jump to which dir? ");
                input(s,4); if(s[0]) {
                    i=atoi(s);
                    directories[n]=r;
                    r=directories[i];
                }
                break;
      case '1':
        nl();
        prt(2,"New Name? ");
        inli(s,"",41,1);
        if (s[0])
          strcpy(r.name,s);
        break;
      case '8':
        nl();
        inputdat("Comment File Name",s,12,0);
        if(s[0]) strcpy(r.upath,s);
        break;
      case '2':
        nl();
        inputdat("New Filename",s,8,0);
        if ((s[0]!=0) && (strchr(s,'.')==0))
          strcpy(r.filename,s);
        break;
      case '3':
        nl();
        pl("You must enter the FULL PATHNAME to the directory.");
        inputdat("FULL Pathname to Desired Directory",s,75,0);
        if (s[0]) {
          if (chdir(s)) {
            chdir(cdir);
            if (mkdir(s)) {
              pl("Error Creating/Changing to directory");
            pausescr();
              s[0]=0;
            }
          } else {
            chdir(cdir);
          }
          if (s[0]) {
            if(s[strlen(s)-1]!='\\')
                strcat(s,"\\");
            strcpy(r.dpath,s);
          }
        }
        break;
      case '4':
        nl();
        inputdat("Enter General Access ACS",s,21,0);
        if(s[0]) strcpy(r.acs,s);
        break;
      case '9':
        nl();
        inputdat("Enter List ACS",s,21,0);
        if(s[0]) strcpy(r.vacs,s);
        break;
      case '5':
        nl();
        npr("5New Confernce Flag? ");
        r.confnum=onek("ABCDEFGHIJKLMNOPQRSTUVWXYZ@!123456790");
        break;
      case '6':
        nl();
        inputdat("Maximum Files for this Area",s,5,0);
        i=atoi(s);
        if ((i>0) && (i<32676) && (s[0]))
          r.maxfiles=i;
        break;
      case '7':
        nl();
        npr("5New DAR? ");
        ch2=onek("ABCDEFGHIJKLMNOP\r");
        if (ch2=='\r')
          r.dar=0;
        else
          r.dar=1 << (ch2-'A');
        break;
    }
  } while ((!done) && (!hangup));
  directories[n]=r;
  if (!wfc)
    changedsl();
}

void swap_dirs(int dir1, int dir2)
{
  int i,i1,i2,nu;
  directoryrec drt;

  nu=number_userrecs();

  drt=directories[dir1];
  directories[dir1]=directories[dir2];
  directories[dir2]=drt;
}


void insert_dir(int n,char path[60], int temp,int config)
{
  directoryrec r;
  int i,i1,nu;
  userrec u;
  long l1,l2,l3;

  if(!temp) {
  for (i=num_dirs-1; i>=n; i--)
    directories[i+1]=directories[i];
  }
  if(temp) strcpy(r.name,"<< Temporary >>");
  else strcpy(r.name,"�> New Directory <�");
  if(temp) strcpy(r.filename,"TEMPDIR");
  else strcpy(r.filename,"NEWDIR");
  strcpy(r.dpath,path);
  strcpy(r.upath,"COMMENT");
  strcpy(r.acs,"D50");
  r.maxfiles=50;
  r.dar=0;
  r.type=temp;
  r.mask=0;
  r.confnum='@';
  directories[n]=r;
  if(!temp) {
  ++num_dirs;
  read_user(1,&u);
  nu=(int) (filelength(userfile) / sizeof(userrec));
  if (n>=32) {
    l1=0xffffffff >>(64-n);
    l2=0xffffffff <<(n-31);
    l3=1L << (n-32);
    for (i=1; i<nu; i++) {
      read_user(i,&u);
      u.nscn2=(u.nscn2 & l1) | ((u.nscn2 << 1) & l2) | l3;
      write_user(i,&u);
    }
  } else {
    l1=0xffffffff >>(32-n);
    l2=0xffffffff <<(n+1);
    l3=1L << n;
    for (i=1; i<nu; i++) {
      read_user(i,&u);
      u.nscn2=(u.nscn2 << 1) | (u.nscn1 >> 31);
      u.nscn1=(u.nscn1 & l1) | ((u.nscn1 << 1) & l2) | l3;
      write_user(i,&u);
    }
  }
  if(config)
      modify_dir(n);
 }
}


void delete_dir(int n)
{
  int i,i1,nu;
  userrec u;
  long l1,l2;

  for (i=n; i<num_dirs; i++)
    directories[i]=directories[i+1];
  --num_dirs;
  read_user(1,&u);
  nu=(int) (filelength(userfile) / sizeof(userrec));
  if (n>=32) {
    l1=0xffffffff >>(64-n);
    l2=0xffffffff <<(n-32);
    for (i=1; i<nu; i++) {
      read_user(i,&u);
      u.nscn2=(u.nscn2 & l1) | ((u.nscn2 >> 1) & l2);
      write_user(i,&u);
    }
  } else {
    l1=0xffffffff >>(32-n);
    l2=0xffffffff <<(n);
    for (i=1; i<nu; i++) {
      read_user(i,&u);
      u.nscn1=(u.nscn1 & l1) | ((u.nscn1 >> 1) & l2) | (u.nscn2 << 31);
      u.nscn2=u.nscn2 >> 1;
      write_user(i,&u);
    }
  }
  if (!wfc)
    changedsl();
}


void diredit()
{
  int i,i1,i2,done,f;
  char s[81],s1[81],s2[81],ch;

  if (!checkpw())
    return;
  showdirs();
  done=0;
  do {
    nl();
    outstr(get_string2(1));
    ch=onek("QPDIM?");
    switch(ch) {
      case '?':
        showdirs();
        break;
      case 'Q':
        done=1;
        break;

      case 'P':
        if (num_dirs<MAX_DIRS) {
          nl();
          prt(2,"Move which Area? ");
          input(s,3);
          i1=atoi(s);
          if ((!s[0]) || (i1<0) || (i1>num_dirs))
            break;
          nl();
          prt(2,"Place before which area? ");
          input(s,3);
          i2=atoi(s);
          if ((!s[0]) || (i2<0) || (i2%32==0) || (i2>num_dirs) || (i1==i2))
            break;
          nl();
          if (i2<i1)
            i1++;
          insert_dir(i2,syscfg.dloadsdir,0,0);
          swap_dirs(i1,i2); 
          delete_dir(i1);   
          showdirs();
        } else {
          nl();
          npr("There must be less than %d areas to move one",MAX_DIRS);
        }
        break;



      case 'M':
        nl();
        prt(2,"Dir number? ");
        input(s,2);
        i=atoi(s);
        if ((s[0]!=0) && (i>=0) && (i<num_dirs))
          modify_dir(i);
        break;
      case 'I':
        if (num_dirs<64) {
          nl();
          prt(2,"Insert before which dir? ");
          input(s,2);
          i=atoi(s);
          if ((s[0]!=0) && (i>=0) && (i<=num_dirs))
            insert_dir(i,syscfg.dloadsdir,0,0);
        }
        break;
      case 'D':
        nl();
        prt(2,"Delete which dir? ");
        input(s,2);
        i=atoi(s);
        if ((s[0]!=0) && (i>=0) && (i<num_dirs)) {
          nl();
          sprintf(s1,"Delete %s? ",directories[i].name);
          prt(5,s1);
          if (yn())
            delete_dir(i);
        }
        break;
    }
  } while ((!done) && (!hangup));
  sprintf(s,"%sDIRS.DAT",syscfg.datadir);
  f=open(s,O_RDWR | O_BINARY | O_CREAT | O_TRUNC, S_IREAD | S_IWRITE);
  write(f,(void *)&directories[0], num_dirs * sizeof(directoryrec));
  close(f);
}


void protdata(int n, char *s)
{
  protocolrec r;

  r=proto[n];
  sprintf(s,"3%-2d  3  %c    3%-59s",n,r.singleok?'Y':'N',r.description);
}

void showprots()
{
  int abort,i;
  char s[180];

  outchr(12);
  abort=0;
  pla("0NN2��0Single2��0Description2��������������������������������������������������������",&abort);
  for (i=0; (i<numextrn) && (!abort); i++) {
    protdata(i,s);
    pla(s,&abort);
  }
}



void modify_prot(int n)
{
  protocolrec r;
  char s[81],s1[81],ch,ch2,*ss;
  int i,i1,done;

  done=0;
  r=proto[n];
  do {
    outchr(12);
    npr("01. Descrition        : 3%s\r\n",r.description);
    npr("02. Key               : 3%c\r\n",r.key);
    npr("03. Batch Receive     : 3%s\r\n",r.receivebatch);
    npr("04. Batch Send        : 3%s\r\n",r.sendbatch);
    npr("05. File Sent         : 3%c",r.ok1); nl();
    npr("06. File Received     : 3%c",r.ok2); nl();
    npr("07. Error in Transfer : 3%c",r.nok1); nl();
    npr("08. Single            : 3%s\r\n",r.singleok? "Ok":"No");
    if(r.singleok) {
        npr("09. Single Receieve   : 3%s\r\n",r.receivefn);
        npr("00. Single Send       : 3%s\r\n",r.sendfn);
    }
    nl();
    pl("%1 = Com Port and Speed");
    pl("%2 = Com Port");
    pl("%3 = File Name");
    pl("%4 = Port Speed");
    pl("%5 = Batch List File (Without @)");
    nl();
    outstr("5Protocol Editor (0-9,J,Q,[,]): ");
    ch=onek("1234567890J[]Q");
    switch(ch) {
      case 'Q': done=1; break;
      case '8': r.singleok=opp(r.singleok); break;
      case '2': outstr("Enter Key for this Protocol: "); r.key=toupper(getkey()); break;
      case ']': if((n>=0) && (n<numextrn-1))  { proto[n++]=r; r=proto[n];}break;
      case '[': if(n>0){ proto[n--]=r; r=proto[n];} break;
      case 'J': nl(); prt(4,"Jump to which Protocol? ");
                input(s,4); if(s[0]) {
                        i=atoi(s);
                        proto[n]=r;
                        r=proto[i];
                        }
                  break;
      case '1': nl(); /*pl("New Description? "); nl();
                      mpl(75); inputl(s,79);*/
                      inputdat("Description",s,75,1);
                      if(s[0]) strcpy(r.description,s); break;
      case '9': nl(); /*pl("New Receive Command Line? ");nl();
                      mpl(75); inputl(s,79);*/
                      inputdat("New Receive Command Line",s,75,1);
                      if(s[0]) strcpy(r.receivefn,s); break;
      case '0': nl(); /*pl("New Send Command Line? ");   nl();
                      mpl(75); inputl(s,79);*/
                      inputdat("New Send Command Line",s,75,1);
                      if(s[0]) strcpy(r.sendfn,s); break;
      case '5': nl(); npr("3File Sent\r\n5: ");
                      input(s,3); if(s[0]) r.ok1=s[0]; break;
      case '6': nl(); npr("3File Received\r\n5: ");
                      input(s,3); if(s[0]) r.ok2=s[0]; break;
      case '7': nl(); npr("3Error in Transfer\r\n5: ");
                      input(s,3); if(s[0]) r.nok1=s[0]; break;
      case '3': nl(); /*pl("New Receive Batch Command Line? ");nl();
                      mpl(75); inputl(s,79);*/
                      inputdat("New Receive Batch Command Line",s,75,1);
                      if(s[0]) strcpy(r.receivebatch,s); break;
      case '4': nl(); /*pl("New Send Batch Command Line? "); nl();
                      mpl(75); inputl(s,79);*/
                      inputdat("New Send Batch Command Line",s,75,1);
                      if(s[0]) strcpy(r.sendbatch,s); break;
    }
  } while ((!done) && (!hangup));
  proto[n]=r;
}


void insert_prot(int n)
{
  protocolrec r;
  int i,i1,nu;
  long l1,l2,l3;
  char s[81];


  for (i=numextrn-1; i>=n; i--)
    proto[i+1]=proto[i];
    numextrn++;

  strcpy(r.description,"** New Protocol **");
  strcpy(r.receivefn,"");
  strcpy(r.sendfn,"");
  r.ok1=0;
  r.nok1=1;
  r.singleok=0;
  strcpy(r.sendbatch,"");
  strcpy(r.receivebatch,"");
  proto[n]=r;
  modify_prot(n);
}


void delete_prot(int n)
{
  int i;

  for (i=n; i<numextrn; i++)
    proto[i]=proto[i+1];
  --numextrn;
}


void protedit()
{
  int i,i1,i2,done,f;
  char s[81],s1[81],s2[81],ch;

  if (!checkpw())
    return;
  showprots();
  done=0;
  do {
    nl();
    outstr(get_string2(1));
    ch=onek("QDIM?");
    switch(ch) {
      case '?':
        showprots();
        break;
      case 'Q':
        done=1;
        break;
      case 'M':
        nl();
        prt(2,"Prot number? ");
        input(s,2);
        i=atoi(s);
        if ((s[0]!=0) && (i>=0) && (i<numextrn))
          modify_prot(i);
        break;
      case 'I':
        if (numextrn<64) {
          nl();
          prt(2,"Insert before which prot? ");
          input(s,2);
          i=atoi(s);
          if ((s[0]!=0) && (i>=0) && (i<=numextrn))
            insert_prot(i);
        }
        break;
      case 'D':
        nl();
        prt(2,"Delete which prot? ");
        input(s,2);
        i=atoi(s);
        if ((s[0]!=0) && (i>=0) && (i<numextrn)) {
          nl();
          sprintf(s1,"Delete %s? ",proto[i].description);
          prt(5,s1);
          if (yn())
            delete_prot(i);
        }
        break;
    }
  } while ((!done) && (!hangup));
  sprintf(s,"%sprotocol.DAT",syscfg.datadir);
  f=open(s,O_RDWR | O_BINARY | O_CREAT | O_TRUNC, S_IREAD | S_IWRITE);
  write(f,(void *)&proto[0], numextrn * sizeof(protocolrec));
  close(f);
}



