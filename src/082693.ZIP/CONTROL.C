#include "vars.h"
#pragma hdrstop

void putf(char *s,FILE *f)
{
    fputs(s,f); fputs("\n",f);
}

typedef struct {
    char bbsid[8];
} qwkcrec;

qwkcrec qwkc;

void createcontrol(void)
{
    FILE *f;
    char *s,s1[81];
    struct time t;
    struct date d;
    int i,max;

    putf(syscfg.systemname,f);
    putf("Dominion Land",f);
    putf(syscfg.systemphone,f);
    putf(syscfg.sysopname,f);

    sprintf(s,"00000,%s","INNOCENT");
    putf(s,f);

    getdate(&d);
    gettite(&t);
    sprintf(s,"%02-%02-%d %02:%02:%02",d.da_mon,d.da_day,d.da_year,t.ti_hour,t.ti_min,t.ti_sec);
    putf(s,f);
    putf("",f);
    putf("0",f);
    putf("0",f);

#ifdef BBS
    max=0;
    for(i=0;i<64&&usub[i].subnum!=-1;i++)
        max++;
    sprintf(s,"%d",max-1);
    putf(s,f);

    for(i=0;i<64&&usub[i].subnum!=-1;i++) {
        sprintf(s,"%d",i);
        putf(s,f);
        putf(subboards[usub[i].subnum].name,f);
    }
#endif
#ifndef BBS
    sprintf(s,"%d",num_subs-1);
    putf(s,f);

    for(i=0;i<num_subs;i++) {
        sprintf(s,"%d",i);
        putf(s,f);
        putf(subboards[i].name,f);
    }
#endif
    putf("HELLO",f);
    putf("NEWS",f);
    putf("GOODBYE",f);
    fclose(f);
}
