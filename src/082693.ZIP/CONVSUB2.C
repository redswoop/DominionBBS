#include <fcntl.h>
#include <sys\stat.h>
#include "vardec.h"


// Message Base Record
typedef struct {
        char            name[41],               /* board name */
                        filename[9],            /* board database filename */
                        conf;                   // Which Conference
        unsigned char   readacs[21],            // Acs required to read
                        postacs[21],            // Acs required to post
                        anony,                  // Anonymous Type
                        age;                    /* minimum age for sub */
        unsigned long   attr;
        unsigned short  maxmsgs,                /* max # of msgs */
                        ar,                     /* AR for sub-board */
                        storage_type;           /* how messages are stored */
} osubboardrec;


subboardrec n[64];
osubboardrec o[64];

void fix(int which)
{
    int i,i1;

    pr("3Converting 3%s - ",o[which].name);

    strcpy(n[which].name,o[which].name);
    strcpy(n[which].filename,o[which].filename);
    strcpy(n[which].nmpath,"");
    strcpy(n[which].postacs,o[which].postacs);
    strcpy(n[which].readacs,o[which].readacs);
    n[which].conf=o[which].conf;
    n[which].ar=o[which].ar;
    n[which].maxmsgs=o[which].maxmsgs;
    n[which].storage_type=o[which].storage_type;
    n[which].age=o[which].age;
    n[which].anony=o[which].anony;
    n[which].attr=o[which].attr;
    n[which].add.zone=0;
    n[which].add.net=0;
    n[which].add.node=0;
    n[which].add.point=0;
    n[which].origin=0;

    npr("5Done. ");
}

void main(void)
{
    configrec syscfg;
    char s[81];
    int i,numsubs;

    i=open("config.dat",O_RDWR|O_BINARY);
    if(i<0) {
        npr("7Config.dat Not found!");
        exit(1);
    }
    read(i,&syscfg,sizeof(syscfg));
    close(i);
    sprintf(s,"%ssubs.dat",syscfg.datadir);
    i=open(s,O_RDWR|O_BINARY);

    numsubs=(read(i,o, (64*sizeof(osubboardrec))))/
           sizeof(osubboardrec);;

    close(i);

    for(i=0;i<numsubs;i++)
        fix(i);

    i=open(s,O_BINARY|O_RDWR|O_TRUNC);
    write(i,&n[0],numsubs*sizeof(n[0]));
    close(i);
}
