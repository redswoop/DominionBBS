#include "vars.h"
#pragma hdrstop

#include <dir.h>


void menuinfoed()
{
    mciok=0;

    outchr(12);
    npr("3Menu File Name: %s\r\n",menuC.menuFn);
    nl();
    npr("31. Prompt       : 0%s\r\n",menuC.pp.prompt);
    npr("32. Titles       : 0%s\r\n",menuC.pp.title1);
    if(menuC.pp.title2[0]) npr("3                :0 %s\r\n",menuC.pp.title2);
    npr("33. Ansi Menu    : 0%s\r\n",menuC.pp.altmenu[0]?menuC.pp.altmenu:"\"\"");
    npr("34. Security     : 0%s\r\n",menuC.pp.slneed[0]?menuC.pp.slneed:"None");
    npr("35. Change Style : 0%d,%d,%d - %d Columns\r\n",menuC.pp.col[0],menuC.pp.col[1],menuC.pp.col[2],menuC.pp.columns);
    npr("36. Help Level   : 0%d\r\n",menuC.pp.helplevel-1);
    npr("37. Format File  : 0%s\r\n",menuC.pp.format);
    npr("38. MCI Name     : 0%s\r\n",menuC.pp.pausefile);
    npr("39. Extended Help: 0%s\r\n",menuC.pp.helpfile);
#ifdef PD
    npr("30. Pldn Prompt  : 0%s\r\n",menuC.pp.prompt2);
#endif
    npr("3A. HotKeys      : 0");
    if(menuC.pp.boarder==1)
        pl("Forced");
    else if(menuC.pp.boarder==2)
        pl("Off");
    else if(!menuC.pp.boarder)
        pl("Normal");
    npr("3B. Ext. Prompt  : 0%s\r\n",(menuC.pp.attr & menu_extprompt)?"Okay":"Internal Only");
    npr("3C. Pulldown Ok  : 0%s\r\n",(menuC.pp.attr & menu_pulldown)?"Yes":"No");
    npr("3F. Append Prmpt : 0%s\r\n",(menuC.pp.attr & menu_promptappend)?"Yes":"No");
    npr("3G. PopUp        : 0%s\r\n",(menuC.pp.attr & menu_popup)?"Yes":"No");
    npr("3H. Use Global   : 0%s\r\n",(menuC.pp.attr & menu_noglobal)?"No":"Yes");
    nl();
    mciok=1;
}


void edmenu (int x)
{
    int i,y,z,f;
    char ch,s[81],done=0,s1[81],fn[15];
    menurec tg;

    GetLink(&menuC.menuCmd,x,&tg);

    while(!done&&!hangup) {
        outchr(12);
        npr("Editing Command #%d\r\n",x); 
        nl();
        npr("1. Desc     : %s\r\n",tg.desc);
        npr("2. Key      : %s\r\n",tg.key);
        npr("3. Type     : %.2s\r\n",tg.type);
        npr("4. Attirbute: ");
        if(tg.attr==command_hidden) npr("Hidden ");
        else
            if(tg.attr==command_unhidden) npr("Unhidden ");
            else
                if(tg.attr==command_forced) npr("Forced ");
                else
                    if(tg.attr==command_title) npr("Sub-Section Title ");
                    else
                        if(tg.attr==command_pulldown) npr("Pull Down Seperator ");
                        else
                            if(tg.attr==command_default) npr("Default ");
                            else
                                npr("None");
        nl();
        npr("5. Security : %s\r\n",tg.sl);
        npr("6. Line     : %s\r\n",tg.line);
        npr("7. Parameter: %s\r\n",tg.ms);
        nl();
        outstr("5Command Editor (Q=Quit, V=View, J=Jump, [,]) ");
        ch=onek("1234567QV?[]J");
        nl();
        switch(ch)
        {
        case 'J':
            inputdat("To Which Command",s,2,0);
            if(s[0]&&(atoi(s)<numLinks(&menuC.menuCmd))) {
                PutLink(&menuC.menuCmd,x,&tg);
                x=atoi(s);
                GetLink(&menuC.menuCmd,x,&tg);
            }
            break;
        case 'V': 
            showmenucol();
            pausescr(); 
            break;
        case ']': 
            if(x<(numLinks(&menuC.menuCmd))-1) {
                PutLink(&menuC.menuCmd,x,&tg);
                x++;
                GetLink(&menuC.menuCmd,x,&tg);
            }
            break;
        case '[': 
            if(x>0) {
                PutLink(&menuC.menuCmd,x,&tg);
                x--;
                GetLink(&menuC.menuCmd,x,&tg);
            }
            break;
        case 'Q': 
            PutLink(&menuC.menuCmd,x,&tg);
            done=1; 
            break;
        case '1': 
            npr("3Description\r\n5: ");
            inli(s,tg.desc,50,1);
            if(s[0])
                strcpy(tg.desc,s);
            break;
        case '3': 
            inputdat("Type",s,2,0);
            if(s[0]) {
                tg.type[0]=s[0];
                tg.type[1]=s[1];
            }
            break;
        case '2': 
            inputdat("Key",s,8,0);
            if(s[0]) {
                strcpy(tg.key,s);
            }
            break;
        case '5': 
thespot:
            inputdat("Security (?=Help)",s,21,0);
            if(s[0]=='?') {
                printmenu(27);
                goto thespot;
            }
            if(s[0]) strcpy(tg.sl,s);
            break;
        case '6': 
            npr("3Command Line\r\n5: ");
            inli(s,tg.line,50,1);
            if(s[0]) strcpy(tg.line,s);
            break;
        case '7': 
            npr("3Command Parameters\r\n5: ");
            inli(s,tg.ms,80,1);
            strcpy(tg.ms,s);
            break;
        case '4': 
            npr("%s\r\n: ",get_string2(10));
            tg.attr=0;
            s[0]=onek("\rHUDFTP");
            if(s[0]=='\r'); 
            else switch(s[0]) {
            case 'H': 
                tg.attr=command_hidden;
                break;
            case 'U': 
                tg.attr=command_unhidden;
                break;
            case 'T': 
                tg.attr=command_title;
                break;
            case 'P': 
                tg.attr=command_pulldown;
                break;
            case 'F': 
                tg.attr=command_forced;
                break;
            case 'D': 
                tg.attr=command_default;
                break;
            }
            break;
        }
    } 
}

void top(char fn[15])
{
    int x,n=0;
    char s[81],s1[161];
    menurec tg;

    outchr(12);
    npr("5Current Menu: 3%s\r\n",fn);
    nl();
    pl("2##. Type5�2Keys    5�2SL      ##. Type5�2Keys    5�2SL     �##. Type5�2Keys    5�2SL");
    pl("5������������������������������������������������������������������������������");

    for(x=0;x<(numLinks(&menuC.menuCmd));x++) {
        GetLink(&menuC.menuCmd,x,&tg);
        npr("0%2d. %-2.2s  5�0%-8.8s5�0%-7.7s ",x,tg.type,tg.key,tg.sl);
        n++;
        if(n==3) { 
            nl(); 
            n=0; 
        }
    }
    nl();
    nl();
}



void addmenu(char fn[15])
{
    int i;
    char s[81];
    menurec tg;
    menuHeaderRec pp;

    sprintf(s,"%s%s.mnu",syscfg.menudir,fn);
    i=open(s,O_RDWR|O_TRUNC|O_CREAT,S_IREAD|S_IWRITE);
    strcpy(menuC.pp.prompt,"Select: ");
    strcpy(menuC.pp.title1,"�Dominion Bulletin Board System");
    strcpy(menuC.pp.title2,"�A New Menu");
    strcpy(menuC.pp.altmenu,"");
    strcpy(menuC.pp.pausefile,"");
    strcpy(menuC.pp.slneed,"");
    strcpy(menuC.pp.format,"");
    menuC.pp.columns=4;
    menuC.pp.battr=5;
    menuC.pp.attr=0;
    menuC.pp.attr |= menu_extprompt;
    menuC.pp.attr |= menu_format;
    menuC.pp.attr |= menu_pulldown;

    strcpy(tg.desc,"<NEW> Menu Command");
    strcpy(tg.type,"OL");
    strcpy(tg.line,"");
    tg.attr=0;
    strcpy(tg.ms,"");

    write(i,&pp,sizeof(menuHeaderRec));
    write(i,&tg,sizeof(menurec));
    write(i,&tg,sizeof(menurec));
    close(i);

    menued(fn);
}


void extractheader()
{
    FILE *f;
    char s[81],fn[81];

    inputdat("Filename to Write to",s,12,0);
    if(!s[0]) return;

    f=fopen(s,"wb");
    strcpy(fn,s);

    fputs(menuC.pp.prompt,f);
    fputs("\n",f);
#ifdef PD
    fputs(menuC.pp.prompt2,f);
    fputs("\n",f);
#endif
    fputs(menuC.pp.title1,f);
    fputs("\n",f);
    fputs(menuC.pp.title2,f);
    fputs("\n",f);
    fputs(menuC.pp.format,f);
    fputs("\n",f);
    itoa(menuC.pp.columns,s,10);
    fputs(s,f); 
    fputs("\n",f);


    fclose(f);
    npr("Menu Header Extracted to %s\r\n",fn);
    pausescr();
}


void readheader()
{
    FILE *f;
    char s[161],fn[81];

    inputdat("Filename to Read",fn,12,0);
    if(!fn[0]) return;
    f=fopen(fn,"rt");

    fgets(s,161,f); 
    filter(s,'\n'); 
    strcpy(menuC.pp.prompt,s);
#ifdef PD
    fgets(s,161,f); 
    filter(s,'\n'); 
    strcpy(menuC.pp.prompt2,s);
#endif
    fgets(s,161,f); 
    filter(s,'\n'); 
    strcpy(menuC.pp.title1,s);
    fgets(s,161,f); 
    filter(s,'\n'); 
    strcpy(menuC.pp.title2,s);
    fgets(s,161,f); 
    filter(s,'\n'); 
    strcpy(menuC.pp.format,s);
    fgets(s,161,f); 
    filter(s,'\n'); 
    menuC.pp.columns=atoi(s);

    fclose(f);

    npr("Menu Header Read from %s\r\n",fn);
    pausescr();
}

void listmform(void)
{
    struct ffblk f;
    char s[81];

    sprintf(s,"%s*.fmt",syscfg.menudir);
    findfirst(s,&f,0);
    nl();
    pl("5Available Format Files");
    nl();

    do
        pl(f.ff_name);
    while(findnext(&f)!=-1);

    nl();

}

void menued(char fn[15])
{
    int i,x=0,y,z,type=status.menuEditorMode,d1=0,f;
    char ch,s[161],s1[161],done=0;
    menurec tg;

    if(!readMenu(fn,0,0,0,&menuC)) {
        return;
    }

    if(type)
        top(fn);
    else
        menuinfoed(fn);

    while(!done&&!hangup) {
        outstr("5Menu Editor (?=Help):0 ");
        ch=onek("PQMDI?XV1234567890ERABCFGH\r");
        switch(ch) {
        case 'E': 
            extractheader(); 
            break;
        case 'R': 
            readheader(); 
            break;
        case '?': 
            printmenu(8); 
            break;
        case  13: 
            if(type)
                top(fn);
            else
                menuinfoed(fn);
            break;
        case '1': 
            pl("Prompt:");
#ifdef PD
            outstr(": "); 
            inli(s,menuC.pp.prompt,99,1);
#else
            outstr(": "); 
            inli(s,menuC.pp.prompt,192,1);
#endif
            if(s[0])
                strcpy(menuC.pp.prompt,s);
            break;
#ifdef PD
        case '0': 
            pl("PullDown Prompt:");
            outstr(": "); 
            inli(s,menuC.pp.prompt2,99,1);
            if(s[0]) strcpy(menuC.pp.prompt2,s);
            break;
#endif
        case '2': 
            pl("Title 1:");
            outstr(": "); 
            inli(s,menuC.pp.title1,51,1);
            if(s[0])
                strcpy(menuC.pp.title1,s);
            pl("Title 2:");
            outstr(": "); 
            inli(s,menuC.pp.title2,51,1);
            if(s[0])
                strcpy(menuC.pp.title2,s);
            break;
        case '3': 
            inputdat("External Menu",s,8,0);
            if(s[0])
                strcpy(menuC.pp.altmenu,s);
            break;
        case '4': 
            inputdat("Security",menuC.pp.slneed,sizeof(menuC.pp.slneed),1);
            break;
        case '6': 
            nl();
            printmenu(25);
            inputdat("Forced Help Level for Menu, -1 Disables",s,2,0);
            if(s[0]) menuC.pp.helplevel=atoi(s)+1;
            break;
        case '7': 
            listmform(); 
            inputdat("Format File",menuC.pp.format,8,0);
            break;
        case '8': 
            inputdat("Menu's MCI Name",menuC.pp.pausefile,9,1);
            break;
        case '9': 
            inputdat("External Help File .HLP",menuC.pp.helpfile,8,0);
            break;
        case 'A': 
            nl();
            npr("3Hotkeys: 0F5orced, 0O5ff, 0N5ormal: ");
            ch=onek("\rNOF");
            if(ch=='N'||ch=='\r')
                menuC.pp.boarder=0;
            else if(ch=='F')
                menuC.pp.boarder=1;
            else if(ch=='O')
                menuC.pp.boarder=2;
            break;
        case 'B': 
            togglebit((long *)&menuC.pp.attr,menu_extprompt);
            break;
        case 'C': 
            togglebit((long *)&menuC.pp.attr,menu_pulldown);
            break;
        case 'F': 
            togglebit((long *)&menuC.pp.attr,menu_promptappend);
            break;
        case 'G': 
            togglebit((long *)&menuC.pp.attr,menu_popup);
            break;
        case 'H': 
            togglebit((long *)&menuC.pp.attr,menu_noglobal);
            break;
        case '5': 
            d1=0;
            do {
                outchr(12);
                npr("0Menu Style Editor\r\n"); 
                nl();
                npr("1. Brackets    : %d\r\n",menuC.pp.col[0]);
                npr("2. Commands    : %d\r\n",menuC.pp.col[1]);
                npr("3. Description : %d\r\n",menuC.pp.col[2]);
                npr("4. Columns     : %d\r\n",menuC.pp.columns);
                nl();
                outstr("Select: ");
                ch=onek("1234VQ\r");
                switch(ch) {
                case '4':  
                    inputdat("Enter Number of Columns (1,2,3,4,5)",s,2,0);
                    if(s[0])
                        menuC.pp.columns=atoi(s);
                    break;
                case '1':  
                    inputdat("Bracket Attr",s,2,0);
                    if(s[0])
                        menuC.pp.col[0]=atoi(s);
                    break;
                case '2':  
                    inputdat("Command Key Attr",s,2,0);
                    if(s[0])
                        menuC.pp.col[1]=atoi(s);
                    break;
                case '3':  
                    inputdat("Description Attr",s,2,0);
                    if(s[0])
                        menuC.pp.col[2]=atoi(s);
                    break;
                case 'V':  
                    showmenucol();
                    pausescr(); 
                    break;
                case '\r':
                case 'Q': 
                    d1=1; 
                    break;
                }
            } 
            while(!d1);
            break;
        case 'Q': 
            done=1; 
            break;
        case 'X':
            type=!type;
            if(type)
                top(fn);
            else
                menuinfoed(fn);
            break;
        case 'M': 
            nl();
            inputdat("Modify starting at which Command",s,2,0);
            x=atoi(s);
            edmenu(x); 
            break;
        case 'I': 
            nl();
            inputdat("Insert before which command",s,2,0);
            if(!s[0])
                break;
            y=atoi(s);
            inputdat("Insert How Many? ",s,2,0);
            if(!s[0])
                i=1;
            else
                i=atoi(s);
            for(x=0;x<i;x++) {
                strcpy(tg.desc,"<NEW> Command");
                strcpy(tg.key,"NEW");
                strcpy(tg.line,"");
                strcpy(tg.sl,"");
                strcpy(tg.type,"OL");
                strcpy(tg.ms,"");
                tg.attr=0;
                InsertLink(&menuC.menuCmd,y,&tg);
            }
            break;
        case 'D': 
            inputdat("Delete which command",s,2,0);
            if(!s[0])
                break;
            i=atoi(s);
            DeleteLink(&menuC.menuCmd,i);
            break;
        case 'P': 
            inputdat("Posistion which command",s,2,0);
            if(!s[0])
                break;
            y=atoi(s);
            GetLink(&menuC.menuCmd,y,&tg);
            inputdat("Posistion where",s,2,0);
            if(!s[0])
                break;
            DeleteLink(&menuC.menuCmd,y);
            i=atoi(s);
            InsertLink(&menuC.menuCmd,i,&tg);
            break;
        case 'V': 
            showmenucol();
            pausescr(); 
            break;
        }
    } 


    sprintf(s,"%s%s",syscfg.menudir,fn);
    f=open(s,O_RDWR|O_BINARY|O_CREAT|O_TRUNC,S_IREAD|S_IWRITE);
    write(f,&menuC.pp,sizeof(menuHeaderRec));
    for(i=0;i<numLinks(&menuC.menuCmd);i++) {
        GetLink(&menuC.menuCmd,i,&tg);
        write(f,&tg,sizeof(menurec));
    }
    close(f);

    status.menuEditorMode=type;
    save_status();

}

void menu(char fn[15])
{
    char ch,s[81],done=0;
    struct ffblk f;

    if(!checkpw())
        return;

    sprintf(s,"%s*.mnu",syscfg.menudir);
    findfirst(s,&f,0);
    outchr(12);
    pl("5Menu Files Available to Edit");
    nl();
    do
        npr("0%-20s",f.ff_name);
    while(findnext(&f)!=-1);

    while(!done&&!hangup) {
        nl();
        nl();
        outstr(get_string2(1));
        ch=onek("QIMD\r");
        switch(ch) {
        case 13 : 
            sprintf(s,"%s*.mnu",syscfg.menudir);
            findfirst(s,&f,0);
            outchr(12);
            pl("5Menu Files Available to Edit");
            nl();
            do npr("0%-20s",f.ff_name); 
            while(findnext(&f)!=-1);
            break;
        case 'Q': 
            done=1; 
            break;
        case 'M': 
            nl();
            inputdat("File to Edit",fn,8,0);
            sprintf(s,"%s%s.mnu",syscfg.menudir,fn);
            if(exist(s))
                menued(fn);
            else
                npr("\r\n4%s Not Found\r\n`P",fn);
            break;
        case 'D': 
            nl();
            inputdat("File to Delete",fn,8,0);
            if(!fn[0]) break;
            sprintf(s,"%s%s.mnu",syscfg.menudir,fn);
            if(exist(s))
                unlink(s);
            else
                npr("\r\n4%s Not Found\r\n`P",fn);
            break;
        case 'I': 
            nl();
            inputdat("File to Add",fn,8,0);
            if(!fn[0])
                break;
            sprintf(s,"%s%s.mnu",syscfg.menudir,fn);
            if(!exist(s))
                addmenu(fn);
            else
                npr("\r\n4%s All Ready Exists\r\n`P",fn);
            break;
        }
    } 
    reloadMenu();
}
