#include "link.h"
#include "vardec.h"

void main(void)
{
    printf("%ld\n",sizeof(userrec));
}
