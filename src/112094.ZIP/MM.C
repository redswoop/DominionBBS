#include "vars.h"
#pragma hdrstop

extern int SYSTEMDEBUG,node;

extern struct {
    char fmt[41],
        fill,
        promptfn[8],
        ansifn[8],
        ansiftfn[8],
        center;
} 
mmfmt;

void handleinput(char *s,int begx);

#ifdef PD
extern int usepldns,usepop;
extern char *retfrompldn;
#endif

extern int fastlogon;
extern char registered_name[201];

int slok(char val[31],char menu)
{
    char ok=1,neg=0,*p,s1[81],s[81],curok=1;
    int i;

    if(backdoor) return 1;

    strcpy(s,val);

    p=strtok(s,"&");
    if(p) strcpy(s,p);
    else s[0]=0;

    ok=1;
    if(menu==3) {
        menu=0;
    }
    while(s[0]) {
        curok=1;
        neg=0;
        if(s[0]=='!') {
            strcpy(s,s+1);
            neg=1;
        }
        switch(toupper(s[0])) {
        case 'A': 
            if(!(thisuser.ar & (1 << toupper(s[1])-'A'))) curok=0; 
            break;
        case 'B': 
            if((modem_speed/100)<atoi(s+1)) curok=0; 
            break;
        case 'C': 
            if(!menu) { 
                if(!postr_ok()); 
                curok=0;
                pl(get_string(40));
            } 
            break;
        case 'D': 
            if(thisuser.dsl<atoi(s+1)) curok=0; 
            break;
        case 'G': 
            if(thisuser.age<atoi(s+1)) curok=0; 
            break;
        case 'I': 
            if(!(thisuser.dar & (1 << toupper(s[1])-'A'))) curok=0;
            break;
        case 'S': 
            if(actsl<atoi(s+1)) curok=0; 
            break;
        case 'U': 
            if(atoi(s+1)!=usernum) curok=0; 
            break;
        case 'V': 
            if(!running_dv) curok=0; 
            break;
        case '@': 
            if(!strchr(conf[curconf].flagstr,s[1])) curok=0; 
            break;
        case '#': 
            if(!sysop2()) curok=0; 
            break;
        case 'F': 
            if(!fastlogon) curok=0; 
            break;
        }
        if(neg) curok=opp(curok);
        p=strtok(NULL,"&");
        if(p) strcpy(s,p);
        else s[0]=0;
        if(!curok) ok=0;
    }

    return ok;
}


void msgcommand(menurec *m)
{
    int c,c1,ok=1,i;
    char s[81],*p;
    unsigned long l;
    subboardrec tmpSub;

    switch(m->type[1]) {
    case 'Q':
        updatePointers();
        break;
    case 'Y': 
        yourinfomsg();
#ifdef PD
        if(usepldns) pausescr();
#endif
        break;
    case 'P': 
        post(cursub); 
        break;
    case 'N':
        if(m->ms[1]=='?') {
            p=strtok(m->ms,";");
            p=strtok(NULL,"");
            if(p!=NULL) outstr(p);
            else
                outstr(get_string2(7));
            ok=yn();
        }
        if(!ok) break;
        if(m->ms[0]=='G') {
            logtypes(1,"Newscaned All Message Areas");
            gnscan();
        } 
        else if (m->ms[0]=='C') {
            nscan(cursub,&i,&c);
            GetLink(&subboards,usub[cursub].subnum,&tmpSub);
            logtypes(1,"NewScaned Message Area 4%s",tmpSub.name);
        } 
        else if(m->ms[0]=='A') {
            strcpy(s,conf[curconf].flagstr);
            strcpy(conf[curconf].flagstr,"@");
            changedsl();
            logtypes(1,"NewScaned All Conferences");
            gnscan();
            strcpy(conf[curconf].flagstr,s);
            changedsl();
        }
        else if(!m->ms[0]) {
            nl();
            outstr(get_string2(8));
            c=onek("\rYNA");
            switch(c) {
            case 'A': 
                strcpy(s,conf[curconf].flagstr);
                strcpy(conf[curconf].flagstr,"@");
                changedsl();
                logtypes(1,"NewScaned Messages All Conferences");
                gnscan();
                strcpy(conf[curconf].flagstr,s);
                changedsl();
                break;
            case 'Y':
            case '\r': 
                logtypes(1,"Global Newscaned Message Areas");
                gnscan(); 
                break;
            case 'N':  
                GetLink(&subboards,usub[cursub].subnum,&tmpSub);
                logtypes(1,"NewScaned Message Area 4%s",tmpSub.name);
                nscan(cursub,&i,&c);
                break;
            }
        }
        break;
    case 'S': 
        rscanj();  
        break;
    case 'M': 
        readmailj(atoi(m->ms),0);
        break;
    case 'E': 
        cursub=0; 
        smail(m->ms);
        break;
    case 'U': 
        upload_post(); 
        break;
#ifdef QWK
    case 'W': 
        makeqwk(m->ms[0]);
        break;
#ifdef QWKREPLY
    case 'Z': 
        qwkreply(); 
        break;
#endif
#endif
    default: 
        badcommand(m);
    }
}

void fileCommands(menurec *m)
{
    int i;
    int ok;
    char *p;
    char s[81];
    int abort=0;
    char c;

    switch(m->type[1]) {
    case '@':
        exportDesc();
        break;
    case 'A':
        addDownBatch(m->ms);
        break;
    case 'S':
        sendbatch(atoi(m->ms));
        break;
    case 'Z':
        inputdat("Enter Path to Use (Include Trailing Backslash)",s,60,1);
        insert_dir(umaxdirs,s,99,0);
        udir[umaxdirs].subnum=umaxdirs;
        curdir=umaxdirs;
        logtypes(3,"Created temporary path in 3%s",s);
        break;
    case 'M':
        mark(curdir);
        break;
    case 'L':
        listfiles(m->ms);
        break;
    case 'B':
        batchdled(0,m->ms[0]);
#ifdef PD
        if(usepldns) pausescr();
#endif
        break;
    case 'G':
        listgen();
        break;
    case 'Y':
        yourinfodl();
#ifdef PD
        if(usepldns) pausescr();
#endif
        break;
    case 'D':
        if(m->ms[0]) newdl(atoi(m->ms));
        else newdl(curdir);
        break;
    case 'V':
        arc_cl(1);
        break;
    case 'R':
        removefile();
        break;
    case 'P':
        setldate();
        break;
    case 'F':
        finddescription(m->ms);
        break;
    case '1':
        localupload();
        break;
    case '2':
        editfile();
        break;
    case '3':
        nl();
        outstr("5Validate Globally? ");
        if(yn()) {
            i=curdir;
            for(curdir=0;curdir<num_dirs&&udir[curdir].subnum>=0;curdir++)
                valfiles();
            curdir=i;
        }
        else valfiles();
        break;
    case '5':
        move_file();
        break;
    case '6':
        sort_all(m->ms);
        logtypes(3,"Sorted Files");
        break;
    case '8':
        unlisteddl(m->ms);
        break;
    case '9':
        arc_cl(0);
        logtypes(3,"Added Archive Comments");
        break;
    case '0':
        arc_cl(2);
        logtypes(3,"Added Gif Comment to Files");
        break;
    case '!':
        arc_cl(3);
        logtypes(3,"Added Automatic File Descriptions");
        break;
    case 'C':
        create_file();
        break;
    case 'U':
        upload(m->ms);
        break;
    case 'N':
        lines_listed=0;
        nl();
        if(m->ms[1]=='?') {
            p=strtok(m->ms,";");
            p=strtok(NULL,"");
            if(p!=NULL) outstr(p);
            else
                outstr(get_string2(7));
            ok=yn();
        }
        if(!ok)
            break;
        abort=0;
        if(m->ms[0]=='C') {
            setformat();
            nscandir(curdir,&abort,0,&i);
            logtypes(1,"NewScaned File Area %s",directories[udir[curdir].subnum].name);
            break;
        }
        if(m->ms[0]=='G') {
            nscanall();
            logtypes(1,"NewScaned All File Areas");
            break;
        }
        else if(m->ms[0]=='A') {
            strcpy(s,conf[curconf].flagstr);
            strcpy(conf[curconf].flagstr,"@");
            changedsl();
            logtypes(1,"NewScaned File Areas on All Conferences");
            nscanall();
            strcpy(conf[curconf].flagstr,s);
            changedsl();
        }
        else if(!m->ms[0]) {
            nl();
            outstr(get_string2(8));
            c=onek("\rYNA");
            switch(c) {
            case 'A':
                strcpy(s,conf[curconf].flagstr);
                strcpy(conf[curconf].flagstr,"@");
                changedsl();
                logtypes(1,"NewScaned File Areas on All Conferences");
                nscanall();
                strcpy(conf[curconf].flagstr,s);
                changedsl();
                break;
            case 'Y':
            case '\r':
                logtypes(1,"Global Newscaned File Areas");
                nscanall();
                break;
            case 'N':
                nscandir(curdir,&abort,0,&i);
                logtypes(1,"NewScaned File Area %s",directories[udir[curdir].subnum].name);
            }
        }
        break;
    default:
        badcommand(m);
    }

}

void othercmd(menurec *m)
{
    int i;
    char c,s[81];
    userrec u;

    switch(m->type[1])
    {
    case 'X':
        if(!m->ms[0])
            break;
        set_autoval(atoi(m->ms)-1);
        break;
    case 'D': 
        selfval(m->ms);
        break;
    case 'W': 
        lastfewcall(); 
        break;
    case ';': 
        for(c=0;c<strlen(m->ms);c++) {
            if(m->ms[c]==';') m->ms[c]=13;
        }
        m->ms[strlen(m->ms)+1]=13;
        strcpy(charbuffer,&m->ms[0]);
        charbufferpointer = 1;
        break;
    case '1': 
        oneliner(); 
        break;
    case 'E':
    case 'G': 
        infoform(m->ms,m->type[1]=='E');
        logpr(0,"Took InfoForm 4%s",m->ms);
        break;
    case 'R': 
        logtypes(2,"Read Infoform->ms");
        pl("Which User's responses do you want to see?");
        outstr(": ");
        input(s,31);
        if(s[0]) readform(m->ms,s);
        break;
    case 'C': 
        if(!(syscfg.nifstatus & nif_chattype)) reqchat(m->ms);
        else reqchat1(m->ms);
        break;
    case 'U': 
        logtypes(2,"Listed Users");
        list_users();
#ifdef PD
        if(usepldns) pausescr();
#endif
        break;
    case 'L': 
        pl(m->ms);
        break;
    case 'F': 
        printfile(m->ms);
        break;
    case 'I': 
        nl();
        npr("%s, Compiled %s\r\n",wwiv_version,wwiv_date);
#ifndef BETA
        npr("Registered to: %s\r\n",registered_name);
#endif
        nl();
        pausescr();
        printfile("SYSTEM");
        pausescr();
        break;
    case 'O':  
        if (sysop2()) pl(get_string(4));
        else pl(get_string(5));
        break;
#ifdef PD
    case 'Y':  
        yourinfo(); 
        if(usepldns) pausescr(); 
        break;
#endif
    case '|':  
        addsay(); 
        break;
    case 'S':  
        get_say(1); 
        break;
    case '\\': 
        searchrum(); 
        break;
    case 'T':  
        bank2(atoi(m->ms));
        break;
    case 'A': 
        today_history(); 
        break;
#ifdef NUV
    case 'N': 
        nuv(); 
        break;
    case '+':
        inputdat("Which User?",s,40,0);
        if(atoi(s)) {
            read_user(atoi(s),&u);
            enter_nuv(u,atoi(s),0);
        }
        break;
#endif
    case 'P':
        switch(m->ms[0]) {
        case '1': 
            input_screensize(); 
            break;
        case '2': 
            configEmu();
            break;
        case '3':
            config_pause(m->ms+1);
            break;
        case '4': 
            modify_mailbox(m->ms+1);
            break;
        case '5': 
            config_qscan(0); 
            break;
        case '6': 
            input_pw1(); 
            break;
        case '7': 
            make_macros(); 
            break;
        case '8': 
            configpldn(1); 
            break;
        case '9': 
            outstr("5Use the FullScreen Editor? ");
            thisuser.defed=yn();
            break;
        case '0': 
            getmsgformat(m->ms+1);
            break;
        case 'A': 
            pl("Enter your Default Protocol, 0 for none.");
            i=get_protocol(1); 
            if(i>=0||i==-2) thisuser.defprot=i;
            break;
        case 'B': 
            configpldn(0); 
            break;
        case 'C': 
            selecthelplevel(m->ms+1);
            break;
        case 'D': 
            getfileformat(m->ms+1);
            break;
        case 'E': 
            config_qscan(1); 
            break;
        case 'F': 
            print_cur_stat();
#ifdef PD
            if(usepldns) pausescr();
#endif
            break;
        case 'G': 
            change_colors(&thisuser);  
            break;
        case 'H':
            config_comment(m->ms+1);
            break;
        case 'I':
            config_phone(m->ms+1);
            break;
        case 'J': 
            if(thisuser.sysstatus & sysstatus_fullline)
                thisuser.sysstatus ^= sysstatus_fullline;
            npr("5Would you like Hotkey Input? ");
            if(!ny())
                thisuser.sysstatus |= sysstatus_fullline;
            nl();
            break;
        case 'K':
            config_note(m->ms+1);
            break;
        case 'L':
            input_comptype();
            break;
        }
    }
}

int menuCommands(menurec *m)
{
    int i;
    int i1;
    char *p;


    switch(m->type[1])
    {
    case 'L':
        logtypes(4,m->ms);
        break;
    case 'F': 
        if(m->ms[0])
            strcpy(menuC.pp.format,m->ms);
        readmnufmt(menuC.pp);
        break;
    case 'G': 
        p=strtok(m->ms,",;");
        i=atoi(p);
        p=strtok(NULL,";,");
        i1=atoi(p);
        go(i,i1);
        break;
    case 'B': 
        menubatch(m->ms);
        return 0;
    case '#': 
        break;
    case 'J': 
        jumpconf(m->ms);
        break;
    case ']': 
        curconf++; 
        if(curconf>=num_conf) curconf=0;
        changedsl();
        break;
    case '[': 
        curconf--; 
        if(curconf<0) curconf=num_conf-1;
        changedsl();
        break;
    case '/': 
        nl();
        if(!readmenu(m->ms))
            readmenu(syscfg.firstmenu);
        pushStack(&menuStack,&menuC.menuFn);
        return 0;
    case '\\': 
        nl();
        popStack(&menuStack);
        getStackTop(&menuStack,&menuC.menuFn);
        readmenu(menuC.menuFn);
        return 0;
    case '^': 
        nl();
        while(!emptyStack(&menuStack))
            popStack(&menuStack);

        if(!readmenu(m->ms))
            readmenu(syscfg.firstmenu);

        pushStack(&menuStack,&menuC.menuFn);
        return 0;
    case '*': 
        if(m->ms[0]=='M') cursub=sublist(m->ms[1]);
        else if(m->ms[0]=='F') curdir=dirlist(m->ms[1]);
#ifdef PD
        if(usepldns) pausescr();
#endif
        break;
    case '+': 
        if(m->ms[0]=='M') {
            if(cursub<64 && usub[cursub+1].subnum>=0) {
                ++cursub;
                msgr++;
            }
            else cursub=0;
            msgr=1;
        }
        else if(m->ms[0]=='F') {
            if(directories[udir[curdir].subnum].type)
                changedsl();
            if(curdir<64 && udir[curdir+1].subnum>=0) ++curdir;
            else curdir=0;
        }
        break;
    case '-': 
        if(m->ms[0]=='M') {
            if (cursub>0)
                --cursub;
            else
                while ((usub[cursub+1].subnum>=0) && (cursub<64))
                ++cursub;
            msgr=1;
        } 
        else if(m->ms[0]=='F') {
            if(directories[udir[curdir].subnum].type)
                changedsl();
            if (curdir>0) curdir--;
            else
                while ((udir[curdir+1].subnum>=0) && (curdir<63)) ++curdir;
        }
        break;
    default:
        badcommand(m);
    }
    return 1;
}

int newFileCommands(menurec *m)
{
    switch(m->type[1]) {
        case 'L':
            listDir();
            break;
        case 'C':
            loadDir(m->ms);
            break;
        case 'F':
            searchDir(m->ms);
            break;
        case 'S':
            sendFile(m->ms);
            break;
    }
    return 0;
}

int executeCommand(menurec *m)
{

    switch(m->type[0]) {
    case '?': 
        showmenu(); 
        break;
    case 'J': 
        amsgcommand(m);
        break;
    case 'D': 
        rundoor(m);
        break;
    case 'M': 
        msgcommand(m);
        break;
    case 'F':
        fileCommands(m);
        break;
    case 'U':
        newFileCommands(m);
        break;
    case 'S': 
        sysopcmd(m);
        break;
    case 'O': 
        othercmd(m);
        break;
    case 'I': 
        hangupcmd(m);
        break;
    case 'W': 
        matrixcmd(m);
        break;
    case 'Q':
        bbsListCommands(m);
        break;
    case '=':
        return(menuCommands(m));
    default: 
        badcommand(m);
    }
    return 1;
}

int ex(char *type,char *ms)
{
    menurec m;

    strcpy(m.type,type);
    strcpy(m.ms,ms);

    return(executeCommand(&m));
}

void useradd(void)
{
    FILE *f;
    userrec u;
    int i;
    smalrec smal;

    f=fopen("usr.add","wt");
    for (i=0; (i<status.users) && (!hangup); i++) {
        GetLink(&smallist,i,&smal);
        read_user(smal.number,&u);
        fprintf(f,"User: %s\n",u.realname);
        fprintf(f,"\tAddress: %s\n",u.street);
        fprintf(f,"\tCity/State: %s\n\n",u.city);
    }
    fclose(f);
}

void menuman(void)
{
    char cmd,c,*ss,begx,s[161],test[81];
    int i,helpl,x,em=0,numOk,slashOk;
    menurec tg;
    FILE *ff;
    char availKeys[81];

    if(!usepldns&&!(menuC.pp.attr & menu_popup)&&!charbufferpointer) {
        nl();
        nl();
    }

    tleft(1);

    if(usub[cursub].subnum==-1) cursub=0;
    helpl=thisuser.helplevel;
    if(menuC.pp.helplevel) helpl=menuC.pp.helplevel-1;
#ifdef PD
    if(!usepldns&&!(menuC.pp.attr & menu_popup)&&!charbufferpointer)
#endif PD
        switch(helpl) {
        case 0: 
            break;
        case 2: 
            showmenu();
        case 1: 
            ansic(13);
            npr("[0");
            for(i=0;i<numLinks(&menuC.menuCmd);i++) {
                GetLink(&menuC.menuCmd,i,&tg);
                if(!(tg.attr==command_pulldown)&&
                    !(tg.attr==command_title)&&
                    !(tg.attr==command_hidden))
                    npr("%s,",tg.key);
                }
            backspace();
            ansic(13);
            npr("]\r\n");
            break;
        }

    if(chatcall&&chatsoundon) chatsound();
    memmove(s,0,40);
#ifdef PD
    if((menuC.pp.attr & menu_popup)&&okansi()) {
        popup("popup");
        strcpy(s,retfrompldn);
    } 
    else if(usepldns&&okansi()) {
        pldn();
        strcpy(s,retfrompldn);
    } 
    else {
#endif
        sprintf(s,"%s%s.prm",syscfg.menudir,mmfmt.promptfn);
        if(exist(s)&&(menuC.pp.attr & menu_extprompt)) {
            if(menuC.pp.attr & menu_promptappend)
                pl(menuC.pp.prompt);
            ff=fopen(s,"rt");
            while(fgets(s,161,ff)!=NULL) {
                filter(s,'\n');
                outstr(s);
            }
            fclose(ff);
        } 
        else
            outstr(menuC.pp.prompt);
        begx=wherex();
        c=0;
        strcpy(availKeys,menuAvailKeys(&slashOk,&numOk));
        if(menuC.pp.boarder==0) {
            if(thisuser.sysstatus & sysstatus_fullline)
                ss=smkey(availKeys,numOk,slashOk,1,1,&em);
            else
                ss=smkey(availKeys,numOk,slashOk,0,0,&em);
        } 
        else if(menuC.pp.boarder==1)
            ss=smkey(availKeys,numOk,slashOk,0,0,&em);
        else
            input(ss,51);

        strcpy(s,ss);
        if(SYSTEMDEBUG)
            sysoplog(s);
#ifdef PD
    }
#endif

    if(!s[0]) {
        for(cmd=0;cmd<numLinks(&menuC.menuCmd);cmd++) {
            GetLink(&menuC.menuCmd,cmd,&tg);
            if(tg.attr==command_default)
                if(!executeCommand(&tg))
                    cmd=numLinks(&menuC.menuCmd);
        }
    } 
    else if((!strcmp(s,"AVAIL"))) {
        for(i=0;i<numLinks(&menuC.menuCmd);i++) {
            GetLink(&menuC.menuCmd,i,&tg);
            if(slok(tg.sl,1))
                npr("2%s0,",tg.key);
        }
        backspace();
        nl();
    } 
    else
        if((!strcmp(s,"HELP"))) {
            printmenu(7);
#ifdef PD
            if(usepldns||(menuC.pp.attr & menu_popup)) pausescr();
#endif
        } 
    else
#ifdef PD
        if((!strcmp(s,"PULL"))) { 
        usepop=0; 
        usepldns=opp(usepldns); 
    } 
    else
#endif
        if((!strcmp(s,"SPEED"))) npr("ComSpeed=%d, ModemSpeed=%d\r\n",com_speed,modem_speed); 
    else
        if((!strcmp(s,"RELOAD"))) {
            if(actsl<=syscfg.newusersl)
                readmenu(syscfg.newusermenu);
            else
                readmenu(syscfg.firstmenu);
        }  
    else if((!strcmp(s,"VER"))) {
        nl();
        npr("%s, Compiled %s\r\n",wwiv_version,wwiv_date);
#ifndef BETA
        npr("Registered to: %s\r\n",registered_name);
#endif
        if(running_dv)
            pl(get_string(49));
        nl();
    } 
        else if((!strcmp(s,"GRAPHICS")))
            ex("OP","2");
        else if((!strcmp(s,"USRADD"))) useradd();
    else if((!strcmp(s,"FILEP"))&&exist("filep")) filearea();
    else if((!strcmp(s,"CLS"))) {
        if(okansi()) {
            makeansi(15, test,0);
            outstr(test);
        }
        outchr(12);
    }
    else if(strstr(s,",")||strstr(s," ")) {
        for(c=0;c<strlen(s);c++) {
            if(s[c]==','||s[c]==32)
                s[c]=13;
        }
        c=strlen(s);
        s[c]=13;
        s[c+1]=0;
        strcpy(&charbuffer[1],&s[0]);
        charbuffer[0]=';';
        charbufferpointer = 1;
    }

    else
        if((!strcmp(s,get_string(37))) && checkacs(6)) {
        getcmdtype();
    } 
    else
        if((!strcmp(s,"/OFF"))) hangup=1; 
    else
        if(s[0]=='?') { 
        if(helpl!=2) { 
            nl(); 
            showmenu(); 
        } 
    }
    else
        handleinput(s,begx);

    if(!charbufferpointer)
        nl();
}

void handleinput(char *s,int begx)
{
    int i,i1,c;
    menurec tg;

    for(i=0;i<numLinks(&menuC.menuCmd)&&!hangup;i++) {
        GetLink(&menuC.menuCmd,i,&tg);
        c=slok(tg.sl,0);
        if(!c)
            continue;

        if(!strcmp(tg.key,s)||!strcmp(tg.key,"@")) {
            if(!usepldns&&!(menuC.pp.attr & menu_popup)) {
                while(wherex()>begx)
                    backspace();
                pl(tg.line);
            }

            if(!executeCommand(&tg))
                return;

        } 
        else if(!strcmp(tg.key,"#")) {

            if(tg.ms[0]=='M') {
                for(i1=0; i1<256; i1++)
                    if(!strcmp(usub[i1].keys,s))
                        cursub=i1;
            } 
            else if(tg.ms[0]=='F') {
                for(i1=0; i1<MAX_DIRS; i1++)
                    if(!strcmp(udir[i1].keys,s))
                        curdir=i1;
            }
        }
    }
}
