#include "vars.h"
#pragma hdrstop

long QuoteLen;

char *ini(char name[161])
{
    char o[81];
    int i=0,p=0;
    userrec u;

    strcpy(u.name,strupr(name));
    strcpy(name,pnam(&u));

    memset(o,0,81);

    for(i=0;name[i];i++) {
        if ((name[i]>='A') && (name[i]<='Z'))
            o[p++]=name[i];
    }

    return(o);
}

int DisplayQuote(int Len)
{
    int i,i1,i2;
    char *p;
    char s[81];
    long cur=0;
    int numLines;

    numLines=0;

    i1=i2=0;
    for(i=0;i<Len;i++) {
        if(quote[i]==13)
            i2++;
        if(quote[i]==10)
            i1++;
    }
    printf("\\r=%d , \\n=%d, len=%d\n",i2,i1,Len);

    while(cur<Len) {
        i1=0;
        while(quote[cur]!=10&&quote[cur]!=13&&cur<QuoteLen) {
            s[i1++]=quote[cur++];
        }
        cur++;
        s[i1]=0;
        npr("%d: %s",numLines+1,s);
        nl();
        numLines++;
    }

    return numLines;
}

void get_quote()
{
    char s[141];
    int maxLine;
    int Start,Stop;
    int done=0;


    while (!done&&!hangup) {
        maxLine=DisplayQuote(QuoteLen);
        Start=Stop=0;
        npr("5Quote from line 1-%d? (A=All,?=relist,Q=quit) ",maxLine);
        input(s,3);
        if(atoi(s)) {
            Start=atoi(s);
            npr("5End on what line %d-%d? (Q=quit) ",Start,maxLine);
            input(s,3);
            if(atoi(s))
                Stop=atoi(s);
        }
        else if (s[0]=='A') {
            Start=1;
            Stop=maxLine;
        }
        else if (s[0]=='Q')
            done=1;

        if (Stop) {
            npr("5Quote line(s) %d-%d? ",Start,Stop);
            if (ny())
                done=1;
        }
    } 

    charbufferpointer=0;
    if (Start && Stop) {
        bquote=Start;
        equote=Stop;
    }
}




int getnextword(char *buf,long len, long *pos,char *s)
{
    long i,i1=0;
    int ret=0;

    i= *pos;

    while(i<len&&buf[i]!=32&&buf[i]!=13&&buf[i]!=10&&i1<81)
        s[i1++]=buf[i++];

    if(buf[i]==13||buf[i]==10)
        ret=1;

    *pos=i+1;
    s[i1]=0;

    return ret;
}

void addline(char *b, char *s, long *ll)
{
    strcpy(&(b[*ll]),s);
    (*ll)+=strlen(s);
    b[(*ll)++]='\r';
}

void quote_jam(char *text,long len,hdrinfo *hdr)
{
    char *outbuf;
    long cur=0,oln=0;
    char curword[81];
    char curline[81];
    char initials[21];
    int EOLFlag=0,thisEOL;
    int StartLine=1;
    int EndLine=0;
    int DontGet=0;
    int i,i1,i2;

    if(quote)
        farfree(quote);

    outbuf=(char *)malloc(len+1000L);
    if(!outbuf)
        return;
    memset(outbuf,0,len+1000L);

    strcpy(initials,ini(hdr->who_from));
    strcat(initials,"> ");

    i1=i2=0;
    for(i=0;i<len;i++) {
        if(text[i]==13)
            i2++;
        if(text[i]==10)
            i1++;
    }
    printf("\\r=%d , \\n=%d, len=%d\n",i2,i1,len);
    pausescr();
    while(cur<len||DontGet) {
        if(!DontGet)
            thisEOL=getnextword(text,len,&cur,curword);
        if(thisEOL&&!EOLFlag)
                EOLFlag=1;
        else if(EOLFlag&&thisEOL) {
            EndLine=1;
            EOLFlag=0;
        }

        if(StartLine) {
            StartLine=0;
            strcpy(curline,initials);
        }
        if((strlen(curword)+strlen(curline))>72) {
            DontGet=1;
            EndLine=1;
        } else {
            DontGet=0;
            strcat(curline,curword);
            strcat(curline," ");
        }

        if(strlen(curline)>72)
            EndLine=1;

        if(EndLine) {
            addline(outbuf,curline,&oln);
            if(!EOLFlag)
                addline(outbuf,initials,&oln);
            StartLine=1;
            EOLFlag=0;
            EndLine=0;
        }
    }

    quote=outbuf;
    QuoteLen=oln;
}
