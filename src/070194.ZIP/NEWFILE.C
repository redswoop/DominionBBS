#include <alloc.h>
#include <stdio.h>
#include <dir.h>
#include <dos.h>
#include <fcntl.h>
#include <sys\stat.h>
#include <io.h>
#include <string.h>
#include <stdlib.h>

typedef struct {
    char name[51],
         acs[31];
    unsigned long
         permissions;
} dirRec;

#define File_val 0x0001
#define File_priv 0x0002
#define File_free 0x0004
#define File_unAvail 0x0008
#define File_extended 0x0010
#define File_direc 0x0020
//#define File_ 0x

typedef struct {
    char fn[13],
         description[51],
         uploader[31];
    int  points,
         owner;
    unsigned long
         ulDate,
         attr,
         size;
} fileRec;

struct FilesF {
    fileRec data;
    struct FilesF *next;
};

typedef struct FilesF Files;

typedef struct {
    dirRec d;
    int num;
    Files *head;
    char parent[MAXPATH];
    char current[14];
} PWDrec;

Files *FindItem(PWDrec *file,int which)
{
	int i;
    Files *p=file->head;
	
    if(which<0||which>file->num)
		return NULL;

    if(!which)
        return p;

	for(i=0;i<which;i++)
        p=p->next;
		
	return p;			
}

int GetItem(PWDrec *file,int which,fileRec *v)
{
    Files *p;
	
    if(which<0||which>file->num)
		return 1;

    p=FindItem(file,which);
    (*v)=p->data;
	return 0;
}

int PutItem(PWDrec *file,int which,fileRec *v)
{
    Files *p;
	
    if(which<0||which>file->num)
		return 1;

    p=FindItem(file,which);
    p->data=(*v);
	return 0;
}

int InsertList(PWDrec *file,int as,fileRec v)
{
    Files *p,*q;
	
/*    if(as<0||as>(numItems+1)) {
		return 1;
    }
*/

    if(!as) {
        if(file->num<1) {
            file->head=(Files *)malloc(sizeof(Files));
            if(file->head==NULL) {
                puts("argh 1!");
                exit(0);
            }
            file->head->data=v;
            file->head->next=0;
        } else {
            q=(Files *)malloc(sizeof(Files));
            if(q==NULL) {
                puts("argh 2!");
                exit(0);
            }
            q->data=v;
            q->next=file->head;
            file->head=q;
        }
        file->num++;
        return 0;
    }
    p=FindItem(file,as-1);
    q=(Files *)malloc(sizeof(Files));
    if(q==NULL) {
        puts("argh 3!");
        exit(0);
    }
    q->data=v;
    q->next=p->next;
    p->next=q;
    file->num++;
	return 0;
}

int DeleteItem(PWDrec *file,int which)
{
    Files *p,*q;
	
    if(which<0||which>file->num)
		return 1;

    file->num--;

    if(!which) {
        p=file->head;
        file->head=p->next;
        farfree(p);
        return 0;
    }
    p=FindItem(file,which - 1);
    q=FindItem(file,which);
    p->next=q->next;
    farfree(q);
	return 0;
}

PWDrec PWD;

void destroyList()
{
    while(PWD.num)
        DeleteItem(&PWD,0);
}

int comparefn(fileRec *a,fileRec *b)
{
    return(strcmp(a->fn,b->fn));
}



void quicksort(int l,int r,PWDrec *list)
{
    register int i,j;
    fileRec a,a2,x;

    i=l; 
    j=r;
    GetItem(list,(l+r)/2,&x);
    do {
        GetItem(list,(i),&a);
        while (comparefn(&a,&x)<0) {
            GetItem(list,++i,&a);
        }
        GetItem(list,j,&a2);
        while (comparefn(&a2,&x)>0) {
            GetItem(list,--j,&a2);
        }
        if (i<=j) {
            if (i!=j) {
                PutItem(list,i,&a2);
                PutItem(list,j,&a);
            }
            i++;
            j--;
        }
    } 
    while (i<j);
    if (l<j)
        quicksort(l,j,list);
    if (i<r)
        quicksort(i,r,list);
}



void loadDir(char *root,char *fn)
{
    int i,num=0;
    char s[MAXPATH];
    fileRec f;
    struct find_t t;

    destroyList();
/*    sprintf(s,"%s\\%s.tdr",root,fn);
    i=open(s,O_RDWR|O_BINARY);
    if(i<0)
        return;
    read(i,&PWD.d,sizeof(dirRec));
    close(i);*/
    sprintf(s,"%s\\%s\\*.*",root,fn);
    printf("Opening %s\n",s);
    i=_dos_findfirst(s,FA_ARCH|FA_HIDDEN|FA_SYSTEM|FA_RDONLY|FA_DIREC,&t);
    while(!i) {
        f.attr=0;
        strcpy(f.fn,t.name);
        if(t.attrib & FA_DIREC)
            f.attr |= File_direc;
        InsertList(&PWD,num,f);
        num++;
        i=_dos_findnext(&t);
    }
    quicksort(0,PWD.num,&PWD);
}

void listDir(void)
{
    int i;
    fileRec f;

    for(i=0;i<PWD.num;i++) {
        GetItem(&PWD,i,&f);
        puts(f.fn);
    }
    printf("%d files\n",PWD.num);
}

void changeDir(void)
{
    char s[MAXPATH],*p,s1[MAXPATH];
    int i;

    printf("NewPath: ");
    gets(s);
    if(!strcmp(s,"..")) {
        strcpy(s,PWD.parent);
        for(i=strlen(s);i&&s[i]!='\\';i--);
        strcpy(s1,&s[i+1]);
        s[i]=0;
        strcpy(PWD.current,s1);
        strcpy(PWD.parent,s);
    } else if(!strcmp(s,"\\")) {
        strcpy(PWD.current,"DLS");
        strcpy(PWD.parent,"D:");
    } else {
        sprintf(s1,"%s\\%s",PWD.parent,PWD.current);
        strcpy(PWD.parent,s1);
        strcpy(PWD.current,s);
    }

    loadDir(PWD.parent,PWD.current);
}

void main(void)
{
    int done=0;
    char s[81];

    PWD.num=0;
    strcpy(PWD.parent,"D:");
    strcpy(PWD.current,"DLS");

    loadDir(PWD.parent,PWD.current);
    while(!done) {
        printf("%s\\%s> ",PWD.parent,PWD.current);
        gets(s);
        if(!stricmp(s,"dir"))
            listDir();
        else if(!stricmp(s,"cd"))
            changeDir();
        else if(!stricmp(s,"exit"))
            done=1;
    }
}
