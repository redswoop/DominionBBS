#include "vars.h"

#pragma hdrstop

#include <dir.h>
#include <math.h>
#include "ansi.h"

extern char menuat[15];


#define GODOWN(x,y) gotoxy(y+1,x+1);

void bargraph1(int percent)
{
    int x;
    for(x=0;x<percent/2;x++)
        printf("%c",219);
}

void dotopinit(char fn[40],int per)
{
    int i;

    if(per);

    /*      GODOWN(1,3);
              for(i=0;i<48;i++) printf(" ");
              GODOWN(1,3);
              textattr(11);
              cprintf("Reading");
              textattr(15);
              cprintf(" %s",fn);
              GODOWN(2,3);
              bargraph1(per);*/
    textattr(1);
    cprintf("� ");
    textattr(9);
    cprintf("Reading %s\r\n",fn);
}

void init(int show)
{
    char s[161],*buf,ch,*ss,s1[81],s2[10];
    int i,i1,i2,sm,cp,n,f;
    long l;
    union REGS r;
    struct date today;
    int resaveconfig=0;
    //  votingrec v;

    crttype=peekb(0x0040,0x0049);
    if (crttype==7)
        scrn=MK_FP(0xb000,0x0000);
    else
        scrn=MK_FP(0xb800,0x0000);
    r.h.ah=15;
    int86(0x10,&r,&r);
    sm=r.h.al;
    if (r.h.ah!=80) {
        printf("\n\nYou must be in 80 column mode to run BBS.\n\n");
        err(6,"","In Init()");
    }
    if ((sm==4) || (sm==5) || (sm==6)) {
        printf("\n\nYou must be in text mode to run BBS.\n\n");
        err(6,"","In Init()");
    }
    defscreenbottom=(int) peekb(0x0000,0x0484);
    if (defscreenbottom<24)
        defscreenbottom=24;
    if (defscreenbottom>63)
        defscreenbottom=24;
    screenbottom=defscreenbottom;
    screenlen=160*(screenbottom+1);

    if(!exist("exitdata.dom")) restoring_shrink=0; 
    else restoring_shrink=1;
    if (!restoring_shrink&&!show) {
        clrscr();
        memmove(scrn,ANSIHEADER,4000);
        gotoxy(1,12);
    }
    strcpy(cdir,"X:\\");
    cdir[0]='A'+getdisk();
    getcurdir(0,&(cdir[3]));
    userfile=-1;
    configfile=-1;
    statusfile=-1;
    dlf=-1;
    curlsub=-1;
    curldir=-1;
    oldx=0;
    oldy=0;
    itimer();
    use_workspace=0;
    chat_file=0;
    do_event=0;
    sysop_alert=0;
    global_handle=0;
    confmode=1;


    getdate(&today);
    if (today.da_year<1993) {
        printf("\r\nYou need to set the date & time before running the BBS.\n");
        err(7,"","In Init()");
    }

    if(!restoring_shrink&&!show) {
        //      GODOWN(2,3);
        //      bargraph(0);
        dotopinit("Config.dat",10);
    }

    configfile=open("CONFIG.DAT",O_RDWR | O_BINARY);
    if (configfile<0) {
        printf("\n\nConfig.Dat, Main Configuration File, Not Found!!.\n");
        err(1,"Config.dat","In Init()");
    }

    read(configfile,(void *) (&syscfg), sizeof(configrec));
    read(configfile,&nifty,sizeof(niftyrec));
    close(configfile);

    if (!syscfg.primaryport)
        ok_modem_stuff=0;

    if(!restoring_shrink&&!show)
        dotopinit("Checking Directories",15);


    for(i=0;i<6;i++) {
        switch(i) {
        case 0: 
            strcpy(s2,"Data"); 
            strcpy(s,syscfg.datadir); 
            break;
        case 1: 
            strcpy(s2,"Afiles"); 
            strcpy(s,syscfg.gfilesdir); 
            break;
        case 2: 
            strcpy(s2,"Temp"); 
            strcpy(s,syscfg.tempdir); 
            break;
        case 3: 
            strcpy(s2,"Msgs"); 
            strcpy(s,syscfg.msgsdir); 
            break;
        case 4: 
            strcpy(s2,"Batch"); 
            strcpy(s,syscfg.batchdir); 
            break;
        case 5: 
            strcpy(s2,"Menus"); 
            strcpy(s,syscfg.menudir); 
            break;
        }

        sprintf(s1,"%snul",s);

        if (!exist(s1)) {
            printf("\n\nYour %s directory isn't valid!  Now set to: %s\n",s2,s);
            printf("\nEnter new value: ");
            gets(s);
            printf("%s\n",s);
            if(s[strlen(s)-1]!='\\')
                strcat(s,"\\");
            printf("%s\n",s);
            sprintf(s1,"%snul",s);
            printf("%s\n",s1);
            if(!exist(s1)) {
                strcpy(s1,s);
                s1[strlen(s1)-1]=0;
                if(mkdir(s1))
                    err(1,s1,"In Init()");
            }
            switch(i) {
            case 0: 
                strcpy(syscfg.datadir,s); 
                break;
            case 1: 
                strcpy(syscfg.gfilesdir,s); 
                break;
            case 2: 
                strcpy(syscfg.tempdir,s); 
                break;
            case 3: 
                strcpy(syscfg.msgsdir,s); 
                break;
            case 4: 
                strcpy(syscfg.batchdir,s); 
                break;
            case 5: 
                strcpy(syscfg.menudir,s); 
                break;
            }
            resaveconfig=1;
        }
    }

    if(resaveconfig) {
        configfile=open("CONFIG.DAT",O_RDWR | O_BINARY);
        if (configfile<0) {
            printf("\n\nConfig.Dat, Main Configuration File, Not Found!!.\n");
            err(1,"Config.dat","In Init()");
        }
        write(configfile,(void *) (&syscfg), sizeof(configrec));
        write(configfile,&nifty,sizeof(niftyrec));
        close(configfile);
    }


    if(!restoring_shrink&&!show)
        dotopinit("Status.dat",20);

    sprintf(s,"%sSTATUS.DAT",syscfg.datadir);
    statusfile=open(s,O_RDWR | O_BINARY);
    if (statusfile<0) {
        printf("\n\n\n%sStatus.Dat not found!\n\n",syscfg.datadir);
        err(1,s,"In Init()");
    }

    read(statusfile,(void *)(&status), sizeof(statusrec));
    close(statusfile);
    status.wwiv_version=wwiv_num_version;
    smallist=(smalrec *) mallocx((long)syscfg.maxusers * (long)sizeof(smalrec));

    screensave.scrn1=(char *)mallocx(screenlen);

    read_in_file("mnudata.dat",(menus),50);

    sprintf(s,"%suser.idx",syscfg.datadir);
    i=open(s,O_RDWR | O_BINARY);
    if (i<0) {
        reset_files(0);
    } 
    else {
        read(i,(void *) (smallist), (sizeof(smalrec) * status.users));
        close(i);
    }


    subboards=(subboardrec *) mallocx(200*sizeof(subboardrec));
    directories=(directoryrec *)mallocx(200*sizeof(directoryrec));
    if(!restoring_shrink&&!show)
        dotopinit("Config.dat",40);

    sprintf(s,"%sSUBS.DAT",syscfg.datadir);
    i=open(s,O_RDWR | O_BINARY);
    if (i<0) {
        printf("\n\n%sSubs.Dat not found!",syscfg.datadir);
        err(1,s,"In Init()");
    }
    num_subs=(read(i,subboards, (200*sizeof(subboardrec))))/
        sizeof(subboardrec);
    if(subboards[0].postacs[0])
        subboards[0].postacs[0]=0;
    if(subboards[0].readacs[0])
        subboards[0].readacs[0]=0;
    if(!(subboards[0].attr & mattr_private)) {
        togglebit((long *)&subboards[0].attr,mattr_private);
        strcpy(subboards[0].name,"Private Mail");
        strcpy(subboards[0].filename,"email");
        subboards[0].conf='@';
    }
    lseek(i,0L,SEEK_SET);
    write(i,&subboards[0],sizeof(subboardrec));
    close(i);

    if(!restoring_shrink&&!show) {
        dotopinit("Subs.dat",50);
    }

    sprintf(s,"%sDIRS.DAT",syscfg.datadir);
    i=open(s,O_RDWR | O_BINARY);
    if (i<0) {
        printf("\n\n%sDirs.dat Not found!\n\n",syscfg.datadir);
        err(1,s,"In Init()");
    }

    num_dirs=(read(i,directories, (200*sizeof(directoryrec))))/
        sizeof(directoryrec);
    close(i);
    sprintf(s,"%snul",directories[0].dpath);
    if(!exist(s)) {
        printf("\n\nYour SysOp directory is invalid!\n");
        printf("Now Set to: %s\n\n",directories[0].dpath);
        err(1,directories[0].dpath,"In Init()");
    }

#ifdef OLDFIDO
    sprintf(s,"%sfnet.dat",syscfg.datadir);
    i=open(s,O_BINARY|O_RDWR|O_CREAT,S_IREAD|S_IWRITE);
    read(i,&fnet,sizeof(fnet));
    close(i);
#endif

    if(!restoring_shrink&&!show)
        dotopinit("Protocol.dat",60);

    sprintf(s,"%sprotocol.dat",syscfg.datadir);
    i=open(s,O_RDWR | O_BINARY);
    if(i<0) {
        printf("\n\n%sProtocol.dat Not Found\n",syscfg.datadir);
        err(1,s,"In Init()");
    }
    numextrn=(read(i,(void *)&proto,20*sizeof(protocolrec)))/
        sizeof(protocolrec);
    close(i);

    sprintf(s,"%sRESULTS.DAT",syscfg.datadir);
    i=open(s,O_RDWR | O_BINARY);
    if (i>0) {
        l=filelength(i);
        num_result_codes=(read(i,result_codes,(unsigned) l))/sizeof(resultrec);
        close(i);
    } 
    else {
        end_bbs(noklevel);
    }


    if(!restoring_shrink&&!show) {
        dotopinit("Conf.dat",70);
    }

    sprintf(s,"%sconf.dat",syscfg.datadir);
    i=open(s,O_RDWR | O_BINARY);
    if(i<0) {
        printf("\n\n%sConf.dat Not Found!\n\n",syscfg.datadir);
        err(1,s,"In Init()");
    }
    num_conf=(read(i,(void *)&conf[0],20*sizeof(confrec)))/ sizeof(confrec);
    if(conf[0].sl[0])
        conf[0].sl[0]=0;
    close(i);


    if(!restoring_shrink&&!show) {
        dotopinit("Archive.dat",70);
    }

    sprintf(s,"%sarchive.dat",syscfg.datadir);
    i=open(s,O_BINARY|O_RDWR);
    if(i<0) {
        printf("\n\n%sArchive.dat Not Found\n",syscfg.datadir);
        err(1,s,"In Init()");
    }
    read(i,&xarc[0],8*sizeof(xarc[0]));
    close(i);



    /*  sprintf(s,"%sVOTING.DAT",syscfg.datadir);
          f=open(s,O_RDWR | O_BINARY);
          if (f>0) {
            n=(int) (filelength(f) / sizeof(votingrec)) -1;
            for (i=0; i<n; i++) {
              lseek(f,(long) i * sizeof(votingrec),SEEK_SET);
              read(f,(void *)&v,sizeof(votingrec));
              if (v.numanswers)
                questused[i]=1;
            }
            close(f);
          }*/

    if(!restoring_shrink&&!show) {
        dotopinit("Modem.dat",70);
    }

    sprintf(s,"%sMODEM.DAT",syscfg.datadir);
    i=open(s,O_RDWR | O_BINARY);
    if (i>0) {
        l=filelength(i);
        modem_i = mallocx(l);
        read(i,modem_i, (unsigned) l);
        close(i);
    } 
    else {
        printf("\n\n%sModem.Dat not found!\n\n",syscfg.datadir);
    }

    read_user(1,&thisuser);
    cursub=0;
    fwaiting=numwaiting(&thisuser);

    sl1(2,status.date1);

    if (ok_modem_stuff) {
        initport(syscfg.primaryport);
        set_baud(syscfg.baudrate[syscfg.primaryport]);
    }
    if (syscfg.sysconfig & sysconfig_no_local)
        topdata=0;
    else
        topdata=status.net_edit_stuff;

    ss=getenv("PROMPT");
    strcpy(newprompt,"PROMPT=BBS: ");
    if (ss)
        strcat(newprompt,ss);
    else
        strcat(newprompt,"$P$G");
    sprintf(dszlog,"%s\\BBSDSZ.LOG",cdir);
    sprintf(s,"DSZLOG=%s",dszlog);
    i=i1=0;
    while (environ[i]!=NULL) {
        if (strncmp(environ[i],"PROMPT=",7)==0)
            xenviron[i1++]=newprompt;
        else
            if (strncmp(environ[i],"DSZLOG=",7)==0)
            xenviron[i1++]=strdup(s);
        else {
            if (strncmp(environ[i],"BBS=",4) && (strncmp(environ[i],"WWIV_FP=",8)))
                xenviron[i1++]=environ[i];
        }
        ++i;
    }
    if (!getenv("DSZLOG"))
        xenviron[i1++]=strdup(s);
    if (!ss)
        xenviron[i1++]=newprompt;

    sprintf(s,"BBS=%s",wwiv_version);
    xenviron[i1++]=s;

    xenviron[i1]=NULL;

    for (i=0; i<20; i++)
        questused[i]=0;

    if(!restoring_shrink&&!show)
        dotopinit("Final Data",95);


    time_event=((double)syscfg.executetime)*60.0;
    last_time=time_event-timer();
    if (last_time<0.0)
        last_time+=24.0*3600.0;
    do_event=0;
    if (status.callernum!=65535) {
        status.callernum1=(long)status.callernum;
        status.callernum=65535;
        save_status();
    }
    frequent_init();
    if (!restoring_shrink&&!show && !already_on) {
        remove_from_temp("*.*",syscfg.tempdir,0);
        remove_from_temp("*.*",syscfg.batchdir,0);
    }
    if(!restoring_shrink&&!show) menuat[0]=0;
    lecho=ok_local();
    quote=NULL;
    bquote=0;
    equote=0;

    daylight=0;

#ifdef MOUSE
    initpointer(1);
#endif

    if (!restoring_shrink&&!show) {
        /*      GODOWN(2,3);
                      bargraph(100);
                      GODOWN(1,3);*/
        cprintf("Completed Loading - ");
        textattr(10);
        cprintf("Entering WFC\n\n\n");
    }

}

void end_bbs(int lev)
{
    sl1(1,"");
    if (ok_modem_stuff) closeport();
    dtr(0);
    clrscrb();
    textattr(9);
    cprintf("\n� ");
    textattr(15);
    cprintf("%s is outta here!\n\n",wwiv_version);
    _setcursortype(2);
    asm mov ax,0x1003;
    asm mov bl,0x1;
    asm int 0x10;

    exit(lev);
}
