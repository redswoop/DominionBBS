#include "vars.h"
#pragma hdrstop

// Pointer type to keep linked list
struct baselist {
    subboardrec b;
    struct baselist *next;
};

typedef struct baselist bases;

struct Base {
    bases *head;
    int num;
};

typedef struct Base Sub;

bases *FindItem(Sub *Subs,int which)
{
	int i;
    bases *p=Subs->head;
	
    if(which<0||which>Subs->num)
		return NULL;

    if(!which)
        return p;

	for(i=0;i<which;i++)
		p=p->next;
		
	return p;			
}

int GetItem(Sub *Subs,int which,videorec *v)
{
    bases *p;
	
    if(which<0||which>Subs->num)
		return 1;
		
    p=FindItem(Subs,which);
	(*v)=p->v;
	return 0;
}

int PutItem(Sub *Subs,int which,subboardrec *b)
{
    bases *p;
	
    if(which<0||which>Subs->num)
		return 1;
		
    p=FindItem(Subs,which);
    p->b=(*b);
	return 0;
}

int InsertList(Sub *Subs,int as,subboardrec *b)
{
    bases *p,*q;
	
    if(as<0||as>(Subs->num+1))
		return 1;

    Subs->num++;

    if(!as) {
        if(Subs->head==0) {
            Subs->head=(bases *)malloc(sizeof(bases));
            Subs->head->next=0;
            Subs->head->b=(*b);
        } else {
            q=(bases *)malloc(sizeof(bases));
            q->b=(*b);
            q->next=Subs->head;
            Subs->head=q;
        }
        return 0;
    }
    p=FindItem(Subs,as-1);
    q=(bases *)malloc(sizeof(bases));
    q->b=(*b);
	q->next=p->next;
	p->next=q;	
	return 0;
}

int DeleteItem(Sub *Subs,int which)
{
    bases *p,*q;
	
    if(which<0||which>Subs->num)
		return 1;

    Subs->num--;

    if(!which) {
        p=Subs->head;
        Subs->head=p->next;
        farfree(p);
        return 0;
    }
    p=FindItem(Subs,which - 1);
    q=FindItem(Subs,which);
    p->next=q->next;
    farfree(q);
	return 0;
}
