#include <stdlib.h>
#include <fcntl.h>
#include <io.h>

typedef struct {
    char rumour[81],
    by[31],
    an;
} 
rumourrec;

int main(int argc,char **argv)
{
    char s[81];
    long len;
    int i;
    int f;
    int whichDel;
    rumourrec rumours[100];

    f=open("rumours.dat",O_RDWR|O_BINARY);
    if(f<0)
        return 2;

    len=filelength(f);

    read(f,(void *)&rumours[0],len);
    close(f);

    if(argc!=2) {
        for(i=0;i<(len/sizeof(rumourrec));i++)
            printf("%d: %s\n",i,rumours[i].rumour);
        gets(s);
        whichDel=atoi(s);
    } else
        whichDel=atoi(argv[1]);

    f=open("rumours.dat",O_RDWR|O_BINARY|O_TRUNC);
    for(i=0;i<(len/sizeof(rumourrec));i++) {
        if(i!=whichDel)
            write(f,&rumours[i],sizeof(rumourrec));
    }

    close(f);
    return 0;
}
