#pragma hdrstop

#include <alloc.h>
#include <fcntl.h>
#include <sys/stat.h>
#include "link.h"
#include "stack.h"

int pushCount=0;

int emptyStack(StackContainer *s)
{
    if(s->list.num)
        return 0;

    return 1;
}

void createStack(StackContainer *s,long size)
{
    int i;

    s->itemSize=size;
    createList(&s->list,size);
}

int deleteStack(StackContainer *s)
{
    int i;

    deleteList(&s->list);

    return 0;
}

int popStack(StackContainer *s)
{
    if(!emptyStack(s))
        return(DeleteLink(&s->list,0));

    return -1;
}

int pushStack(StackContainer *s,void *data)
{
    return(InsertLink(&s->list,0,data));
}

int getStackItem(StackContainer *s,void *data,int which)
{
    if(!emptyStack(s))
        return(GetLink(&s->list,which,data));

    return -1;
}

int getStackTop(StackContainer *s,void *data)
{
    return(GetLink(&s->list,0,data));
}


void writeStack(StackContainer *s,char *fn)
{
    int f;
    int i;
    void *b;

    f=open(fn,O_BINARY|O_RDWR|O_CREAT|O_TRUNC,S_IREAD|S_IWRITE);

    write(f,&s->itemSize,sizeof(s->itemSize));
    write(f,&s->list.num,sizeof(s->list.num));

    b=malloc(s->itemSize);
    for(i=0;i<s->list.num;i++) {
        GetLink(&s->list,i,b);
        write(f,b,s->itemSize);
    }

    farfree(b);
    close(f);
}

void readStack(StackContainer *s,char *fn)
{
    int f;
    int i;
    void *b;
    long size;
    int num;


    f=open(fn,O_BINARY|O_RDWR);


    read(f,&size,sizeof(s->itemSize));
    createStack(s,size);

    read(f,&num,sizeof(s->list.num));

    b=malloc(s->itemSize);

    for(i=0;i<num;i++) {
        read(f,b,s->itemSize);
        InsertLink(&s->list,i,b);
    }

    farfree(b);
    close(f);

    unlink(fn);
}
