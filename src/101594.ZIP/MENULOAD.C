#include "vars.h"
#pragma hdrstop

typedef struct {
    char desc[50],
         key[21],
         type[3],
         line[40],
         ms[80];
    char sl[21];
    int  attr;
} commandRec;

typedef struct {
#ifdef PD
    char prompt[101],
         prompt2[91],
#else
    char prompt[192],
#endif
         helpfile[10],
         title1[101],
         title2[101],
         altmenu[9],
         formatFn[9],
         slneed[31],
         pausefile[9],
         helplevel,
         columns,
         col[3],
         boarder,
         battr;
    int  attr;
} menuHeader;



typedef struct commandL {
    commandRec data;
    struct commandL *next;
} Command;

typedef struct {
    char header[161];
    char footer[161];
    char cmdFmt[51];
    char promptFn[9];
    char headerFn[9];
    char footerFn[9];
    char center;
    char fill;
} formatRec;

typedef struct {
    Command *commands;
    int numCmd;

    char menuName[14];
    menuHeader header;
    formatRec format;

    char availableKeys[81];
    int slashOk;
    int numericOk;
} menuRec;

void availKeys(menuRec *menu)
{
    int i,c=0;
    commandRec cmd;

    menu->slashOk=0;
    menu->numericOk=0;

    for(i=0;i<menu->numCmd;i++) {
        fetchCommand(&menu,&cmd,i);

        if(cmd.key[0]=='#')
            menu->numericOk=1;
        else if(strlen(cmd.key)==2&&cmd.key[0]=='/') {
            menu->availableKeys[c++]=cmd.key[1];
            menu->slashOk=1;
        }
        else if(strlen(cmd.key)==1)
            menu->availableKeys[c++]=cmd.key[0];
    }

    menu->availableKeys[c++]='?';
    menu->availableKeys[c]=0;
}

void parseFormatCommands(char line[81],menuRec *menu)
{
    char s[81],*p;

    p=strtok(line,",");

    while(p) {
        strcpy(s,p);
        if(!stricmp(s,"FILL"))
            menu->format.fill=1;
        if(!stricmp(s,"CENTER"))
            menu->format.center=1;
        p=strtok(NULL,",");
    }
}

void readMenuFormat(menuRec *menu)
{
    FILE *f;
    char s[161];

    sprintf(s,"%s%s.fmt",syscfg.menudir,menu->header.formatFn);
    if(!exist(s))
        return;

    f=fopen(s,"rt");

    menu->format.fill=0;
    menu->format.center=0;

    fgets(s,161,f);
    filter(s,'\n');
    strcpy(menu->format.header,s);

    fgets(s,161,f);
    filter(s,'\n');
    strcpy(menu->format.footer,s);

    fgets(s,161,f);
    filter(s,'\n');
    strcpy(menu->format.cmdFmt,s);

    fgets(s,161,f);
    filter(s,'\n');
    parseFormatCommands(s,menu);

    fgets(s,161,f);
    filter(s,'\n');
    strcpy(menu->format.promptFn,s);

    fgets(s,161,f);
    filter(s,'\n');
    strcpy(menu->format.headerFn,s);

    fgets(s,161,f);
    filter(s,'\n');
    strcpy(menu->format.footerFn,s);
    fclose(f);
}

unsigned char bo(unsigned char c)
{
    switch(c) {
    case '<': 
        return '>';
    case '[': 
        return ']';
    case '(': 
        return ')';
    case '�': 
        return '�';
    case '�': 
        return '�';
    case '�': 
        return '�';
    case '�': 
        return '�';
    }
    return(c);
}


int readMenuFile(char fn[15],int executeAuto,menuRec *menu)
{
    char s[255];
    mmrec f;
    int x;
    int i;
    int fd;
    int numRecords;
    commandRec cmd;
    menuHeader tmpHeader;

    if(!strchr(fn,'.')) {
        strcat(fn,".mnu");
    }

    sprintf(s,"%s%s",syscfg.menudir,fn);
    if(!exist(s)) {
        if(executeAuto) {
            npr("8Menu %s not found!  Please inform the SysOp!!",fn);
            logtypes(5,"Menu 4%s 0Not Found!",fn);
        }
        readMenuFile(syscfg.firstmenu,0,menu);
        return 0;
    }

    menu->numCmd=0;

    fd=open(s,O_BINARY|O_RDONLY);
    lseek(fd,0L,SEEK_SET);
    read(fd,&menu->header,sizeof(menuHeader));

    if(!slok(menu->header.slneed,1)) {
        pl("Sorry, you do not have the proper access to enter this menu.");
        logtypes(3,"Tried entering menu (4%s0) that did not have access for.",fn);
        readMenuFile(syscfg.firstmenu,0,menu);
        return 0;
    }

    strcpy(menu->menuName,fn);

    numRecords=(filelength(fd)-sizeof(menuHeader))/sizeof(commandRec);

    for(i=0;i<numRecords;i++) {
        read(fd,&cmd,sizeof(commandRec));
        if(cmd.attr==command_forced&&executeAuto)
            if(slok(cmd.sl,0))
                executeCommand(&cmd);
        else if(slok(cmd.sl,1))
            addCommand(&menu,&cmd);
    }

    close(fd);

    if(menu->header.formatFn[0])
        readMenuFormat(menu);

    if(!(menu->header.attr & menu_noglobal)) {
        sprintf(s,"%sglobal.mnu",syscfg.menudir);
        if(exist(s)) {
            fd=open(s,O_RDONLY|O_BINARY);
            read(fd,&tmpHeader,sizeof(menuHeader));

            numRecords=(filelength(fd)-sizeof(menuHeader))/sizeof(commandRec);

            for(i=0;i<numRecords;i++) {
                read(fd,&cmd,sizeof(commandRec));
                if(cmd.attr==command_forced&&executeAuto)
                    if(slok(cmd.sl,0))
                        executeCommand(&cmd);
                else if(slok(cmd.sl,1))
                    addCommand(&menu,&cmd);
            }

            close(fd);
        }
    }

#ifdef PD
    readmenup();
#endif

    return 1;
}
