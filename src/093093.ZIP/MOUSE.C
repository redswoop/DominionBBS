#include "vars.h"
#pragma hdrstop

#ifdef MOUSE
int checklclick() {
int z;
    asm {
      mov ax,3;
      int 33h;
      mov word(z),bx;
    }
    if(z & 0x01==0x01) {
        delay(100);
        return 1;
       }
    else return 0;
}

int getmx() {
int x;
    asm {
      mov ax,3;
      int 33h;
      mov word(x),cx;
    }
    return x/8;
}

int getmy() {
int y;
    asm {
      mov ax,3;
      int 33h;
      mov word(y),dx;
    }
    return y/8;
}

void initpointer(int init)
{
  if(!init)
     asm mov ax,2;
  else
    asm mov ax,1;
  asm int 33h;
}

void executemouse(int x,int y)
{
 int a=0;

 if(wfc) return;

 if(y+1==topline&&x==79) {
    topdata+=1;
    if (topdata==4)
    topdata=0;
    topscreen();
    return;
 }

 if(topdata!=3) return;
 if(x<10) switch(y) {
      case 0: chatselect(); break;
      case 1: val_cur_user(59); break;
      case 2: hangup=1; break;
      case 3: temp_cmd(getenv("COMSPEC"),0); break;
      }
  else if(x<22) {
      a=1;
      switch(y) {
        case 0: thisuser.extratime+=5.0 * 60.0; break;
        case 1: thisuser.extratime-=5.0 * 60.0; break;
        case 2: if(thisuser.sl<255) thisuser.sl+=1; actsl=thisuser.sl;
                changedsl(); break;
        case 3: if(thisuser.sl>0) thisuser.sl-=1; actsl=thisuser.sl;
                changedsl(); break;
      }
    }

}
#endif
