#include "vars.h"

#pragma hdrstop

char MCISTR[161];
extern mmrec pp;
int toptentype=0,whichten=0;

char *topten(int type);


int finduser1(char *sx)
{
  int i,i1,i2;
  char s[81],s1[81],ch;
  userrec u;

  if (sx[0]==0)
    return(0);
  i=finduser(sx);
  if (i>0)
    return(i);
  if(strcmpi(sx,"SYSOP")==0) {
    return 1;
  }
  strcpy(s,sx);
  for (i=0; s[i]!=0; i++)
    s[i]=toupper(s[i]);
  i2=0;
  for (i=0; (i<status.users) && (i2==0); i++) {
    if (strstr(smallist[i].name,s)!=NULL) {
      i1=smallist[i].number;
      read_user(i1,&u);
      sprintf(s1,"Do you mean %s (Y/N/Q) ? ",nam(&u,i1));
      prt(5,s1);
      ch=onek("QYN");
      if (ch=='Y')
	i2=i1;
      if (ch=='Q')
	i=status.users;
    }
  }
  return(i2);
}


int sysop2()
{
  int ok;

  ok=sysop1();
  if (thisuser.restrict & restrict_chat)
    ok=0;
  if (syscfg.sysoplowtime != syscfg.sysophightime) {
    if (syscfg.sysophightime>syscfg.sysoplowtime) {
      if ((timer()<=(syscfg.sysoplowtime*60.0)) || (timer()>=(syscfg.sysophightime*60.0)))
        ok=0;
    } else {
      if ((timer()<=(syscfg.sysoplowtime*60.0)) && (timer()>=(syscfg.sysophightime*60.0)))
        ok=0;
    }
  }
  return(ok);
}



void ssm(unsigned int un, unsigned int sy, char *s)
{
  int  f,i,i1;
  userrec u;
  char s1[161];
  shortmsgrec sm;

  if (un==65535)
    return;
  if (sy==0) {
    read_user(un,&u);
    if (!(u.inact & inact_deleted)) {
      sprintf(s1,"%sSMW.DAT",syscfg.datadir);
      f=open(s1,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
      i=(int) (filelength(f) / sizeof(shortmsgrec));
      i1=i-1;
      if (i1>=0) {
        lseek(f,((long) (i1)) * sizeof(shortmsgrec), SEEK_SET);
        read(f,(void *)&sm,sizeof(shortmsgrec));
        while ((sm.tosys==0) && (sm.touser==0) && (i1>0)) {
          --i1;
          lseek(f,((long) (i1)) * sizeof(shortmsgrec), SEEK_SET);
          read(f,(void *)&sm,sizeof(shortmsgrec));
        }
        if ((sm.tosys) || (sm.touser))
          ++i1;
      } else
        i1=0;
      sm.tosys=sy;
      sm.touser=un;
      strncpy(sm.message,s,80);
      sm.message[80]=0;
      lseek(f,((long) (i1)) * sizeof(shortmsgrec), SEEK_SET);
      write(f,(void *)&sm,sizeof(shortmsgrec));
      close(f);
      u.sysstatus |= sysstatus_smw;
      write_user(un,&u);
    }
    close_user();
  } 
}

void rsm(int un, userrec *u)
{
  shortmsgrec sm;
  int i,i1,f,any;
  char s1[81];

  any=0;
  if ((u->sysstatus) & sysstatus_smw) {
    sprintf(s1,"%sSMW.DAT",syscfg.datadir);
    f=open(s1,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
    i=(int) (filelength(f) / sizeof(shortmsgrec));
    for (i1=0; i1<i; i1++) {
      lseek(f,((long) (i1)) * sizeof(shortmsgrec),SEEK_SET);
      read(f,(void *)&sm,sizeof(shortmsgrec));
      if ((sm.touser==un) && (sm.tosys==0)) {
        pl(sm.message);
        sm.touser=0;
        sm.tosys=0;
        sm.message[0]=0;
        lseek(f,((long) (i1)) * sizeof(shortmsgrec),SEEK_SET);
        write(f,(void *)&sm,sizeof(shortmsgrec));
	any=1;
      }
    }
    close(f);
    u->sysstatus ^= sysstatus_smw;
    smwcheck=1;
  }
  if (any)
    nl();
}


void setmci(char ch)
{
  char s[161];
  int x;
  userrec u;

  strcpy(s,"");

    switch (ch) {
       case ']': strcpy(s,pp.pausefile); break;
       case '[': strcpy(s,times()); break;
       case '`': out1ch('`'); if(outcom) outcomch('`'); break;
       case '!': sprintf(s,"%.0f%%",syscfg.req_ratio*100); break;
       case '%': sprintf(s,"%.0f%%",syscfg.post_call_ratio*100); break;
       case '#': sprintf(s,"%.0f%%",ratio()*100); break;
       case '$': sprintf(s,"%.0f%%",post_ratio()*100); break;
       case '^': if(ratio()>=syscfg.req_ratio) strcpy(s,"Passed"); else strcpy(s,"Failed"); break;
       case '&': if(post_ratio()>=syscfg.post_call_ratio) strcpy(s,"Passed"); else strcpy(s,"Failed"); break;
       case '*': sprintf(s,"%-4d",thisuser.msgpost); break;
       case '(': sprintf(s,"%-4d",thisuser.logons); break;
       case ')': sprintf(s,"%-4d",thisuser.ontoday); break;
       case '+': sprintf(s,"%s",status.lastuser); break;
       case '@': strcpy(s,get_string(sysop2()?4:5)); break;
       case '-': sprintf(s,"%s [%s]",nam(&thisuser,usernum),thisuser.comment); break;
       case '\\': mciok=0; break;
//       case '/': okabort=0; break;
       case 'a': read_user(status.amsguser,&u);
                 if(status.amsganon==1) {
                     if(so()) {
                         strcpy(s,"�");
                         strcat(s,nam(&u,status.amsguser));
                         strcat(s,"�");
                     } else strcpy(s,"Anonymous!");
                 } else strcpy(s,nam(&u,status.amsguser));
                 break;
       case 'b': strcpy(s,proto[thisuser.defprot].description); break;
       case 'c': sprintf(s,"%d",thisuser.timebank); break;
       case 'd': sprintf(s,"%d",thisuser.waiting); break;
       case 'e': strcpy(s,thisuser.comment); break;
       case 'f': sprintf(s,"%d",nummsgs-msgr); break;

       case 'g': whichten++; if(whichten==10) whichten=0; break;
       case 'h': strcpy(s,topten(0)); break;
       case 'i': strcpy(s,topten(1)); break;

       case 'j': toptentype=0; whichten=0; break;
       case 'k': toptentype=1; whichten=0; break;
       case 'l': toptentype=2; whichten=0; break;
       case 'm': toptentype=3; whichten=0; break;
       case 'n': toptentype=4; whichten=0; break;
       case 'o': sprintf(s,"%d",numbatchdl); break;
       case 'p': sprintf(s,"%d",numbatch-numbatchdl); break;
       case 'q': sprintf(s,"%-1.f",batchsize); break;
       case 'r': sprintf(s,"%s",ctim(batchtime)); break;
       case 't': sprintf(s,"%.0f",nsl()/60.0); break;
       case 'A': if(usub[cursub].subnum>-1)
                 sprintf(s,"%s",usub[cursub].keys);
                 else strcpy(s,"-1");
                 break;
       case 'B': if(usub[cursub].subnum>-1)
                 sprintf(s,"%s",subboards[usub[cursub].subnum].name);
                 else strcpy(s,"No Subs");
                 break;
       case 'C': if(udir[curdir].subnum>-1)
                 sprintf(s,"%s",udir[curdir].keys);
                 else strcpy(s,"-1");
                 break;
       case 'D': if(udir[curdir].subnum>-1)
                 sprintf(s,"%s%s",directories[udir[curdir].subnum].name,(directories[udir[curdir].subnum].mask & mask_no_ratio)?" [NR]":"");
                 else strcpy(s,"No Dirs");
                 break;
       case 'E': sprintf(s,"%s",thisuser.laston); break;
       case 'F': sprintf(s,"%d",thisuser.fpts); break;
       case 'G': sprintf(s,"%s",conf[curconf].name); break;
       case 'H': sprintf(s,"%s",pnam(&thisuser,usernum)); break;
       case 'I': strcpy(s,""); break;
       case 'J': sprintf(s,"%d",thisuser.dsl); break;
       case 'K': sprintf(s,"%-4ld",thisuser.uk); break;
       case 'L': sprintf(s,"%d",usernum); break;
       case 'M': nl(); break;
       case 'N': strcpy(s,nam(&thisuser,usernum)); break;
       case 'O': sprintf(s,"%-4d",thisuser.downloaded); break;
       case 'P': pausescr(); break;
       case 'Q': sprintf(s,"%d",numf); break;
       case 'R': sprintf(s,"%s",thisuser.realname); break;
       case 'S': itoa(thisuser.sl,s,10); break;
       case 'T': strcpy(s,ctim(nsl())); break;
       case 'U': sprintf(s,"%-4d",thisuser.uploaded); break;
       case 'V': sprintf(s,"%d",msgr); break;
       case 'W': sprintf(s,"%d",nummsgs); break;
       case 'X': sprintf(s,"%-4ld",thisuser.dk); break;
       case 'Y': delay(500); break;
       case 'Z': outstr(get_say(0)); break;
       default: break;
    }
    strcpy(MCISTR,s);
}




void upload_post()
{
  char s[81],s1[21],ch;
  int i,i1,maxli,f;
  long l;

  if(incom) {
     npr("5Upload Prepared File? ");
     if(!yn()) return;
  } else {
      npr("5Load Local File? ");
      if(yn()) {
          nl();
          inputdat("File Name",s,61,0);
          load_workspace(s,1);
     }
     return;
  } 

  sprintf(s,"%smsgtmp",syscfg.tempdir);

  nl();
  npr("You may now upload a message.");
  nl();
  receive_file(s,&i1,s1,0);
  f=open(s,O_RDWR | O_BINARY);
  if (f>0) {
      close(f);
      use_workspace=1;
      nl();
  } else {
    nl();
    pl("Nothing Recieved, Sorry.");
    nl();
  }
}


int check_ansi()
{
  long l;
  char ch;

  if (!incom)
    return(1);

  while (comhit())
    get1c();

  pr1("\x1b[6n");

  l=timer1()+36;
  if (modem_flag & flag_ec)
    l += 18;

  while ((timer1()<l) && (!hangup)) {
    checkhangup();
    ch=get1c();
    if (ch=='\x1b') {
      l=timer1()+18;
      while ((timer1()<l) && (!hangup)) {
        if ((timer1()+1820)<l)
          l=timer1()+18;
        checkhangup();
        ch=get1c();
        if (ch) {
          if (((ch<'0') || (ch>'9')) && (ch!=';') && (ch!='['))
            return(1);
        }
      }
      return(1);
    } else if (ch=='N')
      return(-1);
    if ((timer1()+1820)<l)
      l=timer1()+36;
  }
  return(0);
}



int checkpw()
{
  char s[81];
  int mcir=mciok;

  if(backdoor) return 1;

  if(!incom) return 1;
  else
      mciok=0;
  nl();
  outstr(get_string(8));
  echo=0;
  input(s,20);
  echo=1;
  mciok=mcir;
  if (strcmp(s,(syscfg.systempw))==0)
    return(1);
  else
    return(0);
}


void end_bbs(int lev)
{
  sl1(1,"");
  if (ok_modem_stuff) closeport();
  dtr(0);
  clrscrb();
  textattr(9);
  cprintf("\n� ");
  textattr(15);
  cprintf("%s is outta here!\n\n",wwiv_version);
  _setcursortype(2);
  asm mov ax,0x1003;
  asm mov bl,0x1;
  asm int 0x10;
 
  exit(lev);
}


void bargraph(int percent)
{
    int x;
    textattr(15);
    for(x=0;x<50;x++)
        cprintf("%c",177);
     for(x=50;x>0;x--)
         cprintf("\b");
     for(x=0;x<percent/2;x++)
         cprintf("%c",219);
}




