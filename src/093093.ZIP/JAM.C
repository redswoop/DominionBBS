#include "vars.h"
#pragma hdrstop

#include "jammb.h"
#include "jamutil.h"

JAMAPIREC JamRec;

typedef struct {
    char subject[81],
    who_from[41],
    who_to[41],
    comment[41];
    UINT32 attr;
} 
hdrinfo;



int InitJAMAPIREC( JAMAPIREC * pJam, CHAR8 * pFile );
int DisplayMsgHdr( INT32 MsgNo );
int DisplayMsgSubFld( void );
int DisplayMsgTxt( void );
int DisplayHdrInfo( void );
CHAR8 * AttrToStr( UINT32 Attr );
CHAR8 * GetSubFldName( JAMSUBFIELD * pSubFld );
CHAR8 * GetSubFldStr( JAMSUBFIELD * pSubFld );
CHAR8 * DispTime( UINT32 * pt );
void JAMOpen(char *fn);
void JAMClose(void);
void postjam(int sb,hdrinfo *hdr1, int usehdr);
void replyj(int sb,int msgnum);
void addLastRead(int num);
void saveLastRead(void);
void post(int sb);

void errorjam(void)
{
    switch(JamRec.APImsg) {
        case JAMAPIMSG_ISNOTOPEN: pl("Files not open"); break;
        case JAMAPIMSG_ISNOTLOCKED: pl("Files not locked"); break;
        default: npr("Error type %d\r\n",JamRec.APImsg); break;
    }
    pausescr();
}


int DisplayMsgTxt( void )
{
    int First = 1,
        Col=0;
    UINT32 Pos=0;
    UCHAR8 *p;

    while( 1 )
    {
        if( !JAMmbFetchMsgTxt( &JamRec, First ))
        {
            printf( "Error reading message text, code: %d, errno: %d\n", JamRec.APImsg, JamRec.Errno );
            return( 0 );
        }

        if( JamRec.APImsg == JAMAPIMSG_NOMORETEXT )
            break;

        First = 0;


        for( p = ( UCHAR8 * ) JamRec.WorkBuf; Pos < JamRec.WorkPos; Pos++, p++ )
        {
            if( *p == '\r' || *p==141 )
            {
                pl("");
                Col = 0;
                continue;
            }

            else if( *p < ' ' )
            {
                npr( "<%02x>", *p );
                Col += 4;
            }

            else
            {
                if( Col > 80 && *p == ' ' )
                {
                    nl();
                    Col = 0;
                }
                else
                {
                    outchr( *p );
                    Col++;
                }
            }
        }
    }

    nl();

    return( 1 );
}


void getjamhdr(hdrinfo *hdr1)
{
    hdrinfo hdr;

    UINT32  SubFldLen = JamRec.Hdr.SubfieldLen,
    Len;

    memset(&hdr.subject[0],0L,sizeof(hdrinfo));

    if( !JAMmbFetchMsgHdr( &JamRec, JamRec.Hdr.MsgNum, 1 ))
    {
        printf( "Error reading message header, code: %d, errno: %d\n", JamRec.APImsg, JamRec.Errno );
        return;
    }


    if( SubFldLen > JamRec.WorkLen )
        SubFldLen = JamRec.WorkLen;


    for(  JamRec.SubFieldPtr = ( JAMSUBFIELD * ) JamRec.WorkBuf;

        JamRec.SubFieldPtr->DatLen + sizeof( JAMBINSUBFIELD ) <= SubFldLen;

        Len = JAMsysAlign( JamRec.SubFieldPtr->DatLen + sizeof( JAMBINSUBFIELD )),
        SubFldLen -= Len,
        JamRec.SubFieldPtr = JAMsysAddPtr( JamRec.SubFieldPtr, Len ))
        {
        switch(JamRec.SubFieldPtr->LoID) {
        case 2: 
            strcpy(hdr.who_from,GetSubFldStr(JamRec.SubFieldPtr));
            break;
        case 3: 
            strcpy(hdr.who_to,GetSubFldStr(JamRec.SubFieldPtr));
            break;

        case 6:
            strcpy(hdr.subject,GetSubFldStr(JamRec.SubFieldPtr));
            break;

        case 666:
            strcpy(hdr.comment,GetSubFldStr(JamRec.SubFieldPtr));
            break;
        }
    }

    hdr.attr=JamRec.Hdr.Attribute;

    *hdr1=hdr;
}


void read_msg(long recnr,int *next)
{
    int abort=0;
    hdrinfo hdr;

    JAMmbFetchMsgHdr( &JamRec, recnr, 0 );
    getjamhdr(&hdr);

    showmsgheader(0,hdr.subject,hdr.who_from,curtime(),hdr.who_to,msgr,nummsgs,hdr.comment,0,&abort);
    if(!abort)
        DisplayMsgTxt();
    if(abort)
        *next=0;
    else
        *next=1;
}


void scanj(int msgnum,int *nextsub,int sb, int private)
{
    long recnr,l,len;
    int done=0,next=1,i,ok,abort=0,disp=1,board,f=0;
    char s[81],*b,*ss1,s1[81];
    hdrinfo hdr;

    sprintf(s,"%s%s",syscfg.msgsdir,subboards[usub[sb].subnum].filename);

    JAMOpen(s);

    if(!JAMmbFetchLastRead(&JamRec,usernum)) {
        if(JamRec.APImsg==16) {
            addLastRead(usernum);
            if(!JAMmbFetchLastRead(&JamRec,usernum))
                errorjam();
        }
    }

    while(!done&&!hangup) {
        msgr=msgnum;
        if(private&&disp) {
            f=0;
            strcpy(s,thisuser.realname);
            strlwr(s);
            l=JAMsysCrc32( s,strlen(s), ( UINT32 ) -1L );
            if(l==JamRec.Idx.UserCRC) f=1;
            strcpy(s,pnam(&thisuser,usernum));
            strlwr(s);
            l=JAMsysCrc32( s,strlen(s), ( UINT32 ) -1L );
            if(l==JamRec.Idx.UserCRC) f=1;
            if(!f)
                disp=0;
        }

        if(disp) {
            read_msg(msgnum,&next);

            JamRec.LastRead.UserID=usernum;
            JamRec.LastRead.LastReadMsg=msgnum;
            if(JamRec.LastRead.LastReadMsg>JamRec.LastRead.HighReadMsg)
                JamRec.LastRead.HighReadMsg=msgnum;

            saveLastRead();
            disp=0;
        }

        nl();
        outstr(get_string(14));
        strcpy(s,"Q[]FRPSTVAELFB?-CDH");
        if(cs())
            strcat(s,"UKX!BM");
        ss1=smkey(s,1,1,1,0);
        strcpy(s,ss1);

        if(!s[0]) {
            msgnum++;
            if(msgnum>nummsgs)
                done=1;
            else
                disp=1;
        } 
        else if(atoi(s)) {
            i=atoi(s);
            msgnum=i;
            disp=1;
        } 
        else if(s[0]=='Q') {
            done=1;
            *nextsub=0;
        }
        else if(s[0]=='P'||s[0]=='R') {
            if(s[0]=='R')
                replyj(sb,msgnum);
            else {

                post(sb);
            }
            if(!JamRec.isOpen) {
                sprintf(s,"%s%s",syscfg.msgsdir,subboards[usub[sb].subnum].filename);
                JAMOpen(s);
            }
        }
        else if(s[0]=='A')
            disp=1;
        else if(s[0]=='S') {
            nl();
            done=1;
            *nextsub=1;
        }
        else if(s[0]=='?')
            printmenu(1);
        else if(s[0]=='B')
            boardedit();
        else if(s[0]=='-') {
            if(msgnum>JamRec.HdrInfo.BaseMsgNum)
                msgnum--;
            disp=1;
        } 
        else if(s[0]=='L') {
            msgnum=JamRec.HdrInfo.BaseMsgNum+JamRec.HdrInfo.ActiveMsgs;
            msgnum--;
            disp=1;
        }
        else if(s[0]=='F') {
            msgnum=JamRec.HdrInfo.BaseMsgNum;
            disp=1;
        }
        else if(s[0]=='T') {
            abort=0;
            for(i=0;i<10&&!hangup&&!abort&&msgnum<nummsgs;i++) {
                msgnum++;
                JAMmbFetchMsgHdr(&JamRec, msgnum,0);
                getjamhdr(&hdr);

                if(!stricmp(thisuser.name,hdr.who_from)||!stricmp(thisuser.realname,hdr.who_from))
                    sprintf(s,"3[3%d3] ",msgnum);
                else if(!stricmp(thisuser.name,hdr.who_to)||!stricmp(thisuser.realname,hdr.who_to))
                    sprintf(s,"6[2%d6] ",msgnum);
                else
                    sprintf(s,"1(1%d1) ",msgnum);

                sprintf(s1,"0%-40.40s By: %-21.21s",hdr.subject,hdr.who_from);

                strcat(s,s1);
                pla(s,&abort);
            }
        }
        else if(!stricmp(s,"/C"))
            outchr(12);
        else if(!stricmp(s,"CHAT"))
            reqchat("Chat Reason");
        else if(!stricmp(s,"**"))
            getcmdtype();
    }

    if(!private) {
        nl();
        outstr(get_string(60));
        if(yn())
            post(sb);
    }

    JAMClose();
}


void rscanj(void)
{
    int i,board,next,new;
    char s[81];

    sprintf(s,"%s%s",syscfg.msgsdir,subboards[usub[cursub].subnum].filename);
    JAMOpen(s);

    outstr(get_string2(9));
    input(s,4);
    if(s[0]=='Q') {
        JAMClose();
        return;
    }
    i=atoi(s);
    if(!i)
        i=1;
    if (i>=nummsgs)
        i=nummsgs;
    nl();
    JAMClose();
    scanj(i,&next,cursub,0);
}



#define LEN 161


char *ninmsg(hdrinfo *hdr1,long *len,int *save,int usehdr)
{
    char s[LEN],s1[LEN],s2[LEN],ro[81],fnx[81],chx,*ss,*ss1,to[81],*p;
    int maxli,curli,done,savel,i,i1,i2,i3,i4,i5,f,setanon,result;
    messagerec m;
    long ll,l1;
    char *lin, *b;
    int real_name=0,fsed=0,anony=0;
    hdrinfo hdr;
    hdr= *hdr1;

    if ((fsed!=0) && (!okfsed()))
        fsed=0;
    sprintf(fnx,"%sMSGtmp",syscfg.tempdir);
    if (fsed)
        fsed=1;
    if (use_workspace) {
        if (!exist(fnx))
            use_workspace=0;
        else
            fsed=2;
    }
    done=0;
    setanon=0;
    *save=0;
    curli=0;
    b=NULL;

    if (actsl<45)
        maxli=30;
    else
        if (actsl<60)
        maxli=50;
    else
        if (actsl<80)
        maxli=60;
    else
        maxli=80;
    if (!fsed) {
        if ((lin=malloca((long)(maxli+10)*LEN))==NULL) {
            return NULL;
        }
        for (i=0; i<maxli; i++)
            lin[i*LEN]=0;
        ro[0]=0;
    }

    if(hdr.subject[0]&&usehdr)
        npr("Press enter to use: %.60s\r\n",hdr.subject);
    inputdat("Subject",s,60,1);

    if (s[0]==0) {
        if(hdr.subject[0]&&usehdr)
            strcpy(s,hdr.subject);
        else {
            pl("Aborted.");
            farfree((void *)lin);
            return NULL;
        }
    }

    nl();

    if(hdr.who_from[0]&&usehdr)
        npr("Press enter to use: %s\r\n",hdr.who_from);
    inputdat("Receiver",s,41,1);
    if(!s[0]) {
        if(usehdr&&hdr.who_from[0])
            strcpy(hdr.who_to,hdr.who_from);
        else
            strcpy(hdr.who_to,"All");
    } else
        strcpy(hdr.who_to,s);
    nl();

    if (!fsed) {
        nl();
        pl(get_string(11));
        pl(get_string(12));
        pl(get_string(41));

        while (!done&&!hangup) {

            while((result=ainli(s,ro,160,1,1,curli?1:0))>0) {
                if(result==1||result==2&&curli) {
                    --curli;
                    if(result==2)
                        outstr("[A\r");
                    strcpy(ro,&(lin[(curli)*LEN]));
                    if(strlen(ro)>thisuser.screenchars-1)
                        ro[thisuser.screenchars-2]=0;
                }
            }

            if(result==-1) strcpy(s,"/S");
            if(result==-2) strcpy(s,"/A");
            if(result==-3) strcpy(s,"/L");
            if(result==-4) strcpy(s,"/C");
            if(result==-5) strcpy(s,"/Q");
            if(result==-6) strcpy(s,"/M");

            if (hangup) done=1;
            savel=1;
            if (s[0]=='/') {
                if (stricmp(s,"/!Q")==0) {
                    savel=0;
/*                    if (quote!=NULL)
                        get_quote(0);*/
                }
                if (!stricmp(s,"/M")) {
                    savel=0;
                    printmenu(15);
                }
                if (stricmp(s,"/?")==0) {
                    savel=0;
                    printmenu(2);
                }
                if (stricmp(s,"/L")==0) {
                    savel=0;
                    i2=0;
                    for (i=0; (i<curli) && (!i2); i++) {
                        strcpy(s1,&(lin[i*LEN]));
                        i3=strlen(s1);
                        if (s1[i3-1]==1)
                            s1[i3-1]=0;
                        if (s1[0]==2) {
                            strcpy(s1,&(s1[1]));
                            i5=0;
                            for(i4=0; i4<strlen(s1); i4++)
                                if ((s1[i4]==8) || (s1[i4]==3))
                                    --i5;
                                else
                                    ++i5;
                            for (i4=0; (i4<(thisuser.screenchars-i5)/2) && (!i2); i4++)
                                osan(" ",&i2,&i1);
                        }
                        pla(s1,&i2);
                    }
                    nl();
                    pl("Continue...");
                }
                if (!stricmp(s,"/S")) {
                    *save=1;
                    done=1;
                    savel=0;
                }
                if (stricmp(s,"/A")==0) {
                    npr("5Abort this message? ");
                    if(yn()) {
                        done=1;
                        savel=0;
                    }
                }
                if (stricmp(s,"/C")==0) {
                    npr("5Clear message? ");
                    if(yn()) {
                        savel=0;
                        curli=0;
                        pl("Message cleared.");
                        nl();
                    }
                }
                strcpy(s1,s);
                s1[3]=0;
            }
            if (savel) {
                strcpy(&(lin[(curli++)*LEN]),s);
                if (curli==(maxli+1)) {
                    nl();
                    pl("No more lines... Please Save or back up.");
                    nl();
                    --curli;
                } 
                else if (curli==maxli) {
                    pl("� Message limit reached, /S to save �");
                } 
                else if ((curli+5)==maxli) {
                    pl("�> 5 lines left <�");
                }
            }
        }
        if (curli==0)
            *save=0;
    } 
    else {
        if (fsed==1) {
            *save=external_edit("MSGtmp",syscfg.tempdir,(int) (thisuser.defed)-1,maxli);
        } 
        else {
            *save=exist(fnx);
            use_workspace=0;
        }
    }


    if (*save) {
        switch(anony) {
        case 0:
            anony=0;
            break;
        case anony_enable_anony:
            if (setanon) {
                if (setanon==1)
                    anony=anony_sender;
                else
                    anony=0;
            } 
            else {
                prt(5,"Anonymous? ");
                if (yn())
                    anony=anony_sender;
                else
                    anony=0;
            }
            break;
        case anony_force_anony:
            anony=anony_sender;
            break;
        case anony_real_name:
            real_name=1;
            anony=0;
            break;
        }
        if(!fidotoss)
            outstr(get_string(61));
        if (fsed) {
            i5=open(fnx,O_RDONLY | O_BINARY);
            l1=filelength(i5);
        } 
        else {
            l1=0;
            for (i5=0; i5<curli; i5++) {
                l1 += strlen(&(lin[i5*LEN]));
                l1 += 2;
            }
        }
        l1 += 1024;
        if ((b=malloca(l1))==NULL) {
            farfree(lin);
            pl("Out of memory.");
            return NULL;
        }

        l1=0;

        if (fsed) {
            ll=filelength(i5);
            read(i5, (void *) (& (b[l1]) ),ll);
            l1 += ll;
            close(i5);
        } 
        else {
            for (i5=0; i5<curli; i5++)
                addline(b,&(lin[i5*LEN]),&l1);
        }
    } 
    else {
        if (fsed)
            unlink(fnx);
        pl("Aborted.");
    }


    if(real_name)
        strcpy(hdr.who_from,thisuser.realname);
    else
        strcpy(hdr.who_from,pnam(&thisuser,usernum));
    strcpy(hdr.comment,thisuser.comment);

    *hdr1=hdr;
    *len=l1;

    if (!fsed) {
        farfree((void *)lin);
    }

    charbufferpointer=0;
    charbuffer[0]=0;

    return b;
}


#include <errno.h>

void replyj(int sb,int msgnum)
{
    hdrinfo hdr;

    JAMmbFetchMsgHdr( &JamRec, msgnum, 0 );
    getjamhdr(&hdr);
    JamMsgInit(&JamRec);
    postjam(sb,&hdr,1);
}

void post(int sb)
{
    hdrinfo hdr;

    JamMsgInit(&JamRec);
    memset(&hdr.subject[0],0,sizeof(hdrinfo));
    postjam(sb,&hdr,0);
}

void postjam(int sb,hdrinfo *hdr1,int usehdr)
{
    hdrinfo hdr;
    char *b,s[81];
    long len;
    UINT32 SubFldPos=0;
    int i,save;

    curlsub=usub[sb].subnum;

    if (freek1(syscfg.msgsdir)<10.0) {
        nl();
        pl("Sorry, not enough disk space left.");
        nl();
        return;
    }

    if ((restrict_post & thisuser.restrict) || (thisuser.posttoday>=syscfg.sl[actsl].posts)) {
        nl();
        pl("Too many messages posted today.");
        nl();
        return;
    }

    if (!slok(subboards[curlsub].postacs,1)) {
        nl();
        pl("You can't post here.");
        nl();
        return;
    }

    if (thisuser.restrict & restrict_net) {
        nl();
        pl("You can't post on networked message areas.");
        nl();
        return;
    }

    if (subboards[curlsub].attr & mattr_fidonet) {
        nl();
        pl(get_string(23));
        nl();
    }

    sprintf(s,"%s%s",syscfg.msgsdir,subboards[usub[sb].subnum].filename);
    JAMOpen(s);

    hdr= *hdr1;

    upload_post();
    b=ninmsg(&hdr,&len,&save,usehdr);
    if(!save) {
        JAMClose();
        return;
    }

//    JamMsgInit(&JamRec);

    JamMsgAddSFldStr(&JamRec, JAMSFLD_SUBJECT, hdr.subject, &SubFldPos );
    JamMsgAddSFldStr(&JamRec, JAMSFLD_SENDERNAME, hdr.who_from, &SubFldPos );
    JamMsgAddSFldStr(&JamRec, JAMSFLD_RECVRNAME, hdr.who_to, &SubFldPos );
    JamMsgAddSFldStr(&JamRec, 666, hdr.comment, &SubFldPos );

    JamRec.Hdr.SubfieldLen=SubFldPos;
    JamRec.Hdr.TxtLen=len;
    JamRec.Hdr.Attribute |= MSG_LOCAL;
    time(&JamRec.Hdr.DateWritten);

    JamMsgWrite(&JamRec,b);

    JamMsgDeinit(&JamRec);

    JAMClose();
    farfree(b);

    ++thisuser.msgpost;
    ++thisuser.posttoday;
    ++status.msgposttoday;
    save_status();
    topscreen();

    logtypes(0,"Posted on 4%s 2[2%s2]",subboards[curlsub].name,hdr.subject);
    npr("Posted on %s\r\n",subboards[curlsub].name);

    save_status();
    if ((subboards[curlsub].attr & mattr_fidonet) ) {
        ++thisuser.postnet;
    }
}


CHAR8 * GetSubFldStr( JAMSUBFIELD * pSubFld )
{
    static CHAR8    Buffer [256],
    * pBuf;
    UINT32          i;
    int             BufPos;

    for(  pBuf = Buffer, i = BufPos = 0;
        i < pSubFld->DatLen && BufPos + 5 < sizeof( Buffer );
        pBuf++, i++, BufPos++ )
        {
        if( pSubFld->Buffer [( int ) i] < ' ' )
        {
            sprintf( pBuf, "<%02x>", pSubFld->Buffer [( int ) i] );
            BufPos += 3;
            pBuf += 3;
        }
        else
            *pBuf = pSubFld->Buffer [( int ) i];
    }

    *pBuf = '\0';

    return( Buffer );
}

int JamMsgInit( JAMAPIREC * pJam )
{
    memset( &pJam->Idx, '\0', sizeof( JAMIDXREC ));
    pJam->Idx.UserCRC = ( UINT32 ) -1L;

    memset( &pJam->Hdr, '\0', sizeof( JAMHDR ));

    pJam->Hdr.MsgIdCRC    = ( UINT32 ) -1L;
    pJam->Hdr.ReplyCRC    = ( UINT32 ) -1L;
    pJam->Hdr.PasswordCRC = ( UINT32 ) -1L;

    return( 1 );
}


/* ---------------------------------------------------------------------- *
 *
 *  JamMsgDeinit
 *
 * ---------------------------------------------------------------------- */

int JamMsgDeinit( JAMAPIREC * pJam )
{
    memset( &pJam->Hdr, '\0', sizeof( JAMHDR ));

    return( 1 );
}

int JamMsgWrite( JAMAPIREC * pJam, CHAR8 * pMsgTxt )
{
    int     LockTryCnt = 0;
    UINT32  MsgNo;

    /*
    **  Lock the messagebase
    */

    while( !JAMmbLockMsgBase( pJam, 1 ))
    {
        if( ++LockTryCnt >= 15 )
        {
            puts( "Unable to get lock on messagebase" );
            exit( 3 );
        }

        sleep( 1 );
    }



    MsgNo = ( filelength( pJam->IdxHandle ) / sizeof( JAMIDXREC )) + pJam->HdrInfo.BaseMsgNum;
    pJam->Hdr.MsgNum = MsgNo;


    /*
    **  Get the offset in the header file for the next message header
    */

    pJam->Idx.HdrOffset = filelength( pJam->HdrHandle );


    /*
    **  And get the offset in the text file for the next text
    */


    pJam->Hdr.TxtOffset = filelength( pJam->TxtHandle );


    /*
    **  Store the index record
    */

    if( !JAMmbStoreMsgIdx( pJam, MsgNo ))
    {
        printf( "Error writing JAMIDXREC: %d\n", pJam->APImsg );
        exit( 4 );
    }


    /*
    **  And the header record
    */

    if( !JAMmbStoreMsgHdr( pJam, MsgNo ))
    {
        printf( "Error writing JAMHDR: %d\n", pJam->APImsg );
        exit( 4 );
    }


    /*
    **  Write all the subfields
    */

    if( JAMsysWrite( NULL, pJam->HdrHandle, pJam->WorkBuf, ( int ) pJam->Hdr.SubfieldLen ) != ( int ) pJam->Hdr.SubfieldLen )
    {
        printf( "Error writing SubFields\n" );
        exit( 4 );
    }


    /*
    **  Write the message text
    */


    if( !JAMmbStoreMsgTxtBuf( pJam, pMsgTxt, pJam->Hdr.TxtLen, 1 ))
    {
        printf( "Error writing message text: %d\n", pJam->APImsg );
        exit( 4 );
    }


    /*
    **  Unlock the messagebase
    */

    pJam->HdrInfo.ActiveMsgs++;
    JAMmbUnLockMsgBase( pJam, 1 );

    return( 1 );
}

int JamMsgAddSFldStr( JAMAPIREC * pJam, UINT16 SubFld, CHAR8 * Str, UINT32 * pSubFldPos )
{
    int Len = strlen( Str );

    if( !JAMmbAddField( pJam, SubFld, 1, Len, pSubFldPos, Str ))
        puts( "WARNING: Work buffer for subfields to small" );

    switch( SubFld )
    {
    case JAMSFLD_RECVRNAME :
        strlwr( Str );
        pJam->Idx.UserCRC = JAMsysCrc32( Str, Len, ( UINT32 ) -1L );
        break;

    case JAMSFLD_MSGID :
        strlwr( Str );
        pJam->Hdr.MsgIdCRC = JAMsysCrc32( Str, Len, ( UINT32 ) -1L );
        break;

    case JAMSFLD_REPLYID :
        strlwr( Str );
        pJam->Hdr.ReplyCRC = JAMsysCrc32( Str, Len, ( UINT32 ) -1L );
        break;
    }

    return( 1 );
}

void JAMOpen(char *fn)
{

    if( !JAMsysInitApiRec( &JamRec, fn, WORKBUFSIZE ))
    {
        puts( "Not enough memory" );
        return;
    }

    if(JamRec.isOpen)
        JAMClose();

    if( !JAMmbOpen( &JamRec ))
    {
        if( JamRec.Errno != ENOENT )
        {
            perror( "Unable to open the JAM messagebase" );
            JAMsysDeinitApiRec( &JamRec );
            return;
        }

        if( !JAMmbCreate( &JamRec ))
        {
            perror( "Unable to create the JAM messagebase" );
            JAMsysDeinitApiRec( &JamRec );
            return;
        }
    }

    nummsgs=filelength( JamRec.IdxHandle )/sizeof(JAMIDXREC);
}


void JAMClose(void)
{
    if(!JAMsysDeinitApiRec(&JamRec))
        pl("Deinit error");
    if(JamRec.isOpen)
        pl("still open");
}

void readmailj(void)
{
    int i;

    scanj(1,&i,0,1);
}

void addLastRead(int num)
{
    int i;

    JAMmbLockMsgBase(&JamRec, 1 );
    lseek(JamRec.LrdHandle,0L,SEEK_END);
    JamRec.LastRead.HighReadMsg=0;
    JamRec.LastRead.LastReadMsg=0;
    JamRec.LastRead.UserID=num;
    write(JamRec.LrdHandle,&JamRec.LastRead,sizeof(JAMLREAD));
    JAMmbUnLockMsgBase(&JamRec, 1 );
    JamRec.LastLRDnum=filelength(JamRec.LrdHandle)/sizeof(JAMLREAD);
}

void saveLastRead(void)
{
    JAMmbLockMsgBase(&JamRec, 1 );
    JAMmbStoreLastRead(&JamRec,1);
    JAMmbUnLockMsgBase(&JamRec, 1 );
}

void nscan(int sb,int *next)
{
    int num;
    char s[81];


    sprintf(s,"%s%s",syscfg.msgsdir,subboards[usub[sb].subnum].filename);

    JAMOpen(s);

    if(!JAMmbFetchLastRead(&JamRec,usernum))
        num=1;
    else
        num=JamRec.LastRead.HighReadMsg;

    JAMClose();

    if(nummsgs>num) {
        pl(get_string((18)));
        scanj(++num,next,sb,0);
        nl();
        pl(get_string(19));
    } else
        pl(get_string(35));
}



void gnscan(void)
{
    int i,next=1;

    pl(get_string(15));
    for(i=0;i<200&&usub[i].subnum!=-1&&!hangup&&next;i++) {
        if(thisuser.qscn[usub[i].subnum]!=-1) {
            nscan(cursub=usub[i].subnum,&next);
        }
    }
    pl(get_string(16));
}
