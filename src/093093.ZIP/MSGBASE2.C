#include "vars.h"
#pragma hdrstop
#include <dir.h>


#define LEN 161
#define ALLOW_FULLSCREEN 1
#define EMAIL_STORAGE 2

int deleted_flag;
extern char commstr[41];
char net_email_to[61];

/*void get_quote()
{
    static char s[141];
    static int i,i1,i2,abort,next,rl;
    long l;

    rl=1;
    do {
        if (rl) {
            i=1; 
            i2=0;
            l=0;
            abort=0; 
            next=0;
            do {
                nl();
                npr("0%2d:",i++);
                while(quote[l]!=13&&quote[l]!=0&&quote[l]!=26)
                    outchr(quote[l++]);
            } while (quote[l]!=26);
            --i;
        }
        nl();
        i1=0; 
        i2=0; 
        s[0]=0;
        while (!s[0]) {
            sprintf(s,"Quote from line 1-%d? (A=All,?=relist,Q=quit) ",i);
            prt(5,s);
            input(s,3);
        }
        if (s[0]=='A') {
            charbufferpointer=0;
            bquote=1;
            equote=i;
            return;
        }
        if (s[0]=='Q')
            rl=0;
        else if (s[0]!='?') {
            i1=atoi(s);
            if (i1==i)
                i2=i1;
            else {
                s[0]=0;
                while (!s[0]) {
                    sprintf(s,"through line %d-%d? (Q=quit) ",i1,i);
                    prt(5,s);
                    input(s,3);
                }
                if (s[0]=='Q')
                    rl=0;
                else if (s[0]!='?')
                    i2=atoi(s);
            }
        }
        if (i2) {
            sprintf(s,"Quote line(s) %d-%d? ",i1,i2);
            prt(5,s);
            if (!ny())
                i2=0;
        }
    } 
    while ((!abort) && (!hangup) && (rl) && (!i2));
    charbufferpointer=0;
    if ((i1>0) && (i2>=i1) && (i2<=i) && (i2-i1<50) && (rl)) {
        bquote=i1;
        equote=i2;
    }
}

char *ini(char name[81])
{
    char o[81];
    int i=0,p=0;

    memset(o,0,81);

    for(i=0;name[i];i++) {
        if ((name[i]>='A') && (name[i]<='Z'))
            o[p++]=name[i];
    }

    return(o);
}

void quote_message(messagerec *m1, char *aux)
{
    char *b,*c,s1[81],quotefrom[10],s[81];
    int cc,dq,lc,ok,mc,i;
    long l,l1,l2,l3,l4,f;
    messagerec m;
    userrec u;

    m=*m1;
    b=readfile(&m,aux,&l);
    if (b==NULL)
        return;
    if ((c=malloca(l+1000L))==NULL) {
        farfree(b);
        return;
    }
    lc=0; 
    l1=0; 
    l2=0; 
    ok=1;

    do {
        if (b[l1]==13)
            lc++;
        l1++;
    } 
    while (lc<3);

    lc=0; 
    dq=1; 
    cc=48;

    strcpy(quotefrom,ini(irt_name));

    do {
        if (lc==0) {
            for(f=l1;f<l1+15;f++) {
                if(b[f]=='>')
                    dq=0;
            }

            if(dq) {
                sprintf(&c[l2]," %s> ",quotefrom);
                l2+=strlen(quotefrom)+3;
                lc+=strlen(quotefrom)+3;
            }

            if (cc!=48) {
                c[l2++]=3;
                c[l2++]=cc;
            }
        }
        switch(b[l1]) {
        case 1:
            if (b[l1-1]!=32)
                c[l2++]=' ';
            l1+=3;
            break;
        case 3:
            l1++;
            cc=b[l1++];
            c[l2++]=3;
            c[l2++]=cc;
            break;
        case 14:
            l1++;
            cc=b[l1++];
            c[l2++]=14;
            c[l2++]=cc;
            break;
        case 4:
            l1+=2;
            break;
        case 13:
            if ((b[l1+1]>96) && (b[l1+1]<123)) {
                if (b[l1-1]!=32)
                    c[l2++]=' ';
                l1+=1;
            } 
            else {
                lc=0; 
                l1+=1;
                dq=1;
                c[l2++]=13;
            }
            break;
        default:
            c[l2++]=b[l1++];
            lc++;
            break;
        }

/*        if (dq==1)
            mc=72;
        else*/
            mc=78;

        if (lc>=mc) {
            l3=l1; 
            l4=l2;
            while ((b[l1]!=32) && (lc>0)) {
                --l1; 
                --l2; 
                --lc;
                if ((b[l1]==3) || (b[l1]==4))
                    lc+=1;
                if (b[l1]==1) {
                    l2+=2;
                    lc+=2;
                }
                if ((b[l1]==13) && (b[l1-1]>4)) {
                    lc+=1;
                }
            }
            if (lc<=1) {
                l1=l3; 
                l2=l4;
            } 
            else {
                lc=0;
                l1++;
            }
            c[l2++]=13;
//            c[l2++]=10;
        }
    } 
    while ((l1<l) && (l2<l+998L) && (ok));

    c[l1++]=0;
    if (ok) {
        sprintf(s1,"%sQUOTE.MSG",syscfg.tempdir);
        f=open(s1,O_RDWR | O_BINARY | O_CREAT | O_TRUNC, S_IREAD | S_IWRITE);
        /*        strcpy(u.name,irt_name);
                        sprintf(s,"%s was saying....\r\n",pnam(&u,0));
        write(f,&s,strlen(s));
        */
        write(f,(void *)c,l2);
        close(f);
        farfree(b);
        farfree(c);
        f=open(s1,O_RDONLY | O_BINARY);
        l2=filelength(f);
        if ((quote=malloca(l2+2))!=NULL)
            read(f,(void *) quote,l2);
        quote[l2]=26;
        quote[l2+1]=26;
        close(f);
        unlink(s1);
    }
}
*/



void extract_out(char *b, long len, char *title)
{
    char s1[81],s2[81],ch=26,ch1;
    int i;

    do {
        prt(2,"Save under what filename? ");
        input(s1,12);
        if (s1[0]) {
            sprintf(s2,"%s%s",syscfg.gfilesdir,s1);
            if (exist(s2)) {
                nl();
                pl("Filename already in use.");
                nl();
                outstr("5(O)verwrite, (A)ppend, (N)ew name, (Q)uit? ");
                ch1=onek("QOAN");
                switch(ch1) {
                case 'Q':
                    s2[0]=0;
                    s1[0]=0;
                    break;
                case 'N':
                    s1[0]=0;
                    break;
                case 'A':
                    break;
                case 'O':
                    unlink(s2);
                    break;
                }
                nl();
            }
        } 
        else
            s2[0]=0;
    } 
    while ((!hangup) && (s2[0]!=0) && (s1[0]==0));
    if ((s1[0]) && (!hangup)) {
        i=open(s2,O_RDWR | O_BINARY | O_CREAT , S_IREAD | S_IWRITE);
        if (filelength(i)) {
            lseek(i, -1L, SEEK_END);
            read(i, ((void *)&ch1), 1);
            if (ch1 == 26)
                lseek(i, -1L, SEEK_END);
        }
        write(i,title,strlen(title));
        write(i,"\r\n",2);
        write(i,(void *)b,len);
        write(i,&ch,1);
        close(i);
        npr("Message written to: %s.\r\n",s2);
    }
    farfree(b);
}



void load_workspace(char *fnx, int no_edit)
{
    int i,i5;
    long l;
    char *b,s[81];

    i5=open(fnx,O_RDONLY | O_BINARY);
    if (i5<1) {
        nl();
        pl("File not found.");
        nl();
        return;
    }
    l=filelength(i5);
    if ((b=malloca(l+1024))==NULL) {
        close(i5);
        return;
    }
    read(i5, (void *) b,l);
    close(i5);
    if (b[l-1]!=26)
        b[l++]=26;
    sprintf(s,"%smsgtmp",syscfg.tempdir);
    i5=open(s,O_RDWR | O_CREAT | O_BINARY,S_IREAD | S_IWRITE);
    write(i5, (void *)b,l);
    close(i5);
    farfree(b);
    if ((no_edit))
        use_workspace=1;
    else
        use_workspace=0;
    nl();
    pl("File loaded into workspace.");
    nl();

}



void yourinfomsg()
{
    nl();
    dtitle("Your Message Status");
    npr("0Total Posts   5: 4%d\r\n",thisuser.msgpost);
    npr("0Posts Today   5: 4%d\r\n",thisuser.posttoday);
    npr("0FeedBack      5: 4%d\r\n",thisuser.feedbacksent);
    npr("0Email Sent    5: 4%d\r\n",thisuser.emailsent);
    npr("0Messages Read 5: 4%d\r\n",thisuser.msgread);
    npr("0Mail Waiting  5: 4%d\r\n",thisuser.waiting);
    npr("0Your PCR      5: 4%.0f%%\r\n",post_ratio()*100);
    npr("0Required PCR  5: 4%.0f%%\r\n",syscfg.post_call_ratio*100);
    nl();
    nl();
}

int sublist(char type)
{
    FILE *f;
    subboardrec d;
    char s[163],s1[163],s2[5],s3[25],s4[161];
    int i,i1,abort=0;
    if(type);

    sprintf(s,"%ssublist.fmt",syscfg.gfilesdir);
    f=fopen(s,"rt");

    fgets(s,163,f); filter(s,'\n');
    pla(s,&abort);
    fgets(s,163,f); filter(s,'\n');
    pla(s,&abort);


    fgets(s1,163,f); filter(s1,'\n');
    fgets(s4,163,f); filter(s4,'\n');

    for(i=0;i<umaxsubs&&usub[i].subnum!=-1&&!abort; i++) {
//        iscan(i);
        d=subboards[usub[i].subnum];
        itoa(nummsgs,s2,10);

        i1=0;
        if(thisuser.qscn[usub[i].subnum]>=0) i1=1;

        if(i1)
            stuff_in2(s,s1,noc2(d.name),40,usub[i].keys,2,s2,3,"",0,"",0);
        else
            stuff_in2(s,s4,noc2(d.name),40,usub[i].keys,2,s2,3,"",0,"",0);
        pla(s,&abort);
    }
    fgets(s1,163,f); filter(s1,'\n');
    pla(s1,&abort);

    fclose(f);
    return 0;
}
