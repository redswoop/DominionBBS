int eval_expession(char s[81])
{
    switch(toupper(s[0])) {
    case 'A':
        if(!(thisuser.ar & (1 << toupper(s[1])-'A'))) return 0;
    case 'B':
        if((modem_speed/100)<atoi(s+1)) return 0;
    case 'C':
        if(!menu) {
            if(!postr_ok());
                return 0;
            pl(get_string(40));
            return 1;
        }
    case 'D':
        if(thisuser.dsl<atoi(s+1)) return 0;
    case 'G':
        if(thisuser.age<atoi(s+1)) return 0;
    case 'I':
        if(!(thisuser.dar & (1 << toupper(s[1])-'A'))) return 0;
    case 'S':
        if(actsl<atoi(s+1)) return 0;
    case 'U':
        if(atoi(s+1)!=usernum) return 0;
    case 'V':
        if(!running_dv) return 0;
    case '@':
        if(!strchr(conf[curconf].flagstr,s[1])) return 0;
    case '#':
        if(!sysop2()) return 0;
    case 'F':
        if(!fastlogon) return 0;
    }
    return 1;
}

int sleval(char val[31],char menu,int b,int e)
{
    char ok=1,neg=0,*p,s1[81],s[81],curok=1,cur_eval[81];
    int i;
    int b1,e1;

    if(backdoor)
        return 1;

    strcpy(s,val);

    p=strtok(s,"&");
    if(p)
        strcpy(s,p);
    else
        s[0]=0;

    ok=1;
    if(menu==3) {
        menu=0;
    }
    b1=b;
    e1=e;
    while(s[0]) {
        curok=1;
        neg=0;
        if(s[0]=='!') {
            strcpy(s,s+1);
            neg=1;
        }

        i=b1;
        while(i<e1) {
            if(val[i]=='&'||!val[i]) {
                strcpy(cur_eval,&val[b1],i-b1);
                b1=i+1;
                break;
            } else
                i++;
        }
        curok=eval_expession(cur_eval);

        if(neg) curok= !curok;
        p=strtok(NULL,"&");
        if(p)
            strcpy(s,p);
        else
            s[0]=0;
        if(!curok)
            ok=0;
    }

    return ok;
}

int slok(char val[31],char menu)
{
    return(sleval(val,menu,0,strlen(val)));
}



