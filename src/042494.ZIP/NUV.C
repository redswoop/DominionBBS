#include "vars.h"
#pragma hdrstop

nuvrec nuvlist[30];
int numNuv;

void read_nuv()
{
    char s[81];
    int i;

    sprintf(s,"%snuv.dat",syscfg.datadir);
    i=open(s,O_BINARY|O_RDWR|O_CREAT,S_IREAD|S_IWRITE);
    numNuv=read(i,&nuvlist[0],filelength(i))/sizeof(nuvrec);
    close(i);
}

void write_nuv()
{
    char s[81];
    int i,i1;
    nuvrec n;

    sprintf(s,"%snuv.dat",syscfg.datadir);
    i=open(s,O_BINARY|O_RDWR|O_CREAT|O_TRUNC,S_IREAD|S_IWRITE);
    write(i,&nuvlist[0],sizeof(nuvrec)*numNuv);
    close(i);
}


void add_nuv(nuvrec *nv)
{
    int i;
    char s[81];

    sprintf(s,"%snuv.dat",syscfg.datadir);
    i=open(s,O_BINARY|O_RDWR|O_CREAT,S_IREAD|S_IWRITE);
    lseek(i,0L,SEEK_END);
    write(i,nv,sizeof(nuvrec));
    close(i);
}

void enter_nuv(userrec tu,int un,int form)
{
    char s[81];
    int i,num;
    nuvrec nu;

    read_nuv();

    for(i=0;i<numNuv;i++) {
        if(nuvlist[i].num==un) {
            pl("Already in NUV");
            pausescr();
            return;
        }
    }

    nu.remove=0;
    nu.num = un;
    nu.age = tu.age;
    strcpy(nu.name,tu.name);
    strcpy(nu.firston,tu.firston);

    nu.vote_yes = 0;
    nu.vote_no = 0;
    nu.vcmt_num = 0;
    strcpy(nu.snote,"");

    for (i = 0; i <20; i++) {
        nu.vote_comment[i].user=0;
        nu.vote_comment[i].vote = 0;
        nu.vote_comment[i].counts = 0;
        nu.vote_comment[i].sl = 0;
        strcpy(nu.vote_comment[i].say,"");
    }

    add_nuv(&nu);

    if(form) {
        infoform(nifty.nuvinf,0);
        printfile("nuvmsg");
    }
    logtypes(2,"%s added to NUV",nam(&tu,un));
}


int avoted(int which)
{
    int i;

    for (i=0; i < nuvlist[which].vcmt_num; i++)
        if(nuvlist[which].vote_comment[i].user==usernum)
            return(1);

    return 0;
}



void val_nuv(unsigned int user)
{
    int i,i1;
    nuvrec valn=nuvlist[user];
    userrec u;
    int work;

    for(i=user;i<numNuv;i++)
        nuvlist[i]=nuvlist[i+1];
    numNuv--;

    i1 = valn.num;
    read_user(i1,&u);
    u.nuv=-1;

    if (valn.vote_no >= nifty.nuvbad) {
        switch(nifty.nuvaction) {
        case 0:
            pl("7Deleting User");
            deluser(i1);
            logtypes(3,"NUV Deleted %s",nam(&u,i1));
            nl();
            pausescr();
            break;
        case 1:
            pl("7Locking Out User");
            u.inact |= inact_lockedout;
            logtypes(3,"NUV Locking Out %s",nam(&u,i1));
            write_user(i1,&u);
            u.nuv=0;
            nl();
            pausescr();
            break;
        case 2:
            pl("7Bad Validating User");
            u.sl=syscfg.autoval[nifty.nuvbadlevel-1].sl;
            u.dsl=syscfg.autoval[nifty.nuvbadlevel-1].dsl;
            u.ar=syscfg.autoval[nifty.nuvbadlevel-1].ar;
            u.dar=syscfg.autoval[nifty.nuvbadlevel-1].dar;
            u.restrict=syscfg.autoval[nifty.nuvbadlevel-1].restrict;
            logtypes(3,"NUV Bad Validated %s",nam(&u,i1));
            u.nuv=0;
            write_user(i1,&u);
            pausescr();
            break;
        }
    }
    else {
        pl("7Validating User");
        u.sl=syscfg.autoval[nifty.nuvlevel-1].sl;
        u.dsl=syscfg.autoval[nifty.nuvlevel-1].dsl;
        u.ar=syscfg.autoval[nifty.nuvlevel-1].ar;
        u.dar=syscfg.autoval[nifty.nuvlevel-1].dar;
        u.restrict=syscfg.autoval[nifty.nuvlevel-1].restrict;
        logtypes(3,"NUV Validated %s",nam(&u,i1));
        u.nuv=0;
        write_user(i1,&u);
        pausescr();
    }
}

void print_nuv(int which)
{
    char s[151];
    int i;
    userrec u,u1;

    read_user(nuvlist[which].num,&u);
    outchr(12);
    npr("3Voting On5: 3%s\r\n",nam(&u,nuvlist[which].num));
    nl();

    npr("3Yes Votes5: 2%d 3- Required: 3%d \r\n",nuvlist[which].vote_yes,nifty.nuvyes);
    npr("3No Votes 5: 2%d 3- Required: 3%d \r\n",nuvlist[which].vote_no,nifty.nuvbad);
    npr("3First on 5: 2%s\r\n",nuvlist[which].firston);
    nl();
    npr("3Comments On 5: 3%s3...",nam(&u,nuvlist[which].num));
    nl();

    for (i = 0; i < nuvlist[which].vcmt_num; i=i+1) {
        if (nuvlist[which].vote_comment[i].say[0]) {
            read_user(nuvlist[which].vote_comment[i].user,&u1);
            npr("3%-25s5: 2%s - 0%s"\
            ,nam(&u1,nuvlist[which].vote_comment[i].user)\
            ,nuvlist[which].vote_comment[i].vote?"Yay":"Nay"\
            ,nuvlist[which].vote_comment[i].say);
            nl();
        }
    }
    nl();
}


int vote_nuv(int user, int *done1)
{
    nuvrec vn=nuvlist[user];
    char s[81],cmt[81];
    int vv=0,done=0;
    userrec u;


    /*    if(so()) {
            nl();
            pl("0SysOp's Note");
            npr("5%s\r\n",vn.snote);
            nl();
            prt(5,"Change SysOp's Note? ");
            if (yn()) {
                inputl(vn.snote,65);
                nl();
            } 
            else nl();
        }*/

    while(!done&&!hangup) {
        print_nuv(user);

        if(vv!=0) {
            npr("3Your Vote Will Be: ");
            if(vv==1)
                npr("Yay");
            else if(vv==-1)
                npr("Nay");
            nl();
        }

        strcpy(s,"ISQ\r");
        if (!avoted(user)) {
            strcat(s,"YNC");
        } else
            pl("You've already voted on this user...just look");

        npr(get_string(88));

        switch(onek(s)) {
        case 'Q': 
            *done1=1; 
            done=1; 
            break;
        case 'S': 
            vv=0;
        case '\r': 
            done=1; 
            break;
        case 'I':
            read_user(vn.num,&u);
            readform(nifty.nuvinf,u.name);
            break;

        case 'Y':
            vv=1;
            break;

        case 'N':
            vv=-1;
            break;

        case 'C':
            nl();
            if(vv==0) {
                nl();
                pl("You must vote before you can comment.");
                nl();
                pausescr();
            } 
            else {
                npr("5Would You Like To Comment On This New User? ");
                if (yn()) {
                    inputdat("Comment to be seen by other voters",s,41,1);
                    if(s[0])
                        strcpy(cmt,s);
                }
            }
            break;
        }
    }


    if(vv) {
        if(vv==1)
            vn.vote_yes++;
        else if(vv==-1)
            vn.vote_no++;

        vn.vote_comment[vn.vcmt_num].user=usernum;
        vn.vote_comment[vn.vcmt_num].vote = vv;
        vn.vote_comment[vn.vcmt_num].sl = thisuser.sl;

        vn.vote_comment[vn.vcmt_num].say[0]=0;

        if(cmt[0])
            strcpy(vn.vote_comment[vn.vcmt_num].say,s);
        vn.vcmt_num++;
    }

    nuvlist[user]=vn;

    if ((vn.vote_yes>=nifty.nuvyes)||(vn.vote_no>=nifty.nuvbad)) {
        val_nuv(user);
        return 1;
    }

    return 0;
}




void nuv(void)
{
    userrec u;
    char s[81];
    int i,done=0,sh=0,done1;

    strcpy(s,nifty.nuvsl);
    if(!slok(s,0)) {
        nl();
        pl(get_string(59));
        nl();
        return;
    }

    read_nuv();

    i = 1;

    if(!numNuv) {
        nl();
        pl(get_string(58));
        nl();
        return;
    }


    while(!done&&!hangup) {
        outchr(12);
        npr("5Number of New Users: 2%d",numNuv);
        nl();
        nl();
        npr(get_string(57));
        s[0]=onek("?LVQ!\r");
        switch(s[0]) {
        case '!': 
            if(!so()) break;
            nl();
            inputdat("Remove Which? ",s,3,0);
            if(!s[0]) break;
            nuvlist[atoi(s)].remove=1;
            break;
        case '?': 
            printmenu(31);
            pausescr();
            break;
        case 'L':
            nl();
            for(i=0;i<numNuv;i++) {
                read_user(nuvlist[i].num,&u);
                if(nuvlist[i].remove)
                    npr("8 * ");
                npr("1<1%d1> 0%-35s 3[3%.3s3] 5[5%s5]\r\n",i,nam(&u,nuvlist[i].num),u.phone,u.comment);
            }
            nl();
            pausescr();
            break;
        case '\r':
        case 'Q':
            done=1;
            break;
        case 'V':
            sh=0;
            done1=0;
            for(i=0;i<numNuv&&!hangup&&!done1;i++) {
                sh=1;
                vote_nuv(i,&done1);
            }
            if(!sh) {
                nl();
                pl("Sorry, but you have already voted on all the users");
                pausescr();
            }
        }
    }
    write_nuv();
}
