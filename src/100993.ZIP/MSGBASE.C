#include "vars.h"

#pragma hdrstop

#include <mem.h>


/****************************************************************************/

void showmsgheader(char a,char title[81],char name[41],char date[41],char to[41],int reading, int nummsgs,char comment[51],char subnum,int *abort);
void show_message(int *next,int abort,char *buf,unsigned long len);

char *curtime(void)
{
    struct time t;
    struct date d;
    static char s[81],an[3];

    getdate(&d);
    gettime(&t);
    if(t.ti_hour>11) strcpy(an,"pm");
    else strcpy(an,"am");
    if(t.ti_hour==0) {
        t.ti_hour=12;
        strcpy(an,"pm");
    }
    if(t.ti_hour>12) t.ti_hour-=12;

    sprintf(s,"%02d:%02d:%02d%s  %02d/%02d/%02d",t.ti_hour,t.ti_min,t.ti_sec,an,d.da_mon,d.da_day,d.da_year-1900);
    return(s);
}



int external_edit(char *fn1, char *direc, int ednum, int numlines)
{
    char s[81];

    sprintf(s,"q %s%s",direc,fn1);
    runprog(s,0);
    sprintf(s,"%s%s",direc,fn1);
    if(!exist(s))
        return 0;
    else
        return 1;
}


int okfsed()
{
    int ok;

    if (!okansi())
        ok=0;
    if (!thisuser.defed)
        ok=0;
    return(ok);
}



void addline(char *b, char *s, long *ll)
{
    strcpy(&(b[*ll]),s);
    *ll +=strlen(s);
    strcpy(&(b[*ll]),"\r");
    *ll += 1;
    //  strcpy(&(b[*ll]),"\r\n");
    //  *ll += 2;
}



void imail(unsigned short u, unsigned short s)
{
    char s1[81],s2[81];
    int i;
    userrec ur;

/*    if (forwardm(&u,&s))
        pl("Mail forwarded.");*/

    if (!u && !s)
        return;

    i=1;
    read_user(u,&ur);
    if ((ur.inact & inact_deleted)==0) {
        npr("5Send Mail to %s? ",nam(&ur,u));
        if (yn()==0)
            i=0;
    } 
    else
        i=0;
    if (i)
        email(u,s,0,0);
}



void plan(char *s, int *abort, int *next)
{
    int i;

    i=0;
    checkhangup();
    if (hangup)
        *abort=1;
    checka(abort,next,0);
    while ((s[i]) && (!(*abort))) {
        outchr(s[i++]);
    }
    checka(abort,next,0);
    if (!(*abort))
        nl();
}

void showfile(char *fn)
{
    int i,abort=0;
    long l,l1;
    char *b;

    i=open(fn,O_BINARY|O_RDWR);
    if(i<0)
        return;

    l=filelength(i);
    b=malloca(l);
    read(i,b,l);
    close(i);

    show_message(&i,abort,b,l);

    farfree(b);
}

void printmenu(int which)
{
    int i,abort=0;
    long l,l1;
    char *b,ch,s[81];

    sprintf(s,"%smnudata.dat",syscfg.gfilesdir);

    i=open(s,O_BINARY|O_RDWR);
    if(i<0)
        return;

    lseek(i,menus[which].storage_type,0);
    l1=menus[which].stored_as;

    b=malloca(l1);
    read(i,b,l1);
    close(i);

    show_message(&i,abort,b,l1);

    farfree(b);
}

int printfile(char *fn)
{
    char s[81],s1[81],s2[3],tmp[81];
    messagerec m;
    int next,done=0;

    m.stored_as=0L;
    m.storage_type=255;
    strcpy(s,syscfg.gfilesdir);

    strcat(s,fn);
    if (strchr(s,'.')==NULL) {
        strcpy(tmp,s);

        if(thisuser.sysstatus & sysstatus_rip) {
            strcat(s,".RIP");
            if(exist(s))
                done=1;
        }

        if(!done&&(thisuser.sysstatus & sysstatus_avatar)) {
            strcpy(s,tmp);
            strcat(s,".AVT");
            if(exist(s))
                done=1;
        }

        if(!done&&(thisuser.sysstatus & sysstatus_color)) {
            strcpy(s,tmp);
            strcat(s,".ANS");
            if(exist(s))
                done=1;
        }

        if(!done&&(thisuser.sysstatus & sysstatus_ansi)) {
            strcpy(s,tmp);
            strcat(s,".B&W");
            if(exist(s))
                done=1;
        }

        if(!done) {
            strcpy(s,tmp);
            strcat(s,".MSG");
        }
    }

    next=0;
    if(!exist(s))
        return 0;
    showfile(s);
    return(1);
}


void showmsgheader(char a,char title[81],char name[41],char date[41],char to[41],int reading, int nummsgs,char comment[51],char subnum,int *abort)
{
    FILE *f;
    char s[255],s1[255],s2[10],s3[10],s4[41];
    int mcir=mciok;

    mciok=1;
    if(subboards[usub[subnum].subnum].attr & mattr_fidonet)
        sprintf(s,"%smsgnet%d.fmt",syscfg.gfilesdir,thisuser.mlisttype);
    else
        sprintf(s,"%smsg%d.fmt",syscfg.gfilesdir,thisuser.mlisttype);

    if(!exist(s)) {
        npr("By: %-30s, To:%s\r\n",name,to);
        npr("Title: %s\r\n",title);
        nl();
        return;
    }

    f=fopen(s,"rt");
    fgets(s,255,f);

    while((fgets(s,255,f))!=NULL) {
        filter(s,'\n');

        strcpy(s1,noc2(title));
        strcpy(title,s1);

        if(a==1) {
            strcpy(name,"Anonymous");
            strcpy(comment,"Unknown!");
        } 
        else if(a==2) {
            strcpy(s1,name);
            strcpy(name,"�");
            strcat(name,s1);
            strcat(name,"�");
        }

        strcpy(s4,noc2(subboards[usub[subnum].subnum].name));
        sprintf(s2,"%3d",reading);
        sprintf(s3,"%3d",nummsgs);

        stuff_in1(s1,s,title,name,date,to,"",comment,s2,s3,s4,"");
        pla(s1,abort);
    }
    fclose(f);
    mciok=mcir;
}



void osan(char *s, int *abort, int *next)
{
    int i;

    i=0;
    checkhangup();
    if (hangup)
        *abort=1;
    checka(abort,next,0);
    while ((s[i]) && (!(*abort))) {
        outchr(s[i++]);
    }
    checka(abort,next,0);
}


void getorigin(int origin, originrec *or)
{
    int i;
    char s[81];

    sprintf(s,"%sorigin.dat",syscfg.datadir);
    i=open(s,O_BINARY|O_RDWR);
    lseek(i,sizeof(originrec)*origin,0);
    read(i,or,sizeof(originrec));
    close(i);
}

void upload_post()
{
  char s[81],s1[21],ch;
  int i,i1,maxli,f;
  long l;

  if(incom) {
     npr("5Upload Prepared File? ");
     if(!yn()) return;
  } else {
      npr("5Load Local File? ");
      if(yn()) {
          nl();
          inputdat("File Name",s,61,0);
          load_workspace(s,1);
     }
     return;
  } 

  sprintf(s,"%smsgtmp",syscfg.tempdir);

  nl();
  npr("You may now upload a message.");
  nl();
  receive_file(s,&i1,s1,0);
  f=open(s,O_RDWR | O_BINARY);
  if (f>0) {
      close(f);
      use_workspace=1;
      nl();
  } else {
    nl();
    pl("Nothing Recieved, Sorry.");
    nl();
  }
}
