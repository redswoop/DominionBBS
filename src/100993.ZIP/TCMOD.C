#include "vars.h"
#pragma hdrstop


void far moddevice( int *device );
void far modvolume( int vol1, int vol2,int vol3,int vol4);
void far modsetup( char *filenm, int looping, int prot,int mixspeed,
									 int device, int *status);
void far modstop(void);
void far modinit(void);

playmod(char fn[15])
{
    int dev,mix,vol,stat,i,i1;
	char md[41];

	modinit();
	vol = 255;
	mix = 10000;
    dev=0;
	modvolume(vol,vol,vol,vol);
    modsetup( fn, 4, 0 ,mix, dev, &stat );
    i=0;
    do {
      wait1(30);
      outstr(get_string(17));
      if(kbhitb()) {
        dev=getch();
        if(dev==13) {
            chatsoundon=0;
            modstop();
        }
        else if(dev==32) {
            chatreason[0]=0;
            topscreen();
            modstop();
            chat1("",syscfg.sysconfig & sysconfig_2_way);
            return;
        }
      }
    } while(i++<10);
	modstop();
}
