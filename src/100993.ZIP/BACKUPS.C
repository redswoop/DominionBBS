#include <dos.h>

void main(void)
{

    char s[81];
    struct date d;

    getdate(&d);
    sprintf(s,"pkzip -ex -u    d:\\lisa\\%02d%02d%02d.zip *.c *.h *.mak *. *.asm",d.da_mon,d.da_day,d.da_year-1900);
    system(s);
}
