#include "vars.h"

#pragma hdrstop



void print_quests(int f)
{
  char s[100];
  int i,abort;
  votingrec v;

  abort=0;
  npr("0NN2�0Question2����������������������������������0Answers2���������");
  nl();
  for (i=1; (i<=20) && (abort==0); i++) {
    lseek(f,((long) (i-1)) * sizeof(votingrec), SEEK_SET);
    read(f,(void *)&v,sizeof(votingrec));
    if(!v.numanswers) strcpy(v.question,"Empty");
    sprintf(s,"3%2d 3%-45.45s 3%d",i,v.question,v.numanswers);
    pla(s,&abort);
  }
  nl();
  if (abort)
    nl();
}

void del_question(int f, int ii)
{
  votingrec v,v1;
  int i,i1,i2;
  char s[81];
  userrec u;
  voting_response vr;

  v.numanswers=0;
  vr.numresponses=0;
  vr.response[0]='X';
  vr.response[1]=0;
  for (i=0; i<20; i++)
    v.responses[i]=vr;

  lseek(f,((long) (ii)) * sizeof(votingrec), SEEK_SET);
  write(f,(void *)(&v),sizeof(votingrec));
  lseek(f,((long) (ii)) * sizeof(votingrec), SEEK_SET);
  read(f,(void *)(&v1),sizeof(votingrec));
  close(f);
  if (v.numanswers)
    questused[ii]=1;
  else
    questused[ii]=0;

  read_user(1,&u);
  i1=number_userrecs();
  for (i=1; i<=i1; i++) {
    read_user(i,&u);
    u.votes[ii]=0;
    write_user(i,&u);
  }
  close_user();
}

votingrec vvv;

void editres(votingrec v,int which)
{
    int done=0,i,i1;
    char s[81],c;

    do {
        outchr(12);
        npr("0Editing Question %d: 2%s\r\n",which,v.question);

        for(i=0;i<v.numanswers;i++)
            npr("3%2d  3%s\r\n",i,v.responses[i].response);
        nl();
        outstr(get_string2(1));
        c=onek("QMID");
        switch(c) {
            case 'Q': done=1; break;
            case 'I': /*npr("3Enter New Answer\r\n5: ");
                      mpl(71);
                      inputl(s,71);*/
                      inputdat("Enter New Answer",s,71,1);
                      if(s[0])
                        strcpy(v.responses[v.numanswers++].response,s);
                      break;
            case 'M': nl();
                      outstr("2Modify Which? ");
                      input(s,3);
                      if(atoi(s)>=0&&atoi(s)<v.numanswers) {
                        i=atoi(s);
                        nl();
                        npr("3%2d  3%s\r\n",i,v.responses[i].response);
                        nl();
                        npr("3Enter New Answer\r\n5: ");
                        mpl(71);
                        inputl(s,71);
                        if(s[0]) strcpy(v.responses[i].response,s);
                      } break;
            case 'D': nl();
                      outstr("2Delete Which? ");
                      input(s,3);
                      if(atoi(s)>=0&&atoi(s)<v.numanswers) {
                        i=atoi(s);
                        for(i1=v.numanswers;i1>i;i1--)
                            strcpy(v.responses[i1-1].response,v.responses[i1].response);
                        v.numanswers--;
                      }
                      break;
        }
    } while(!done&&!hangup);

    vvv=v;
}


void mod_question(int f, int ii)
{
  votingrec v,v1;
  int i,i1,i2;
  char s[81],c;
  userrec u;
  voting_response vr;
  int done=0;

  lseek(f,((long) (ii)) * sizeof(votingrec), SEEK_SET);
  read(f,(void *)&v,sizeof(votingrec));

  do {
      outchr(12);
      npr("31. Question: 0%-45.45s\r\n",v.question);
      npr("32. Reponses: 0%d Responses\r\n",v.numanswers);
      nl();
      outstr("3Voting Editor: ");
      c=onek("Q12");

      switch(c) {
           case '1': /*npr("3Enter new question, <C/R> for none.\r\n5: ");
                     mpl(75);
                     inputl(s,81);*/
                     inputdat("Enter new question, <C/R> for none.",s,71,1);
                     if(s[0]) strcpy(v.question,s);
                     break;
           case '2': editres(v,ii);
                     v=vvv;
                     break;
           case 'Q': done=1; break;
      }

  } while(!done&&!hangup);

  lseek(f,((long) (ii)) * sizeof(votingrec), SEEK_SET);
  write(f,(void *)(&v),sizeof(votingrec));
  lseek(f,((long) (ii)) * sizeof(votingrec), SEEK_SET);
  read(f,(void *)(&v1),sizeof(votingrec));
  close(f);
  if (v.numanswers)
    questused[ii]=1;
  else
    questused[ii]=0;

  read_user(1,&u);
  i1=number_userrecs();
  for (i=1; i<=i1; i++) {
    read_user(i,&u);
    u.votes[ii]=0;
    write_user(i,&u);
  }
  close_user();
}


void ivotes()
{
  int i,f,abort,n,done;
  char s[81],c;
  votingrec v;

  outchr(12);
  close_user();
  sprintf(s,"%sVOTING.DAT",syscfg.datadir);
  f=open(s,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
  n=(int) (filelength(f) / sizeof(votingrec)) -1;
  if (n<20) {
    v.question[0]=0;
    v.numanswers=0;
    for (i=n; i<20; i++)
      write(f,(void *)&v,sizeof(votingrec));
  }
  done=0;

  do {
    outchr(12);
    print_quests(f);
    nl();
    outstr(get_string2(1));
    c=onek("QMID");
    switch(c) {
        case 'Q': done=1; break;
        case 'D':
        case 'M': nl();
                  prt(2,"Question Number? ");
                  input(s,2);
                  i=atoi(s);
                  if(s[0]&&i>0&&i<21) {
                    nl();
                    if(c=='D') del_question(f,i-1);
                    else mod_question(f,i-1);
                    sprintf(s,"%sVOTING.DAT",syscfg.datadir);
                    f=open(s,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
                  }
                  break;
    }
  } while ((!done) && (!hangup));
  close(f);
}


void voteprint()
{
  int f,f1,i,i1,i2,i3,nu;
  char s[81],s1[81],s2[81];
  votingrec v;
  char *x;
  userrec u;

  read_user(1,&u);
  nu=number_userrecs();
  if ((x=malloca(20*(2+nu)))==NULL)
    return;
  for (i=0; i<nu; i++) {
    read_user(i,&u);
    for (i1=0; i1<20; i1++)
      x[i1+i*20]=u.votes[i1];
  }
  close_user();
  sprintf(s,"%svoting.dat",syscfg.datadir);
  if(!exist(s)) return;
  sprintf(s,"%sVOTING.TXT",syscfg.gfilesdir);
  f=open(s,O_RDWR | O_BINARY | O_CREAT | O_TRUNC, S_IREAD | S_IWRITE);
  sprintf(s,"%sVOTING.DAT",syscfg.datadir);
  f1=open(s,O_RDWR | O_BINARY);
  sprintf(s,"Voting results as of %s\r\n\r\n",date());
  write(f,(void *)s,strlen(s));

  for (i=0; i<20; i++) {
    lseek(f1,((long)i)*sizeof(votingrec),SEEK_SET);
    read(f1,(void *)&v,sizeof(votingrec));
    if (v.numanswers) {
      pl(v.question);
      sprintf(s,"\r\n%s\r\n",v.question);
      write(f,s,strlen(s));
      for (i1=0; i1<v.numanswers; i1++) {
	sprintf(s,"     %s\r\n",v.responses[i1].response);
	write(f,s,strlen(s));
	for (i2=0; i2<status.users; i2++)
          if (x[i+20*smallist[i2].number]==i1+1) {
	    sprintf(s,"          %s #%d\r\n",smallist[i2].name,smallist[i2].number);
	    write(f,s,strlen(s));
	  }
      }
    }
  }

  close(f1);
  close(f);
  farfree(x);
}

int add_question(int ii, votingrec v)
{
  votingrec v1;
  int i,i1,i2,f;
  char s[81];
  userrec u;
  voting_response vr;

  if(v.numanswers>19) return 0;

  sprintf(s,"%svoting.dat",syscfg.datadir);
  f=open(s,O_RDWR|O_BINARY);
  npr("0Enter New Response\r\n%d5: ",v.numanswers+1);
  mpl(63);
  inputl(s,63);
  strcpy(vr.response,s);
  vr.numresponses=1;
  v.responses[v.numanswers]=vr;
  if (s[0]) ++v.numanswers;

  lseek(f,((long) (ii)) * sizeof(votingrec), SEEK_SET);
  write(f,(void *)(&v),sizeof(votingrec));
  close(f);
  return v.numanswers;
}
