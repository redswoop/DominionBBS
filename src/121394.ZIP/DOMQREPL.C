int xreadqwkmsg (FILE *fp,QWKHDR *qwh,char **hold, long *ll)
{

    QWKHDR    hdr;
    time_t    t;
    struct tm *tm;
    long      size,pos,len;
    int error=0,rep=1;
    char *p;

    *hold = NULL;


    /* get header */


    if(!qwkreadhdr(fp,&hdr,rep)) {
        error = 1;    /* end of the line */
        return 1;
    }


    pos = ftell(fp);

    /* now get text */

    size = hdr.numchunks * (long)QWKBLKSIZE;
    if(!size) {
        error = 1;    /* possible? */
        return error;
    }


    if(size > 65024L) size = 65024L;
    *hold = malloc((size_t)(size + 1L));
    if(!*hold) {
        error = 1;     /* fatal */
        return error;
    }

    if(!qwkreadblks(fp,*hold,(size_t)(size / (long)QWKBLKSIZE))) {
        farfree(*hold);
        *hold = NULL;
        fseek(fp,pos + (hdr.numchunks * (long)QWKBLKSIZE),SEEK_SET);
        error = 1;    /* maybe not fatal */
        return 1;
    }
    fseek(fp,pos + (hdr.numchunks * (long)QWKBLKSIZE),SEEK_SET);

    rstrip(*hold);
    len = strlen(*hold);

    /* "treat" the message */


    p = *hold;
    while (*p) {
        if(*p == '\x8d' || *p == '\n') {
            memmove(p,&p[1],len - ((unsigned int)p - (unsigned int)*hold));
            len--;
            if(!len) break;
            continue;
        }
        else p++;
    }

    if(*(p - 1) != '\r' && p > *hold) {
        *p = '\r';
        p[1] = 0;
    }

    if(len==0) {
        farfree(*hold);
        *hold = NULL;
        error = 1;    /* maybe not fatal */
    }

    *qwh = hdr;
    *ll = len;
    return error;
}


void qwkwmsg(QWKHDR qwk,char *b,long len)
{
    messagerec m;
    postrec p;
    char s[121], s1[41];
    int i, dm, a, f,bn;
    long len1, len2, r, w;
    char *b1;


    sprintf(s, "%smsgtmp", syscfg.tempdir);
    i = open(s, O_BINARY | O_RDWR | O_CREAT | O_TRUNC, S_IREAD | S_IWRITE);
    write(i, b, len);

    f = 26;
    write(i, &f, 1);
    close(i);
    farfree(b);

    m.storage_type = 2;

    use_workspace = 1;
    strcpy(irt, qwk.subj);
    if(!qwk.to[0])
        strcpy(qwk.to,"All");
    strcpy(irt_name, qwk.to);
    strcpy(irt_from, qwk.from);
    fidotoss = 1;
    a = 0;
    bn=qwk.confnum-1;
    fiscan(bn);

    npr("Adding '%s' to %s\r\n",irt,subboards[bn].name);
    inmsg(&m, p.title, &a, 1, (subboards[bn].filename), 0);

    if (m.stored_as != 0xffffffff) {
        p.anony = a;
        p.msg = m;
        p.ownersys = 1;
        p.owneruser = 1;
        p.qscan = status.qscanptr++;
        time((long *) (&p.daten));
        p.status = 0;
        if (nummsgs >= subboards[bn].maxmsgs) {
            i = 1;
            dm = 0;
            while ((dm == 0) && (i <= nummsgs)) {
                if ((msgs[i].status & status_no_delete) == 0)
                    dm = i;
                ++i;
            }
            if (dm == 0)
                dm = 1;
            delete(dm);
        }
        msgs[++nummsgs] = p;
        ++status.msgposttoday;
    }
    fsavebase(bn);
}

void qwkreply(void)
{

    FILE *qwk;
    int area;
    char *hold,s1[81],s[81],s2[81];
    QWKHDR p;
    long len,fl;
    int i;


    if(outcom) {
        remove_from_temp("*.*",syscfg.tempdir,0);
        dtitle("QWK Reply Upload");
        nl();
        sprintf(s1,"%s%s.rep",syscfg.tempdir,syscfg.menudir);
        receive_file(s1,&i,s,0);
    } 
    else {
        dtitle("Local QWK Import");
        nl();
        inputdat("Enter full Packet pathname",s1,76,0);
    }

    if(!exist(s1))
        return;

    sprintf(s,"%s.msg",syscfg.menudir);

    unarc(s1,s);
    if(!exist(s)) {
        npr("Couldn't find %s!\r\n",s);
        return;
    }

    dtitle("Successfully Received Packet: Processing");

    qwk=flopen(s,"rb",&fl);

    fseek(qwk,128L,SEEK_SET);

    while(!feof(qwk)&&ftell(qwk)<fl) {
        if(xreadqwkmsg(qwk,&p,&hold,&len)==0) {
            qwkwmsg(p,hold,len);
        }
    }

    fclose(qwk);
}



