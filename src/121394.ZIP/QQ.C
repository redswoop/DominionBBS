#include <stdio.h>
#include <string.h>
#include <alloc.h>
#include <fcntl.h>

List Quote;

char *quote(char *buf,char *initials)
{
    char storedWord[81];
    char line[161],line2[161];
    char *quoteBuffer;
    char *p;
    int i;


    storedWord[0]=0;
    quoteBuffer=(char *)malloc(strlen(buf)+1024);
    quoteBuffer[0]=0;


    p=strtok(buf,"\r");
    while(p) {
        if(kbhit())
            exit(0);

        strcpy(line,p);
        if(strchr(line,'>')==NULL)
            strcpy(line2,initials);
        else
            strcpy(line2,"");

        if(storedWord[0]) {
            strcat(line2,storedWord);
            strcat(line2," ");
            storedWord[0]=0;
        }

        strcat(line2,line);

        if(strlen(line2)>80) {
            for(i=strlen(line2);i>0&&(line2[i]!=32||i>79);i--);
            strcpy(storedWord,&line2[i+1]);
            line2[i]=0;
        }
        strcat(quoteBuffer,line2);
        InsertLink(&Quote,numLinks(&Quote),&line2);

        p=strtok(NULL,"\r");
    }

    return quoteBuffer;
}


int main(int argc,char **argv)
{
    FILE *f;
    char *buf;
    char ch;
    char s[2];
    int i;

    i=open(argv[1],O_TEXT|O_RDWR);
    buf=(char *)malloc(filelength(i));

    f=fdopen(i,"rt");
    buf[0]=0;

    while((ch=fgetc(f))!=EOF) {
        if(ch=='\n')
            ch='\r';
        s[0]=ch;
        s[1]=0;
        strcat(buf,s);
    }
    fclose(f);

    puts(quote(buf,"FA> "));
}
