#pragma hdrstop
#include <alloc.h>

#include "link.h"

int numLinks(List *list)
{
    return list->num;
}

nodeL *FindLink(List *list,int which)
{
    int i;
    nodeL *p=list->head;

    if(which<0||which>list->num)
        return NULL;

    if(!which)
        return p;

    for(i=0;i<which;i++)
        p=p->next;

    return p;           
}

int GetLink(List *list,int which,void *v)
{
    nodeL *p;

    if(which<0||which>list->num) {
        printf("getitem error out of bounds (%d from %d)\n",which,list->num);
        exit(100);
    }

    p=FindLink(list,which);
    memcpy(v,p->data,list->size);
    return 0;
}

int PutLink(List *list,int which,void *v)
{
    nodeL *p;

    if(which<0||which>list->num) {
        puts("putitem error out of bounds");
        exit(101);
    }

    p=FindLink(list,which);
    memcpy(p->data,v,list->size);
    return 0;
}

int InsertLink(List *list,int as,void *data)
{
    nodeL *p,*q;


    if(!as) {
        if(list->num<1) {
            list->head=(nodeL *)malloc(sizeof(nodeL));
            if(list->head==NULL) {
                puts("argh 1!");
                return -2;
            }
            list->head->data=malloc(list->size);
            memcpy(list->head->data,data,list->size);
            list->head->next=0;
        } 
        else {
            q=(nodeL *)malloc(sizeof(nodeL));
            if(q==NULL) {
                puts("argh 2!");
                return -1;
            }
            q->data=malloc(list->size);
            memcpy(q->data,data,list->size);
            q->next=list->head;
            list->head=q;
        }
        list->num++;
        return 0;
    }

    p=FindLink(list,as-1);
    q=(nodeL *)malloc(sizeof(nodeL));
    if(q==NULL) {
        puts("argh 3!");
        return -2;
    }
    q->data=malloc(list->size);
    memcpy(q->data,data,list->size);
    q->next=p->next;
    p->next=q;
    list->num++;
    return 0;
}

int DeleteLink(List *list,int which)
{
    nodeL *p,*q;

    if(which<0||which>list->num)
        return 1;

    list->num--;

    if(!which) {
        p=list->head;
        list->head=p->next;
        farfree(p->data);
        farfree(p);
        return 0;
    }
    p=FindLink(list,which - 1);
    q=FindLink(list,which);
    p->next=q->next;
    farfree(q->data);
    farfree(q);
    return 0;
}

void createList(List *l,long size)
{
    l->head=NULL;
    l->size=size;
    l->num=0;
}

void deleteList(List *l)
{
    while(numLinks(l))
        DeleteLink(l,0);

    l->head=NULL;
}
