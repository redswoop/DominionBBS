#include "vars.h"
#pragma hdrstop

/*
void CreateArea(subboardrec *r)
{
    int i,n=num_subs-1;

    for (i=num_subs-1; i>=n; i--)
        subboards[i+1]=subboards[i];
    subboards[n]=(*r);
    ++num_subs;
}

void AutoCreate(void)
{
    FILE *f;
    char s[81];
    char *p;
    subboardrec r;
    int i,i1,nu;

    f=fopen("Areas.new","rt");
    while(fgets(s,81,f)!=NULL) {
        p=strtok(s,",");
        strcpy(r.filename,p);
        p=strtok(NULL,",");
        strcpy(r.name,p);
        p=strtok(NULL,",");
        strcpy(s,p);
        r.attr=0;
        if(s[0]=='N')
            togglebit((long *)&r.attr,mattr_fidonet);
        r.nmpath[0]=0;
        r.conf='@';
        strcpy(r.readacs,"S20");
        strcpy(r.postacs,"S20");
        r.anony=0;
        togglebit((long *)&r.anony,anony_enable_anony);
        r.age=0;
        r.maxmsgs=50;
        r.ar=0;
        r.storage_type=2;
        r.origin=0;
        memset(&r.add.zone,0,sizeof(r.add));
        CreateArea(&r);
        npr("5Area 9%s 5created\r\n",r.name);
    }
    fclose(f);
}

*/

void printSubData(int n, char *s)
{
    char x,y,k,i,s1[81];
    subboardrec r;

    GetLink(&subboards,n,&r);
    if (r.ar==0)
        x=32;
    else {
        for (i=0; i<16; i++)
            if ((1 << i) & r.ar)
                x='A'+i;
    }
    noc(s1,r.name);
    sprintf(s,"3%2d 3%c  3%-40s  3%-8s 3%-4s 3%-4s 3%-3d 3%c",
    n,x,s1,r.filename,r.readacs,r.postacs,r.maxmsgs,r.conf);
}

void showSubs()
{
    int abort,i;
    char s[180];

    outchr(12);
    abort=0;
    pla("0NN2�0AR2�0Name2��������������������������������������0FileName2�0RAcs2�0PAcs2�0Max2�0Conf2",
    &abort);
    for (i=0; (i<numLinks(&subboards)) && (!abort); i++) {
        printSubData(i,s);
        pla(s,&abort);
    }
}




void modifySub(int n)
{
    subboardrec r;
    char s[81],s1[81],ch,ch2,*p;
    int i,i1,done;
    unsigned int ui;

    done=0;
    GetLink(&subboards,n,&r);

    do {
        outchr(12);
        npr("31. Name         : 0%s\r\n",r.name);
        npr("32. Filename     : 0%s\r\n",r.filename);
        npr("33. Conference   : 0%c\r\n",r.conf);
        npr("34. Read SL      : 0%s\r\n",r.readacs);
        npr("35. Post SL      : 0%s\r\n",r.postacs);
        npr("36. Min. Age     : 0%d\r\n",r.age);
        npr("37. Max Msgs     : 0%d\r\n",r.maxmsgs);
        strcpy(s,"None.");
        if (r.ar!=0) {
            for (i=0; i<16; i++)
                if ((1 << i) & r.ar)
                    s[0]='A'+i;
            s[1]=0;
        }
        npr("38. AR           : 0%s\r\n",s);
        npr("39. Address      : 0%d:%d/%d\r\n",r.add.zone,r.add.net,r.add.node);
        npr("30. Origin Type  : 0%d\r\n",r.origin);
        npr("3E. Netmail Path : 0%s\r\n",r.nmpath);
        s[0]=196;
        if(r.attr & mattr_ansi_only) s[1]='G'; 
        else s[1]='�';
        if(r.attr & mattr_autoscan) s[2]='A'; 
        else s[2]='�';
        if(r.attr & mattr_fidonet) s[4]='F'; 
        else s[4]='�';
        if(r.attr & mattr_nomci) s[6]='M'; 
        else s[6]=196;
        if(r.attr & mattr_netmail) s[7]='N'; 
        else s[7]=196;
        if(r.attr & mattr_private) s[8]='P';
        else s[8]='�';

        if(r.anony & anony_real_name) s[5]='R'; 
        else s[5]='�';
        if(r.anony & anony_enable_anony) s[3]='U'; 
        else s[3]='�';


        s[9]=0;

        npr("3Flags           :0 %s\r\n",s);
        nl();
        nl();
        prt(5,"Message Base Edit (?=Help) ? ");
        ch=onek("!Q1234567890AVFUGRNEMJOP[]?");
        switch(ch) {
        case 'O':
            fidocfg();
            break;
        case '?': 
            printmenu(28); 
            pausescr(); 
            break;
        case 'Q':
            done=1; 
            break;
        case '1':
            nl();
            strcpy(s1,"");
            prt(2,"New Name? ");
            inli(s,s1,40,1);
            if (s[0])
                strcpy(r.name,s);
            break;
        case '2':
            nl();
            inputdat("Filename/Net Directory",s,8,0);
            if ((s[0]!=0) && (strchr(s,'.')==0))
                strcpy(r.filename,s);
            break;
        case '3':
            nl();
            prt(2,"New Conference (@=All): ");
            r.conf=onek("ABCDEFGHIJKLMNOPQRSTUVWXYZ@!1234567890");
            break;
        case '4':
            nl();
            inputdat("New Read ACS",s,21,0);
            if(s[0]) strcpy(r.readacs,s);
            break;
        case '5':
            nl();
            inputdat("New Post ACS",s,21,0);
            if(s[0]) strcpy(r.postacs,s);
            break;
        case '6':
            nl();
            inputdat("Minimum Age",s,3,0);
            i=atoi(s);
            if ((i>=0) && (i<128) && (s[0]))
                r.age=i;
            break;
        case '7':
            nl();
            inputdat("Maximum Messages (1-65534)",s,5,0);
            ui=atoi(s);
            if ((ui>0) && (ui<65534) && (s[0]))
                r.maxmsgs=ui;
            break;
        case '8':
            nl();
            prt(5,"New AR (<SPC>=None) ? ");
            ch2=onek("ABCDEFGHIJKLMNOP ");
            if (ch2==32)
                r.ar=0;
            else
                r.ar=1 << (ch2-'A');
            break;
        case '!':
            r.storage_type=2; 
            break;
        case '9':
            nl();
            inputdat("Enter Specific Origin, or Blank to use Default",s,20,0);
            if(!s[0]) { 
                r.add.zone=0; 
                r.add.net=0; 
                r.add.node=0; 
            }
            else {
                strcpy(s1,s);
                p=strtok(s1,":");
                r.add.zone=atoi(p);
                p=strtok(NULL,"/");
                r.add.net=atoi(p);
                p=strtok(NULL,"");
                r.add.node=atoi(p);
            }
            break;
        case '0':
            nl();
            inputdat("Use which Origin/Address? (0=Main)",s,3,0);
            if(s[0]) r.origin=atoi(s);
            break;
        case 'E':
            nl();
            inputdat("New Netmail Path",s,51,0);
            if(s[0]) strcpy(r.nmpath,s);
            break;
        case 'G': 
            togglebit((long *)&r.attr,mattr_ansi_only);
            break;
        case 'A': 
            togglebit((long *)&r.attr,mattr_autoscan);
            break;
        case 'F': 
            togglebit((long *)&r.attr,mattr_fidonet);
            break;
        case 'M': 
            togglebit((long *)&r.attr,mattr_nomci);
            break;
        case 'P':
            togglebit((long *)&r.attr,mattr_private);
            break;
        case 'N': 
            togglebit((long *)&r.attr,mattr_netmail);
            break;
        case 'U': 
            togglebit((long *)&r.anony,anony_enable_anony);
            break;
        case 'R': 
            togglebit((long *)&r.anony,anony_real_name);
            break;
        }
    } 
    while ((!done) && (!hangup));
    PutLink(&subboards,n,&r);
    if (!wfc)
        changedsl();
}



void swapSubs(int sub1, int sub2)
{
    int i,i1,i2,nu;
    unsigned long tl,tl1;
    subboardrec sb1,sb2;
    userrec u;

    GetLink(&subboards,sub1,&sb1);
    GetLink(&subboards,sub2,&sb2);

    PutLink(&subboards,sub2,&sb1);
    PutLink(&subboards,sub1,&sb2);

}


void insertSub(int n,int config)
{
    subboardrec r;
    int i,i1,nu;
    userrec u;
    long l1,l2,l3;
    char s[81];

    inputdat("Name for New Sub",r.name,41,1);
    if(!r.name[0])
        strcpy(r.name,"New Sub!");

    inputdat("JAM Filename for New Area",r.filename,8,0);
    if(!r.filename[0])
        strcpy(r.filename,"NONAME");

    sprintf(s,"%s.nws",syscfg.msgsdir);
    unlink(s);

    r.nmpath[0]=0;
    r.conf='@';
    strcpy(r.readacs,"S20");
    strcpy(r.postacs,"S20");
    r.anony=0;
    r.attr=0;
    togglebit((long *)&r.anony,anony_enable_anony);
    r.age=0;
    r.maxmsgs=50;
    r.ar=0;
    r.storage_type=2;
    r.origin=0;
    memset(&r.add.zone,0,sizeof(r.add));

    InsertLink(&subboards,n,&r);

    if(config)
        modifySub(n);
}


void deleteSub(int n)
{
    int i,i1,i2,nu;
    userrec u;
    long l1,l2;
    char s[81];

    DeleteLink(&subboards,n);
}

void saveSubList(void)
{
    char s[81];
    int i;
    int i1;
    subboardrec tmpSub;

    sprintf(s,"%ssubs.dat",syscfg.datadir);
    i=open(s,O_RDWR|O_BINARY|O_CREAT|O_TRUNC,S_IREAD|S_IWRITE);
    if(i<0) {
        err(4,s,"saveSubList");
        return;
    }
    for(i1=0;i1<numLinks(&subboards);i1++) {
        GetLink(&subboards,i1,&tmpSub);
        write(i,&tmpSub,sizeof(subboardrec));
    }
    close(i);
}

void boardedit()
{
    int i,i1,i2,done,f;
    char s[81],s1[81],s2[81],ch;

    if (!checkpw())
        return;
    showSubs();
    done=0;
    do {
        nl();
        outstr(get_string2(18));
        ch=onek("QDIM?P!");
        switch(ch) {
        case '?':
            showSubs();
            break;
        case 'Q':
            done=1;
            break;
        case 'P':
            pl("Swapping Areas");
            nl();
            prt(5,"First area? ");
            input(s,2);
            i=atoi(s);
            if ((s[0]!=0) && (i>=0) && (i<numLinks(&subboards))) {
                prt(5,"Second area? ");
                input(s,2);
                i1=atoi(s);
                if ((s[0]!=0) && (i1>=0) && (i1<numLinks(&subboards))&&(i!=i1))
                    swapSubs(i,i1);
            }
            break;
        case 'M':
            nl();
            prt(5,"Which area? ");
            input(s,2);
            i=atoi(s);
            if ((s[0]!=0) && (i>=0) && (i<numLinks(&subboards)))
                modifySub(i);
            break;
        case 'I':
                nl();
                prt(5,"Insert before which Area? ");
                input(s,2);
                i=atoi(s);
                if(i==0)
                    pl("Nothing can be inserted before area 0!");
                else if ((s[0]!=0) && (i>=0) && (i<=numLinks(&subboards)))
                    insertSub(i,1);
            break;
        case 'D':
            nl();
            prt(2,"Delete which Area? ");
            input(s,2);
            i=atoi(s);
            if(i==0)
                pl("Area #0 Cannot be deleted!");
            else {
                sprintf(s1,"Delete %d? ",i);
                prt(5,s1);
                if (yn())
                    deleteSub(i);
            }
            break;
        }
    } 
    while ((!done) && (!hangup));

    saveSubList();
}


void confdata(int n, char *s)
{
    char x,y,k,i,s1[81];
    confrec r;

    r=conf[n];
    noc(s1,r.name);
    sprintf(s,"3%2d  3%-40s 3%-8s 3%s",n,s1,r.sl,r.flagstr);
}

void showconf()
{
    int abort,i;
    char s[180];

    outchr(12);
    abort=0;
    pla("0NN2��0Name2�������������������������������������0SL2�������0Flags2������������������",&abort);
    for (i=0; (i<num_conf) && (!abort); i++) {
        confdata(i,s);
        pla(s,&abort);
    }
}



void modify_conf(int n)
{
    confrec r;
    char s[81],s1[81],ch,ch2;
    int i,i1,done;

    done=0;
    r=conf[n];

    do {
        outchr(12);
        npr("31. Name       : 0%s\r\n",r.name);
        npr("32. ACS        : 0%s\r\n",r.sl);
        npr("33. Flags      : 0%s\r\n",r.flagstr);
        strcpy(s,"All");
        if(r.type=='M') strcpy(s,"Message");
        if(r.type=='F') strcpy(s,"File");
        npr("34. Type       : 0%s\r\n",s);
        nl();
        outstr("5Conefence Editor (?=Help) 0");
        ch=onek("Q1234J[]T");
        switch(ch) {
        case ']': 
            if((n>=0) && (n<num_conf-1))
            { 
                conf[n++]=r;
                r=conf[n];
            } 
            break;

        case '[': 
            if(n>0) { 
                conf[n--]=r;
                r=conf[n];
            } 
            break;
        case 'J': 
            nl(); 
            outstr("To Which Conference? ");
            input(s,3);
            if(s[0]) {
                i=atoi(s);
                conf[n]=r;
                r=conf[i];
            } 
            break;
        case 'Q':
            done=1; 
            break;
        case '1':
            nl();
            strcpy(s1,"");
            npr("3Name for Confernece\r\n5: 0");
            inli(s,s1,40,1);
            if (s[0]) strcpy(r.name,s);
            break;
        case '2':
            nl();
            inputdat("New SL (Can Include Menu Type Codes)",s,10,0);
            if(s[0])  strcpy(r.sl,s);
            break;
        case '3':
            nl();
            inputdat("Flags for this Conference",s,10,0);
            if(s[0]) strcpy(r.flagstr,s);
            break;
        case '4':
            nl();
            outstr("5Enter Conference Type (3M,F,A5) ");
            ch=onek("MFA\r");
            if(ch=='A'||ch=='\r') r.type=0;
            else r.type=ch;
            break;
        }                                 

    } 
    while ((!done) && (!hangup));
    conf[n]=r;
    if (!wfc)
        changedsl();
}


void insert_conf(int n)
{
    confrec r;
    int i,i1,nu;
    userrec u;
    long l1,l2,l3;

    for (i=num_conf-1; i>=n; i--)
        conf[i+1]=conf[i];

    strcpy(r.name,">New Conference<");
    strcpy(r.sl,"s20");
    strcpy(r.flagstr,"");
    conf[n]=r;
    ++num_conf;
    modify_conf(n);
}


void delete_conf(int n)
{
    int i,i1,nu;
    userrec u;
    long l1,l2;

    for (i=n; i<num_conf; i++)
        conf[i]=conf[i+1];
    --num_conf;
    if (!wfc)
        changedsl();
}


void confedit()
{
    int i,i1,i2,done,f;
    char s[81],s1[81],s2[81],ch;

    if (!checkpw())
        return;
    showconf();
    done=0;
    do {
        nl();
        outstr(get_string2(1));
        ch=onek("QDIM?");
        switch(ch) {
        case '?':
            showconf();
            break;
        case 'Q':
            done=1;
            break;
        case 'M':
            nl();
            prt(2,"Conference number? ");
            input(s,2);
            i=atoi(s);
            if ((s[0]!=0) && (i>=0) && (i<num_conf))
                modify_conf(i);
            break;
        case 'I':
            if (num_conf<10) {
                nl();
                prt(2,"Insert before which conf? ");
                input(s,2);
                i=atoi(s);
                if ((s[0]!=0) && (i>=0) && (i<=num_conf))
                    insert_conf(i);
            }
            break;
        case 'D':
            nl();
            prt(2,"Delete which conf? ");
            input(s,2);
            i=atoi(s);
            if ((s[0]!=0) && (i>=0) && (i<num_conf)) {
                nl();
                sprintf(s1,"Delete %s? ",conf[i].name);
                prt(5,s1);
                if (yn())
                    delete_conf(i);
            }
            break;
        }
    } 
    while ((!done) && (!hangup));
    sprintf(s,"%sConf.DAT",syscfg.datadir);
    f=open(s,O_RDWR | O_BINARY | O_CREAT | O_TRUNC, S_IREAD | S_IWRITE);
    write(f,(void *)&conf[0], num_conf * sizeof(confrec));
    close(f);
}
