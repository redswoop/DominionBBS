#ifdef QWK
#include "vars.h"
#pragma hdrstop
#include "qwk.h"
#define WORKBUFSIZE       0x8000

#define hdr_private 1
#define hdr_netmail 2

char *getMessage(int msgNum,hdrinfo *hdr,long *len);

void cleanUpQWK(void)
{
    remove_from_temp("*.ndx",syscfg.tempdir,0);
    remove_from_temp("messages.dat",syscfg.tempdir,0);
    remove_from_temp("control.dat",syscfg.tempdir,0);
}

void putf(char *s,FILE *f)
{
    fprintf(f,"%s\n",s);
}

void createControl(void)
{
    FILE *f;
    char s[81];
    struct time t;
    struct date d;
    int i,numAreas=0;
    subboardrec tmpSub;

    sprintf(s,"%scontrol.dat",syscfg.tempdir);

    f=fopen(s,"wt");

    putf(syscfg.systemname,f);
    putf("Dominion Land",f);
    putf(syscfg.systemphone,f);
    putf(syscfg.sysopname,f);

    fprintf(f,"00000,DOMINION\n");

    getdate(&d);
    gettime(&t);
    fprintf(f,"%02d-%02d-%d %02d:%02d:%02d\n",d.da_mon,d.da_day,d.da_year,t.ti_hour,t.ti_min,t.ti_sec);
    putf(thisuser.realname,f);
    putf("",f);
    putf("0",f);
    putf("0",f);

    while(usub[numAreas].subnum!=-1&&i<MAX_SUBS)
        numAreas++;

    fprintf(f,"%d\n",numAreas-1);

    for(i=0;i<numAreas;i++) {
        GetLink(&subboards,usub[i].subnum,&tmpSub);
        fprintf(f,"%d\n",usub[i].subnum);
        fprintf(f,"%s\n",tmpSub.filename);
    }

    putf("HELLO",f);
    putf("NEWS",f);
    putf("GOODBYE",f);
    fclose(f);
}

void compressQWK(void)
{
    char s[81];

    nl();
    pl("Done Scanning, Now Compressing");

    ARC_NUMBER=0;
    sprintf(s,"%sdominon.qwk",syscfg.tempdir);
    add_arc(s,"*.ndx messages.dat control.dat newfiles.dat");

    if(outcom) {
        int i;
        char s1[81];

        i=open(s,O_BINARY|O_RDWR);
        npr("5Packet is %ld bytes.  Transfer? ",filelength(i));
        close(i);
        if(ny())
            send_file(s,&i,&i,s1);
    }
    else
        npr("\r\nPacket %s created\r\n",s);

    cleanUpQWK();
}

void writeQWKmsg (FILE *Messagef,FILE *idxf,char *hold,long len,hdrinfo *mhdr,int msgnum,int area)
{
    QWKHDR hdr;
    long pos,l1;
    char s[81];
    long bpos;
    QWKIDX i;
    float ff;

    pos = ftell(Messagef);
    strncpy(hdr.from,mhdr->who_from,25);
    strncpy(hdr.to,mhdr->who_to,25);
    strncpy(hdr.subj,mhdr->subject,25);
    hdr.subj[25] = hdr.to[25] = hdr.from[25] = 0;
    hdr.status = QWKPUBUNREAD;
    hdr.msgnum = msgnum;
    hdr.confnum = area+1;
    hdr.date = time(NULL);
    hdr.pword[0] = 0;
    hdr.repnum = 0;
    hdr.numchunks = (long)(len / QWKBLKSIZE) + ((len % QWKBLKSIZE) != 0);
    hdr.live = 1;

    if(!qwkwritehdr(Messagef,&hdr,0))
        return;

    qwkwriteblks(Messagef,&hold[0]);

    hdr.numchunks = (long)((len / 128) + ((len % 128) != 0));

    bpos = ftell(Messagef);
    fseek(Messagef,pos,SEEK_SET);
    qwkwritehdr(Messagef,&hdr,0);
    fseek(Messagef,bpos,SEEK_SET);

    ff = (float)((pos / 128.0));
    ff += 1.0;
    i.recnum=IEEEToMSBIN(ff);
    fwrite(&i,sizeof(QWKIDX),1,idxf);

}

void addMessageQWK(FILE *messageFile,FILE *idxFile,int num,int baseNum)
{
    hdrinfo hdr;
    char *text;
    long len;

    text=getMessage(num,&hdr,&len);

    npr("Writing message %d (%s) %ld bytes\r\n",num,hdr.subject,len);
    writeQWKmsg(messageFile,idxFile,
        text,len,&hdr,num,baseNum);
}

void processBase(subboardrec *tmpPwd,FILE *messageFile,int startNum,int baseNum)
{
    char s[81];
    FILE *idxFile;
    int i;

    npr("5Scanning 0%-40s 3(3%3d New3)\r\n",tmpPwd->name,(nummsgs-startNum));
    sprintf(s,"%s%03d.ndx",syscfg.tempdir,baseNum);
    idxFile=fopen(s,"wb");

    if(i<0)
        i=1;

    for(i=startNum;i<=nummsgs;i++)
        addMessageQWK(messageFile,idxFile,i,baseNum);

    fclose(idxFile);
    pausescr();
}

void makeqwk(int type)
{
    int i;
    int num;
    char s[81];
    FILE *messageFile;
    subboardrec tmpSub;


    dtitle("Creating QWK Packet");

    ARC_NUMBER=0;

    cleanUpQWK();

    sprintf(s,"%smessages.dat",syscfg.tempdir);
    messageFile=fopen(s,"wb");
    createControl();

    qwkwriteblk(messageFile,"Not produced by Qmail, no Copyright (c) 1987 and No Rights Reserved.");

    i=0;
    while(usub[i].subnum!=-1&&!hangup&&i<MAX_SUBS) {
        GetLink(&subboards,usub[i].subnum,&tmpSub);
        if(inscan(usub[i].subnum,&thisuser,0)&&!(tmpSub.attr & mattr_private)) {
            openMessageBase(&tmpSub);
            num=getLastReadMsg(&thisuser,usernum);

            if(num<nummsgs)
                processBase(&tmpSub,messageFile,num,usub[i].subnum);
        }
        i++;
    }

    fclose(messageFile);

    compressQWK();
}
#endif
