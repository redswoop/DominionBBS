#include "vars.h"
#pragma hdrstop

#include "link.h"
#include "stack.h"
#include "fileDir.h"

extern StackContainer dirStack;
extern List batchList;
extern PWDrec PWD;
extern char dirPath[81];


void Quicksort(int l,int r,List *list)
{
    register int i,j;
    fileRec a,a2,x;

    i=l; 
    j=r;
    GetLink(list,(l+r)/2,&x);
    do {
        GetLink(list,(i),&a);
        while (strcmp(a.fn,x.fn)<0) {
            GetLink(list,++i,&a);
        }
        GetLink(list,j,&a2);
        while (strcmp(a2.fn,x.fn)>0) {
            GetLink(list,--j,&a2);
        }
        if (i<=j) {
            if (i!=j) {
                PutLink(list,i,&a2);
                PutLink(list,j,&a);
            }
            i++;
            j--;
        }
    } 
    while (i<j);
    if (l<j)
        Quicksort(l,j,list);
    if (i<r)
        Quicksort(i,r,list);
}

void findDescription(char *fn,char *path,char *descript)
{
    FILE *f;
    char s[81];
    char *p;

    descript[0]=0;
    sprintf(s,"%s\\descript.ion",path);
    f=fopen(s,"rt");
    if(f==NULL)
        return;

    while(fgets(s,81,f)!=NULL) {
        if(stristr(s,fn)) {
            filter(s,'\n');
            p=strchr(s,32);
            strcpy(descript,p+1);
            fclose(f);
            return;
        }
    }

    fclose(f);
}

void registerDir(char *path)
{
    char s[MAXPATH];
    FILE *f;
    int i;
    fileRec inf;
    struct find_t t;
    PWDrec p;
    char *pp;
    PWDrec tmpPwd;
    char desc[81];
    char alias[81];

    if(so()) {
        inputdat("Name for new Directory",alias,14,1);
        inputdat("Description for new Directory",desc,50,1);
    } 
    else {
        strcpy(alias,"NewArea");
        strcpy(desc,"NewArea");
    }

    strcpy(tmpPwd.acs,"S30");
    sprintf(tmpPwd.alias,"%s",alias);
    sprintf(tmpPwd.desc,"%s",desc);


    sprintf(s,"%s\\dominion.dir",path);
    npr("Registering: %s\r\n",path);
    f=fopen(s,"wt");
    fprintf(f,"Dominion Directory\n");
    fprintf(f,"%s\n",tmpPwd.acs);
    fprintf(f,"%s\n",tmpPwd.alias);
    fprintf(f,"%s\n",tmpPwd.desc);

    sprintf(s,"%s\\*.*",path);

    i=_dos_findfirst(s,FA_ARCH|FA_HIDDEN|FA_SYSTEM|FA_RDONLY|FA_DIREC,&t);
    while(!i) {
        if(t.name[0]!='.') {
            if(t.attrib & FA_DIREC) {
                sprintf(s,"%s\\%s",path,t.name);
                fprintf(f,"Link %s %s\n",t.name,s);
            } 
            else {
                inf.attr=0;
                inf.size=(t.size+1023)/1024;
                inf.points=inf.size/10;
                inf.ulDate=time(NULL);
                strcpy(inf.fn,t.name);
                findDescription(inf.fn,path,inf.description);
                if(inf.description[0]==0)
                    strcpy(inf.description,"describe me!");
                fprintf(f,"%s %s\n",inf.fn,inf.description);
                fprintf(f,"   %ld P%d N%d O%d D%ld \n",inf.size,inf.points,inf.numDls,inf.owner,inf.ulDate);
            }
        }
        i=_dos_findnext(&t);
    }

    fclose(f);
}

void writeDirData(char *path,PWDrec *tmpPwd)
{
    char s[MAXPATH];
    FILE *f;
    int i;
    fileRec inf;
    linkRec l;

    sprintf(s,"%s\\dominion.dir",path);
    f=fopen(s,"wt");
    fprintf(f,"Dominion Directory\n");
    fprintf(f,"%s\n",tmpPwd->acs);
    fprintf(f,"%s\n",tmpPwd->alias);
    fprintf(f,"%s\n",tmpPwd->desc);

    for(i=0;i<numLinks(&tmpPwd->links);i++) {
        GetLink(&tmpPwd->links,i,&l);
        fprintf(f,"Link %s %s\n",l.fn,l.linkData);
    }
    for(i=0;i<numLinks(&tmpPwd->files);i++) {
        GetLink(&tmpPwd->files,i,&inf);
        fprintf(f,"%s %s\n",inf.fn,inf.description);
        fprintf(f,"   %ld P%d N%d O%d D%ld \n",inf.size,inf.points,inf.numDls,inf.owner,inf.ulDate);
    }

    fclose(f);
}

int readDirHeader(char *path,PWDrec *tmpPwd)
{
    FILE *f;
    char s[255];
    fileRec inf;
    linkRec l;
    char *p;
    pathStack si;

    sprintf(s,"%s\\dominion.dir",path);
    if(!exist(s)) {
        strcpy(tmpPwd->alias,"Newdir");
        strcpy(tmpPwd->desc,"Newdir");
        strcpy(tmpPwd->acs,"S255");
        strcpy(tmpPwd->path,path);
        return 1;
    }

    f=fopen(s,"rt");
    if(f==NULL) {
        npr("Bad path %s\r\n",path);
        return 1;
    }

    fgets(s,81,f);
    if(!strcmpi(s,"Dominion Directory\n")) {
        fgets(s,81,f); 
        filter(s,'\n');
        strcpy(tmpPwd->acs,s);
        fgets(s,81,f); 
        filter(s,'\n');
        strcpy(tmpPwd->alias,s);
        fgets(s,81,f); 
        filter(s,'\n');
        strcpy(tmpPwd->desc,s);
    }
    fclose(f);

    return 0;
}


int readDirData(char *path,PWDrec *tmpPwd)
{
    FILE *f;
    char s[255];
    fileRec inf;
    linkRec l;
    char *p;

    sprintf(s,"%s\\dominion.dir",path);
    if(!exist(s)) {
        npr("file %s not found, registering\r\n",s);
        registerDir(path);
    }

    f=fopen(s,"rt");
    if(f==NULL) {
        npr("Bad path %s\r\n",path);
        return 1;
    }

    fgets(s,81,f);
    if(!strcmpi(s,"Dominion Directory\n")) {

        destroyPath(tmpPwd);

        fgets(s,81,f); 
        filter(s,'\n');
        strcpy(tmpPwd->acs,s);
        fgets(s,81,f); 
        filter(s,'\n');
        strcpy(tmpPwd->alias,s);
        fgets(s,81,f); 
        filter(s,'\n');
        strcpy(tmpPwd->desc,s);

        strcpy(tmpPwd->path,path);

        while(fgets(s,255,f)!=NULL) {
            filter(s,'\n');

            p=strtok(s," ,");
            if(!stricmp(p,"link")) {
                p=strtok(NULL," ,");
                strcpy(l.fn,p);
                p=strtok(NULL,";");
                strcpy(l.linkData,p);
                InsertLink(&tmpPwd->links,numLinks(&tmpPwd->links),&l);
            } 
            else {
                inf.size=0;
                inf.points=0;
                inf.numDls=0;
                inf.owner=0;
                inf.ulDate=0;

                strcpy(inf.fn,p);
                p=strtok(NULL,";");
                strcpy(inf.description,p);

                fgets(s,255,f);

                p=strtok(s," ,");
                inf.size=atol(p);
                p=strtok(NULL," ,");

                while(p) {
                    switch(p[0]) {
                    case '$':
                    case 'P':
                        inf.points=atoi(p+1);
                        break;

                    case '#':
                    case 'N':
                        inf.numDls=atoi(p+1);
                        break;

                    case '@':
                    case 'O':
                        inf.owner=atoi(p+1);
                        break;

                    case 'D':
                        inf.ulDate=atoi(p+1);
                        break;
                    }
                    p=strtok(NULL," ,");
                }

                InsertLink(&tmpPwd->files,numLinks(&tmpPwd->files),&inf);
            }
        }
    } 
    else {
        fclose(f);
        return(1);
    }


    numf=numLinks(&tmpPwd->files)+numLinks(&tmpPwd->links);


    fclose(f);
    return(0);
}

void loadDir(char *path)
{
    pathStack si;
    linkRec l;
    fileRec inf;
    int i;

    if(!strcmp(path,"..")) {
        popStack(&dirStack);
        getStackTop(&dirStack,&si);
        readDirData(si.path,&PWD);
        createPathName();
        return;
    } 
    else
        if(!strcmp(path,"/")) {
        dirStack.list.num=0;
        readDirData(syscfg.dloadsdir,&PWD);
        strcpy(si.alias,PWD.alias);
        strcpy(si.path,syscfg.dloadsdir);
        pushStack(&dirStack,&si);
        createPathName();
        return;
    }

    for(i=0;i<numLinks(&PWD.links);i++) {
        GetLink(&PWD.links,i,&l);
        if(!stricmp(path,l.fn)) {
            readDirData(l.linkData,&PWD);
            strcpy(si.alias,PWD.alias);
            strcpy(si.path,l.linkData);
            pushStack(&dirStack,&si);
            createPathName();
            return;
        }
    }

    npr("Bad path: %s\r\n",path);
}


