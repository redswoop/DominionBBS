#include "vars.h"
#pragma hdrstop


#include "link.h"
#include "stack.h"
#include "fileDir.h"
#include "queue.h"

StackContainer dirStack;
List batchList;
PWDrec PWD;
char dirPath[81];

void findPath(char path[81],PWDrec *tmpPwd);
int listFiles(PWDrec *tmpPwd,int *which,int max,int *topFile,int *sPos,int *abort);
void listFilesNonStop(PWDrec *tmpPwd,int which,int max,int *abort);

void createPath(PWDrec *tmpPwd)
{
    createList(&tmpPwd->files,sizeof(fileRec));
    createList(&tmpPwd->links,sizeof(linkRec));
}

void destroyPath(PWDrec *tmpPwd)
{
    while(numLinks(&tmpPwd->files))
        DeleteLink(&tmpPwd->files,0);
    while(numLinks(&tmpPwd->links))
        DeleteLink(&tmpPwd->links,0);
}

int comparefn(char fn1[13],char fn2[13])
{
    int ok,i;

    align(fn1);
    align(fn2);

    ok=1;
    for (i=0; i<12; i++)
        if ((fn1[i]!=fn2[i]) && (fn1[i]!='?') && (fn2[i]!='?'))
            ok=0;
    return(ok);
}

void getExtension(char *fn,char *ext)
{
    int i,i1;
    char *p;

    ext[0]=0;

    if(fn[0]=='.')
        return;

    p=strchr(fn,'.');
    if(p!=NULL)
        strcpy(ext,p+1);
    else
        ext[0]=0;

    p[0]=0;
}

void createPathName(void)
{
    int i;
    pathStack si;

    dirPath[0]=0;

    for(i=dirStack.list.num-1;i>0;--i) {
        getStackItem(&dirStack,&si,i);
        sprintf(&dirPath[strlen(dirPath)],"%s/",si.alias);
    }

    strcat(dirPath,PWD.alias);
}

void printInfo(PWDrec *tmpPwd,fileRec *f, int *abort,int number)
{
    char s[161],ss[39],s1[10],s2[5],s3[5],s4[5],fn[MAXPATH];
    int i,i1,i2;
    double t;
    pathStack si;
    char fileName[14];

    sprintf(fn,"%s\\%s",tmpPwd->path,f->fn);

    if(modem_speed)
        t=((double) (((f->size*1024)+127)/128)) * (1620.0)/((double) (modem_speed));

    sprintf(s1,"%4d",f->size);

    sprintf(s2,"%4d",f->points);
    sprintf(s3,"%3d",number);
    sprintf(ss,"%-39.39s",f->description);
    sprintf(s4,"%3d",f->numDls);
    sprintf(fileName,"%12s",f->fn);

    if(exist(fn))
        stuff_in1(s,filelistformat,fileName,ss,s1,s2,s3,"","",s4,ctim(t));
    else
        stuff_in1(s,filelistformat2,fileName,ss,s1,s2,s3,"","",s4,ctim(t));

    pla(s,abort);
}

void pauseLine(PWDrec *tmpPwd,int *which,int *topFile,int max,int *abort)
{
    int done=0,i;
    char c;
    char s[40];

    if(*abort)
        return;

    pl(getfhead(1));

    while(!done&&!hangup) {
        outstr(get_string(39));
        strcpy(s,"I?VWMDSNBRZ\r");
        if(cs())
            strcat(s,"!@#$");
        c=onek(s);
        if(okansi())
            outstr("[A[K");
        checkhangup();
        switch(c) {
        case '\r': 
            done=1;
            break;
        case 'R':
            *which= (*topFile);
            return;
        case 'N':
            listFilesNonStop(tmpPwd,*which+1,max,abort);
            (*abort)=1;
            return;
        case '?': 
            printmenu(22); 
            if(cs())
                printmenu(17);
            break;
        case 'S':
            *abort=1;
            break;
        }
    }

}

void listFilesNonStop(PWDrec *tmpPwd,int which,int max,int *abort)
{
    fileRec f;

    outchr(12);
    printtitle();

    while(which<max) {
        GetLink(&tmpPwd->files,which,&f);
        printInfo(tmpPwd,&f,abort,which);
        which++;
    }

}

int listFiles(PWDrec *tmpPwd,int *which,int max,int *topFile,int *sPos,int *abort)
{
    int drawSize;
    fileRec f;

    if(*which==max||(*abort))
        return 0;

    if(*sPos==0) {
        outchr(12);
        printtitle();
        *topFile= (*which);
    }

    drawSize=1;
    if(drawSize+(*sPos)>(thisuser.screenlines-5)) {
        *sPos=0;
        return 1;
    } else {
        GetLink(&tmpPwd->files,*which,&f);
        printInfo(tmpPwd,&f,abort,*which);
        *sPos+=drawSize;
        *which+=1;
        return listFiles(tmpPwd,which,max,topFile,sPos,abort);
    }
}


void listDir(char *path)
{
    int abort=0;
    int sPos=0;
    int topFile=0;
    int which=0;
    PWDrec tmpPwd;

    setformat();

    if(!path[0])
        strcpy(path,"*.*");

    findPath(path,&tmpPwd);

    while((!abort)&&listFiles(&tmpPwd,&which,numLinks(&tmpPwd.files),&topFile,&sPos,&abort))
        pauseLine(&tmpPwd,&which,&topFile,numLinks(&tmpPwd.files),&abort);
    npr("%d files\r\n",numLinks(&tmpPwd.files));

    destroyPath(&tmpPwd);
}

int isNumeric(char *s)
{
    int i;
    int len;

    len=strlen(s);

    if(len==0)
        return 0;

    for(i=0;i<len;i++) {
        switch(s[i]) {
        case '0':
        case '1':
        case '2':
        case '3':
        case '4':
        case '5':
        case '6':
        case '7':
        case '8':
        case '9':  
            break;
        default: 
            return 0;
        }
    }

    return 1;
}

void executeNumberic(char *s)
{
    int i;
    fileRec inf;
    linkRec l;
    pathStack si;

    i=atoi(s);
    if(i<numLinks(&PWD.links)) {
        GetLink(&PWD.links,i,&l);
        readDirData(l.linkData,&PWD);
        strcpy(si.alias,PWD.alias);
        strcpy(si.path,l.linkData);
        pushStack(&dirStack,&si);
        createPathName();
    } 
    else if(i<=numLinks(&PWD.files)) {
        i-=numLinks(&PWD.links);
        GetLink(&PWD.files,i,&inf);
        npr("Executing %s\r\n",inf.fn);
    }
}

void recurseDir(int *abort,int actOnFiles,int actOnLinks,void (*func)(int *,char *,fileRec *),char *parameter)
{
    int i;
    char s[81];
    fileRec inf;
    linkRec l;

    if(actOnFiles) {
        for(i=0;i<numLinks(&PWD.files)&&!hangup&&!*abort;i++) {
            GetLink(&PWD.files,i,&inf);
            func(abort,parameter,&inf);
        }
    } else
        func(abort,parameter,NULL);

    if(actOnLinks) {
        for(i=0;i<numLinks(&PWD.links)&&!hangup&&!*abort;i++) {
            GetLink(&PWD.links,i,&l);
            loadDir(l.fn);
            recurseDir(abort,actOnFiles,actOnLinks,func,parameter);
            loadDir("..");
        }
    }
}

void searchDir(int *abort,char *spec,fileRec *inf)
{
    int printData=0;
    char s[81],s1[81];

    strcpy(s,inf->fn);
    strupr(s);
    strcpy(s1,spec);
    if(comparefn(s1,s))
        printData=1;
    else {
        strcpy(s,inf->description);
        strupr(s);
        if(strstr(s,spec))
            printData=1;
    }
    if(printData)
        printInfo(&PWD,inf,abort,0);
}

void syncDir(int *abort,char *parameter,fileRec *inf)
{
    int i;
    linkRec l;
    PWDrec linkHeader;
    pathStack si;

    for(i=0;i<numLinks(&PWD.links)&&!hangup;i++) {
        GetLink(&PWD.links,i,&l);
        readDirHeader(l.linkData,&linkHeader);
        strcpy(l.fn,linkHeader.alias);
        PutLink(&PWD.links,i,&l);
    }

    writeDirData(PWD.path,&PWD);
}


void travel(PWDrec *tmpPwd,QueueContainer *pQueue)
{
    char s[21];
    int i;
    fileRec f;
    linkRec l;
    int n;

    getQueueTop(pQueue,&s);

    for(i=0;i<numLinks(&tmpPwd->links);i++) {
        GetLink(&tmpPwd->links,i,&l);
        if(!strcmpi(s,l.fn)) {
            removeQueue(pQueue);
            readDirData(l.linkData,tmpPwd);
            travel(tmpPwd,pQueue);
            return;
        }
    }

    if(emptyQueue(pQueue))
        return;

    for(i=0;i<numLinks(&tmpPwd->files)&&numLinks(&tmpPwd->files);) {
        GetLink(&tmpPwd->files,i,&f);
        if(comparefn(s,f.fn))
            i++;
        else
            DeleteLink(&tmpPwd->files,i);
    }
}

void findPath(char path[81],PWDrec *tmpPwd)
{
    char *p;
    int i;
    QueueContainer pQueue;
    char s[21];

    createPath(tmpPwd);

    if(path[0]=='/') {
        readDirData(syscfg.dloadsdir,tmpPwd);
        strcpy(path,path+1);
    } else if(path[0]=='.'&&path[1]=='.') {
        pathStack si;

        getStackItem(&dirStack,&si,1);
        pl(si.path);
        readDirData(si.path,tmpPwd);
    } else {
        readDirData(PWD.path,tmpPwd);
    }

    createQueue(&pQueue,sizeof(s));
    p=strtok(path,"/");
    while(p) {
        addQueue(&pQueue,p);
        p=strtok(NULL,"/");
    }

    travel(tmpPwd,&pQueue);
}

void initFileSystem(void)
{
    pathStack si;

    destroyPath(&PWD);
    createPath(&PWD);

    deleteList(&batchList);
    createList(&batchList,sizeof(PWDrec));

    deleteStack(&dirStack);
    createStack(&dirStack,sizeof(pathStack));

    strcpy(si.alias,"Root");
    strcpy(si.path,syscfg.dloadsdir);
    pushStack(&dirStack,&si);
    readDirData(syscfg.dloadsdir,&PWD);
    createPathName();
}

void filearea(void)
{
    int done=0;
    char s[81],*p;
    char cmd[21],args[81];
    int i;
    pathStack si;

    initFileSystem();
    pl("Type help for help!");

    while(!done&&!hangup) {
        npr("%s>",dirPath);
        inputl(s,80);
        p=strchr(s,32);
        if(p==NULL)
            args[0]=0;
        else
            strcpy(args,p+1);
        p[0]=0;
        strcpy(cmd,s);
        if(!stricmp(cmd,"dir"))
            listDir(args);
        else if(!stricmp(cmd,"cd"))
            loadDir(args);
        else if(!stricmp(cmd,"sort")) {
            Quicksort(0,numLinks(&PWD.files),&PWD.files);
            Quicksort(0,numLinks(&PWD.links),&PWD.links);
            writeDirData(PWD.path,&PWD);
        }
        else if(!stricmp(cmd,"find")) {
            int abort=0;
            strupr(args);
            recurseDir(&abort,1,1,&searchDir,args);
        }
        else if(!stricmp(cmd,"sync")) {
            int abort=0;
            recurseDir(&abort,0,1,&syncDir,NULL);
        }
        else if(!stricmp(cmd,"exit"))
            done=1;
        else if(!stricmp(cmd,"tag"))
            tagFiles(args);
        else if(!stricmp(cmd,"blist"))
            listBatch();
        else if(isNumeric(cmd))
            executeNumberic(cmd);
        else if(!stricmp(cmd,"help")) {
            pl("find <spec>  - searchs for file spec, recusively");
            pl("tag <spec>   - tags all files matching spec");
            pl("dir <spec>   - displays files matching spec");
            pl("sort         - sorts current area");
            pl("cd <link>    - change dir");
            pl("<filenumber> - executes a file");
            nl();
        }
    }
}
