#include "vars.h"
#pragma hdrstop

List Quote;

char *ini(char name[161])
{
    static char o[81];
    int i=0,p=0;
    userrec u;

    strcpy(u.name,strupr(name));
    strcpy(name,pnam(&u));

    memset(o,0,81);

    for(i=0;name[i];i++) {
        if ((name[i]>='A') && (name[i]<='Z'))
            o[p++]=name[i];
    }

    return(o);
}

void DisplayQuote(void)
{
    int i;
    char s[161];


    nl();
    for(i=0;i<numLinks(&Quote);i++) {
        GetLink(&Quote,i,&s);
        npr("%d: %s",i+1,s);
        nl();
    }
}

void get_quote()
{
    char s[141];
    int maxLine;
    int Start,Stop;
    int done=0;

    maxLine=numLinks(&Quote);

    while (!done&&!hangup) {
        DisplayQuote();
        Start=Stop=0;
        npr("5Quote from line 1-%d? (A=All,?=relist,Q=quit) ",maxLine);
        input(s,3);
        if(atoi(s)) {
            Start=atoi(s);
            npr("5End on what line %d-%d? (Q=quit) ",Start,maxLine);
            input(s,3);
            if(atoi(s))
                Stop=atoi(s);
        }
        else if (s[0]=='A') {
            Start=1;
            Stop=maxLine;
        }
        else if (s[0]=='Q')
            done=1;

        if (Stop) {
            npr("5Quote line(s) %d-%d? ",Start,Stop);
            if (ny())
                done=1;
        }
    } 

    charbufferpointer=0;
    if (Start && Stop) {
        bquote=Start;
        equote=Stop;
    }
}

void addline(char *b, char *s, long *ll)
{
    strcpy(&(b[*ll]),s);
    (*ll)+=strlen(s);
    b[(*ll)++]='\r';
}

void quoteMessage(char *buf,char *initials)
{
    char storedWord[81];
    char line[161],line2[161];
    char *p;
    int i;
    int numLines=0;

    storedWord[0]=0;

    p=strtok(buf,"\r");
    while(p) {

        strcpy(line,p);
        if(strchr(line,'>')==NULL)
            strcpy(line2,initials);
        else
            strcpy(line2,"");

        if(storedWord[0]) {
            strcat(line2,storedWord);
            strcat(line2," ");
            storedWord[0]=0;
        }

        strcat(line2,line);

        if(strlen(line2)>80) {
            for(i=strlen(line2);i>0&&(line2[i]!=32||i>79);i--);
            strcpy(storedWord,&line2[i+1]);
            line2[i]=0;
        }

        InsertLink(&Quote,numLines,&line2);
        numLines++;

        p=strtok(NULL,"\r");
    }

}

void quoteJam(char *text,long len,hdrinfo *hdr)
{
    char initials[41];
    char s[161];
    int i;

    deleteList(&Quote);

    strcpy(initials,ini(hdr->who_from));
    strcat(initials,"> ");

    text[len]=0;
    quoteMessage(text,initials);
}
