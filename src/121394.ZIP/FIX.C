#include <fcntl.h>
#include <sys/stat.h>
#include "link.h"
#include "vardec.h"

void main(void)
{
    userrec u;
    int f;
    int o;
    int i;

    f=open("user.lst",O_RDWR|O_BINARY);
    o=open("out.lst",O_RDWR|O_BINARY|O_CREAT,S_IREAD|S_IWRITE);
    for(i=0;i<40;i++) {
        read(f,&u,sizeof(u));
        write(o,&u,sizeof(u));
    }

    close(f);
    close(o);
}
