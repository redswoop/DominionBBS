#include "vars.h"
#pragma hdrstop

#include "link.h"
#include "stack.h"
#include "fileDir.h"

extern StackContainer dirStack;
extern List batchList;
extern PWDrec PWD;
extern char dirPath[81];

void printInfo(fileRec *f, int *abort,int number)
{
    char s[161],ss[39],s1[10],s2[5],s3[5],s4[5],fn[MAXPATH];
    int i,i1,i2;
    double t;
    pathStack si;
    char fileName[14];

    sprintf(fn,"%s\\%s",PWD.path,f->fn);

    if(modem_speed)
        t=((double) (((f->size*1024)+127)/128)) * (1620.0)/((double) (modem_speed));

    sprintf(s1,"%4d",f->size);

    sprintf(s2,"%4d",f->points);
    sprintf(s3,"%3d",number);
    sprintf(ss,"%-39.39s",f->description);
    sprintf(s4,"%3d",f->numDls);
    sprintf(fileName,"%12s",f->fn);

    if(exist(fn))
        stuff_in1(s,filelistformat,fileName,ss,s1,s2,s3,"","",s4,ctim(t));
    else
        stuff_in1(s,filelistformat2,fileName,ss,s1,s2,s3,"","",s4,ctim(t));

    pla(s,abort);

}

int listFiles(PWDrec *tmpPwd,int *which,int max,int *topFile,int *sPos,int *abort);
void listFilesNonStop(PWDrec *tmpPwd,int which,int max,int *abort);

void pauseLine(PWDrec *tmpPwd,int *which,int *topFile,int max,int *abort)
{
    int done=0,i;
    char c;
    char s[40];

    if(*abort)
        return;

    pl(getfhead(1));

    while(!done&&!hangup) {
        outstr(get_string(39));
        strcpy(s,"I?VWMDSNBRZ\r");
        if(cs())
            strcat(s,"!@#$");
        c=onek(s);
        if(okansi())
            outstr("[A[K");
        checkhangup();
        switch(c) {
        case '\r': 
            done=1;
            break;
        case 'R':
            *which= (*topFile);
            return;
        case 'N':
            listFilesNonStop(tmpPwd,*which+1,max,abort);
            (*abort)=1;
            return;
        case '?': 
            printmenu(22); 
            if(cs())
                printmenu(17);
            break;
        case 'S':
            *abort=1;
            break;
        }
    }

}

void listFilesNonStop(PWDrec *tmpPwd,int which,int max,int *abort)
{
    fileRec f;

    outchr(12);
    printtitle();

    while(which<max) {
        GetLink(&tmpPwd->files,which,&f);
        printInfo(&f,abort,which);
        which++;
    }

}

int listFiles(PWDrec *tmpPwd,int *which,int max,int *topFile,int *sPos,int *abort)
{
    int drawSize;
    fileRec f;

    if(*which==max||(*abort))
        return 0;

    if(*sPos==0) {
        outchr(12);
        printtitle();
        *topFile= (*which);
    }

    drawSize=1;
    if(drawSize+(*sPos)>(thisuser.screenlines-5)) {
        *sPos=0;
        return 1;
    } else {
        GetLink(&tmpPwd->files,*which,&f);
        printInfo(&f,abort,*which);
        *sPos+=drawSize;
        *which+=1;
        return listFiles(tmpPwd,which,max,topFile,sPos,abort);
    }
}


void listDir(char *path)
{
    int abort=0;
    int sPos=0;
    int topFile=0;
    int which=0;
    PWDrec tmpPwd;

    setformat();

    if(!path[0])
        strcpy(path,"*.*");

    findPath(path,&tmpPwd);

    while((!abort)&&listFiles(&tmpPwd,&which,numLinks(&tmpPwd.files),&topFile,&sPos,&abort))
        pauseLine(&tmpPwd,&which,&topFile,numLinks(&tmpPwd.files),&abort);
    npr("%d files\r\n",numLinks(&tmpPwd.files));

    destroyPath(&tmpPwd);
}


