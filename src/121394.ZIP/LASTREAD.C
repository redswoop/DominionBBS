#include "vars.h"
#pragma hdrstop

extern List Quote;

#define WORKBUFSIZE       0x8000

#define hdr_private 0x001
#define hdr_netmail 0x002
#define hdr_Imail   0x004



void addLastRead(userrec *u,int userNum)
{
    int i;

    JAMmbLockMsgBase(&JamRec, 1 );
    lseek(JamRec.LrdHandle,0L,SEEK_END);
    JamRec.LastRead.HighReadMsg=0;
    JamRec.LastRead.LastReadMsg=0;
    JamRec.LastRead.UserID=userNum;
    write(JamRec.LrdHandle,&JamRec.LastRead,sizeof(JAMLREAD));
    JAMmbUnLockMsgBase(&JamRec, 1 );
    JamRec.LastLRDnum=filelength(JamRec.LrdHandle)/sizeof(JAMLREAD);
    saveLastRead();
}

void saveLastRead(void)
{
    JAMmbLockMsgBase(&JamRec, 1 );
    JAMmbStoreLastRead(&JamRec,1);
    JAMmbUnLockMsgBase(&JamRec, 1 );
}

void updateLastRead(userrec *u,int userNum,int msgNum)
{
    JamRec.LastRead.UserID=userNum;
    JamRec.LastRead.LastReadMsg=msgNum;
    if(JamRec.LastRead.LastReadMsg>JamRec.LastRead.HighReadMsg)
        JamRec.LastRead.HighReadMsg=msgNum;

    saveLastRead();
}

int getLastReadMsg(userrec *u,int userNum)
{

    if(!JAMmbFetchLastRead(&JamRec,userNum)) {
        if(JamRec.APImsg==JAMAPIMSG_CANTFINDUSER) {
            addLastRead(u,userNum);
            if(!JAMmbFetchLastRead(&JamRec,userNum)) {
                errorjam();
                return 1;
            }
        }
        return 1;
    } else
        return JamRec.LastRead.HighReadMsg;
}
