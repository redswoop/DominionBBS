#include "vars.h"
#pragma hdrstop
#include <stdarg.h>

#ifdef PD

char menutitles[4][20],ml[4][20];
int curitem=0,curtitle=0,numtitles=0,numitems[4],usepldns=0;

void popup(char *fn);
int usepop;
#endif

void getcmdtype(void)
{
    menurec mm;

    nl();
    inputdat("Type",mm.type,2,0);
    nl();
    inputdat("Parameters",mm.ms,40,1);
    executeCommand(&mm,"");
}

void logtypes(char type,char *fmt, ...)
{
    va_list ap;
    char s[512],s1[81];

    va_start(ap, fmt);
    vsprintf(s, fmt, ap);
    va_end(ap);

    switch(type) {
    case 0: 
        strcpy(s1,"7�7>"); 
        break;
    case 1: 
        strcpy(s1,"5�5�"); 
        break;
    case 2: 
        strcpy(s1,"1�1>"); 
        break;
    case 3: 
        strcpy(s1,"2�2�"); 
        break;
    case 4: 
        strcpy(s1,"3�3>"); 
        break;
    case 5: 
        strcpy(s1,"9#9#9#"); 
        break;
    }

    strcat(s1,"0 ");
    strcat(s1,s);
    if(type==5) sl1(0,s1);
    else
        sysoplog(s1);
}



void badcommand(menurec *m,char *args)
{
    char s[81];

    nl();
    sprintf(s,"2�2� 0Invalid Command Type %s",m->type);
    sysoplog(s);
    pl(s);
    nl();
}


void matrixcmd(menurec *m,char *args)
{
    switch(m->type[1]) {
    case 'C': 
        checkmatrixpw(); 
        break;
    case 'L': 
        getmatrixpw(); 
        break;
    case 'N': 
        nl();
        npr("5Logon as New? ");
        if(yn())
            newuser();
        break;
    default: 
        badcommand(m,args);
    }
}

void bbsListCommands(menurec *m,char *args)
{
        switch(m->type[1])
        {
        case 'A': 
            addbbs(m->ms[0]?m->ms:"bbslist.msg");
            break;
        case 'R': 
            printfile(m->ms[0]?m->ms:"bbslist.msg");
            pausescr();
            break;
        case 'S': 
            searchbbs(m->ms[0]?m->ms:"bbslist.msg");
            break;
        default: 
            badcommand(m,args);
            break;
    }
}

void amsgcommand(menurec *m,char *args)
{
    switch(m->type[1]) {
    case 'W': 
        write_automessage(); 
        break;
    case 'R': 
        read_automessage();
#ifdef PD
        if(usepldns) pausescr();
#endif
        break;
    case 'A':
        if(status.amsguser)
            email(status.amsguser,"Reply to AutoMessage",1);
        break;
    default: 
        badcommand(m,args);
    }
}



void hangupcmd(menurec *m,char *args)
{
    if(numbatchdl) {
        outstr(get_string(78));
        if(!yn()) return;
    }
    switch(m->type[1]) {
    case 'H': 
        hangup=1; 
        break;
    case 'A':
    case 'L':
    case 'C': 
        nl();
        outstr(m->ms);
        if(yn()) {
            if(m->type[1]=='C'||m->type[1]=='L') {
                outstr("5Leave Feedback to SysOp? ");
                if(yn()) {
                    //                    strcpy(irt,"LogOff Feedback.");
                }
                nl();
                if(m->type[1]=='L') {
                    outstr("5Leave Message to Next User? ");
                    if(yn()) {
                        ex("JW","");
                    }
                }
            }
            printfile("logoff");
            hangup=1;
        }
        break;
    default: 
        badcommand(m,args);
    }
}


void sysopcmd(menurec *m,char *args)
{
    switch(m->type[1])
    {
    case 'B': 
        logtypes(3,"Edited Message Areas");
        boardedit(); 
        break;
    case '-': 
        glocolor(); 
        break;
    case 'P': 
        logtypes(3,"Edited Configuration");
        config(); 
        break;
    case 'F': 
        logtypes(3,"Edited Directories");
        diredit(); 
        break;
    case 'M': 
        logtypes(3,"Read All Mail");
        break;
    case 'H': 
        logtypes(3,"Changed Users");
        chuser(); 
        break;
    case 'C': 
        pl(((*(char far *)0x00000417L ^= 0x10) & 0x10) ?
        "Sysop now unavailable" : "Sysop now available");
        logtypes(3,"Changed Chat Availability");
        topscreen();
        break;
    case 'U': 
        logtypes(3,"Edited Users");
        uedit(usernum); 
        break;
    case 'Z': 
        zlog(); 
        break;
    case 'E': 
        logtypes(3,"Edited Strings");
        if(m->ms[0]) edstring(atoi(m->ms));
        else edstring(0); 
        break;
    case 'R': 
        reset_files(1); 
        break;
    case 'X': 
        logtypes(3,"Edited Protocols");
        protedit(); 
        break;
    case 'L': 
        logtypes(3,"Edited Conferences");
        confedit(); 
        break;
    case 'O': 
        viewlog(); 
        break;
    case '#': 
        logtypes(3,"Edited Menus");
        menu("");
        break;
    default: 
        badcommand(m,args);
    }
}


#ifdef PD

char *retfrompldn;

void readmenup()
{
    int i,i1;
    int comn=0,done;
    menurec tg;


    numtitles=0;
    for(i=0;i<5;i++)
        numitems[i]=0;
    curitem=0;
    curtitle=0;
    memset(&ml[0][0],0,80);

    i=0;
    GetLink(&menuC.menuCmd,0,&tg);
    strcpy(menutitles[i++],tg.desc);

    do {
        GetLink(&menuC.menuCmd,i,&tg);
        if(!(tg.attr & command_pulldown)&&!(tg.attr & command_title)&&!(tg.attr & command_hidden)&&comn<20) {
            ml[numtitles][comn++]=i;
        } 
        else if(!(tg.attr & command_hidden)&&numtitles<4) {
            numitems[numtitles]=comn;
            comn=0;
            numtitles++;
            strcpy(menutitles[numtitles],tg.desc);
        }
    } 
    while(i++<numLinks(&menuC.menuCmd));

    numitems[numtitles]=comn-1;
    numtitles++;
}


void bar(int where)
{
    int i;

    go(where,1);
    outstr("[K�[79C�");
}

void drawheader(void)
{
    int i;

    bar(1);
    go(1,2);
    for(i=0;i<numtitles;i++) {
        if(i==curtitle) npr(""); 
        else npr("");
        npr("%-19.19s�",menutitles[i]);
    }
    ansic(0);
}


void pldn(void)
{
    int done=0,draw=4,lastnum=0;
    int i,ch,x,y,r,slen,tlen,numOk;
    char s[212],fmt[81],fmto[81],s1[212],desc[81],key[20];
    FILE *f;
    menurec tg;
    char availKeys[81];

    sprintf(s,"%s%s.fmt",syscfg.menudir,"pulldown");
    f=fopen(s,"rt");

    fgets(s,211,f);
    fgets(s,211,f);
    fgets(fmt,211,f);
    filter(fmt,'\n');
    fgets(fmto,211,f);
    filter(fmto,'\n');
    fgets(s,211,f);
    slen=atoi(s);
    fclose(f);


    do {
        if(draw==1||draw==4) {
            if(draw==4)
                outchr(12);
            drawheader();
            go(2,1);
            if(draw!=4)
                for(i=0;i<lastnum+2;i++)
                    pl("[K");
            x=20*curtitle;
            if(curtitle==3) x--;
            y=3;
            makerembox(x,y-1,y+numitems[curtitle]-1,"pulldown");
            for(i=0;i<numitems[curtitle];i++) {
                go(y+i,x);
                if(i==curitem)
                    strcpy(s1,fmt);
                else
                    strcpy(s1,fmto);

                GetLink(&menuC.menuCmd,ml[curtitle][i],&tg);
                aligncmd1(tg.desc,key,desc);
                tlen=slen;
                if(strlen(key)>1)
                    tlen-=(strlen(key)-1);
                stuff_in(s,s1,key,makelen(desc,tlen),tg.desc,"","");
                npr(s);
            }

            if(draw==4) {
                bar(22);
                go(21,0);
                ansic(0);
                outstr(menuC.pp.prompt2);
                draw=0;
            }
        }
        if(draw==2||draw==3) {
            if(draw==2)
                i=-1;
            else
                i=1;

            GetLink(&menuC.menuCmd,ml[curtitle][curitem+i],&tg);
            aligncmd1(tg.desc,key,desc);
            tlen=slen;
            if(strlen(key)>1)
                tlen-=(strlen(key)-1);

            go(curitem+y+i,x);
            GetLink(&menuC.menuCmd,ml[curtitle][curitem+i],&tg);
            stuff_in(s,fmto,key,makelen(desc,tlen),tg.desc,"","");
            npr(s);

            go(curitem+y,x);
            GetLink(&menuC.menuCmd,ml[curtitle][curitem],&tg);
            aligncmd1(tg.desc,key,desc);
            tlen=slen;
            if(strlen(key)>1)
                tlen-=(strlen(key)-1);

            stuff_in(s,fmt,key,makelen(desc,tlen),tg.desc,"","");
            npr(s);
        }
        r=1;
        strcpy(availKeys,menuAvailKeys(&i,&numOk));
        retfrompldn=smkey(availKeys,numOk,i,1,0,&r);
        if(r) {
            switch(r) {
            case -2: 
                if(curitem<numitems[curtitle]-1) {
                    curitem++;
                    draw=2;
                }
                break;
            case -1: 
                if(curitem>0) {
                    curitem--;
                    draw=3;
                }
                break;
            case -4: 
                if(curtitle>0) {
                    lastnum=numitems[curtitle];
                    curtitle--;
                    curitem=0;
                    draw=1;
                }
                break;
            case -3: 
                if(curtitle<numtitles-1) {
                    lastnum=numitems[curtitle];
                    curtitle++;
                    curitem=0;
                    draw=1;
                }
                break;
            case 1:
                npr("[24;1H");
                nl();
                GetLink(&menuC.menuCmd,ml[curtitle][curitem],&tg);
                strcpy(retfrompldn,tg.key);
                ansic(0);
                return;
            }
        } 
        else {
            if(retfrompldn[0]=='~') {
                usepldns=0;
                strcpy(retfrompldn,"");
                done=1;
            } 
            else {
                npr("[24;1H");
                nl();
                ansic(0);
                return;
            }
        }
    } 
    while(!done&&!hangup);
    ansic(0);
    return;
}


#endif

void configpldn(int config)
{
#ifdef PD
    if(config==1) {
        nl();
        npr("5Do you want Pulldowns automatically when you logon? ");
        if(yn())
            thisuser.sysstatus |= sysstatus_clr_scrn;
        else
            thisuser.sysstatus ^= sysstatus_clr_scrn;
        return;
    }

    if(config==2||config==3) {
        if(thisuser.sysstatus & sysstatus_clr_scrn) {
            if(!incom) {
                topdata=0;
                topscreen();
            }
            usepldns=1;
            return;
        }
        if(config==3) return;
    }

    if(okansi()) {
        printfile("PullDown");
        nl();
        outstr(get_string(31));
        usepldns=yn();
    }
#endif
}


#ifdef PD

void makerembox(int x,int y,int ylen,char *fn)
{
    int i,xx,yy,old;
    unsigned char s[212];
    FILE *f;

    sprintf(s,"%s%s.fmt",syscfg.menudir,fn);
    f=fopen(s,"rt");


    fgets(s,211,f);
    filter(s,'\n');
    npr("[%d;%dH%s",y,x,s);

    fgets(s,211,f);
    filter(s,'\n');
    npr("[%d;%dH%s",y+ylen-1,x,s);


    fclose(f);
}


void aligncmd1(char in[81],char *cmd,char *desc)
{
    int r=1,w=0,init=0;
    char s1[81],s2[12],s3[50],s[81];

    strcpy(s1,noc2(in));
    init=s1[0];
    while(s1[r]!=bo(init)&&r<strlen(s1))
        s2[w++]=s1[r++];
    s2[w]=0;
    r++;
    strcpy(s3,s1+r);

    strcpy(cmd,s2);
    strcpy(desc,s3);
}

char *makelen(char *in ,int len)
{
    int r;
    static char out[161];

    r=ccount(in);

    memset(out,32,70);
    out[len]=0;
    strcpy(out,in);
    out[strlen(out)]=32;
    out[len+r]=0;

    return out;
}

void popup(char *fn)
{
    int done=0,draw=4;
    int i,ch,x,y,r,slen,em;
    char s[81],fmt[200],fmto[200],s1[81],s2[81],desc[81],key[20];
    FILE *f;
    menurec tg;
    char availKeys[81];

    x=50;
    y=24-numitems[0];

    makerembox(x,y-1,(24-y)+2,fn);

    sprintf(s,"%s%s.fmt",syscfg.menudir,fn);
    f=fopen(s,"rt");


    fgets(s,211,f);
    fgets(s,211,f);
    fgets(fmt,211,f);
    filter(fmt,'\n');
    fgets(fmto,211,f);
    filter(fmto,'\n');
    fgets(s,211,f);
    slen=atoi(s);
    fclose(f);

    curtitle=0;
    curitem=0;

    go(y,x);

    for(i=0;i<numitems[curtitle];i++) {
        go(y+i,x);
        if(i==curitem)
            strcpy(s1,fmt);
        else
            strcpy(s1,fmto);

        GetLink(&menuC.menuCmd,ml[curtitle][curitem+i],&tg);
        aligncmd1(tg.desc,key,desc);
        stuff_in(s,s1,key,makelen(desc,slen),tg.desc,"","");
        npr(s);
    }

    do {
        if(draw==2||draw==3) {
            if(draw==2)
                i=-1;
            else
                i=1;

            go(curitem+y+i,x);
            GetLink(&menuC.menuCmd,ml[curtitle][curitem+i],&tg);
            aligncmd1(tg.desc,key,desc);
            stuff_in(s,fmto,key,desc,tg.desc,"","");
            npr(s);

            go(curitem+y,x);
            GetLink(&menuC.menuCmd,ml[curtitle][curitem],&tg);
            aligncmd1(tg.desc,key,desc);
            stuff_in(s,fmt,key,desc,tg.desc,"","");
            npr(s);
        }

        r=1;
        strcpy(availKeys,menuAvailKeys(&i,&i));
        retfrompldn=smkey(availKeys,0,1,1,0,&r);
        if(r) {
            switch(r) {
            case 1:
                GetLink(&menuC.menuCmd,ml[curtitle][curitem],&tg);
                strcpy(retfrompldn,tg.key);
                ansic(0);
                return;
            case -2:
                if(curitem<numitems[curtitle]-1) {
                    curitem++;
                    draw=2;
                }
                break;
            case -1: 
                if(curitem>0) {
                    curitem--;
                    draw=3;
                }
                break;
            }
        } 
        else {
            if(retfrompldn[0]=='~') {
                usepldns=0;
                strcpy(retfrompldn,"");
                done=1;
            } 
            else {
                ansic(0);
                return;
            }
        }
    } 
    while(!done&&!hangup);
    ansic(0);

    return;
}

void linpopup(char *fn)
{
    int done=0,draw=4;
    int i,ch,x,y,r,slen,em;
    char s[81],fmt[200],fmto[200],s1[81],s2[81],desc[81],key[20];
    FILE *f;
    menurec tg;
    char availKeys[81];

    x=1;
    y=24;

    makerembox(x,y-1,22,"linear");

    sprintf(s,"%s%s.fmt",syscfg.menudir,"linear");
    f=fopen(s,"rt");


    fgets(s,211,f);
    fgets(s,211,f);
    fgets(fmt,211,f);
    filter(fmt,'\n');
    fgets(fmto,211,f);
    filter(fmto,'\n');
    fgets(s,211,f);
    slen=atoi(s);
    fclose(f);

    curtitle=0;
    curitem=0;

    go(y,x);

    for(i=0;i<numitems[curtitle];i++) {
        if(i==curitem)
            strcpy(s1,fmt);
        else
            strcpy(s1,fmto);
        GetLink(&menuC.menuCmd,ml[curtitle][curitem+i],&tg);
        aligncmd1(tg.desc,key,desc);
        stuff_in(s,s1,key,desc,tg.desc,"","");
        go(y,x+(i*15));
        npr(s);
    }

    while(!done&&!hangup) {
        if(draw==2||draw==3) {
            if(draw==2)
                i=-1;
            else
                i=1;
            GetLink(&menuC.menuCmd,ml[curtitle][curitem+i],&tg);
            aligncmd1(tg.desc,key,desc);
            stuff_in(s,fmto,key,makelen(desc,slen),tg.desc,"","");
            go(y,x+((curitem+i)*15));
            npr(s);

            GetLink(&menuC.menuCmd,ml[curtitle][curitem],&tg);
            aligncmd1(tg.desc,key,desc);
            stuff_in(s,fmt,key,makelen(desc,slen),tg.desc,"","");
            go(y,x+(curitem*15));
            npr(s);
        }

        strcpy(availKeys,menuAvailKeys(&i,&i));
        retfrompldn=smkey(availKeys,em,i,1,0,&r);
        if(r) {
            switch(r) {
            case 1:
                GetLink(&menuC.menuCmd,ml[curtitle][curitem],&tg);
                strcpy(retfrompldn,tg.key);
                ansic(0);
                return;
            case -3:
                if(curitem<numitems[curtitle]-1) {
                    curitem++;
                    draw=2;
                }
                break;
            case -4:
                if(curitem>0) {
                    curitem--;
                    draw=3;
                }
                break;
            }
        } 
        else {
            if(retfrompldn[0]=='~') {
                usepldns=0;
                strcpy(retfrompldn,"");
                done=1;
            } 
            else {
                ansic(0);
                return;
            }
        }
    } 
    ansic(0);

    return;
}

#endif
