#include "vars.h"
#pragma hdrstop
#include "mb_lib.h"

void read_hudson(MSGHDR_RECORD *hdr1, int *next)
{
    char s[161],ss[255],ch;
    int f,abort,done,printit,ctrla,centre,i,i1,ansi,ctrld;
    long len,l1,p=0,p1=0,lblock;
    MSGHDR_RECORD hdr;
    M_TEXT txt;

    hdr=*hdr1;

    ansi=0;
    *next=0;
    done=0;
    abort=0;
    ctrld=0;

    showmsgheader(0,hdr.subject,hdr.who_from,hdr.post_date,hdr.who_to,0,0,"",0,&abort);

    txt=msg_read_text(&hdr);
    i=i1=0;

    len=0;

    done=0;
    printit=0;
    ctrla=0;
    centre=0;
    lblock=0;

    for(lblock=0;lblock<hdr.num_blocks;lblock++) {
        done=l1=ch=p=p1=0;
        strcpy(ss,txt->txt[lblock].str_txt);
        len=txt->txt[lblock].str_len;
        ss[len-1]=26;

        while ((!done) && (!abort) && (!hangup)) {
            ch=ss[l1];

            ++l1;

            if (ch==26) done=1; //End of it all..
                else if (ch!=10) {
                if ((ch==13) || (!ch)) {
                    if (ch==13)
                        ctrld=0;
                    printit=1;
                } 
                else if (ch==1) //Goto next line?  For wrapping?  No wrapping?
                ctrla=1;
                else if (ch==2)
                    centre=1; //Control b - center
                    else if (ch==4) //OptionalVal stuff
                    ctrld=1;
                else if (ctrld==1) {
                    if ((ch>='0') && (ch<='9')) {
                        if (thisuser.optional_val<(ch-'0'))
                            ctrld=0;
                        else
                            ctrld=-1;
                    } 
                    else
                        ctrld=0;
                } 
                else {
                    if(!ctrla) {
                        if (ch==27) {
                            if ((topline) && (screenbottom==24) && (!ansi))
                                set_protect(0);
                            ansi=1;
                            lines_listed=0;
                        }
                        s[p++]=ch;
                        if ((ch==3) || (ch==8))
                            --p1;
                        else
                            ++p1;
                        if ((ch==32) && (!centre))
                            printit=1;
                    }
                }

                if ((printit) || (ansi) || (p>=80)) {
                    printit=0;
                    if (centre && (ctrld!=-1)) {
                        i1=(thisuser.screenchars-wherex()-p1)/2;
                        for (i=0; (i<i1) && (!abort) && (!hangup); i++)
                            osan(" ",&abort,next);
                    }
                    if (p) {
                        if (ctrld!=-1) {
                            if ((wherex() + p1 >= thisuser.screenchars) && (!centre) && (!ansi))
                                nl();
                            s[p]=0;
                            outstr(s);
                        }
                        p1=0;
                        p=0;
                    }
                    centre=0;
                }

                checka(&abort,next,1);
                if (ch==13)
                    if (ctrla==0) {
                        if (ctrld!=-1)
                            nl();
                    } 
                    else
                        ctrla=0;
            } 
            else
                ctrld=0;
        }

        if ((!abort) && (p)) {
            s[p]=0;
            pl(s);
        }

    }

    if ((!abort) && (p)) {
        s[p]=0;
        pl(s);
    }


    nl();
    if ((express) && (abort) && (!(*next)))
        expressabort=1;


    if ((ansi) && (topdata) && (useron))
        topscreen();

    mciok=1;
}

void rhd(void)
{
    long recnr;
    MSGHDR_RECORD hdr;
    MSGTOIDX_RECORD to;
    M_TEXT txt;
    int next=1;

    msg_open ("C:\\fd");
    strcpy(to,"All");
    npr("Scanning for unread mail to %s\r\n", to);
    recnr = msg_firstto (& to);
    while (recnr != -1) {
        msg_read_hdr (recnr, & hdr);
        npr("reading %ld`P",recnr);
        read_hudson(&hdr,&next);
        recnr = msg_nextto (recnr);
    }
    msg_read_hdr(0,&hdr);
    read_hudson(&hdr,&next);

    msg_close ();
}
