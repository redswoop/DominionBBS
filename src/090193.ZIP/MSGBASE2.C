#include "vars.h"
#pragma hdrstop
#include <dir.h>


#define LEN 161
#define ALLOW_FULLSCREEN 1
#define EMAIL_STORAGE 2

int deleted_flag;
extern char commstr[41];
char net_email_to[61];

void get_quote()
{
    static char s[141];
    static int i,i1,i2,abort,next,rl;

    rl=1;
    do {
        if (rl) {
            i=1; 
            i2=0; 
            abort=0; 
            next=0;
            do {
                npr("0%2d:",i++);
                i1=0;
                if (abort) {
                    do {
                        i2++;
                    } 
                    while ((quote[i2]!=13) && (quote[i2]!=0));
                } 
                else {
                    do {
                        s[i1++]=quote[i2++];
                    } 
                    while ((quote[i2]!=13) && (quote[i2]!=0));
                }
                if (quote[i2]) {
                    i2+=2;
                    s[i1]=0;
                }
                pla(s,&abort);
            } 
            while (quote[i2]!=0);
            --i;
        }
        nl();
        i1=0; 
        i2=0; 
        s[0]=0;
        while (!s[0]) {
            sprintf(s,"Quote from line 1-%d? (A=All,?=relist,Q=quit) ",i);
            prt(5,s);
            input(s,3);
        }
        if (s[0]=='A') {
            charbufferpointer=0;
            bquote=1;
            equote=i;
            return;
        }
        if (s[0]=='Q')
            rl=0;
        else if (s[0]!='?') {
            i1=atoi(s);
            if (i1==i)
                i2=i1;
            else {
                s[0]=0;
                while (!s[0]) {
                    sprintf(s,"through line %d-%d? (Q=quit) ",i1,i);
                    prt(5,s);
                    input(s,3);
                }
                if (s[0]=='Q')
                    rl=0;
                else if (s[0]!='?')
                    i2=atoi(s);
            }
        }
        if (i2) {
            sprintf(s,"Quote line(s) %d-%d? ",i1,i2);
            prt(5,s);
            if (!ny())
                i2=0;
        }
    } 
    while ((!abort) && (!hangup) && (rl) && (!i2));
    charbufferpointer=0;
    if ((i1>0) && (i2>=i1) && (i2<=i) && (i2-i1<50) && (rl)) {
        bquote=i1;
        equote=i2;
    }
}

char *ini(char name[81])
{
    char o[81];
    int i=0,p=0;

    memset(o,0,81);

    for(i=0;name[i];i++) {
        if ((name[i]>='A') && (name[i]<='Z'))
            o[p++]=name[i];
    }

    return(o);
}

void quote_message(messagerec *m1, char *aux)
{
    char *b,*c,s1[81],quotefrom[10],s[81];
    int cc,dq,lc,ok,mc,i;
    long l,l1,l2,l3,l4,f;
    messagerec m;
    userrec u;

    m=*m1;
    b=readfile(&m,aux,&l);
    if (b==NULL)
        return;
    if ((c=malloca(l+1000L))==NULL) {
        farfree(b);
        return;
    }
    lc=0; 
    l1=0; 
    l2=0; 
    ok=1;

    do {
        if (b[l1]==13)
            lc++;
        l1++;
    } 
    while (lc<3);

    lc=0; 
    dq=1; 
    cc=48;

    strcpy(quotefrom,ini(irt_name));

    do {
        if (lc==0) {
            for(f=l1;f<l1+15;f++) {
                if(b[f]=='>')
                    dq=0;
            }

            if(dq) {
                sprintf(&c[l2]," %s> ",quotefrom);
                l2+=strlen(quotefrom)+3;
                lc+=strlen(quotefrom)+3;
            }

            if (cc!=48) {
                c[l2++]=3;
                c[l2++]=cc;
            }
        }
        switch(b[l1]) {
        case 1:
            if (b[l1-1]!=32)
                c[l2++]=' ';
            l1+=3;
            break;
        case 3:
            l1++;
            cc=b[l1++];
            c[l2++]=3;
            c[l2++]=cc;
            break;
        case 14:
            l1++;
            cc=b[l1++];
            c[l2++]=14;
            c[l2++]=cc;
            break;
        case 4:
            l1+=2;
            break;
        case 13:
            if ((b[l1+1]>96) && (b[l1+1]<123)) {
                if (b[l1-1]!=32)
                    c[l2++]=' ';
                l1+=1;
            } 
            else {
                lc=0; 
                l1+=1;
                dq=1;
                c[l2++]=13;
            }
            break;
        default:
            c[l2++]=b[l1++];
            lc++;
            break;
        }

/*        if (dq==1)
            mc=72;
        else*/
            mc=78;

        if (lc>=mc) {
            l3=l1; 
            l4=l2;
            while ((b[l1]!=32) && (lc>0)) {
                --l1; 
                --l2; 
                --lc;
                if ((b[l1]==3) || (b[l1]==4))
                    lc+=1;
                if (b[l1]==1) {
                    l2+=2;
                    lc+=2;
                }
                if ((b[l1]==13) && (b[l1-1]>4)) {
                    lc+=1;
                }
            }
            if (lc<=1) {
                l1=l3; 
                l2=l4;
            } 
            else {
                lc=0;
                l1++;
            }
            c[l2++]=13;
//            c[l2++]=10;
        }
    } 
    while ((l1<l) && (l2<l+998L) && (ok));

    c[l1++]=0;
    if (ok) {
        sprintf(s1,"%sQUOTE.MSG",syscfg.tempdir);
        f=open(s1,O_RDWR | O_BINARY | O_CREAT | O_TRUNC, S_IREAD | S_IWRITE);
        /*        strcpy(u.name,irt_name);
                        sprintf(s,"%s was saying....\r\n",pnam(&u,0));
        write(f,&s,strlen(s));
        */
        write(f,(void *)c,l2);
        close(f);
        farfree(b);
        farfree(c);
        f=open(s1,O_RDONLY | O_BINARY);
        l2=filelength(f);
        if ((quote=malloca(l2))!=NULL)
            read(f,(void *) quote,l2);
        close(f);
        unlink(s1);
    }
}




void extract_out(char *b, long len, char *title)
{
    char s1[81],s2[81],ch=26,ch1;
    int i;

    do {
        prt(2,"Save under what filename? ");
        input(s1,12);
        if (s1[0]) {
            sprintf(s2,"%s%s",syscfg.gfilesdir,s1);
            if (exist(s2)) {
                nl();
                pl("Filename already in use.");
                nl();
                outstr("5(O)verwrite, (A)ppend, (N)ew name, (Q)uit? ");
                ch1=onek("QOAN");
                switch(ch1) {
                case 'Q':
                    s2[0]=0;
                    s1[0]=0;
                    break;
                case 'N':
                    s1[0]=0;
                    break;
                case 'A':
                    break;
                case 'O':
                    unlink(s2);
                    break;
                }
                nl();
            }
        } 
        else
            s2[0]=0;
    } 
    while ((!hangup) && (s2[0]!=0) && (s1[0]==0));
    if ((s1[0]) && (!hangup)) {
        i=open(s2,O_RDWR | O_BINARY | O_CREAT , S_IREAD | S_IWRITE);
        if (filelength(i)) {
            lseek(i, -1L, SEEK_END);
            read(i, ((void *)&ch1), 1);
            if (ch1 == 26)
                lseek(i, -1L, SEEK_END);
        }
        write(i,title,strlen(title));
        write(i,"\r\n",2);
        write(i,(void *)b,len);
        write(i,&ch,1);
        close(i);
        npr("Message written to: %s.\r\n",s2);
    }
    farfree(b);
}


void grab_user_name(messagerec *m, char *fn)
{
    char *ss,*ss1;
    char *b;
    long len;
    long p,p1,p2;
    char s[81];

    b=readfile(m,fn,&len);

    ss=strtok(b,"\r");
    strcpy(net_email_name,ss);
    ss=strtok(NULL,"\r");
    ss=strtok(NULL,"\r");
    strcpy(net_email_to,ss);

    farfree(ss);

}



void printmenu(int i)
{
    char s[81],s1[81];
    int next;

    next=0;
    commstr[0]=0;

    sprintf(s,"%smenu%d.ans",syscfg.gfilesdir,i);
    if(exist(s)) {
        printfile(s);
        return;
    }
    sprintf(s,"%smnudata.dat",syscfg.gfilesdir);
    if(menus[i].stored_as) read_message1(&menus[i],0,&next,s,0,"",0,"");
}


void delmail(int f, int loc)
{
    mailrec m,m1;
    userrec u;
    int rm,i,t,otf;

    lseek(f,((long) loc) * ((long) sizeof(mailrec)), SEEK_SET);
    read(f,(void *)&m,sizeof(mailrec));

    rm=1;
    if (m.status & status_multimail) {
        t=filelength(f)/sizeof(mailrec);
        otf=0;
        for (i=0; i<t; i++)
            if (i!=loc) {
                lseek(f,((long)i)*((long)sizeof(mailrec)),SEEK_SET);
                read(f,(void *)&m1,sizeof(mailrec));
                if ((m.msg.stored_as==m1.msg.stored_as) && (m.msg.storage_type==m1.msg.storage_type) && (m1.daten!=0xffffffff))
                    otf=1;
            }
        if (otf)
            rm=0;
    }

    if (rm)
        remove_link(&m.msg,"EMAIL");

    if (m.tosys==0) {
        read_user(m.touser,&u);
        if (u.waiting) {
            --u.waiting;
            write_user(m.touser,&u);
            close_user();
        }
        if (m.touser==1)
            --fwaiting;
    }

    lseek(f,((long) loc) * ((long) sizeof(mailrec)), SEEK_SET);
    m.touser=0;
    m.tosys=0;
    m.daten=0xffffffff;
    m.msg.storage_type=0;
    m.msg.stored_as=0xffffffff;
    write(f,(void *)&m,sizeof(mailrec));
    mailcheck=1;
}

void purgemail(int f,int *mloc,int mw,int *curmail, mailrec *m1, slrec *ss)
{
    int i;
    mailrec m;

    ansic(5);
    if ((m1->anony & anony_sender) && ((ss->ability & ability_read_email_anony)==0)) {
        npr("5Delete all mail to you from this user? ");
    } 
    else if (m1->fromsys) {
        npr("5Delete all mail to you from #%u @%u? ",m1->fromuser, m1->fromsys);
    } 
    else {
        npr("5Delete all mail to you from #%u? ",m1->fromuser);
    }
    if (yn()) {
        for (i=0; i<mw; i++) {
            if (mloc[i]>=0) {
                lseek(f,((long) mloc[i]) * sizeof(mailrec),SEEK_SET);
                read(f,(void *) (&m),sizeof(mailrec));
                if ((m.fromuser==m1->fromuser) && (m.fromsys==m1->fromsys)) {
                    npr("Deleting mail msg #%d\r\n",i+1);
                    delmail(f,mloc[i]);
                    mloc[i]=-1;
                    if (*curmail==i)
                        ++(*curmail);
                }
            } 
            else {
                if (*curmail==i)
                    ++(*curmail);
            }
        }
    }
}


/****************************************************************************/


void remove_link(messagerec *m1, char *aux)
{
    messagerec m;
    char s[81],s1[81];
    int f;
    long csec,nsec;

    m=*m1;
    strcpy(s,syscfg.msgsdir);
    switch(m.storage_type) {
    case 0:
    case 1:
        ltoa(m.stored_as,s1,16);
        if (m.storage_type==1) {
            strcat(s,aux);
            strcat(s,"\\");
        }
        strcat(s,s1);
        unlink(s);
        break;
    case 2:
        f=open_file(aux);
        set_gat_section(f,m.stored_as/2048);
        csec=m.stored_as % 2048;
        while ((csec>0) && (csec<2048)) {
            nsec=(long) gat[csec];
            gat[csec]=0;
            csec=nsec;
        }
        save_gat(f);
        close(f);
        break;
    default:
        /* illegal storage type */
        break;
    }
}



void load_workspace(char *fnx, int no_edit)
{
    int i,i5;
    long l;
    char *b,s[81];

    i5=open(fnx,O_RDONLY | O_BINARY);
    if (i5<1) {
        nl();
        pl("File not found.");
        nl();
        return;
    }
    l=filelength(i5);
    if ((b=malloca(l+1024))==NULL) {
        close(i5);
        return;
    }
    read(i5, (void *) b,l);
    close(i5);
    if (b[l-1]!=26)
        b[l++]=26;
    sprintf(s,"%smsgtmp",syscfg.tempdir);
    i5=open(s,O_RDWR | O_CREAT | O_BINARY,S_IREAD | S_IWRITE);
    write(i5, (void *)b,l);
    close(i5);
    farfree(b);
    if ((no_edit))
        use_workspace=1;
    else
        use_workspace=0;
    nl();
    pl("File loaded into workspace.");
    nl();

}


int forwardm(unsigned short *u, unsigned short *s)
{
    userrec ur;
    char *ss;
    int i,i1,cu;

    if (*s)
        return(0);
    read_user(*u,&ur);
    if (ur.inact & inact_deleted)
        return(0);
    if ((ur.forwardusr==0) && (ur.forwardsys==0))
        return(0);
    cu=ur.forwardusr;
    if (cu==-1) {
        pl("Mailbox Closed.");
        if (so()) {
            pl("(Forcing)");
        } 
        else {
            *u=0;
            *s=0;
        }
        return(0);
    }
    if ((ss=malloca((long) syscfg.maxusers+ 300L))==NULL)
        return(0);
    for (i=0; i<syscfg.maxusers+300; i++)
        ss[i]=0;
    ss[*u]=1;
    read_user(cu,&ur);
    while ((ur.forwardusr) || (ur.forwardsys)) {
        if (ss[cu]) {
            farfree(ss);
            return(0);
        }
        ss[cu]=1;
        if (ur.forwardusr==65535) {
            pl("Mailbox Closed.");
            if (so()) {
                pl("(Forcing)");
                *u=cu;
                *s=0;
            } 
            else {
                *u=0;
                *s=0;
            }
            farfree(ss);
            return(0);
        }
        cu=ur.forwardusr;
        read_user(cu,&ur);
    }
    farfree(ss);
    *s=0;
    *u=cu;
    return(1);
}


void sendout_email(char *title, messagerec *msg, int anony, unsigned un, unsigned sy, int an)
{
    mailrec m,m1;
    int f,len,i,i1;
    char *b,*b1,s[129],s2[129],s1[129];
    long len1;
    userrec ur;


    strcpy(m.title, title);
    m.msg=*msg;
    m.anony=anony;
    m.fromsys=0;
    m.fromuser=usernum;
    m.tosys=sy;
    m.touser=un;
    m.status=0;
    time((long *)&(m.daten));
    sprintf(s,"%sEMAIL.DAT",syscfg.datadir);
    if (sy==0) {
        f=open(s,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
        if (!f) {
            return;
        }
        len=(int) filelength(f)/sizeof(mailrec);
        if (len==0)
            i=0;
        else {
            i=len-1;
            lseek(f,((long) (i))*(sizeof(mailrec)), SEEK_SET);
            read(f,(void *)&m1,sizeof(mailrec));
            while ((i>0) && (m1.tosys==0) && (m1.touser==0)) {
                --i;
                lseek(f,((long) (i))*(sizeof(mailrec)), SEEK_SET);
                i1=read(f,(void *)&m1,sizeof(mailrec));
                if (i1==-1)
                    pl("DIDN'T READ RIGHT.");
            }
            if ((m1.tosys) || (m1.touser))
                ++i;
        }
        lseek(f,((long) (i))*(sizeof(mailrec)), SEEK_SET);
        i1=write(f,(void *)&m,sizeof(mailrec));
        if (i1==-1) {
            pl("DIDN'T SAVE RIGHT!");
        }
        close(f);
    }
    s2[0]=0;
    strcpy(s,"Mail sent to ");
    if (sy==0) {
        read_user(un,&ur);
        ++ur.waiting;
        write_user(un,&ur);
        close_user();
        if (un==1)
            ++fwaiting;
        if (an) {
            strcat(s,nam(&ur,un));
            sysoplog(s);
        } 
        else {
            strcpy(s1,s);
            strcat(s1,nam(&ur,un));
            sysoplog(s1);
            strcat(s,"Anonymous");
        }
    } 
    if ((un==1) && (sy==0)) {
        ++status.fbacktoday;
        ++thisuser.feedbacksent;
        ++thisuser.fsenttoday1;
        ++fsenttoday;
    } 
    else {
        ++status.emailtoday;
        ++thisuser.etoday;
        if (sy==0) {
            ++thisuser.emailsent;
        } 
        else {
            ++thisuser.emailnet;
            /* len1=nh.length+sizeof(net_header_rec); */
            /* fl = (csne->cost) * ((float)len1) / 1024.0; */
            /* sprintf(s2,"Total cost: $%6.2f",fl); */
        }
    }
    save_status();
    if (!wfc)
        topscreen();
    pl(s);
    if (s2[0])
        pl(s2);
}


int ok_to_mail(unsigned un, unsigned sy, int forceit)
{
    userrec ur;
    slrec ss;

    ss=syscfg.sl[actsl];

    if (sy==0) {
        if (un==0)
            return(0);
        read_user(un,&ur);
        if (((ur.sl==255) && (ur.waiting>(syscfg.maxwaiting * 5))) ||
            ((ur.sl!=255) && (ur.waiting>syscfg.maxwaiting)) ||
            (ur.waiting>200)) {
            if (!forceit) {
                nl();
                pl("Mailbox full.");
                nl();
                return(0);
            }
        }
        if (ur.inact & inact_deleted) {
            nl();
            pl("Deleted user.");
            nl();
            return(0);
        }
    } 
    if (forceit==0) {
        if ((((un==1) && (sy==0) && ((fsenttoday>=5) || (thisuser.fsenttoday1>=10))) ||
            (((un!=1) || (sy!=0)) && (thisuser.etoday>=ss.emails))) && (!cs())) {
            nl();
            pl("Too much mail sent today.");
            nl();
            return(0);
        }
        if ((restrict_email & thisuser.restrict) && (un!=1)) {
            nl();
            pl("You can't send mail.");
            nl();
            return(0);
        }
    }
    return(1);
}



void yourinfomsg()
{
    nl();
    dtitle("Your Message Status");
    npr("0Total Posts   5: 4%d\r\n",thisuser.msgpost);
    npr("0Posts Today   5: 4%d\r\n",thisuser.posttoday);
    npr("0FeedBack      5: 4%d\r\n",thisuser.feedbacksent);
    npr("0Email Sent    5: 4%d\r\n",thisuser.emailsent);
    npr("0Messages Read 5: 4%d\r\n",thisuser.msgread);
    npr("0Mail Waiting  5: 4%d\r\n",thisuser.waiting);
    npr("0Your PCR      5: 4%.0f%%\r\n",post_ratio()*100);
    npr("0Required PCR  5: 4%.0f%%\r\n",syscfg.post_call_ratio*100);
    nl();
    nl();
}

void anscan(int ss)
{
    int i,nextsub,abort,next,disp=0;

    nl();
    nextsub=1;

    for (i=ss; (usub[i].subnum!=-1) && (i<64) && (nextsub) && (!hangup); i++) {
        if (subboards[usub[i].subnum].attr & mattr_autoscan) {
            if(!disp) {
                pl("4AutoScanning Subs");
                disp=1;
            }
            qscan(i,&nextsub);
        }
        abort=next=0;
        checka(&abort,&next,0);
        if (abort)
            nextsub=0;
    }
}

void find_subject(void)
{
    char subject[80], string[80], s[80], s1[80],s2[80];
    char title[80];
    char *result;
    int i,k,yes,count,abort;
    subboardrec sb;
    postrec m;
    FILE *fptr,*fptr2;

    i=k=count=abort=0;
    dtitle("Title Search");
    nl();
    inputdat("Text to Search for in Titles",subject,30,1);
    if (subject[0]==0)
        return;
    nl();
    strcpy(string,subject);
    strupr(subject);
    strcpy(s1,syscfg.datadir);
    strcat(s1,"\\SUBS.DAT");
    fptr=fopen(s1,"rb");
    prt(0,"Seaching for \"");
    prt(0,string);
    prt(0,"\" ...");
    nl();
    nl();
    while ((fread(&sb, sizeof(sb),1,fptr)==1) && (abort==0)){
        result=NULL;
        if (slok(sb.readacs,0)) {
            k++;
            strcpy(s1,syscfg.datadir);
            strcat(s1,sb.filename);
            strcat(s1,".SUB");
            fptr2=fopen(s1,"rb");
            i=yes=0;
            while (fread(&m, sizeof(m),1,fptr2)==1) {
                strcpy(title,m.title);
                strupr(m.title);
                result=strstr(m.title,subject);
                if ((result!=NULL) && (i!=0)){
                    if (!yes) {
                        ansic(2);
                        itoa(k, s, 10);
                        strcpy(s2, "[");
                        strcat(s2,s);
                        strcat(s2,"] [");
                        strcat(s2,sb.name);
                        strcat(s2,"]");
                        pla(s2,&abort);
                        yes=1;
                    }
                    ansic(0);
                    itoa(i,s,10);
                    strcpy(s2,"\t#");
                    if (strlen(s) < 2)
                        strcat(s2," ");
                    strcat(s2, s);
                    strcat(s2,": ");
                    strcat(s2, title);
                    pla(s2,&abort);
                    count++;
                }
                i++;
            }
        }
        fclose(fptr2);
    }
    fclose(fptr);
    if (abort==0) {
        itoa(count,s,10);
        nl();
        prt(0,s);
        prt(0," match");
        if (count!=1)
            prt(0,"es");
        prt(0," found");
    }
}

void send_email()
{
    char s1[81],*ss;
    int i;
    unsigned short sy,un;

    nl();
    nl();
    inputdat("Enter User Name/Number",s1,41,0);
    irt[0]=0;
    irt_name[0]=0;
    parse_email_info(s1,&un,&sy);
    if (un || sy)
        email(un,sy,0,0);
}

void packm(void)
{
    char s[161],s1[81],*b;
    int f,i,i1,i2;
    long l1;
    mailrec m;


    for (i=0; (i<num_subs); i++) {
        sprintf(s,"%s%s.SUB",syscfg.msgsdir,subboards[i].filename);
        f=open(s,O_BINARY | O_RDWR);
        if (f==-1){
            f=open(s,O_BINARY | O_RDWR | O_CREAT,S_IREAD | S_IWRITE);
            msgs[0].owneruser=0;
            write(f,(void *) (&msgs[0]),sizeof(postrec));
        }
        lseek(f,0L,SEEK_SET);
        nummsgs=(read(f,(void *) (&msgs[0]),501*sizeof(postrec)) / sizeof(postrec))-1;
        nummsgs=msgs[0].owneruser;
        close(f);
        i1=1;
        i2=1;
        sprintf(s,"Optimizing %s...",subboards[i].name);
        outchr(12);
        prt(1,s);
        while ((i1<=nummsgs) && (i2)){
            b=readfile(&(msgs[i1].msg),(subboards[i].filename),&l1);
            if (b!=NULL)
                savefile(b,l1,&(msgs[i1].msg),"NEW");
            else
                i2=0;
            i1++;
        }
        if (i2){
            sprintf(s,"%s%s.SUB",syscfg.msgsdir,subboards[i].filename);
            f=open(s,O_BINARY | O_RDWR);
            lseek(f,0L,SEEK_SET);
            msgs[0].owneruser=nummsgs;
            write(f,(void *) (&msgs[0]), ((nummsgs+1) * sizeof(postrec)));
            close(f);

            cd_to(syscfg.msgsdir);
            sprintf(s,"%s.DAT",(subboards[i].filename));
            remove(s);
            rename("NEW.DAT",s);
            cd_to(cdir);
            pl("Done.");
        }
        else {
            cd_to(syscfg.msgsdir);
            remove("NEW.DAT");
            cd_to(cdir);
            pl("Cannot Optimize.");
        }
    }
    curlsub=num_subs+1;
}

int sublist(char type)
{
    FILE *f;
    subboardrec d;
    char s[163],s1[163],s2[5],s3[25],s4[161];
    int i,i1,abort=0;
    if(type);

    sprintf(s,"%ssublist.fmt",syscfg.gfilesdir);
    f=fopen(s,"rt");

    fgets(s,163,f); filter(s,'\n');
    pla(s,&abort);
    fgets(s,163,f); filter(s,'\n');
    pla(s,&abort);


    fgets(s1,163,f); filter(s1,'\n');
    fgets(s4,163,f); filter(s4,'\n');

    for(i=0;i<umaxsubs&&usub[i].subnum!=-1&&!abort; i++) {
        iscan(i);
        d=subboards[usub[i].subnum];
        itoa(nummsgs,s2,10);

        i1=0;
        if (i>=32) { if (thisuser.qscn2 & (1L << (i-32))) i1=1; }
        else { if (thisuser.qscn & (1L << i)) i1=1; }

        if(i1)
            stuff_in2(s,s1,noc2(d.name),40,usub[i].keys,2,s2,3,"",0,"",0);
        else
            stuff_in2(s,s4,noc2(d.name),40,usub[i].keys,2,s2,3,"",0,"",0);
        pla(s,&abort);
    }
    fgets(s1,163,f); filter(s1,'\n');
    pla(s1,&abort);

    fclose(f);
    return 0;
}
