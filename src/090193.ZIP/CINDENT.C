/*_ cindent.c   Mon Mar  3 1986 */
/*
        Pretty-printer for C Programs
       
        Swiped from the CIPG's UNIX system and modified to run
                under BDS C by William C. Colley, III

        Mods made July 1980
        
        Originally known as CB.C for BDS C
        Changed back to K&R C by Gary Martin
        Now always requires an output file -- does not print to console
        Expands tabs to spaces
        Known to work on DeSmet C 2.4
        February 1985


To use the program, type the following command line:

        A>indent input.fil output.fil

where input.fil is the file to be pretty-printed and output.fil is an
output file. 

*/

#include <stdio.h>
#include <fcntl.h>
#include <alloc.h>

int slevel[10];
int clevel;
int spflg[20][10];
int sind[20][10];
int siflev[10];
int sifflg[10];
int iflev;
int ifflg;
int level;
int ind[10] = {
    0,0,0,0,0,0,0,0,0,0};
int eflg;
int paren;
int pflg[10] = {
    0,0,0,0,0,0,0,0,0,0};
char lchar;
char pchar;
int aflg;
int ct;
int stabs[20][10];
int qflg;
char *wif[2];
char *welse[2];
char *wfor[2];
char *wds[3];
int j;
int loop;
char string[200];
char cc;
int sflg;
int bflg;
int peak;
int tabs;
int chr;
int lastchar;
char c;

FILE *infile,*outfile;

main(argc,argv)
int argc;
char *argv[];
{
    int k;

    /*  Initialize everything here.  */

    if (argc < 2 || argc > 4){
        printf("Usage:  indent input.fil output.fil\n");
        exit();
    }

    if ((infile = fopen(*++argv,"r")) == 0){
        printf("File not found\n\n");
        exit();
    }

    if (argc == 3) {
            if ((outfile = fopen(*++argv,"w")) == 0) {
                printf("Could not create output file\n");
                exit();
            }
    }

    clevel = iflev = level = eflg = paren = 0;
    aflg = qflg = j = bflg = tabs = 0;
    ifflg = peak = -1;
    sflg = 1;      
    wif[0] = "if";
    welse[0] = "else";
    wfor[0] = "for";
    wds[0] = "case";
    wds[1] = "default";
    wif[1] = welse[1] = wfor[1] = wds[2] = 0;

    /*  End of initialization.  */

    while((chr = getchr()) != EOF){
        c = (char) chr;
        switch(c){
        default:
            string[j++] = c;
            if(c != ',')lchar = c;
            break;
        case ' ':
            if(lookup(welse) == 1){
                gotelse();
                if(sflg == 0 || j > 0) string[j++] = c;
                putstr();
                sflg = 0;
                break;
            }
            if(sflg == 0 || j > 0)  string[j++] = c;
            break;

        case '\t':
            if(lookup(welse) == 1){
                gotelse();
                if(sflg == 0 || j > 0)
                    for (loop=0;loop <= 4;loop++) string[j++] = ' ';
                putstr();
                sflg = 0;
                break;
            }
            if(sflg == 0 || j > 0)
                for (loop=0;loop <= 4;loop++) string[j++] = ' ';
            break;
        case '\n':
            if(eflg = lookup(welse) == 1)gotelse();
            putstr();
            printit("\n");
            sflg = 1;
            if(eflg == 1){
                pflg[level]++;
                tabs++;
            }
            else
                if(pchar == lchar)
                    aflg = 1;
            break;
        case '{':
            if(lookup(welse) == 1)gotelse();
            siflev[clevel] = iflev;
            sifflg[clevel] = ifflg;
            iflev = ifflg = 0;
            clevel++;
            if(sflg == 1 && pflg[level] != 0){
                pflg[level]--;
                tabs--;
            }
            string[j++] = c;
            putstr();
            getnl();
            putstr();
            printit("\n");
            tabs++;
            sflg = 1;
            if(pflg[level] > 0){
                ind[level] = 1;
                level++;
                slevel[level] = clevel;
            }
            break;
        case '}':
            clevel--;
            if((iflev = siflev[clevel]-1) < 0)iflev = 0;
            ifflg = sifflg[clevel];
            putstr();
            tabs--;
            ptabs();
            if((peak = getchr()) == ';'){
                printit("%c;",c);
                peak = -1;
            }
            else printit("%c",c);
            getnl();
            putstr();
            printit("\n");
            sflg = 1;
            if(clevel < slevel[level])if(level > 0)level--;
            if(ind[level] != 0){
                tabs -= pflg[level];
                pflg[level] = 0;
                ind[level] = 0;
            }
            break;
        case '"':
        case '\'':
            string[j++] = c;
            while((cc = getchr()) != c){
                string[j++] = cc;
                if(cc == '\\'){
                    string[j++] = getchr();
                }
                if(cc == '\n'){
                    putstr();
                    sflg = 1;
                }
            }
            string[j++] = cc;
            if(getnl() == 1){
                lchar = cc;
                peak = '\n';
            }
            break;
        case ';':
            string[j++] = c;
            putstr();
            if(pflg[level] > 0 && ind[level] == 0){
                tabs -= pflg[level];
                pflg[level] = 0;
            }
            getnl();
            putstr();
            printit("\n");
            sflg = 1;
            if(iflev > 0)
                if(ifflg == 1){
                    iflev--;
                    ifflg = 0;
                }
                else iflev = 0;
            break;
        case '\\':
            string[j++] = c;
            string[j++] = getchr();
            break;
        case '?':
            qflg = 1;
            string[j++] = c;
            break;
        case ':':
            string[j++] = c;
            if(qflg == 1){
                qflg = 0;
                break;
            }
            if(lookup(wds) == 0){
                sflg = 0;
                putstr();
            }
            else{
                tabs--;
                putstr();
                tabs++;
            }
            if((peak = getchr()) == ';'){
                printit(";");
                peak = -1;
            }
            getnl();
            putstr();
            printit("\n");
            sflg = 1;
            break;
        case '/':
            string[j++] = c;
            if((peak = getchr()) != '*')break;
            string[j++] = peak;
            peak = -1;
            comment();
            break;
        case ')':
            paren--;
            string[j++] = c;
            putstr();
            if(getnl() == 1){
                peak = '\n';
                if(paren != 0)aflg = 1;
                else if(tabs > 0){
                    pflg[level]++;
                    tabs++;
                    ind[level] = 0;
                }
            }
            break;
        case '#':
            string[j++] = c;
            while((cc = getchr()) != '\n'){
                if (cc != '\t') string[j++] = cc;
                else for (loop=0;
                loop <= 4;
                loop++) string[j++] = ' ';
            }
            string[j++] = cc;
            sflg = 0;
            putstr();
            sflg = 1;
            break;
        case '(':
            string[j++] = c;
            paren++;
            if(lookup(wfor) == 1){
                while((c = getstr()) != ';');
                ct=0;
cont:
                while((c = getstr()) != ')'){
                    if(c == '(') ct++;
                }
                if(ct != 0){
                    ct--;
                    goto cont;
                }
                paren--;
                putstr();
                if(getnl() == 1){
                    peak = '\n';
                    pflg[level]++;
                    tabs++;
                    ind[level] = 0;
                }
                break;
            }
            if(lookup(wif) == 1){
                putstr();
                stabs[clevel][iflev] = tabs;
                spflg[clevel][iflev] = pflg[level];
                sind[clevel][iflev] = ind[level];
                iflev++;
                ifflg = 1;
            }
        }
    }        
    fclose(infile);
    fclose(outfile);

    unlink(argv[1]);
    rename(argv[2],argv[1]);

    exit();
}
ptabs(){
    int i;
    for(i=0; i < tabs; i++)printit("    ");
}
getchr(){
    if(peak < 0 && lastchar != ' ' && lastchar != '\t')pchar = lastchar;
    if (peak < 0)
        lastchar = getc(infile);        
    else
        lastchar = peak;
    peak = -1;
    return(lastchar == '\r' ? getchr():lastchar);
}
putstr(){
    if(j > 0){
        if(sflg != 0){
            ptabs();
            sflg = 0;
            if(aflg == 1){
                aflg = 0;
                if(tabs > 0)printit("    ");
            }
        }
        string[j] = '\0';
        printit("%s",string);
        j = 0;
    }
    else{
        if(sflg != 0){
            sflg = 0;
            aflg = 0;
        }
    }
}
lookup(tab)
char *tab[];
{
    char r;
    int l,kk,k,i;
    if(j < 1)return(0);
    kk=0;
    while(string[kk] == ' ')kk++;
    for(i=0; tab[i] != 0; i++){
        l=0;
        for(k=kk;(r = tab[i][l++]) == string[k] && r != '\0';k++);
        if(r == '\0' && (string[k] < 'a' || string[k] > 'z'))return(1);
    }
    return(0);
}
getstr(){
    char ch;
beg:
    if((ch = string[j++] = getchr()) == '\\'){
        string[j++] = getchr();
        goto beg;
    }
    if(ch == '\'' || ch == '"'){
        while((cc = string[j++] = getchr()) != ch)if(cc == '\\')string[j++] = getchr();
        goto beg;
    }
    if(ch == '\n'){
        putstr();
        aflg = 1;
        goto beg;
    }
    else return(ch);
}
gotelse(){
    tabs = stabs[clevel][iflev];
    pflg[level] = spflg[clevel][iflev];
    ind[level] = sind[clevel][iflev];
    ifflg = 1;
}
getnl(){
    while((peak = getchr()) == '\t' || peak == ' '){
        if ( peak == '\t')
            for (loop=0;loop <= 4;loop++) string[j++] = ' ';
        if (peak == ' ') string[j++] = peak;
        peak = -1;
    }
    if((peak = getchr()) == '/'){
        peak = -1;
        if((peak = getchr()) == '*'){
            string[j++] = '/';
            string[j++] = '*';
            peak = -1;
            comment();
        }
        else string[j++] = '/';
    }
    if((peak = getchr()) == '\n'){
        peak = -1;
        return(1);
    }
    return(0);
}
comment(){
rep:
    while((c = getchr()) != '*'){
        if (c != '\t') string[j++] = c;
        else  for (loop=0;loop <= 4;loop++) string[j++] = ' ';
        if(c == '\n'){
            putstr();
            sflg = 1;
        } 
    }
    string[j++] = c;
gotstar:
    if((c = string[j++] = getchr()) != '/'){
        if(c == '*')goto gotstar;
        goto rep;
    }
}
printit(format,arg)
char *format;
unsigned arg;
{
    if (fprintf(outfile,format,arg) == -1){
        printf("Disk write error\n");
        exit();
    }
}
