void main(){
      asm mov ax,0x1003;
  asm mov bl,0x0;
  asm int 0x10;

}
