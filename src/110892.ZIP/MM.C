#include "vars.h"
#pragma hdrstop

#define fourcol 0x01

menurec tg[50];
mmrec pp;

char avail[50][8],maxcmd,menuat[15],lastmenu[15];

int slok(char *s,char menu)
{
    char ok=1,neg=0,*p,s1[81];
    int i;

    p=strtok(s,"&");
    if(p) strcpy(s,p);
    else s[0]=0;

    while(s[0]) {
        neg=0;
        if(s[0]=='!') {
          strcpy(s,s+1);
          neg=1;
        }
        switch(toupper(s[0])) {
            case '#': if(sysop2()) ok=1; else ok=1; break;
            case 'C': if(!menu) ok=postr_ok(); break;
            case 'A': if(!(thisuser.ar & (1 << toupper(s[1])-'A'))) ok=0;
                      break;
            case 'I': if(!(thisuser.dar & (1 << toupper(s[1])-'A'))) ok=0;
                      break;
            case 'S': if(actsl<atoi(s+1)) ok=0;
                       break;
            case 'D': if(thisuser.dsl<atoi(s+1)) ok=0;
                      break;
            case 'B': if(modem_speed<atoi(s+1)) ok=0;
                      break;
            case 'U': if(atoi(s+1)!=usernum) ok=0; break;
            case '@': if(!strchr(conf[curconf].flagstr,s[1])) ok=0; break;
            case 'G': if(thisuser.age<atoi(s+1)) ok=0; break;
         }
        if(neg) ok=opp(ok);
        p=strtok(NULL,"&");
        if(p) strcpy(s,p);
        else s[0]=0;
        }

    return ok;
}



int ex(char type[2],char ms[81])
{
  int abort,i,i1;
  long l;
  char s[255],s1[81],*s2,c;


  switch(type[0]) {
    case 'V': nuv(); break;
    case '@': enter_nuv(thisuser); break;
    case '!': mailsys(ms[0]); break;
    case 'J': amsgcommand(type[1]); break;
    case 'A': arccommands(type[1]); break;
    case 'D':
        create_chain_file("CHAIN.TXT");
        write_door_sys(0);
        dorinfo_def();
        sprintf(s1,"%d",syscfg.primaryport);
        sprintf(s2,"%d",com_speed);
        stuff_in(s,ms,s2,thisuser.name,s2,s1,ctim(nsl()));
        set_protect(0);
        save_status();
        printf("[0m");
        clrscr();
        logpr("5�> 0Ran Door 4%s",ms);
        sl1(1,"");
        switch(type[1]) {
             case '1': runprog(s,0); break;
             case '2': runprog(s,1); break;
        }
        topscreen();
        break;
    case 'M': msgcommand(type[1],ms); break;
    case 'F':
         switch(type[1])
            {
            case 'Z': npr("\r\n3Enter Path to Use (Include Trailing Backslash)\r\n5: ");
                      mpl(60);
                      input(s,60);
                      insert_dir(umaxdirs,s,1);
                      udir[umaxdirs].subnum=umaxdirs;
                      curdir=umaxdirs;
                      logpr("2@0 Created temporary path in %s",s);
                      break;
            case 'M': mark(curdir); break;
            case 'L': if(ms[0]) listfiles(atoi(ms)); else listfiles(curdir); break;
            case 'B': batchdled(); break;
            case 'G': listgen(); sysoplog("2>0 Downloaded File List"); break;
            case 'Y': yourinfodl(); break;
            case 'D': if(ms[0]) newdl(atoi(ms)); else newdl(curdir); break;
            case 'V': arc_cl(1); break;
            case 'S': searchall(); break;
            case 'R': removefile(0); sysoplog("2>0 Removed Files"); break;
            case 'P': setldate(); break;
            case 'F': finddescription(); break;
            case '1': localupload(); break;
            case '2': editfile(); sysoplog("5@ 0Edit Files"); break;
            case '3': nl();
                      outstr("5Validate Globally? ");
                      if(yn()) {
                        i=curdir;
                        for(curdir=0;curdir<num_dirs&&udir[curdir].subnum>=0;curdir++)
                            valfiles();
                        curdir=i;
                      } else valfiles();
                      sysoplog("2@ 0Validated Files");
                      break;
            case '4': removefile(1); sysoplog("2@0 Killed Offline Files"); break;
            case '5': move_file(1); sysoplog("2@0 Moved Offline files"); break;
            case '6': nl(); outstr("5Sort all dirs? ");
                      i=yn(); nl();
                      prt(5,"Sort by date? ");
                      if(yn()) i1=2; else i1=0;
                      if(i) sort_all(i1); else sortdir(udir[curdir].subnum,i1);
                      if(i) sysoplog("2@0 Sorted Files");
                      break;
            case '7': move_file(0); sysoplog("2@0 Moved Files"); break;
            case '8': unlisteddl(); break;
            case '9': arc_cl(0); sysoplog("2@0 Commented Files"); break;
            case '0': arc_cl(2); sysoplog("2@0 Added Gif Comment to Files"); break;
            case 'U': upload(); break;
            case 'N':   nl();
                        abort=0;
                        if(ms[0]=='C') {
                          nscandir(curdir,&abort,0,&i);
                          logpr("5NewScaned File Area %s",directories[udir[curdir].subnum].name);
                          break;
                        }
                        if(ms[0]=='G') {
                          nscanall();
                          break;
                        }
                        outstr("5Global NewScan? ");
                        if(ny())
                        nscanall();
                        else {
                          nscandir(curdir,&abort,0,&i);
                          logpr("5NewScaned File Area %s",directories[udir[curdir].subnum].name);
                        }
                        break;
            } break;
    case 'S':
          switch(type[1])
          {
            case 'D': sysoplog("5@0 Entered MiniDos");
                      minidos(); break;
            case 'B': sysoplog("5@0 Ran Board Edit");
                      boardedit(); break;
            case '-': glocolor(); break;
            case 'P': sysoplog("5@0 Ran SysCfgEdit");
                      config(); break;
            case 'F': sysoplog("5@0 Ran Dir Edit");
                      diredit(); break;
            case 'M': sysoplog("5@0 Read All Mail");
                      mailr(); break;
            case 'H': sysoplog("5@0 Changed Users");
                      chuser(); break;
            case 'C': pl(((*(char far *)0x00000417L ^= 0x10) & 0x10) ?
                     "Sysop now unavailable" : "Sysop now available");
                      sysoplog("5@0 Changed sysop avail status");
                      topscreen();
                      break;
           case 'I': sysoplog("5@ 0Printed Voting Results");
                     voteprint(); break;
           case 'U': sysoplog("5@ 0Ran User Editor");
                     uedit(1,0); break;
           case 'V': sysoplog("5@ 0Editing Voting");
                     ivotes(); break;
           case 'Z': sysoplog("5@ 0Looked at System Activity");
                     zlog(); break;
           case '+': sysoplog("5@ 0Re-Read Menus.msg");
                     read_new_stuff(); break;
           case 'E': sysoplog("5@ 0Edited Strings");
                     if(ms[0]) edstring(atoi(ms));
                     else edstring(0); break;
           case 'R': sysoplog("5@ 0Reset Rumours and Names List");
                     reset_files(); break;
           case 'X': sysoplog("5@ 0Ran Protocol Editor");
                     protedit(); break;
           case 'L': sysoplog("5@ 0Ran Conference Editor");
                     confedit(); break;
           case 'T': text_edit(); break;
           case 'O': viewlog(); break;
           case '#': sysoplog("5@ 0Ran Menu Editor");
                     if(ms[0]=='!') menued(menuat);
                     else menu("");
                     break;
        } break;
    case 'O': othercmd(type[1],ms); break;
    case 'I': hangupcmd(type[1],ms); break;
    case 'Q': switch(type[1])
              {
                case 'A': addbbs(ms[0]?ms:"bbslist.msg"); break;
                case 'R': printfile(ms[0]?ms:"bbslist.msg");
                          pausescr();
                          break;
                case 'S': searchbbs(ms[0]?ms:"bbslist.msg");
                          break;
            } break;

    case '=':
         switch(type[1])
           {
             case 'J': jumpconf(); break;
             case ']': curconf++; if(curconf>=num_conf) curconf=0;
                       changedsl();
                       break;
             case '[': curconf--; if(curconf<0) curconf=num_conf-1;
                       changedsl();
                       break;
             case '/':  nl(); strcpy(lastmenu,menuat);
                              if(!readmenu(ms)) readmenu(nifty.firstmenu);
                              return 0;
             case '\\':  nl(); if(readmenu(lastmenu))
                              readmenu(menuat);
                              return 0;
             case '^':  nl(); if(!readmenu(ms))
                              readmenu(nifty.firstmenu);
                                      return 0;
             case '*':  if(ms[0]=='M') sublist(ms[1]);
                        else if(ms[0]=='F') curdir=dirlist(ms[1]);
                        break;
             case '+':  if(ms[0]=='M') {
                          if(cursub<64 && usub[cursub+1].subnum>=0) {
                            ++cursub;
                            msgr++;
                          }
                          else cursub=0;
                          iscan(cursub);
                          msgr=1;
                        }
                        else if(ms[0]=='F') {
                          if(directories[udir[curdir].subnum].type)
                          changedsl();
                          if(curdir<64 && udir[curdir+1].subnum>=0) ++curdir;
                          else curdir=0;
                        }
                        break;
             case '-': if(ms[0]=='M') {
                          if (cursub>0)
                            --cursub;
                          else
                            while ((usub[cursub+1].subnum>=0) && (cursub<64))
                             ++cursub;
                             iscan(cursub);
                             msgr=1;
                        } else if(ms[0]=='F') {
                          if(directories[udir[curdir].subnum].type)
                          changedsl();
                          if (curdir>0) curdir--;
                            else
                          while ((udir[curdir+1].subnum>=0) && (curdir<63)) ++curdir;
                        }
              break;
        } break;
    }
return 1;
}

#define USEPLDNS 1

#ifdef USEPLDNS

#define myxy(x,y) npr("[%d;%dH",x,y)

void mdbar()
{
    int i;

    myxy(1,1);
    ansic(0);
    for(i=0;i<80;i++) outchr('�');
    ansic(10);
    myxy(2,1);
    for(i=0;i<80;i++) outchr(32);
    ansic(11);
    myxy(3,1);
    for(i=0;i<80;i++) outchr('�');
}

void drawheader(char titles[5][20],int num)
{
    int i;

    mdbar();
    myxy(2,1);
    npr("[47;37;1m");
    for(i=0;i<num;i++)
        npr("%-20.20s",titles[i]);
}

char menutitles[5][20];
menurec tgp[5][20];
int curitem=0,curtitle=0,numtitles=0,numitems[5],usepldns=0;

void readmenup()
{
    int i=0,total=0;
    int titlen=0,comn=0,done;

    total=maxcmd;

    numtitles=0;
    for(i=0;i<5;i++) numitems[i]=0;
    curitem=0;
    curtitle=0;

    i=0;
    strcpy(menutitles[i++],tg[0].desc);
    do {
        if(tg[i].at!='P'&&tg[i].at!='T'&&tg[i].at!='H'&&comn<20) {
            tgp[titlen][comn++]=tg[i];
        } else if(tg[i].at!='H') {
            numitems[titlen]=comn;
            numtitles++;
            titlen++;
            strcpy(menutitles[titlen],tg[i].desc);
            comn=0;
        }
   } while(i++<total);
    numitems[titlen]=comn-1;
    numtitles++;
}

char *pldn(void)
{
    int done=0,draw=1;
    int i,ch;
    char s[81];
    char temp[10];


    readmenup();
    do {
        if(draw==1) {
            draw=0;
            outchr(12);
            drawheader(menutitles,numtitles);
            myxy(2,20*curtitle);
            npr("[30;1;47m�[33m%-18.18s[30m�",menutitles[curtitle]);
            myxy(3,20*curtitle);
            npr("[0;30;1m�[47m");
            for(i=0;i<18;i++) outchr(220);
            npr("[40m�");
            outstr("0");
            myxy(4,20*curtitle);
            for(i=0;i<20;i++) outchr('�');
            for(i=0;i<numitems[curtitle];i++) {
                myxy(5+i,20*curtitle);
                npr("[47m %s%-18.18s[47m ",i==curitem?"[0;33;1m":"[47;37;1m",tgp[curtitle][i].desc);
            }
            outstr("1");
            myxy(5+numitems[curtitle],20*curtitle);
            for(i=0;i<20;i++) outchr('�');
        }
        if(draw==2) {
            myxy(5+curitem-1,20*curtitle);
            npr("[0;47;1m %-18.18s [0m",tgp[curtitle][curitem-1].desc);
            myxy(5+curitem,20*curtitle);
            npr("[47;33;1m [40m%-18.18s[47m [0m",tgp[curtitle][curitem].desc);
        }
        if(draw==3) {
            myxy(5+curitem+1,20*curtitle);
            npr("[0;37;47;1m %-18.18s [0m",tgp[curtitle][curitem+1].desc);
            myxy(5+curitem,20*curtitle);
            npr("[47;33;1m [40m%-18.18s[47m [0m",tgp[curtitle][curitem].desc);
        }
        temp[0]=0;
        temp[1]=0;
        temp[2]=0;
        switch(temp[0]=getkey()) {
            case 27: temp[1]=getkey();
                     temp[2]=getkey();
                     switch(temp[2]) {
                        case 'B': if(curitem<numitems[curtitle]-1) {
                                    curitem++;
                                    draw=2;
                                 }
                                 break;
                        case 'A': if(curitem>0) {
                                    curitem--;
                                    draw=3;
                                  }
                                  break;
                        case 'D': if(curtitle>0) {
                                    curtitle--;
                                    curitem=0;
                                    draw=1;
                                  }
                                  break;
                        case 'C':
                                if(curtitle<numtitles-1) {
                                    curtitle++;
                                    curitem=0;
                                    draw=1;
                                 }
                                 break;
                    }
                    break;
            case ';': break;
            case 13: return(tgp[curtitle][curitem].key);
            case '~': usepldns=0; done=1; break;
//            default: sprintf(s,"%c",toupper(temp[0])); return(s);
        }
    } while(!done&&!hangup);
    return "";
}

#endif

void menuman(void)
{
    char cmd,c,*s,x,begx;
    int i;
    menurec mm;

    nl();
    nl();

    tleft(1);

    if(usub[cursub].subnum==-1) cursub=0;
#ifdef USEPLDNS
    if(!usepldns)
#endif USEPLDNS
    switch(thisuser.res[1]) {
        case 0: break;
        case 2: showmenu(tg,pp,maxcmd);
        case 1: npr("5[0");
                for(i=0;i<maxcmd;i++)
                    if(tg[i].at!='P'&&tg[i].at!='T')
                        npr("%s,",avail[i]);
                backspace();
                npr("5]\r\n");
                break;
    }

    if(chatreason[0]&&chatsoundon) chatsound();
    memmove(s,0,40);
#ifdef USEPLDNS
    if(usepldns) s=pldn();
    else {
#endif
        outstr(pp.prompt);
        begx=wherex();
        cmd=0;
        if(umaxdirs>umaxsubs) cmd=1;
        s=mmkey(cmd);
#ifdef USEPLDNS
    }
#endif

    if(!s[0]) {
         for(cmd=0;cmd<maxcmd;cmd++)
            if(tg[cmd].at=='D')
              if(!ex(tg[cmd].type,tg[cmd].ms)) cmd=maxcmd;
    } else if((!strcmp(s,"AVAIL"))) {
        for(i=0;i<maxcmd;i++) if(slok(tg[i].key,1)) npr("2%s0,",avail[i]);
        backspace();
        nl();
    } else
    if((!strcmp(s,"HELP"))) printmenu(7); else
#ifdef USEPLDNS
    if((!strcmp(s,"PULL"))) usepldns=opp(usepldns); else
#endif
    if((!strcmp(s,"SPEED"))) npr("ComSpeed=%d, ModemSpeed=%d\r\n",com_speed,modem_speed); else
    if((!strcmp(s,"RELOAD"))) readmenu(nifty.firstmenu); else
    if((!strcmp(s,"VER"))) {
              nl();
              npr("%s, Compiled %s",wwiv_version,wwiv_date);
              nl();
    } else
    if((!strcmp(s,"GRAFIX"))) ex("OP","2"); else
    if((!strcmp(s,"CLS"))) outchr(12); else
    if(strstr(s,";")) {
        for(c=0;c<strlen(s);c++) {
            if(s[c]==',') s[c]=13;
        }
        s[strlen(s)]=13;
        strcpy(charbuffer,&s[0]);
         charbufferpointer = 1;
    } else
    if((!strcmp(s,get_string(37))) && cs()) {
        nl();
        npr("3Type\r\n5: ");
        mpl(2);
        input(mm.type,2);
        nl();
        npr("3MS\r\n5: ");
        mpl(40);
        inputl(mm.ms,40);
        ex(mm.type,mm.ms);
    } else
    if((!strcmp(s,"HANGUP"))) hangup=1; else
    if(s[0]=='?') { if(thisuser.res[1]!=2) { nl(); showmenu(tg,pp,maxcmd); } }
    else
    for(cmd=0;cmd<maxcmd;cmd++)
      if(!strcmp(tg[cmd].key,s)) {
        c=slok(tg[cmd].sl,0);
        if(c)
          if(c==2) { nl(); pl(get_string(40)); }
          else { while (wherex()>begx) backspace(); pl(tg[cmd].line); nl();
          if(!ex(tg[cmd].type,tg[cmd].ms)) cmd=maxcmd; }
        }
      else
      if(!strcmp(avail[cmd],"#")) {
        if(s[0]>=0 && s[0]<=MAX_SUBS) {
         if(tg[cmd].ms[0]=='M') {
            for(x=0; x<64; x++)
                if(!strcmp(usub[x].keys,s))
                    cursub=x;
         } else if(tg[cmd].ms[0]=='F') {
            for(x=0; x<64; x++)
                if(!strcmp(udir[x].keys,s))
                    curdir=x;
         }
       }
      }
  nl();
}
