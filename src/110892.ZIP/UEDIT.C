#include "vars.h"
#pragma hdrstop

#include <stdarg.h>

void print(char *msg, ...)
{
  va_list ap;
  char *str, str1[160];

  va_start(ap, msg);
  strcpy(str1, msg);
  str = va_arg(ap, char *);
  while (str[0]) {
    strcat(str1,str);
    str = va_arg(ap, char *);
  }
  va_end(ap);
  outstr(str1);
  nl();
}


void deluser(int un)
{
  userrec u;
  int i,i1,f,n;
  mailrec m;
  char fn[81];
  votingrec v;
  voting_response vr;

  read_user(un,&u);
  if ((u.inact & inact_deleted)==0) {
    rsm(un,&u);
    dsr(u.name);
    u.inact |= inact_deleted;
    u.waiting=0;
    write_user(un,&u);
    sprintf(fn,"%sEMAIL.DAT",syscfg.datadir);
    f=open(fn,O_RDWR | O_BINARY, S_IREAD | S_IWRITE);
    if (f>0) {
      i1=filelength(f)/sizeof(mailrec);
      for (i=0; i<i1; i++) {
        lseek(f,((long) i) * sizeof(mailrec), SEEK_SET);
        read(f,(void *)(&m),sizeof(mailrec));
        if (((m.tosys==0) && (m.touser==un)) ||
            ((m.fromsys==0) && (m.fromuser==un))) {
          delmail(f,i);
        }
      }
    }
    close(f);
    sprintf(fn,"%sVOTING.DAT",syscfg.datadir);
    f=open(fn,O_RDWR | O_BINARY, S_IREAD | S_IWRITE);
    n=(int) (filelength(f) / sizeof(votingrec)) -1;
    for (i=0; i<20; i++)
      if (u.votes[i]) {
        if (i<=n) {
          lseek(f,((long) i) * sizeof(votingrec), SEEK_SET);
          read(f,(void *)&v,sizeof(votingrec));
          vr=v.responses[u.votes[i]-1];
          vr.numresponses--;
          v.responses[u.votes[i]-1]=vr;
          lseek(f,((long) i) * sizeof(votingrec), SEEK_SET);
          write(f,(void *)&v,sizeof(votingrec));
        }
        u.votes[i]=0;
      }
    write_user(un,&u);
    close(f);
  }
}


void print_data(int un, userrec *u,int lng)
{
  char s[255],s1[81],s2[81],s3[81],s4[81];
  int i;

  outchr(12);

  strcpy(s,"");
  strcpy(s1,"");
  if ((u->inact) & inact_deleted) strcpy(s1,"0(6Deleted0)");
  if ((u->inact) & inact_lockedout) strcpy(s,"0(8Locked Out0)");
  npr("4[User #%d] %s %s",un,s1,s);
  nl();
  npr("31. Name    :0 %-27.27s",nam(u,un));
  npr("32. Realname:0 %s\r\n",u->realname);
  if(lng) {
    npr("33. Password:0 %-27.27s",u->pw);
    npr("34. Computer:0 %s\r\n",ctypes[u->comp_type]);
    npr("35. Address :0 %-27.27s",(u->street));
    npr("36. City    :0 %s\r\n",(u->city));
    npr("37. Fpts    :0 %-27d",u->fpts);
    npr("38. Phone   :0 %s\r\n",u->phone);
  }
  npr("39. SL      :0 %-27d",u->sl);
  npr("30. DSL     :0 %d\r\n",u->dsl);

  if(lng) {
    strcpy(s2,"");
    if(u->exempt & exempt_ratio) s[0]='R'; else s[0]=32;
    if(u->exempt & exempt_time) s[1]='T'; else s[1]=32;
    if(u->exempt & exempt_post) s[2]='P'; else s[2]=32;
    sprintf(s1,"%c%c%c",s[0],s[1],s[2]);
    npr("3A. Exempt  : 0%-27.27s",s1);
    npr("3B. SubOp   : 0%d\r\n",u->sysopsub);
  }
 
  npr("3C. Note    :0 %-27.27s",u->note);
  npr("3D. Comment :0 %.26s\r\n",u->comment);

  strcpy(s3,restrict_string);
  for (i=0; i<=15; i++) {
    if (u->ar & (1 << i)) s[i]='A'+i;
    else s[i]='a'+i;
    if (u->dar & (1 << i)) s1[i]='A'+i;
    else s1[i]='a'+i;
    if (u->restrict & (1 << i)) s2[i]=s3[i];
    else s2[i]='-';
  }
  s[16]=0;
  s1[16]=0;
  s2[16]=0;
  npr("3E. AR      :0 %-27.27s",s);
  npr("3F. DARs    :0 %s\r\n",s1);
  npr("3G. Restrict:0 %s\r\n",s2);

  if(lng) {
    npr("3H. Age     :0 %-27d",u->age);
    npr("3I. Sex     :0 %c\r\n",u->sex);
    npr("3Logon Rate :0 %d",u->lastrate);
    nl();
  }

  if(lng) {
    nl();
    npr("3Message Stats :0 Posts=%3d   Emails=%3d  FeedBack=%3d    Waiting=%d\r\n",u->msgpost,u->emailsent,u->feedbacksent,u->waiting);
    npr("3File Stats    :0  Uled=%3d     Dled=%3d       Upk=%3ldK    DownK=%ldK\r\n",u->uploaded,u->downloaded,u->uk,u->dk);
    npr("3Login Stats   :0 Calls=%3d    Today=%3d  Last On:%s   First On:%s\r\n",u->logons,u->ontoday,u->laston,u->firston);
    nl();
  }
}


/****************************************************************************/


#pragma warn -par

void uedit(int usern, int other)
{
  char s[81],s1[81],s2[81],ch,ch1;
  int i,i1,i2,i3,un,done,nu,done1,full,temp_full,tempu,top;
  userrec u;

  top=topline;
  topline=0;
  full=1;
  un=usern;
  done=0;
  read_user(un,&u);
  nu=(int) (filelength(userfile) / sizeof(userrec)) - 1;
  do {
    read_user(un,&u);
    done1=0;
    temp_full=0;
    do {
      if ((full) || (temp_full))
        print_data(un,&u,1);
      else
        print_data(un,&u,0);
      nl();
      prt(5,"User Editor (?=Help):0 ");
      if ((actsl==255) || (wfc))
        ch=onek("1234567890ABCDEFGHIJKLSUQ[],.?|:;^|_!-");
      else
        ch=onek("1234567890ABCDEFGHIUQ[],.?|^_-");
      switch(ch) {
        case ';': u.street[0]=0; write_user(un,&u); break;
        case '5': nl(); pl("Enter Street Address:");
                  outstr(": "); inputl(s,50);
                  if(s[0]) { strcpy(u.street,s);
                  write_user(un,&u); }
                  break;
        case '_': readform(nifty.nuinf,u.name); break;
        case '-': nl();
                  npr("3Which Infoform\r\n3: ");
                  mpl(8);
                  input(s,8);
                  if(s[0])
                    readform(s,u.name);
                  break;
        case '|':
        nl();
        outstr("3Set Access to which AutoVal Level?0 ");
        input(s,2);
        i=atoi(s);
        if(s[0]) {
            i--;
            u.sl=syscfg.autoval[i].sl;
            u.dsl=syscfg.autoval[i].dsl;
            u.ar=syscfg.autoval[i].ar;
            u.dar=syscfg.autoval[i].dar;
            u.restrict=syscfg.autoval[i].restrict;
            write_user(un,&u);
        }
        break;

        case 'Q':
          done=1;
          done1=1;
          topline=top;
          break;
        case '3':
          nl();
          prt(3,"New User Password?0 ");
          input(s,19);
          if(s[0]) {
            prt(5,"Are you sure? ");
            if(yn()) strcpy(u.pw,s); }
            write_user(un,&u);
            break;
        case ']':
          ++un;
          if (un>nu)
            un=1;
          done1=1;
          break;
        case '[':
          --un;
          if (un==0)
            un=nu;
          done1=1;
          break;
        case '.':
          full=(!full);
          temp_full=full;
          break;
        case ',':
          temp_full=(!temp_full);
          break;

        case '?':
          printmenu(6);
          getkey();
          break;

        case '^':
          if ((u.inact & inact_deleted)==0) {
            prt(5,"Delete? ");
            if (yn()) {
              deluser(un);
              read_user(un,&u);
            }
          } else
          if (u.inact & inact_deleted) {
            u.inact ^= inact_deleted;
            isr(un,u.name);
            write_user(un,&u);
          }
          break;

        case '!':
          if ((u.inact & inact_lockedout)==0) {
            prt(5,"Lock Out? ");
            if (yn()) {
              u.inact ^= inact_lockedout;
            write_user(un,&u);
            }
          } else
          if (u.inact & inact_lockedout) {
            u.inact ^= inact_lockedout;
            isr(un,u.name);
            write_user(un,&u);
          }
          break;

        case 'U':
          nl();
          prt(3,"User name/number:0 ");
          input(s,30);
          i=finduser1(s);
          if (i>0) {
            un=i;
            done1=1;
          }
          break;
        case '1':
          nl();
          prt(3,"New name? ");
          input(s,30);
          if (s[0]) {
              dsr(u.name);
              strcpy(u.name,s);
              isr(un,u.name);
              write_user(un,&u);
          }
          break;

        case '2':
          nl();
          prt(3,"New real name? ");
          inputl(s,20);
          if (s[0]) {
            strcpy(u.realname,s);
            write_user(un,&u);
          }
          break;
        case '6':
          nl();
          prt(3,"City: ");
          inputl(s,31);
          if (s[0]) {
            strcpy(u.city,s);
            write_user(un,&u);
          }
          break;
        case '8':
          nl();
          prt(3,"New phone number? ");
          input(s,12);
          if (s[0]) {
            strcpy(u.phone,s);
            write_user(un,&u);
          }
          break;
        case 'C':
          nl();
          prt(3,"New note? ");
          inputl(s,39);
          strcpy(u.note,s);
          write_user(un,&u);
          break;
        case 'D':
          nl();
          prt(3,"New Comment? ");
          inputl(s,39);
          strcpy(u.comment,s);
          write_user(un,&u);
          break;
        case 'H':
          nl();
          sprintf(s,"Current birthdate: %02d/%02d/%02d",(int) u.month,
	         (int) u.day,
                 (int) u.year);
          pl(s);
          input_age(&u);
          write_user(un,&u);
          break;
        case '4':
          nl();
          pl("Known computer types:");
          nl();
          for (i=0; ctypes[i]; i++)
            npr("%d. %s\r\n",i+1,ctypes[i]);
          nl();
          ansic(3);
          pl("Enter your computer type, or the closest to it.");
          prt(2,":");
          mpl(2);
          input(s,2);
          i2=atoi(s);
          i1=1;
          if ((i2<1) || (i2>i)) i1=0;
          if(i1) u.comp_type=i2-1;
          write_user(un,&u);
          break;
        case '7':
          nl();
          prt(3,"New Fpts? ");
          input(s,4);
          u.fpts=atoi(s);
          write_user(un,&u);
          break;

        case '9':

          nl();
          prt(3,"New SL? ");
          input(s,4);
          u.sl=atoi(s);
          write_user(un,&u);
          break;

        case '0':
          prt(3,"New DSL? ");
          input(s,4);
          i=atoi(s);
          u.dsl=i;
          write_user(un,&u);
          break;

        case 'A':
          i=0;
          do {
           nl();
           prt(3,"Toggle Which Exemption (R,T,P)? ");
           ch1=onek("RTPQ?");
           switch(ch1) {
            case 'R': if(u.exempt & exempt_ratio) u.exempt ^= exempt_ratio;
                      else u.exempt |= exempt_ratio; break;
            case 'T': if(u.exempt & exempt_time) u.exempt ^= exempt_time;
                      else u.exempt |= exempt_time; break;
            case 'P': if(u.exempt & exempt_post) u.exempt ^= exempt_post;
                      else u.exempt |= exempt_post; break;
            case 'Q': i=1; break;
            case '?': printmenu(17); break;
           }
           nl();
          } while(!i);
          write_user(un,&u);
          break;
        case 'B':
          nl();
          prt(3,"New sysop sub? ");
          input(s,3);
          i=atoi(s);
          if ((i>=0) && (i<=255) && (s[0])) {
            u.sysopsub=i;
            write_user(un,&u);
          }
          break;
        case 'G':
          nl();
          pl(restrict_string);
	  do {
            prt(3,"Toggle? ");
            s[0]=13;
	    s[1]='?';
            strcpy(&(s[2]),restrict_string);
            ch1=onek(s);
            if (ch1==32)
              ch1=13;
	    if (ch1=='?')
	      printmenu(10);
            if ((ch1!=13) && (ch1!='?')) {
              i=-1;
              for (i1=0; i1<16; i1++)
                if (ch1==s[i1+2])
                  i=i1;
              if (i>-1) {
                u.restrict ^= (1 << i);
                write_user(un,&u);
              }
            }
	  } while ((!hangup) && (ch1=='?'));
          break;
        case 'E':
          nl(); do {
          prt(3,"Toggle which AR? ");
          ch1=onek("\rABCDEFGHIJKLMNOPQ");
          if (ch1!=13&&ch1!='Q') {
            ch1-='A';
            if ((wfc) || (thisuser.ar & (1 << ch1))) {
              u.ar ^= (1 << ch1);
              write_user(un,&u);
            }
          } } while(ch1!='Q'&&!hangup);
          break;
        case 'F':
          nl(); do {
          prt(3,"Toggle which DAR? ");
          ch1=onek("\rABCDEFGHIJKLMNOPQ");
          if (ch1!=13&&ch1!='Q') {
            ch1-='A';
            if ((wfc) || (thisuser.dar & (1 << ch1))) {
              u.dar ^= (1 << ch1);
              write_user(un,&u);
            }
          } } while (ch1!='Q'&&!hangup);
          break;
        case '~':
          u.ass_pts=0;
          write_user(un,&u);
          break;
	case ':':
	  u.year=0;
	  write_user(un,&u);
	  break;
      }
    } while ((!done1) && (!hangup));
  } while ((!done) && (!hangup));
  close_user();
  if (!wfc)
    topscreen();
}

#pragma warn +par



