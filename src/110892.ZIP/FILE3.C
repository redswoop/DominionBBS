#include "vars.h"
#pragma hdrstop

#include <time.h>
#include <dir.h>

#define INDENTION 30
#define MAX_LINES 10
#define FSED_OK ((okfsed()) && (0))
#define CHECK_FOR_EXISTANCE



#define SETREC(i)  lseek(dlf,((long) (i))*((long)sizeof(uploadsrec)),SEEK_SET);

void move_file(int offline)
{
  char sx[81],s[81],s1[81],s2[81],ch,*ss;
  int i,i1,ok,d1,d2,done,cp;
  uploadsrec u,u1,u2;
  char *b;

  ok=0;
  nl();
  nl();
  if(!offline) {
  prt(2,"Filename to move: ");
  input(sx,12);
  } else strcpy(sx,"*.*");
  if (strchr(sx,'.')==NULL)
    strcat(sx,".*");
  align(sx);
  dliscan();
  i=recno(sx);
  if (i<0) {
    nl();
    pl("File not found.");
    closedl();
    return;
  }
  done=0;
  while ((!hangup) && (i>0) && (!done)) {
    cp=i;
    SETREC(i);
    read(dlf,(void *)&u,sizeof(uploadsrec));
    nl();
    strcpy(s,directories[udir[curdir].subnum].dpath);
    strcat(s,u.filename);
/**/    if((!exist(s)&&offline)||(!offline)) {
       printfileinfo(&u,udir[curdir].subnum,0,0);
       nl();
       prt(5,"Move this (Y/N/Q)? ");
       ch=onek("QNY");
       if (ch=='Q')
         done=1;
       if (ch=='Y') {
         strcpy(s1,directories[udir[curdir].subnum].dpath);
         strcat(s1,u.filename);
         d1=-1;
         /*
         do {
           nl();
           nl();
           prt(2,"To which directory? ");
           ss=mmkey(1);
           if (ss[0]=='?')
             dirlist('L');
         } while ((!hangup) && (ss[0]=='?'));
         if (ss[0])
           for (i1=0; (i1<64) && (udir[i1].subnum!=-1); i1++)
             if (strcmp(udir[i1].keys,ss)==0)
               d1=i1;
         */
         i1=dirlist(0);
         if(i1<64&&udir[i1].subnum!=-1)
             d1=i1;
         if (d1!=-1) {
           ok=1;
           d1=udir[d1].subnum;
           closedl();
           dliscan1(d1);
           if (recno(u.filename)>0) {
             ok=0;
             nl();
             pl("Filename already in use in that directory.");
           }
           if (numf>=directories[d1].maxfiles) {
             ok=0;
             nl();
             pl("Too many files in that directory.");
           }
           if (freek1(directories[d1].dpath)<((double)(u.numbytes/1024L)+3)) {
             ok=0;
             nl();
             pl("Not enough disk space to move it.");
           }
           closedl();
           dliscan();
         } else
           ok=0;
       } else
         ok=0;
       if (ok) {
         --cp;
         for (i1=i; i1<numf; i1++) {
           SETREC(i1+1);
           read(dlf,(void *)&u1,sizeof(uploadsrec));
           SETREC(i1);
           write(dlf,(void *)&u1,sizeof(uploadsrec));
         }
         --numf;
         u1.numbytes=numf;
         SETREC(0);
         write(dlf,(void *)&u1,sizeof(uploadsrec));
         ss=read_extended_description(u.filename);
         if (ss)
           delete_extended_description(u.filename);
         closedl();

         strcpy(s2,directories[d1].dpath);
         strcat(s2,u.filename);
         dliscan1(d1);
         for (i=numf; i>=1; i--) {
           SETREC(i);
           read(dlf,(void *)&u1,sizeof(uploadsrec));
           SETREC(i+1);
           write(dlf,(void *)&u1,sizeof(uploadsrec));
         }
         SETREC(1);
         write(dlf,(void *)&u,sizeof(uploadsrec));
         ++numf;
         u1.numbytes=numf;
         SETREC(0);
         write(dlf,(void *)&u1,sizeof(uploadsrec));
         if (ss) {
           add_extended_description(u.filename,ss);
           farfree(ss);
         }
         closedl();

         if ((strcmp(s1,s2)!=0) && (exist(s1))) {
           d2=0;
           if ((s1[1]!=':') && (s2[1]!=':'))
             d2=1;
           if ((s1[1]==':') && (s2[1]==':') && (s1[0]==s2[0]))
             d2=1;
           if (d2) {
             rename(s1,s2);
             unlink(s1);
           } else {
             if ((b=malloca(16400))==NULL)
               return;
             d1=open(s1,O_RDONLY | O_BINARY);
             d2=open(s2,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
             i=read(d1,(void *)b,16384);
             while (i>0) {
               write(d2,(void *)b,i);
               i=read(d1,(void *)b,16384);
             }
             close(d1);
             close(d2);
             unlink(s1);
             farfree(b);
           }
         }
         nl();
         pl("File moved.");
/**/        }
       } else
         closedl();
       dliscan();
       i=nrecno(sx,cp);

  }
  closedl();
}




int comparedl(uploadsrec *x, uploadsrec *y, int type)
{
  switch(type) {
    case 0:
      return(strcmp(x->filename,y->filename));
    case 1:
      if (x->daten < y->daten)
        return(-1);
      else
        if (x->daten > y->daten)
          return(1);
        else
          return(0);
    case 2:
      if (x->daten < y->daten)
        return(1);
      else
        if (x->daten > y->daten)
          return(-1);
        else
          return(0);
  }
  return(0);
}


void quicksort(int l,int r,int type)
{
  register int i,j;
  uploadsrec a,a2,x;

  i=l; j=r;
  SETREC(((l+r)/2));
  read(dlf, (void *)&x,sizeof(uploadsrec));
  do {
    SETREC(i);
    read(dlf, (void *)&a,sizeof(uploadsrec));
    while (comparedl(&a,&x,type)<0) {
      SETREC(++i);
      read(dlf, (void *)&a,sizeof(uploadsrec));
    }
    SETREC(j);
    read(dlf, (void *)&a2,sizeof(uploadsrec));
    while (comparedl(&a2,&x,type)>0) {
      SETREC(--j);
      read(dlf, (void *)&a2,sizeof(uploadsrec));
    }
    if (i<=j) {
      if (i!=j) {
        SETREC(i);
        write(dlf,(void *)&a2,sizeof(uploadsrec));
        SETREC(j);
        write(dlf,(void *)&a,sizeof(uploadsrec));
      }
      i++;
      j--;
    }
  } while (i<j);
  if (l<j)
    quicksort(l,j,type);
  if (i<r)
    quicksort(i,r,type);
}


void sortdir(int dn, int type)
{
  dliscan1(dn);
  if (numf>1)
    quicksort(1,numf,type);
  closedl();
}


void sort_all(int type)
{
  int i;

  for (i=0; (i<64) && (udir[i].subnum!=-1) && (!kbhitb()); i++) {
    nl();
    ansic(7);
    npr("Sorting 0%s",directories[udir[i].subnum].name);
    sortdir(i,type);
  }
}


void valfiles()
{
  char s[81],s1[81],s2[81],*ss,s3[81],ch;
  int i,cp,done;
  uploadsrec u;
  userrec uu;

  strcpy(s,"*.*");
  align(s);
  dliscan();
  done=0;
  strcpy(s3,s);
  i=recno(s);
  while (i>0&&!done) {
    cp=i;
    SETREC(i);
    read(dlf,(void *)&u,sizeof(uploadsrec));
    if(!u.ats[0]) {
    nl();
    nl();
    printfileinfo(&u,udir[curdir].subnum,0,0);
    outstr("7Validate 0(2Y/N/P/Q0)7? ");
    ch=onek("YNQP\r");
    switch(ch) {
        case 'P':
        case 'Y':
        case '\r': u.ats[0]=1;
                   if(ch=='P') {
                    nl();
                    outstr("Enter Points: ");
                    input(s2,5);
                    if(s2[0]) u.points=atoi(s2);
                    else u.points=((u.numbytes+1023)/10240);
                   } else u.points=((u.numbytes+1023)/10240);
                   SETREC(i);
                   write(dlf,(void *)&u,sizeof(uploadsrec));
                   read_user(u.ownerusr,&uu);
                   uu.fpts+=u.points;
                   write_user(u.ownerusr,&uu);
                   close_user();
                   break;
        case 'N': break;
        case 'Q': done=1; break;
      }
    }
    i=nrecno(s3,cp);
  }
  closedl();
}



void add_extended_description(char *fn, char *desc)
{
  ext_desc_type ed;

  strcpy(ed.name,fn);
  ed.len=strlen(desc);
  lseek(edlf,0L,SEEK_END);
  write(edlf,&ed,sizeof(ext_desc_type));
  write(edlf,desc,ed.len);
}


void delete_extended_description(char *fn)
{
  ext_desc_type ed;
  long r,w,l1;
  char *ss=NULL;

  r=w=0;
  if ((ss=malloca(10240L))==NULL)
    return;
  l1=filelength(edlf);
  while (r<l1) {
    lseek(edlf,r,SEEK_SET);
    read(edlf,&ed,sizeof(ext_desc_type));
    if (ed.len<10000) {
      read(edlf,ss,ed.len);
      if (strcmp(fn,ed.name)) {
        if (r!=w) {
          lseek(edlf,w,SEEK_SET);
          write(edlf,&ed,sizeof(ext_desc_type));
          write(edlf,ss,ed.len);
        }
        w +=(sizeof(ext_desc_type) + ed.len);
      }
    }
    r += (sizeof(ext_desc_type) + ed.len);
  }
  farfree(ss);
  chsize(edlf,w);
}


char *read_extended_description(char *fn)
{
  ext_desc_type ed;
  long l,l1;
  char *ss=NULL;

  l=0;
  l1=filelength(edlf);
  while (l<l1) {
    lseek(edlf,l,SEEK_SET);
    l += (long) read(edlf,&ed,sizeof(ext_desc_type));
    if (strcmp(fn,ed.name)==0) {
      ss=malloca((long) ed.len+10);
      if (ss) {
        read(edlf,ss,ed.len);
        ss[ed.len]=0;
      }
      return(ss);
    } else
      l += (long) ed.len;
  }
  return(NULL);
}



int print_extended(char *fn, int *abort, unsigned char numlist, int indent)
{
  char *ss;
  int next=0;
  unsigned char numl=0;
  int cpos=0;
  char ch,s[81];
  int i;

  ss=read_extended_description(fn);
  if (ss) {
    ch=10;
    while ((ss[cpos]) && (!(*abort)) && (numl<numlist)) {
      if ((ch==10) && (indent)) {
        if (okansi())
          sprintf(s,"\x1b[%dC",INDENTION);
        else {
          for (i=0; i<INDENTION; i++)
            s[i]=32;
          s[INDENTION]=0;
        }
        osan(s,abort,&next);
        ansic(2);
      }
      outchr(ch=ss[cpos++]);
      checka(abort,&next,0);
      if (ch==10)
        ++numl;
      else
        if ((ch!=13) && (wherex()>=78)) {
          osan("\r\n",abort,&next);
          ch=10;
        }
    }
    if (wherex())
      nl();
  }
  farfree(ss);
  return(numl);
}



void modify_extended_description(char **sss)
{
  char s[161],s1[161];
  int f,ii,i,i1,i2;

  if (*sss)
    ii=1;
  else
    ii=0;
  do {
    if (ii) {
      nl();
      if (FSED_OK)
        prt(5,"Modify the extended description? ");
      else
        prt(5,"Enter a new extended description? ");
      if (!yn())
        return;
    } else {
      nl();
      prt(5,"Enter an extended description? ");
      if (!yn())
        return;
    }
    if (FSED_OK) {
      sprintf(s,"%sEXTENDED.DSC", syscfg.tempdir);
      if (*sss) {
        f=open(s,O_RDWR | O_BINARY | O_CREAT | O_TRUNC, S_IREAD | S_IWRITE);
        write(f,*sss,strlen(*sss));
        close(f);
        farfree(*sss);
        *sss=NULL;
      } else
        unlink(s);
      i=thisuser.screenchars;
      if (thisuser.screenchars>(76-INDENTION))
        thisuser.screenchars=76-INDENTION;
      i1=external_edit("extended.dsc",syscfg.tempdir,(int) thisuser.defed-1,MAX_LINES);
      thisuser.screenchars=i;
      if (i1) {
        if ((*sss=malloca(10240))==NULL)
          return;
        f=open(s,O_RDWR | O_BINARY);
        read(f,*sss,(int) filelength(f));
        (*sss)[filelength(f)]=0;
        close(f);
      }
    } else {
      if (*sss)
        farfree(*sss);
      if ((*sss=malloca(10240))==NULL)
        return;
      *sss[0]=0;
      i=1;
      nl();
      sprintf(s,"Enter up to %d lines, %d chars each.",MAX_LINES,78-INDENTION);
      pl(s);
      nl();
      s[0]=0;
      i1=thisuser.screenchars;
      if (thisuser.screenchars>(76-INDENTION))
        thisuser.screenchars=76-INDENTION;
      do {
        ansic(2);
        npr("%d: ",i);
        ansic(0);
        s1[0]=0;
        inli(s1,s,90,1);
        i2=strlen(s1);
        if (i2 && (s1[i2-1]==1))
          s1[i2-1]=0;
        if (s1[0]) {
          strcat(s1,"\r\n");
          strcat(*sss,s1);
        }
      } while ((i++<10) && (s1[0]));
      thisuser.screenchars=i1;
      if (*sss[0]==0) {
        farfree(*sss);
        *sss=NULL;
      }
    }
    prt(5,"Is this what you want? ");
    i=!yn();
    if (i) {
      farfree(*sss);
      *sss=NULL;
    }
  } while (i);
}


int getbytes(FILE *dev) {
    int byte1;
    int byte2;
    int result;

    byte1 = getc(dev);
    byte2 = getc(dev);

    result = (byte2 << 8) | byte1;

    return result;

}


void addgif(char *fn, char *descript)
{
  int byte1, bits_per_pix,colors,i;
  unsigned int width;
  unsigned int height;
  FILE *in;
  char s[81];

  in = fopen (fn, "rb");
  for (i = 0; (i < 6); i++) s[i] = getc(in);
  s[6] = '\0';
  width = getbytes(in);
  height = getbytes(in);
  byte1 = getc(in);
  fclose(in);

  if((strcmp(s,"GIF87a")==0)||(strcmp(s,"GIF89a")==0));
  else {
    sprintf(s,"%s is not a GIF file, skipping",fn);
    sysoplog(s);
    return;
  }
  bits_per_pix = byte1 & 0x07;
  bits_per_pix++;
  colors = 1 << bits_per_pix;
  sprintf(s,"7(%dx%dx%-3d)0 %s",width,height,colors,descript);
  strcpy(descript,s);
  pl(s);
}

int finddup(char *fn,int quiet)
{
  int i,here,i1;
  uploadsrec u;

  here=0;
  if(!quiet)
  pl(get_string(54));
  nl();
  closedl();
  for (i=0; (i<num_dirs) && (!hangup);i++) {
    dliscan1(i);
    for(i1=1;i1<=numf;i1++) {
        SETREC(i1);
        read(dlf,&u,sizeof(uploadsrec));
        if(stricmp(u.filename,fn)==0)
            return 1;
    }
    closedl();
  }
  return(0);
}

