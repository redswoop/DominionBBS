#include "vars.h"
#pragma hdrstop
extern char menuat[15];


void arccommands(char type)
{
    switch(type) {
                case 'D': download_temp_arc("Temp",1); break;
                case 'V': list_temp_arc(); break;
                case 'A': add_temp_arc(); break;
                case 'R': del_temp(); break;
                case 'L': list_temp_dir(); break;
                case 'T': list_temp_text(); break;
                case 'E': temp_extract(); break;
    }
}

void amsgcommand(char type)
{
    switch(type) {
               case 'W': write_automessage(); break;
               case 'R': read_automessage(); break;
               case 'A': if(status.amsguser)
                            email(status.amsguser,0,0,status.amsganon);
                         break;
    }
}

void msgcommand(char type,char ms[40])
{
    int c,c1;
    unsigned long l;

    switch(type) {
            case 'Y': yourinfomsg(); break;
            case 'Q': nl();
                      prt(5,"Reset Message NewScan Pointers? ");
                      if (yn()) {
                        for (c=0; c<33; c++)
                            thisuser.qscnptr[c]=status.qscanptr-1L;
                        for (c=0; c<MAX_SUBS-32; c++)
                            thisuser.qscnptr2[c]=status.qscanptr-1L;
                      } break;
            case 'P': irt[0]=0; irt_name[0]=0;
                      post();
                      break;
            case 'E': irt[0]=0; irt_name[0]=0; smail(ms); break;
            case 'N': express=0; expressabort=0;
                      if(ms[0]=='G') {
                        sysoplog("5- 0Global Newscaned Message Areas");
                        nscan(0);
                      } else if (ms[0]=='C') {
                        qscan(cursub,0);
                        logpr("5- 0NewScaned Message Area 4%s",subboards[usub[cursub].subnum].name);
                      }
                      else if (!ms[0]) {
                        nl();
                        outstr("5Global Newscan (Y/n/0a5ll Conferences): ");
                        c=onek("\rYNA");
                        switch(c) {
                           case 'A': sysoplog("5- 0Global Newscanned All Message Areas in all Conferences");
                                     c1=curconf;
                                     for(c=0;c<num_conf;c++) {
                                        curconf=c;
                                        changedsl();
                                        nscan(0);
                                    }
                                    curconf=c1;
                                    break;
                           case 'Y':
                           case '\r': sysoplog("5- 0Global Newscaned Message Areas");
                                      nscan(0); break;
                           case 'N':  logpr("5- 0NewScaned Message Area 4%s",subboards[usub[cursub].subnum].name);
                                      qscan(cursub,0); break;
                        }
                      }
                      break;
            case 'R': remove_post(); break;
            case 'S': express=0; expressabort=0; scan2(); break;
            case 'M': if(thisuser.waiting>0) readmail();
                      else pl("You have no Mail waiting"); break;
            case 'F': find_subject(); break;
            case 'K': kill_old_email(); break;
            case 'A': maillist(); break;
            case 'U': upload_post(); break;
            case 'Z': express=1; expressabort=0; l=thisuser.sysstatus;
                      if (l & sysstatus_pause_on_page)
                      thisuser.sysstatus ^= sysstatus_pause_on_page;
                      nscan(0); express=0; expressabort=0; thisuser.sysstatus=l;
                      break;
            case '!': iscan(cursub);
                      if(msgr<=nummsgs&&curlsub>=0) {
                        read_message(msgr,&c,&c);
                        msgr++;
                      }
       }
}

void othercmd(char type,char ms[40])
{
    int i;
    char c,s[81];

          switch(type)
          {
            case ';': for(c=0;c<strlen(ms);c++) {
                            if(ms[c]==';') ms[c]=13;
                       }
                      ms[strlen(ms)+1]=13;
                      strcpy(charbuffer,&ms[0]);
                      charbufferpointer = 1;
                      break;
            case '1': oneliner(); break;
            case 'G': logpr("7* 0Took InfoForm 4%s",ms);
                      infoform(ms); break;
            case 'R': sysoplog("Read Infoforms");
                      pl("Which User's responses do you want to see?");
                      outstr(": ");
                      input(s,31);
                      if(s[0]) readform(ms,s); break;
            case 'C': if(!(nifty.nifstatus & nif_chattype)) reqchat(ms);
                      else reqchat1(ms); break;
            case 'U': sysoplog("5�> Listed Users");
                      list_users(); break;
            case 'L': pl(ms); break;
            case 'F': printfile(ms); break;
            case 'I': nl();
                      npr("%s, Compiled %s",wwiv_version,wwiv_date);
                      nl();
                      pausescr();
                      printfile("SYSTEM");
                      pausescr();
                      break;
           case 'O':  if (sysop2()) pl(get_string(4));
                      else pl(get_string(5));
                      break;
           case 'V':  vote(); break;
           case 'Y':  yourinfo(); break;
           case '|':  addsay(); break;
           case 'S':  get_say(1); break;
           case '\\': searchrum(); break;
           case 'T':  bank2(atoi(ms)); break;
           case 'P':
                 switch(ms[0]) {
                   case '1': input_screensize(); break;
                   case '2': input_ansistat(); break;
                   case '3': if (thisuser.sysstatus & sysstatus_pause_on_page)
                              thisuser.sysstatus ^= sysstatus_pause_on_page;
                             prt(5,"Pause each screenfull? ");
                             if (yn()) thisuser.sysstatus |= sysstatus_pause_on_page;
                             break;
                   case '4': modify_mailbox(); break;
                   case '5': config_qscan(0); break;
                   case '6': input_pw1(); break;
                   case '7': make_macros(); break;
                   case '8': break;
                   case '9': select_editor(); break;
                   case 'A': pl("Enter your Default Protocol, 0 for none.");
                             i=get_protocol(1,1); if(i>=0||i==-2) thisuser.defprot=i;
                             break;
                   case 'C': selecthelplevel(); break;
                   case 'D': getfileformat(); break;
                   case 'E': config_qscan(1); break;
                   case 'F': print_cur_stat(); break;
                   case 'G': change_colors(&thisuser);  break;
                   case 'H': pl("3Enter your Comment:");
                             mpl(39); inputl(s,39);
                             if(s[0]) strcpy(thisuser.comment,s);
                             break;
                   case 'J': npr("\r\n3%sgaging Hotkey input\r\n",thisuser.sysstatus & sysstatus_fullline? "En": "Dis");
                             if(thisuser.sysstatus & sysstatus_fullline)
                             thisuser.sysstatus ^= sysstatus_fullline;
                             else thisuser.sysstatus |= sysstatus_fullline;
                             nl();
                             break;
            }
         }
}

void hangupcmd(char type,char ms[40])
{
          switch(type) {
            case 'H': hangup=1; break;
            case 'A':
            case 'L':
            case 'C': nl();
                      outstr(ms);
                      if(yn()) {
                          if(type=='C'||type=='L') {
                              outstr("5Leave Feedback to SysOp? ");
                              if(yn()) {
                                  strcpy(irt,"LogOff Feedback.");
                                  nmail(1,0);
                              }
                              nl();
                              if(type=='L') {
                                  outstr("5Leave Message to Next User? ");
                                  if(yn()) {
                                      amsgcommand('W');
                                  }
                              }
                          }
                          printfile("logoff");
                          hangup=1;
                      }
                      break;
          }
}

void sysopcmd(char type,char ms[41])
{
          switch(type)
          {
            case 'D': minidos(); break;
            case 'B': sysoplog("5@0 Ran Board Edit");
                      boardedit(); break;
            case '-': glocolor(); break;
            case 'P': sysoplog("5@0 Ran SysCfgEdit");
                      config(); break;
            case 'F': sysoplog("5@0 Ran Dir Edit");
                      diredit(); break;
            case 'M': sysoplog("5@0 Read All Mail");
                      mailr(); break;
            case 'H': sysoplog("5@0 Changed Users");
                      chuser(); break;
            case 'C': pl(((*(char far *)0x00000417L ^= 0x10) & 0x10) ?
                     "Sysop now unavailable" : "Sysop now available");
                      sysoplog("5@0 Changed sysop avail status");
                      topscreen();
                      break;
           case 'I': voteprint(); break;
           case 'U': sysoplog("5@ 0Ran User Editor");
                     uedit(1,0); break;
           case 'V': sysoplog("5@ 0Editing Voting");
                     ivotes(); break;
           case 'Z': zlog(); break;
           case 'E': sysoplog("5@ 0Edited Strings");
                     if(ms[0]) edstring(atoi(ms));
                     else edstring(0); break;
           case 'R': reset_files(); break;
           case 'X': sysoplog("5@ 0Ran Protocol Editor");
                     protedit(); break;
           case 'L': sysoplog("5@ 0Ran Conference Editor");
                     confedit(); break;
           case 'T': text_edit(); break;
           case 'O': viewlog(); break;
           case '#': sysoplog("5@ 0Ran Menu Editor");
                     if(ms[0]=='!') menued(menuat);
                     else menu("");
                     break;
        }
}
