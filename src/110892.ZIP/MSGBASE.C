#include "vars.h"

#pragma hdrstop

#include <mem.h>

char commstr[41];
extern char MCISTR[161];

#define ALLOW_FULLSCREEN 1
#define EMAIL_STORAGE 2

/****************************************************************************/

void showmsgheader(char a,char title[81],char name[41],char date[41],char to[41],int reading, int nummsgs,char comment[51],char subnum);

int open_file(char *fn)
{
  int f,i;
  char s[81];

  sprintf(s,"%s%s.DAT",syscfg.msgsdir,fn);
  f=open(s,O_RDWR | O_BINARY);
  if (f<0) {
    f=open(s,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
    for (i=0; i<2048; i++)
      gat[i]=0;
    write(f,(void *)gat,4096);
    strcpy(gatfn,fn);
    //chsize(f,4096L + (75L * 1024L));
    gat_section=0;
  }
  if (strcmp(gatfn,fn)) {
    lseek(f,0L,SEEK_SET);
    read(f,(void *)gat,4096);
    strcpy(gatfn,fn);
    gat_section=0;
  }
  return(f);
}

#define GATSECLEN (4096L+2048L*512L)
#define MSG_STARTING (((long)gat_section)*GATSECLEN + 4096)


void set_gat_section(int f, int section)
{
  long l,l1;
  int i;

  if (gat_section!=section) {
    l=filelength(f);
    l1=((long)section)*GATSECLEN;
    if (l<l1) {
      chsize(f,l1);
      l=l1;
    }
    lseek(f,l1,SEEK_SET);
    if (l<(l1+4096)) {
      for (i=0; i<2048; i++)
        gat[i]=0;
      write(f,(void *)gat, 4096);
    } else {
      read(f,(void *)gat, 4096);
    }
    gat_section=section;
  }
}

void save_gat(int f)
{
  long l;

  l=((long)gat_section)*GATSECLEN;
  lseek(f,l,SEEK_SET);
  write(f,(void *)gat,4096);
}


void savefile(char *b, long l1, messagerec *m1, char *aux)
{
  int f,gatp,i5,i4,gati[128],section;
  messagerec m;
  char s[81],s1[81];
  long l2;

  m=*m1;
  switch(m.storage_type) {
    case 0:
    case 1:
      m.stored_as=status.qscanptr++;
      save_status();
      ltoa(m.stored_as,s1,16);
      strcpy(s,syscfg.msgsdir);
      if (m.storage_type==1) {
        strcat(s,aux);
        strcat(s,"\\");
      }
      strcat(s,s1);
      f=open(s,O_RDWR | O_CREAT | O_BINARY,S_IREAD | S_IWRITE);
      write(f, (void *)b,l1);
      close(f);
      break;
    case 2:
      f=open_file(aux);
      for (section=0; section<100; section++) {
        set_gat_section(f,section);
        gatp=0;
        i5=(int) ((l1 + 511L)/512L);
        i4=1;
        while ((gatp<i5) && (i4<2048)) {
          if (gat[i4]==0)
            gati[gatp++]=i4;
          ++i4;
        }
        if (gatp>=i5) {
          l2=MSG_STARTING;
          gati[gatp]=-1;
          for (i4=0; i4<i5; i4++) {
            lseek(f,l2 + 512L * (long)(gati[i4]),SEEK_SET);
            write(f,(void *)(&b[i4*512]),512);
            gat[gati[i4]]=gati[i4+1];
          }
          save_gat(f);
          break;
        }
      }
      close(f);
      m.stored_as=(long) gati[0] + gat_section*2048;
      break;
    case 3:
      m.stored_as=status.qscanptr++;
      save_status();
      sprintf(s,"%s%s",syscfg.gfilesdir,aux);
      f=open(s,O_RDWR | O_CREAT | O_BINARY,S_IREAD | S_IWRITE);
      write(f, (void *)b,l1);
      close(f);
      break;

    case 255:
      f=open(aux,O_RDWR | O_CREAT | O_BINARY,S_IREAD | S_IWRITE);
      write(f, (void *)b,l1);
      close(f);
      break;
    default:
      sprintf(s,"Illegal storage type of %u on save!",m.storage_type);
      pl(s);
      break;
  }
  farfree((void *)b);
  *m1=m;
}


char *readfile(messagerec *m1, char *aux, long *l)
{
  int f,i,i1,csec;
  long l1,l2;
  char *b,s[81],s1[81];
  messagerec m;

  *l=0L;
  m=*m1;
  switch(m.storage_type) {
    case 0:
    case 1:
      strcpy(s,syscfg.msgsdir);
      ltoa(m.stored_as,s1,16);
      if (m.storage_type==1) {
        strcat(s,aux);
        strcat(s,"\\");
      }
      strcat(s,s1);
      f=open(s,O_RDONLY | O_BINARY);
      if (f==-1) {
	*l=0L;
        return(NULL);
      }
      l1=filelength(f);
      if ((b=malloca(l1))==NULL) {
        close(f);
        return(NULL);
      }
      read(f,(void *)b,l1);
      close(f);
      *l=l1;
      break;
    case 3:
      sprintf(s,"%s%s",syscfg.gfilesdir,aux);
      f=open(s,O_RDONLY | O_BINARY);
      if (f==-1) {
    *l=0L;
        return(NULL);
      }
      l1=filelength(f);
      if ((b=malloca(l1))==NULL) {
        close(f);
        return(NULL);
      }
      read(f,(void *)b,l1);
      close(f);
      *l=l1;
      break;

    case 2:
      f=open_file(aux);
      set_gat_section(f,m.stored_as/2048);
      csec=m.stored_as % 2048;
      l1=0;
      while ((csec>0) && (csec<2048)) {
	l1+=512L;
	csec=gat[csec];
      }
      if (!l1) {
        nl();
        pl("No message found.");
        nl();
        close(f);
        return(NULL);
      }
      if ((b=malloca(l1))==NULL) {
        close(f);
        return(NULL);
      }
      csec=m.stored_as % 2048;
      l1=0;
      l2=MSG_STARTING;
      while ((csec>0) && (csec<2048)) {
        lseek(f,l2 + 512L*csec,SEEK_SET);
        l1+=(long)read(f,(void *)(&(b[l1])),512);
	csec=gat[csec];
      }
      close(f);
      l2=l1-512;
      while ((l2<l1) && (b[l2]!=26)) {
      ++l2;
      }
      *l=l2;
      break;
    case 255:
      f=open(aux,O_RDONLY | O_BINARY);
      if (f==-1) {
	*l=0L;
        return(NULL);
      }
      l1=filelength(f);
      if ((b=malloca(l1+256L))==NULL) {
        close(f);
        return(NULL);
      }
      read(f,(void *)b,l1);
      close(f);
      *l=l1;
      break;
    default:
      /* illegal storage type */
      *l=0L;
      b=NULL;
      break;
  }
  return(b);
}

#define LEN 161

int ttchk(char *ttl)
{
  int reval,abort,ct;
  char s[81],s1[81];

    ct=0;
    reval=0;
    abort=0;
    strcpy(s,ttl);
    while ((!abort) && (!hangup) && (ct<nummsgs)) {
    ++ct;
    strcpy(s1,msgs[ct].title);
    if (strncmp(s,s1,60)==0) {
      nl();
      nl();
      prt(2,"Sorry, that title is already in use. Please use a different one.");
      nl();

      reval=1;
      abort=1;
     }
   }
   return(reval);
}

int checkreply()
{
  char s1[20];

  strncpy(s1,irt,9);
  if (strncmp(s1,"5RE: 3",8) ==0) {
   return(1);
 } else {
   return(0);
  }
}

int inmsg(messagerec *m1, char *title, int *anony, int needtitle, char *aux, int fsed)
{
  char s[LEN],s1[LEN],s2[LEN],ro[81],fnx[81],chx,*ss,*ss1,to[81];
  int maxli,curli,done,save,savel,i,i1,i2,i3,i4,i5,f,setanon,result;
  messagerec m;
  long ll,l1;
  char *lin, *b;
  int real_name=0;

  if ((fsed!=0) && (!okfsed()))
    fsed=0;
  sprintf(fnx,"%sINPUT.MSG",syscfg.tempdir);
  if (fsed)
    fsed=1;
  if (use_workspace) {
    if (!exist(fnx))
      use_workspace=0;
    else
      fsed=2;
  }
  done=0;
  setanon=0;
  save=0;
  curli=0;
  m=*m1;
  if (actsl<45)
    maxli=30;
  else
    if (actsl<60)
      maxli=50;
    else
      if (actsl<80)
        maxli=60;
      else
        maxli=80;
  if (!fsed) {
    if ((lin=malloca((long)(maxli+10)*LEN))==NULL) {
      m1->stored_as=0xffffffff;
      return 0;
    }
    for (i=0; i<maxli; i++)
      lin[i*LEN]=0;
    ro[0]=0;
  }

  if(m1->storage_type!=3) {
      nl();

      thatpoint:

      if(!irt[0]) {
        prt(5,"Title: ");
        mpl(60);
        inputl(title,60);
        if(ttchk(title)) goto thatpoint;

        if ((title[0]==0) && (needtitle)) {
          pl("Aborted.");
          m.stored_as=0xffffffff;
          *m1=m;
          if (!fsed)
            farfree((void *)lin);
          return 0;
        }
      } else {
        if(checkreply()||fidotoss) strcpy(title,irt);
        else sprintf(title,"5RE: 3%s",irt);
      }

      if(!irt_name[0]&&strcmp(aux,"EMAIL")) {
        nl();
        outstr("5To   : ");
        mpl(41);
        inputl(to,41);
        if(!to[0]) strcpy(to,"All");
      } else if(irt_name[0]) {
        strcpy(to,irt_name);
      }
  }

  if (!fsed) {
    nl();
    pl(get_string(11));
    pl(get_string(12));
    pl(get_string(41));

    while (!done && !hangup) {

      while((result=ainli(s,ro,160,1,1,curli?1:0))>0) {
            --curli;
            strcpy(ro,&(lin[(curli)*LEN]));
            if(strlen(ro)>thisuser.screenchars-1)
               ro[thisuser.screenchars-2]=0;
      }


      if(result==-1) strcpy(s,"/S");
      if(result==-2) strcpy(s,"/A");
      if(result==-3) strcpy(s,"/L");
      if(result==-4) strcpy(s,"/C");
      if(result==-5) strcpy(s,"/Q");
      if(result==-6) strcpy(s,"/M");

      if (hangup) done=1;
      savel=1;
      if (s[0]=='/') {
        if (stricmp(s,"/Q")==0) {
          savel=0;
          if (quote!=NULL)
            get_quote(0);
        }
        if (!stricmp(s,"/M")) {
            savel=0;
            printmenu(15);
        }
        if (stricmp(s,"/?")==0) {
          savel=0;
          printmenu(2);
        }
        if (stricmp(s,"/L")==0) {
          savel=0;
          prt(5,"With line numbers? ");
          i1=yn();
          i2=0;
          for (i=0; (i<curli) && (!i2); i++) {
            if (i1)
              npr("%d:\r\n",i+1);
            strcpy(s1,&(lin[i*LEN]));
            i3=strlen(s1);
            if (s1[i3-1]==1)
              s1[i3-1]=0;
            if (s1[0]==2) {
              strcpy(s1,&(s1[1]));
              i5=0;
              for(i4=0; i4<strlen(s1); i4++)
                if ((s1[i4]==8) || (s1[i4]==3))
                  --i5;
                else
                  ++i5;
              for (i4=0; (i4<(thisuser.screenchars-i5)/2) && (!i2); i4++)
                osan(" ",&i2,&i1);
            }
            pla(s1,&i2);
          }
          nl();
          pl("Continue...");
        }
        if (!stricmp(s,"/S")) {
          save=1;
          done=1;
          savel=0;
        }
        if (stricmp(s,"/A")==0) {
          done=1;
          savel=0;
        }
        if (stricmp(s,"/C")==0) {
          savel=0;
          curli=0;
          pl("Message cleared... Start over...");
          nl();
        }
        if (stricmp(s,"/T")==0) {
          savel=0;
          prt(2,"Title: ");
          mpl(60);
          inputl(title,60);
          pl("Continue...");
          nl();
        }
        strcpy(s1,s);
        s1[3]=0;
        if (stricmp(s1,"/C:")==0) {
          s1[0]=2;
          strcpy((&s1[1]),&(s[3]));
          strcpy(s,s1);
        }

	if ((stricmp(s1,"/SU")==0) && (s[3]=='/') && (curli)) {
	  strcpy(s1,&(s[4]));
          ss=strstr(s1,"/");
          if (ss) {
            ss1=&(ss[1]);
            ss[0]=0;
            stuff(&(lin[(curli-1)*LEN]),s1,ss1);
            pl("Last line:");
            pl(&(lin[(curli-1)*LEN]));
            pl("Continue...");
          }
          savel=0;
	}
      }
      if (savel) {
        strcpy(&(lin[(curli++)*LEN]),s);
        if (curli==(maxli+1)) {
          nl();
          pl("No more lines... Please Save or back up.");
          nl();
          --curli;
        } else if (curli==maxli) {
          pl("� Message limit reached, /S to save �");
        } else if ((curli+5)==maxli) {
          pl("�> 5 lines left <�");
        }
      }
    }
    if (curli==0)
      save=0;
  } else {
    if (fsed==1) {
      save=external_edit("INPUT.MSG",syscfg.tempdir,(int) (thisuser.defed)-1,maxli);
    } else {
      save=exist(fnx);
      if (save) {
        pl("Reading in file...");
      }
      use_workspace=0;
    }
  }


  if (save) {
    switch(*anony) {
      case 0:
        *anony=0;
        break;
      case anony_enable_anony:
        if (setanon) {
          if (setanon==1)
            *anony=anony_sender;
          else
            *anony=0;
        } else {
          prt(5,"Anonymous? ");
          if (yn())
            *anony=anony_sender;
          else
            *anony=0;
        }
        break;
      case anony_force_anony:
        *anony=anony_sender;
        break;
      case anony_real_name:
        real_name=1;
        *anony=0;
        break;
    }
    outstr("Saving...");
    if (fsed) {
      i5=open(fnx,O_RDONLY | O_BINARY);
      l1=filelength(i5);
    } else {
      l1=0;
      for (i5=0; i5<curli; i5++) {
	l1 += strlen(&(lin[i5*LEN]));
	l1 += 2;
      }
    }
    l1 += 1024;
    if ((b=malloca(l1))==NULL) {
      farfree(lin);
      pl("Out of memory.");
      m1->stored_as=0xffffffff;
      return 0;
    }

    l1=0;
    if(fidotoss) addline(b,irt_from,&l1);
    else {
        if (real_name)
          addline(b,thisuser.realname,&l1);
        else
          addline(b,nam1(&thisuser,usernum,syscfg.systemnumber),&l1);
    }
    if(m1->storage_type!=3) {
      time(&ll);
      strcpy(s,ctime(&ll));
      s[strlen(s)-1]=0;
      addline(b,s,&l1);
      strcpy(s,"�");
      strcat(s,to);
      addline(b,s,&l1);
    }

    if (fsed) {
      ll=filelength(i5);
      read(i5, (void *) (& (b[l1]) ),ll);
      l1 += ll;
      close(i5);
    } else {
      for (i5=0; i5<curli; i5++)
	addline(b,&(lin[i5*LEN]),&l1);
    }
    if (b[l1-1]!=26)
      b[l1++]=26;
    savefile(b,l1,&m,aux);
    if (fsed)
      unlink(fnx);
  } else {
    if (fsed)
      unlink(fnx);
    pl("Aborted.");
    m.stored_as=0xffffffff;
  }
  *m1=m;
  if (!fsed) {
    farfree((void *)lin);
  }
  charbufferpointer=0;
  charbuffer[0]=0;
  return save;
}


void email(unsigned short un, unsigned short sy, int forceit, int anony)
{
  int i,i1,f,len,an;
  messagerec msg;
  char s[81],s1[81],s2[81],t[81],*b,*b1;
  userrec ur;
  slrec ss;
  long len1;
  float fl;
  unsigned int ui;
  net_system_list_rec *csne;


  if (freek1(syscfg.msgsdir)<10.0) {
    nl();
    pl("Sorry, not enough disk space left.");
    nl();
    return;
  }
  nl();
  sprintf(s,"%sEMAIL.DAT",syscfg.datadir);
  ss=syscfg.sl[actsl];
  if (forwardm(&un,&sy)) {
    nl();
    pl("Mail Forwarded.");
    nl();
    if ((un==0) && (sy==0)) {
      pl("Forwarded to unknown user.");
      return;
    }
  }
  if (!un && !sy)
    return;
  if (!ok_to_mail(un, sy, forceit))
    return;
  if (sy)
    csne=next_system(sy);
  if (ss.ability & ability_read_email_anony)
    an=1;
  else
    if (anony & (anony_sender | anony_sender_da | anony_sender_pp))
      an=0;
    else
      an=1;
  if (sy==0) {
    if (an) {
      read_user(un,&ur);
      strcpy(s2,nam(&ur,un));
    } else
      strcpy(s2,">UNKNOWN<");
  } else {
    if (un==0)
      sprintf(s2,"%s @%u",net_email_name,sy);
    else
      sprintf(s2,"User %u @%u",un,sy);
  }
  npr("E-mailing %s\r\n",s2);
  if (ss.ability & ability_email_anony)
    i=anony_enable_anony;
  else
    i=0;
  if (anony & (anony_receiver_pp | anony_receiver_da))
    i=anony_enable_dear_abby;
  if (anony & anony_receiver)
    i=anony_enable_anony;
  if ((i==anony_enable_anony) && (thisuser.restrict & restrict_anony))
    i=0;
  if (sy!=0) {
    i=0;
    anony=0;
    nl();
    sprintf(s,"Name of system: '%s'",csne -> name);
    pl(s);
    sprintf(s,"Number of hops: %u",csne->numhops);
    pl(s);
    nl();
  }
  msg.storage_type=EMAIL_STORAGE;
  strcpy(irt_name,nam(&ur,un));
  upload_post();
  inmsg(&msg,t,&i,!forceit,"EMAIL",ALLOW_FULLSCREEN);
  if (msg.stored_as==0xffffffff)
    return;
  if (anony & anony_sender)
    i|=anony_receiver;
  if (anony & anony_sender_da)
    i|=anony_receiver_da;
  if (anony & anony_sender_pp)
    i|=anony_receiver_pp;

  sendout_email(t, &msg, i, un, sy, an);
}


void imail(unsigned short u, unsigned short s)
{
  char s1[81],s2[81];
  int i;
  userrec ur;

  if (forwardm(&u,&s))
    pl("Mail forwarded.");

  if (!u && !s)
    return;

  i=1;
  if (s==0) {
    read_user(u,&ur);
    if ((ur.inact & inact_deleted)==0) {
      sprintf(s1,"E-mail %s? ",nam(&ur,u));
      prt(5,s1);
      if (yn()==0)
        i=0;
    } else
      i=0;
  } else {
    sprintf(s1,"E-mail User %u @%u ? ",u,s);
    prt(5,s1);
    if (yn()==0)
      i=0;
  }
  if (i)
    email(u,s,0,0);
}


void iscan(int b)
{
  int f;
  char s[81];

  if (usub[b].subnum==curlsub)
    return;
  curlsub=usub[b].subnum;
  bchanged=0;
  nummsgs=0;
  if (curlsub<0)
    return;

  sprintf(s,"%s%s.SUB",syscfg.datadir,subboards[curlsub].filename);
  f=open(s,O_BINARY | O_RDWR);
  if (f==-1) {
    f=open(s,O_BINARY | O_RDWR | O_CREAT,S_IREAD | S_IWRITE);
    msgs[0].owneruser=0;
    write(f,(void *) (&msgs[0]),sizeof(postrec));
  }
  lseek(f,0L,SEEK_SET);
  nummsgs=(read(f,(void *) (&msgs[0]),255*sizeof(postrec)) / sizeof(postrec))-1;
  nummsgs=msgs[0].owneruser;
  if (nummsgs) {
    sub_dates[curlsub]=msgs[nummsgs].qscan;
  } else {
    sub_dates[curlsub]=1;
  }
  close(f);
}

void iscan_hash(int b)
{
  int f,nm;
  char s[81];
  postrec msg;

  if ((b>=num_subs) || (sub_dates[b]))
    return;

  sprintf(s,"%s%s.SUB",syscfg.datadir,subboards[b].filename);
  f=open(s,O_BINARY | O_RDWR);
  if (f==-1) {
    sub_dates[b]=1;
    return;
  }
  lseek(f,0L,SEEK_SET);
  read(f,&msg,sizeof(postrec));
  nm=msg.owneruser;
  if (nm>0) {
    lseek(f,nm*sizeof(postrec),SEEK_SET);
    read(f,&msg,sizeof(postrec));
    sub_dates[b]=msg.qscan;
  } else {
    sub_dates[b]=1;
  }
  close(f);
}


void savebase()
{
  int f;
  char s[81];

  if (bchanged==0)
    return;


  sprintf(s,"%s%s.SUB",syscfg.datadir,subboards[curlsub].filename);
  f=open(s,O_BINARY | O_RDWR);
  lseek(f,0L,SEEK_SET);
  msgs[0].owneruser=nummsgs;
  write(f,(void *) (&msgs[0]), ((nummsgs+1) * sizeof(postrec)));
  close(f);
  bchanged=0;
  if (nummsgs) {
    sub_dates[curlsub]=msgs[nummsgs].qscan;
  } else {
    sub_dates[curlsub]=1;
  }
}


void plan(char *s, int *abort, int *next)
{
  int i;

  i=0;
  checkhangup();
  if (hangup)
    *abort=1;
  checka(abort,next,0);
  while ((s[i]) && (!(*abort))) {
    outchr(s[i++]);
    checka(abort,next,0);
  }
  if (!(*abort))
    nl();
}


#define buf_size 512

void read_message1(messagerec *m1, char an, int readit, int *next,
       char *fn,int filter,char tit[81],int reading,char to1[61])
{
  char n[81],d[81],s[161],s1[81],s2[81],s3[81],*sss,*ss,ch,to[61];
  int f,abort,done,end,cur,p,p1,p2,printit,ctrla,centre,i,i1,ansi,ctrld;
  char a,a1,a2;
  messagerec m;
  char *buf;
  long csec,len,l1,l2;

  if ((buf=malloca(buf_size))==NULL)
    return;
  ss=NULL;
  ansi=0;
  m=*m1;
  *next=0;
  f=-1;
  done=0;
  cur=0;
  end=0;
  abort=0;
  ctrld=0;
  if(filter);
  switch(m.storage_type) {
    case 0:
    case 1:
    case 2:
    case 3:
      ss=readfile(&m,fn,&len);
      if (m.storage_type<2) {
        strcpy(s,syscfg.msgsdir);
        ltoa(m.stored_as,s1,16);
        if (m.storage_type==1) {
      strcat(s,fn);
          strcat(s,"\\");
        }
        strcat(s,s1);
        strcpy(s2,"FN  : ");
        strcat(s2,s1);
        if (so())
          pl(s2);
        else {
          strcat(s2,"\r\n");
          outs(s2);
        }
      }
      if (ss==NULL) {
        plan("File Not Found.",&abort,next);
        nl();
    farfree(buf);
        return;
      }

      p=0;
      while ((ss[p]!=13) && ((long)p<len) && (p<60))
        n[p]=ss[p++];
      n[p]=0;
      ++p;

      p1=0;
      if(m.storage_type==3) {
       cur=p+1;
       p1=-1;
      }

      if(p1==-1) break;

      if (ss[p]==10) ++p;

      while ((ss[p+p1]!=13) && ((long)p+p1<len) && (p1<60))
    d[p1]=ss[(p1++)+p];
      d[p1]=0;
      p1+=2;

      p2=0;

      while ((ss[p+p1+p2]!=13) && ((long)p+p1+p2<len) && (p2<60))
    to[p2]=ss[(p2++)+p1+p];
      to[p2]=0;
      if(!strchr(to,'�')) {
    strcpy(to,"All");
    cur=p+p1;

      } else { strcpy(to,to+1); cur=p+p1+p2; }

      break;
    case 255:
      strcpy(s,fn);
      f=open(s,O_RDONLY | O_BINARY);
      if (f==-1) {
    plan("File Not Found.",&abort,next);
    nl();
    farfree(buf);
    return;
      }
      lseek(f,m.stored_as,SEEK_SET);
      end=read(f,(void *)buf,buf_size);
      break;
    default:
      nl();
      pl("->ILLEGAL STORAGE TYPE<-");
      nl();
      farfree(buf);
      return;
  }

  if(to1[0]) strcpy(to,to1);
  if (m.storage_type!=255&&m.storage_type!=3) {
    showmsgheader(readit,tit,n,d,to,reading,nummsgs,commstr,cursub);

  } else if(m.storage_type==3) {
    outchr(12);
    sprintf(s,"%s %s",get_string(13),n);
    plan(s,&abort,next);
    ansic(2);
    for(p=0;p<78;p++) outchr(196);
    nl();
  }

  
  p=0;
  p1=0;
  done=0;
  printit=0;
  ctrla=0;
  centre=0;

  l1=(long) cur;

  while ((!done) && (!abort) && (!hangup)) {
    switch(m.storage_type) {
      case 0:
      case 1:
      case 2:
      case 3:
    ch=ss[l1];
    if (l1>=len)
      ch=26;
    break;
      case 255:
    if (cur>=end) {
      cur=0;
      end=read(f,(void *)buf,buf_size);
      if (end==0)
        buf[0]=26;
    }
    if ((buf[cur]=='`') && (m.stored_as))
      buf[cur]=26;
    ch=buf[cur];
    break;
    }
    if (ch==26)
      done=1;
    else
      if (ch!=10) {
    if ((ch==13) || (!ch)) {
      if (ch==13)
        ctrld=0;
      printit=1;
        } else if (ch==1)
          ctrla=1;
        else if (ch==2)
          centre=1;
        else if (ch==4)
          ctrld=1;
        else if (ctrld==1) {
          if ((ch>='0') && (ch<='9')) {
            if (thisuser.optional_val<(ch-'0'))
              ctrld=0;
            else
              ctrld=-1;
          } else
            ctrld=0;
        } else {
          if (ch==27) {
            if ((topline) && (screenbottom==24) && (!ansi))
              set_protect(0);
            ansi=1;
            lines_listed=0;
          }
          s[p++]=ch;
          if ((ch==3) || (ch==8))
            --p1;
          else
        ++p1;
          if ((ch==32) && (!centre))
            printit=1;
        }

        if ((printit) || (ansi) || (p>=80)) {
          printit=0;
          if (centre && (ctrld!=-1)) {
            i1=(thisuser.screenchars-wherex()-p1)/2;
            for (i=0; (i<i1) && (!abort) && (!hangup); i++)
            cosan(" ",&abort,next);
          }
          if (p) {
        if (ctrld!=-1) {
              if ((wherex() + p1 >= thisuser.screenchars) && (!centre) && (!ansi))
                nl();
              s[p]=0;
              cosan(s,&abort,next);
              if ((ctrla) && (s[p-1]!=32) && (!ansi))
                outchr(32);
            }
            p1=0;
            p=0;
          }
          centre=0;
        }
    checka(&abort,next,1);
        if (ch==13)
          if (ctrla==0) {
            if (ctrld!=-1)
              nl();
          } else
            ctrla=0;
      } else
        ctrld=0;
    ++cur;
    ++l1;
  }
  if ((!abort) && (p)) {
    s[p]=0;
    pl(s);
  }
  nl();
  if (f!=-1)
    close(f);
  if ((m.storage_type==255) && (abort))
    *next=1;
  if ((express) && (abort) && (!(*next)))
    expressabort=1;
  farfree(buf);
  if (ss!=NULL)
    farfree(ss);
  if ((ansi) && (topdata) && (useron))
    topscreen();

  if(m.storage_type==3) {
    ansic(2);
    for(p=0;p<78;p++) outchr(196);
    nl();
    pausescr();
  }
}


int printfile(char *fn)
{
  char s[81],s1[81],s2[3];
  messagerec m;
  int next;

  m.stored_as=0L;
  m.storage_type=255;
  strcpy(s,syscfg.gfilesdir);
  strcat(s,fn);
  if (strchr(s,'.')==NULL) {
    if (thisuser.sysstatus & sysstatus_ansi) {
      if (thisuser.sysstatus & sysstatus_color) {
	strcpy(s1,s);
	strcat(s1,".ANS");
	if (exist(s1))
	  strcat(s,".ANS");
      }
      if (strchr(s,'.')==NULL) {
	strcpy(s1,s);
	strcat(s1,".B&W");
	if (exist(s1))
	  strcat(s,".B&W");
	else
	  strcat(s,".MSG");
      }
    } else
      strcat(s,".MSG");
  }
  next=0;
  if(!exist(s)) return 0;
  commstr[0]=0;
  read_message1(&m,0,0,&next,s,0,"",1,"");
  return(1);
}


void read_message(int n, int *next, int *val)
{
  char s[100],s1[80];
  postrec p;
  int abort,a;
  slrec ss;
  userrec u;

  nl();
  abort=0;
  *next=0;
  commstr[0]=0;
  p=msgs[n];
  if (p.status & (status_unvalidated | status_delete)) {
    plan("<<< NOT VALIDATED YET >>>",&abort,next);
    if (!lcs())
      return;
    *val |= 1;
    osan(s,&abort,next);
    if(!cs()) return;
  }
  strcpy(irt,p.title);
  irt_name[0]=0;

  if ((p.status & status_no_delete) && (lcs())) {
    plan("||||> Permanent Message",&abort,next);
  }

  if (p.status & status_pending_net) {
    plan("----> Not Network Validated",&abort,next);
    *val |= 2;
  }
  if (!abort) {
    ss=syscfg.sl[actsl];
    a=0;
    if((p.anony & 0x0f) & anony_sender)
        if ((lcs()) || (ss.ability & ability_read_post_anony))
          a=2;
        else
          a=1;
    setorigin(p.ownersys, p.owneruser);

    read_user(p.owneruser,&u);
    strcpy(commstr,u.comment);

    read_message1(&(p.msg),(p.anony & 0x0f),a,next,(subboards[curlsub].filename),1,p.title,n,"");
    setorigin(p.ownersys, p.owneruser);
    ++thisuser.msgread;
    ++msgreadlogon;
  } else
    if ((express) && (!(*next)))
      expressabort=1;
  if (p.qscan>QSCN(curlsub))
    QSCN(curlsub)=p.qscan;
}


void lineadd(messagerec *m1, char *sx, char *aux)
{
  messagerec m;
  char s1[81],s[81],s2[181],*b;
  int f,i,j,new;

  strcpy(s2,sx);
  strcat(s2,"\r\n\x1a");
  m=*m1;
  strcpy(s,syscfg.msgsdir);
  switch(m.storage_type) {
    case 0:
    case 1:
      ltoa(m.stored_as,s1,16);
      if (m.storage_type==1) {
        strcat(s,aux);
        strcat(s,"\\");
      }
      strcat(s,s1);
      f=open(s,O_RDWR | O_BINARY);
      if (f>0) {
        lseek(f,-1L,SEEK_END);
        write(f,(void *)s2,strlen(s2));
        close(f);
      }
      break;
    case 2:
      f=open_file(aux);
      set_gat_section(f,m.stored_as/2048);
      new=1;
      while ((new<2048) && (gat[new]!=0))
	++new;
      i=(int)(m.stored_as % 2048);
      while (gat[i]!=-1)
	i=gat[i];
      if ((b=malloca(2048))==NULL) {
        close(f);
        return;
      }
      lseek(f,MSG_STARTING + ((long)i)*512L,SEEK_SET);
      read(f,(void *)b,512);
      j=0;
      while ((j<512) && (b[j]!=26))
	++j;
      strcpy(&(b[j]),s2);
      lseek(f,MSG_STARTING + ((long)i)*512L,SEEK_SET);
      write(f,(void *)b,512);
      if (((j+strlen(s2))>512) && (new!=2048)) {
        lseek(f,MSG_STARTING + ((long)new)*512L,SEEK_SET);
        write(f,(char *)b+512,512);
	gat[new]=-1;
	gat[i]=new;
        save_gat(f);
      }
      farfree((void *)b);
      close(f);
      break;
    default:
      /* illegal storage type */
      break;
  }
}


void delete(int mn)
{
  postrec p1;
  int i;

  iscan(cursub);
  if ((mn>0) && (mn<=nummsgs)) {
    p1=msgs[mn];
    remove_link(&p1.msg,(subboards[curlsub].filename));
    for (i=mn; i<nummsgs; i++)
      msgs[i]=msgs[i+1];
    nummsgs--;
    bchanged=1;
  }
}

void showmsgheader(char a,char title[81],char name[41],char date[41],char to[41],int reading, int nummsgs,char comment[51],char subnum) {
    FILE *f;
    char s[161],s1[161],s2[10],s3[10],s4[41];
    int abort=0;

    sprintf(s,"%smsg%s.fmt",syscfg.gfilesdir,a?"net":"local");
    if(!exist(s)) {
        pl("Message Header Format Not Found!");
        logpr("7!!! Message Header Format %s not found!",s);
        return;
    }
    f=fopen(s,"rt");

    while((fgets(s,160,f))!=NULL) {
        filter(s,'\n');

        strcpy(s1,noc2(title));
        sprintf(title,"%-63.70s",s1);

        strcpy(s1,name);
        if(a==1)
            strcpy(name,"Anonymous");
        else if(a==2)
            sprintf(name,"�%s�",s1);

        strcpy(irt_name,name);
        strcpy(s1,name);
        sprintf(name,"%-30.30s",s1);

        strcpy(s1,to);
        sprintf(to,"%-30.30s",s1);

        strcpy(s1,date);
        sprintf(date,"%-30.30s",s1);

        strcpy(s1,comment);
        sprintf(comment,"%-40.40s",s1);

        sprintf(s4,"%-30.30s",noc2(subboards[usub[subnum].subnum].name));

        if(origin_str[0]==0) strcpy(origin_str,"Post is Local");

        sprintf(s2,"%3d",reading);
        sprintf(s3,"%3d",nummsgs);


        stuff_in1(s1,s,title,name,date,to,origin_str,comment,s2,s3,s4,"");
        pla(s1,&abort);
    }
    fclose(f);
}




