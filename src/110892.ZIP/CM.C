//#include "std.c"
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <conio.h>
#include <string.h>
#include "vardec.h"
#include <fcntl.h>
#include <sys\stat.h>

void main(int argc,char **argv)
{
    FILE *f,*f1;
    char *p,s[161],s1[161],*p1,s2[161],fileline[161],s3[50];
    result_info ri[100],delf;
    modem_info mi;
    int done=0,i=0,numres=0,numlines=0,append,i3;


    nl();
    pl("5Dominion Modem Script Compiler0  Copyright 1992 Dominous");
    nl();

    if(argc<2) {
        pl("Usage: CM <filename>");
        return;
    }

    f=fopen(argv[1],"rt");
    if(f==NULL) {
        npr("File %s not found!",argv[1]);
        return;
    }
    npr("Compiling Configuration File %s",argv[1]);
    while(fgets(s1,161,f)!=NULL) {
        if(s1[0]=='#') continue;
        strcpy(fileline,s1);
        numlines++;
        p=strtok(s1,":");
        strcpy(s,p);
       if(!stricmp(s,"NAME")||!stricmp(s,"SETU")||!stricmp(s,"INIT")
        ||!stricmp(s,"ANSR")||!stricmp(s,"PICK")||!stricmp(s,"HANG")
        ||!stricmp(s,"DIAL")||!stricmp(s,"PICK")||!stricmp(s,"SEPR")) {
            p=strtok(NULL,"\"");
            p=strtok(NULL,"\"");
            if(!stricmp(s,"NAME")) strncpy(mi.name,p,81);
            if(!stricmp(s,"SETU")) strncpy(mi.setu,p,161);
            if(!stricmp(s,"DIAL")) strncpy(mi.dial,p,81);
            if(!stricmp(s,"PICK")) strncpy(mi.pick,p,81);
            if(!stricmp(s,"SEPR")) strncpy(mi.sepr,p,10);
            if(!stricmp(s,"INIT")) strncpy(mi.init,p,161);
            if(!stricmp(s,"ANSR")) strncpy(mi.ansr,p,81);
            if(!stricmp(s,"HANG")) strncpy(mi.hang,p,81);
        }
       if(!stricmp(s,"DEFL")) {
        p=strtok(NULL,"|");
        done=0;
        delf.main_mode=0;
        delf.flag_value=0;
        strcpy(delf.description,"");
        strcpy(delf.result,"");
        delf.flag_mask |= flag_ec;
        delf.flag_mask |= flag_dc;
        delf.flag_mask |= flag_as;
        delf.flag_mask |= flag_fc;
        delf.flag_mask |= flag_append;


        while(!done) {
                p=strtok(NULL," ");

                if(!p[0]) done=1;

                if(strstr(p,"MS")||strstr(p,"CS")||strstr(p,"EC")||strstr(p,"DC")
                ||strstr(p,"AS")||strstr(p,"FC")) {
                    i=0;
                    strcpy(s2,p);
                    strcpy(s,"");
                    while(s2[i]!='=') s[i]=s2[i++];
                    i++;
                    s[2]=0;
                    strcpy(s1,s2+i);
                    if(!stricmp(s,"MS")) delf.modem_speed=atoi(s1);
                    if(!stricmp(s,"CS")) delf.com_speed=atoi(s1);
                    if(!stricmp(s,"EC")) { if(s1[0]=='Y') delf.flag_value+=flag_ec; delf.flag_mask |= flag_ec; }
                    if(!stricmp(s,"AS")) { if(s1[0]=='Y') delf.flag_value+=flag_as; delf.flag_mask |= flag_as; }
                    if(!stricmp(s,"DC")) { if(s1[0]=='Y') delf.flag_value+=flag_dc; delf.flag_mask |= flag_dc; }
                    if(!stricmp(s,"FC")) { if(s1[0]=='Y') delf.flag_value+=flag_fc; delf.flag_mask |= flag_fc; }
                }

            }
      }
      if(!stricmp(s,"RESL")) {
            i=append=0;
            strcpy(s1,fileline);
            p=strtok(s1,"\"");
            p=strtok(NULL,"\"");
            strcpy(ri[numres].result,p);
            p=strtok(NULL,"|");
            strcpy(s1,p);
            if(strchr(s1,'\''))
                append=1;
            p=strtok(s1,"'\"");
            p=strtok(NULL,"'\"");
            strcpy(ri[numres].description,p);

            done=0;
            ri[numres].main_mode=0;
            ri[numres].flag_value=0;
            ri[numres].flag_mask |= flag_ec;
            ri[numres].flag_mask |= flag_dc;
            ri[numres].flag_mask |= flag_as;
            ri[numres].flag_mask |= flag_fc;
            if(!append)
            ri[numres].flag_mask |= flag_append;
            else {
                ri[numres].flag_mask ^= flag_append;
                ri[numres].flag_value +=flag_append;
            }
            strcpy(s1,fileline);
            p1=strtok(s1,"|");
            while(!done) {
                p1=strtok(NULL," ");

                if(!p1[0]) done=1;

                if(strstr(p1,"NORM")) ri[numres].main_mode=mode_norm;
                if(strstr(p1,"CON"))  ri[numres].main_mode=mode_con;
                if(strstr(p1,"RING")) ri[numres].main_mode=mode_ring;
                if(strstr(p1,"ERR"))  ri[numres].main_mode=mode_err;
                if(strstr(p1,"RINGING")) ri[numres].main_mode=mode_ringing;
                if(strstr(p1,"NDT"))  ri[numres].main_mode=mode_ndt;
                if(strstr(p1,"DIS"))  ri[numres].main_mode=mode_dis;


                if(strstr(p1,"MS")||strstr(p1,"CS")||strstr(p1,"EC")||strstr(p1,"DC")
                ||strstr(p1,"AS")||strstr(p1,"FC")) {
                    i=0;
                    strcpy(s2,p1);
                    strcpy(s,"");
                    while(s2[i]!='=') s[i]=s2[i++];
                    i++;
                    s[2]=0;
                    strcpy(s1,s2+i);
                    if(!stricmp(s,"MS")) ri[numres].modem_speed=atoi(s1);
                    if(!stricmp(s,"CS")) ri[numres].com_speed=atoi(s1);
                    if(!stricmp(s,"EC")) if(s1[0]=='Y') { ri[numres].flag_value+=flag_ec; ri[numres].flag_mask ^= flag_ec; }
                    if(!stricmp(s,"AS")) if(s1[0]=='Y') { ri[numres].flag_value+=flag_as; ri[numres].flag_mask ^= flag_as; }
                    if(!stricmp(s,"DC")) if(s1[0]=='Y') { ri[numres].flag_value+=flag_dc; ri[numres].flag_mask ^= flag_dc; }
                    if(!stricmp(s,"FC")) if(s1[0]=='Y') { ri[numres].flag_value+=flag_fc; ri[numres].flag_mask ^= flag_fc; }
                }
            }
            numres++;
      }
    }
    fclose(f);

    mi.defl=delf;
    mi.num_resl=numres;
    f=fopen("modem.dat","wb");
    fwrite(&mi,sizeof(modem_info)-sizeof(result_info),1,f);
    fwrite(&ri[0],sizeof(result_info)*numres,1,f);
    fclose(f);
    npr("Compiled \"%s\", %d lines ",mi.name,numlines+1);
}
