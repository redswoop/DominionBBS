#include "vars.h"

#pragma hdrstop
#include "swap.h"

#include <math.h>
#define modem_time 3.5
extern double thing;


void pr1(unsigned char *s)
{
  int i;

  if(!ok_modem_stuff) return;
  for (i = 0; s[i] > 0; i++)
    if (s[i]=='{')
      outcomch(13);
    else if (s[i] =='~')
      wait1(9);
    else
      outcomch(s[i]);
}


void get_modem_line(char *s, double d, int allowa)
{
  int i=0;
  char ch=0, ch1;
  double t;


  if(!ok_modem_stuff) return;
  t = timer();
  do {
    ch = get1c();
    if (kbhitb() && allowa) {
      ch1 = getchd();
      if (toupper(ch1) == 'H') {
        ch = 13;
        s[0] = i = 1;
      }
    }
    if (ch >= 32)
      s[i++] = toupper(ch);
  } while ((ch != 13) && (fabs(timer() - t) < d) && (i<=40));
  s[i] = 0;
}




void do_result(result_info *ri)
{
  if (ri->description[0])
    if (ri->flag_value & flag_append)
      strcat(curspeed, ri->description);
    else
      strcpy(curspeed, ri->description);

  if (ri->main_mode)
    modem_mode = ri->main_mode;

  /* ignore the ringing mode */
  if (modem_mode == mode_ringing)
    modem_mode=0;

  modem_flag = (modem_flag & ri->flag_mask) | ri->flag_value;
  if (modem_flag & flag_fc) {
    flow_control = 1;
  }

  if (ri->com_speed) {
    com_speed = ri->com_speed;
    set_baud(com_speed);
  }

  if (ri->modem_speed)
    modem_speed = ri->modem_speed;
}


void process_full_result(char *s)
{
  char *ss;
  int i;

  ss=strtok(s,modem_i->sepr);

  while (ss) {
    for (i=0; i<modem_i->num_resl; i++) {
      if (strcmp(modem_i->resl[i].result,ss)==0) {
        do_result(&(modem_i->resl[i]));
        break;
      }
    }
    ss=strtok(NULL,modem_i->sepr);
  }
}


int mode_switch(double d, int allowa)
{
  double t;
  char s[81];
  int abort=0;

  t=timer();
  modem_mode = 0;

  while ((modem_mode==0) && (fabs(timer()-t)<d) && (!abort)&&!kbhit()) {
    get_modem_line(s,d+t-timer(), allowa);
    if (s[0]==1)
      abort=1;
    else if (s[0])
      process_full_result(s);
  }

  return(modem_mode);
}


void holdphone(int d,int force)
{

  if (!ok_modem_stuff)
    return;
  if (no_hangup)
    return;
  if ((!(syscfg.pickupphone)) || (!(syscfg.hangupphone)))
    return;

  if (d) {
    if (!global_xx) {
      if ((syscfg.sysconfig & sysconfig_off_hook)||force) {
        pr1(syscfg.pickupphone);
        xtime=timer();
        global_xx=1;
      }
    }
  } else {
    if ((syscfg.sysconfig & sysconfig_off_hook)||force) {
      if (global_xx) {
        dtr(1);
        if (fabs(xtime-timer())<modem_time) {
            topit();
            movecsr(38,2);
            outs("Waiting for modem");
        }
        while (fabs(xtime-timer())<modem_time);
        pr1(syscfg.hangupphone);
        imodem(0);
        global_xx=0;
      }
    }
  }
}

void imodem(int x)
{
  int i,done;
  double d;
  char *is;
  char s[81];

  if(!ok_modem_stuff) return;

  if (x)
    is=modem_i->setu;
  else
    is=modem_i->init;

  if (!(*is))
    return;

  topit();
  movecsr(38,1);
  outs("Sending Modem Init String");
  start_dv_crit();
  dtr(1);
  do_result(&(modem_i->defl));
  i=0;
  done=0;
  wait1(9);
  while (!done&&!kbhit()) {
    initport(syscfg.primaryport);
    pr1(is);
    dump();
    if (mode_switch(10.0,0)==mode_norm) {
      done=1;
    } else {
      ++i;
      sprintf(s,"(%d)...",modem_mode);
      outs(s);
    }
    if (i>5)
      done=1;
  }
  topit();
  topit2();
  movecsr(38,1);
  outs("Modem Ready");
  topit();
  end_dv_crit();
}


void answer_phone()
{
  char ch,s[81],s1[81];
  int i,i1;
  double d;

  if(!ok_modem_stuff) return;
  topit();
  movecsr(38,1);
  outs("Answering phone, 'H' to abort.");
  topit2();
  movecsr(38,4);
  outs(modem_i->ansr);
  do_result(&(modem_i->defl));
  pr1(modem_i->ansr);
  d=timer();
  if ((mode_switch(45.0,1)!=mode_con) && (modem_mode!=mode_fax)) {
    if (modem_mode == 0) {
       outcomch(' ');
      wait1(18);
      if (fabs(timer()-d)<modem_time) {
        while (fabs(timer()-d)<modem_time);
      }
      imodem(0);
      imodem(0);
    } else {
      outs(curspeed);
      imodem(0);
      imodem(0);
    }
  } else {
    incom=outcom=1;
    if (!(modem_flag & flag_ec))
      wait1(45);
    else
      wait1(2);
  }
  topit();
  topit2();
}

void getcaller()
{
  char s[81],s1[81],ch,done,lokb;
  int i,i1,i2,i3,any,x,y,r,c,hold,numhit=0;
  double d,d1,tt;
  long l,l1;

  c_sub=c_dir=0;

  frequent_init();
  sl1(1,"");
  usernum=0;
  wfc=0;
  hold=0;
  read_user(1,&thisuser);
  usernum=1;
  reset_act_sl();
  fwaiting=thisuser.waiting;
  if (thisuser.inact & inact_deleted) {
    thisuser.screenchars=80;
    thisuser.screenlines=25;
  }
  screenlinest=defscreenbottom+1;
  d=(1.0+timer()) / 102.723;
  d-=floor(d);
  d*=10000.0;
  srand((unsigned int)d);
  wfcs();
  imodem(1);
  imodem(0);
  topit();
  do {
    any=0;
    wfc=1;
    wfct();
    printf("[24;60H%s",hold?"[30;1m��[31mPhone Off Hook[30m��":"                  ");
    check_event();
    if (do_event) {
      run_event();
      any=1;
    }
    lokb=0;
    strcpy(curspeed,"KB");
    if (!any&&((rand() % 8000)==0)&&syscfg.systemnumber&&ok_modem_stuff) {
//      attempt_callout();
      any=1;
    }
    okskey=0;
    ch=toupper(inkey());
    if (ch) {
      any=1;
      _setcursortype(2);
      switch(ch) {
        case   1: input(s,3); status.activetoday=atoi(s); break;
        case ' ':
          topit();
          movecsr(38,1);
          outs("Log on? ");
          d=timer();
          while ((!kbhitb()) && (fabs(timer()-d)<60.0));
          if (kbhitb()) {
            ch=toupper(getchd1());
            if (ch=='Y') {
              outs("Yes\r\n");
              lokb=1;
              if ((syscfg.sysconfig & sysconfig_off_hook)==0)
                dtr(0);
            }
            if ((ch=='F') && (ok_local())) {
              outs("Fast\r\n");
              read_user(1,&thisuser);
              reset_act_sl();
              if (thisuser.inact & inact_deleted) {
                out1ch(12);
                break;
              }
              lokb=2;
              if ((syscfg.sysconfig & sysconfig_off_hook)==0)
                dtr(0);
            }
            if (ch==0)
              getchd1();
          }
          topit();
          break;
        case 'A':
          if (!ok_modem_stuff)
            break;
          answer_phone();
          break;
        case '1':
        case '2':
        case '3':
        case '4':
        case '5':
        case '6':
        case '7':
        case '8':
        case '9':
        case '0':
            sprintf(s,"wfcbat%c.bat",ch);
            runprog(s,1);
            wfcs();
            break;
        case '(':
        case '*':
        case ')':
        case '!':
        case 'O':
        case 'X':
        case '@':
        case 'S':
        case 'E':
        case '#':
        case 'F':
        case 'B':
        case 'V':
        case 'M':
        case 'C':
        case 'U':
          okskey=1;
          if (ok_local()) {
            holdphone(1,0);
            outchr(12);
            if(ch=='B') boardedit();
            else if(ch=='F') diredit();
            else if(ch=='X') protedit();
            else if(ch=='E') text_edit();
            else if(ch=='(') mailsys('S');
            else if(ch==')') mailsys('T');
#ifdef QWK
            else if(ch=='*') qmailsys();
#endif
            else if(ch=='V') ivotes();
            else if(ch=='#') menu("");
            else if(ch=='M') mailr();
            else if(ch=='!') nmail(0,0);
            else if(ch=='@') maillist();
            else if(ch=='U') uedit(1,0);
            else if(ch=='S') edstring(0);
            else if(ch=='C') confedit();
            else if(ch=='O') config();
            holdphone(0,0);
          }
          okskey=0;
          wfcs();
          break;
        case 'D':
          if (ok_local()) {
            holdphone(1,0);
            clrscrb();
            nl();
            pl("Type \"EXIT\" to return to the BBS");
            nl();
            runprog(getenv("COMSPEC"),1);
            cleanup_net();
            holdphone(0,0);
            wfcs();
          }
          break;
        case 'H': hold=opp(hold); holdphone(hold,1); break;
        case 'L': clrscr(); viewlog(); wfcs(); break;
        case 'N': if (ok_local()) print_local_file("NET.LOG"); wfcs(); break;
        case 'P': clrscrb(); print_pending_list(); wfcs(); break;
        case 'Q': end_bbs(oklevel); break;
        case 'R':
          if (ok_local()) {
            clrscrb();
            usernum=1;
            if (thisuser.waiting) {
              holdphone(1,0);
              okskey=1;
              readmail();
              okskey=0;
              write_user(1,&thisuser);
              close_user();
              cleanup_net();
              holdphone(0,0);
            }
          }
          wfcs();
          break;
        case 'I':
          if (ok_local()) {
            prstatus();
            getkey();
          }
          wfcs();
          break;
        case 'T':
          if ((ok_local()) && (syscfg.terminal[0])) {
            runprog("term.bat",1);
            imodem(1);
            imodem(0);
          }
          wfcs();
          break;
        case 'W':
          if (ok_local()) {
            clrscrb();
            usernum=1;
            useron=1;
            holdphone(1,0);
            okskey=1;
            send_email();
            okskey=0;
            useron=0;
            write_user(1,&thisuser);
            close_user();
            cleanup_net();
            holdphone(0,0);
          }
          wfcs();
          break;
        case 'Z': clrscr(); zlog(); getkey(); wfcs();  break;
        case '/': clrscr(); if((syscfg.systemnumber) && (ok_local())) force_callout(); wfcs(); break;
        case '\\': if(ok_local()) minidos(); wfcs(); break;
        case '+': imodem(0); break;
        case '|': if(!ok_local()) break;
                  clrscr();
                  npr("3Command Type\r\n5: ");
                  mpl(2);
                  input(s,2);
                  nl();
                  npr("3MString\r\n5: ");
                  mpl(40);
                  input(s1,40);
                  nl();
                  ex(s,s1);
                  pausescr();
                  wfcs();
                  break;
        case '=': wfcs(); break;
        case 13: tt=timer();
                  tt-=thing;
                  if(tt>60.0) wfcs();
                  break;
      }
      if (!incom) {
        _setcursortype(0);
        frequent_init();
        read_user(1,&thisuser);
        fwaiting=thisuser.waiting;
        reset_act_sl();
        usernum=1;
      }
      okskey=0;
    }
 /*   if(!hold) {
        if ((comhit()) && (ok_modem_stuff) && (!lokb)) {
            get_modem_line(s,1.0,1);
            if (stricmp(s,syscfg.ring)==0) {
            answer_phone();
            if (!incom) imodem(0);
            else clrscr();
          }
        }
    }*/
    if ((comhit()) && (ok_modem_stuff) && (!lokb)) {
      any=1;
      if (peek1c()==10)
        get1c();
      else {
        if (mode_switch(1.0,0)==mode_ring) {
          numhit++;
          if(numhit==1) {
             numhit=0;
             answer_phone();
          }
        } else if (modem_mode == mode_con) {
          incom=outcom=1;
          if (!(modem_flag & flag_ec))
            wait1(45);
          else
            wait1(2);
        }
      }
    }
    dv_pause();
    if (!any) {
      if (c_sub<num_subs) {
        if (!sub_dates[c_sub]) {
          any=1;
          iscan_hash(c_sub);
        }
        c_sub++;
      }
    }
  } while ((!incom) && (!lokb) && (!endday));
  if (lokb)
    modem_speed = modem_i->defl.modem_speed;
  using_modem=incom;
  if (lokb==2)
    using_modem=-1;
  okskey=1;
  if (!endday) {
    clrscr();
    printf("Connection Established at: %s\n",curspeed);
  }
  wfc=0;
}


void gotcaller(unsigned int ms, unsigned int cs)
{
  char s[81];
  double d;

  frequent_init();
  com_speed = cs;
  set_baud(cs);
  modem_speed = ms;
  sl1(1,"");
  incom=1;
  outcom=1;
  read_user(1,&thisuser);
  reset_act_sl();
  usernum=1;
  if (thisuser.inact & inact_deleted) {
    thisuser.screenchars=80;
    thisuser.screenlines=25;
  }
  screenlinest=25;
  clrscrb();
  sprintf(s,"\x0cLogging on at %s...\r\n",curspeed);
  outs(s);
  using_modem=1;
  d=(timer()) / 102.723;
  d-=floor(d);
  d*=10000.0;
  srand((unsigned int)d);
  _setcursortype(2);
}
