#include "vardec.h"
#include "direct.c"

configrec syscfg;
niftyrec nif;

#pragma warn -sus

void getselect(char *s,int row,int col,int len)
{
    int i;

    printf("[%d;%dH",row+1,col+1);
    for(i=0;i<len;i++) outchr(32);
    printf("[%d;%dH",row+1,col+1);
    input(s,len);
}

void getselectd(int *i,int row,int col,int len)
{
    int i1;
    char s[41];

    printf("[%d;%dH",row+1,col+1);
    for(i1=0;i1<len;i1++) outchr(32);
    printf("[%d;%dH",row+1,col+1);
    input(s,len);
    *i=atoi(s);
}

void togglebit(int *byte,int bit)
{
    if(*byte & bit) *byte ^=bit;
    else *byte |=bit;
}

void setbit(int row, int col,char bits[16],int *byte)
{
    char s[16];
    int i,done=0;

    do {
        for (i=0; i<=15; i++)
            if(*byte & (1 << i)) s[i]=bits[i];
            else s[i]='-';

        printf("[%d;%dH",row+1,col+1);
        outstr(s);
        printf("[%d;%dH",row+1,col+1);
        i=toupper(getch());
        switch(i) {
            case 13 :
            case 'Q': done=1; break;
            default : i-='A'+1; *byte ^= (1 << bits[i]); break;
        }
    } while(!done);
}

void bitset(char *msg,int byte,int bit)
{
   npr("%-30s: %s",msg,byte & bit?"Yes":"No");
}

void getlist(int *val,char **list,int num)
{
    char c;
    int i;

    nl();
    for(i=0;i<num;i++)
        npr("0%d. %s",i+1,list[i]);
    nl();
    outstr("5Select : 0");
    c=getch()-'1';
    *val=c;
}

void namepath()
{
    int done=0;
    char s[81];

    do {
        clrscr();
        npr("5� 0System Info And Paths");
        nl();
        npr("1. System Name       : %s",syscfg.systemname);
        npr("2. System Phone      : %s",syscfg.systemphone);
        npr("3. System Password   : %s",syscfg.systempw);
        npr("4. SysOp Name        : %s",syscfg.sysopname);
        npr("5. Matrix Password   : %s",nif.matrix);
        npr("6. New User Password : %s",syscfg.newuserpw);
        nl();
        npr("7. Data Directory    : %s",syscfg.datadir);
        npr("8. Afiles Directory  : %s",syscfg.gfilesdir);
        npr("9. Msgs Directory    : %s",syscfg.msgsdir);
        npr("0. Menu Directory    : %s",nif.menudir);
        npr("A. Batch Directory   : %s",syscfg.batchdir);
        npr("B. Temp Directory    : %s",syscfg.tempdir);
        npr("C. Defautl Dls Dir   : %s",syscfg.dloadsdir);
        nl();
        outstr("5 Select (Q=Quit)0  ");
        switch(toupper(getch())) {
            case 'Q': done=1; break;
            case '1': getselect(syscfg.systemname,2,23, sizeof(syscfg.systemname)); break;
            case '2': getselect(syscfg.systemphone,3,23,sizeof(syscfg.systemphone)); break;
            case '3': getselect(syscfg.systempw,4,23,   sizeof(syscfg.systempw)); break;
            case '4': getselect(syscfg.sysopname,5,23,  sizeof(syscfg.sysopname)); break;
            case '5': getselect(nif.matrix,6,23,      sizeof(nif.matrix)); break;
            case '6': getselect(syscfg.newuserpw,7,23,  sizeof(syscfg.newuserpw)); break;
            case '7': getselect(syscfg.datadir,9,23,    sizeof(syscfg.datadir)); break;
            case '8': getselect(syscfg.gfilesdir,10,23, sizeof(syscfg.gfilesdir)); break;
            case '9': getselect(syscfg.msgsdir,11,23,   sizeof(syscfg.msgsdir)); break;
            case '0': getselect(nif.menudir,12,23,    sizeof(nif.menudir)); break;
            case 'A': getselect(syscfg.batchdir,13,23,  sizeof(syscfg.batchdir)); break;
            case 'B': getselect(syscfg.tempdir,14,23,   sizeof(syscfg.tempdir)); break;
            case 'C': getselect(syscfg.dloadsdir,15,23, sizeof(syscfg.dloadsdir)); break;
        }
    } while(!done);
}

void flagged()
{
    int done=0;

    do {
        clrscr();
        npr("5� 0Flagged Information");
        nl();
        bitset("1. File Ratio",nif.nifstatus,nif_ratio);
        bitset("2. File Point Ratio",nif.nifstatus,nif_fpts);
        bitset("3. Post Call Ratio",nif.nifstatus,nif_pcr);
        bitset("4. Auto UL Credit",nif.nifstatus,nif_autocredit);
        nl();
        bitset("5. 2Way Default",syscfg.sysconfig,sysconfig_2_way);
        bitset("6. TwoColor Chat",syscfg.sysconfig,sysconfig_two_color);
        bitset("7. Chat Filters",nif.nifstatus,nif_mpl);
        npr("%-30s: %s","8. Chat Call Type",nif.nifstatus & nif_chattype?"Screech":"Beep");
        nl();
        bitset("9. Log to Printer",syscfg.sysconfig,sysconfig_printer);
        bitset("0. Disallow Handles",syscfg.sysconfig,sysconfig_no_alias);
        bitset("A. Phone Number in Logon",syscfg.sysconfig,sysconfig_free_phone);
        bitset("B. AutoMessage in Logon",nif.nifstatus,nif_automsg);
        bitset("C. Last Few Callers in Logon",nif.nifstatus,nif_lastfew);
        bitset("D. Your Info in Logon",nif.nifstatus,nif_yourinfo);
        nl();
        bitset("E. Automatic Chat Buffer Open",nif.nifstatus,nif_autochat);
        bitset("F. Local System Security",syscfg.sysconfig,sysconfig_no_local);
        bitset("G. Phone Off-Hook",syscfg.sysconfig,sysconfig_off_hook);
        bitset("H. Swap to run Term",syscfg.sysconfig,sysconfig_shrink_term);
        nl();
        outstr("5Select (Q=Quit) 0");
        switch(toupper(getch())) {
            case 'Q': done=1; break;
            case '1': togglebit(&nif.nifstatus,nif_ratio); break;
            case '2': togglebit(&nif.nifstatus,nif_fpts); break;
            case '3': togglebit(&nif.nifstatus,nif_pcr); break;
            case '4': togglebit(&nif.nifstatus,nif_autocredit); break;
            case '5': togglebit(&syscfg.sysconfig,sysconfig_2_way); break;
            case '6': togglebit(&syscfg.sysconfig,sysconfig_two_color); break;
            case '7': togglebit(&nif.nifstatus,nif_mpl); break;
            case '8': togglebit(&nif.nifstatus,nif_chattype); break;
            case '9': togglebit(&syscfg.sysconfig,sysconfig_printer); break;
            case '0': togglebit(&syscfg.sysconfig,sysconfig_no_alias); break;
            case 'A': togglebit(&syscfg.sysconfig,sysconfig_free_phone); break;
            case 'B': togglebit(&nif.nifstatus,nif_automsg); break;
            case 'C': togglebit(&nif.nifstatus,nif_lastfew); break;
            case 'D': togglebit(&nif.nifstatus,nif_yourinfo); break;
            case 'E': togglebit(&nif.nifstatus,nif_autochat); break;
            case 'F': togglebit(&syscfg.sysconfig,sysconfig_no_local); break;
            case 'G': togglebit(&syscfg.sysconfig,sysconfig_off_hook); break;
            case 'H': togglebit(&syscfg.sysconfig,sysconfig_shrink_term); break;
        }
    } while(!done);

}

void varible()
{
    int done=0;
    char s[81],*systype[]={"Normal","Alternate Enviroment","Other"};
    char *matrixtype[]={"None","Redefinable","StarLan"};

    do {
        clrscr();
        npr("5� 0Varible System Data");
        nl();
        npr("1. Start Out Menu    : %s",nif.firstmenu);
        npr("2. New User Menu     : %s",nif.newusermenu);
        npr("3. Echo Character    : %c",nif.echochar);
        nl();
        npr("4. New User SL/DSL   : %3d/%3d",syscfg.newusersl,syscfg.newuserdsl);
        npr("5. Maximum  Users    : %d",syscfg.maxusers);
        npr("6. Max Waiting Mail  : %d",syscfg.maxwaiting);
        nl();
        npr("7. KiloByte Ratio    : %-5.3f",syscfg.req_ratio);
        npr("8. File Point Ratio  : 1 to %d ",nif.fptsratio);
        npr("9. Post Call Ratio   : %-5.3f",syscfg.post_call_ratio);
        nl();
        npr("0. System Type       : %s",systype[nif.systemtype]);
        npr("A. Maxtrix Type      : %s",matrixtype[nif.matrixtype]);
        npr("B. Lock Out Rate     : %d",nif.lockoutrate);
        nl();
        outstr("5 Select (Q=Quit)0  ");
        switch(toupper(getch())) {
            case 'Q': done=1; break;
            case '1': getselect(nif.firstmenu,2,23,sizeof(nif.firstmenu)); break;
            case '2': getselect(nif.newusermenu,3,23,sizeof(nif.newusermenu)); break;
            case '3': getselect(s,4,23,1);
                      nif.echochar=s[0];
                      break;
            case '4': getselectd(&syscfg.newusersl,6,23,3);
                      getselectd(&syscfg.newuserdsl,6,27,3); break;
            case '5': getselectd(&syscfg.maxusers,7,23,4); break;
            case '6': getselectd(&syscfg.maxwaiting,8,23,4); break;
            case '7': getselect(s,10,23,5);
                      syscfg.req_ratio=atof(s);
                      break;
            case '8': getselectd(&nif.fptsratio,11,23,20); break;
            case '9': getselect(s,12,23,5);
                      syscfg.req_ratio=atof(s);
                      break;
            case '0': getlist(&nif.systemtype,systype,3); break;
            case 'A': getlist(&nif.matrixtype,matrixtype,3); break;
            case 'B': getselectd(&nif.lockoutrate,16,23,20); break;

        }
    } while(!done);

}

void events()
{
    int done=0;
    char s[81];

    do {
        clrscr();
        npr("5� 0Event Manager");
        nl();
        npr("1. Logon Event     : %s",syscfg.logon_c);
        npr("2. Logoff Event    : %s",syscfg.upload_c);
        npr("3. Begin Day Event : %s",syscfg.beginday_c);
        npr("4. Newuser Event   : %s",syscfg.newuser_c);
        nl();
        npr("5. Timed Event Execute Time : %d minutes after midnight",syscfg.executetime);
        npr("6. Timed Event File Name    : %s",syscfg.executestr);
        nl();
        outstr("5 Select (Q=Quit)0  ");
        switch(toupper(getch())) {
            case 'Q': done=1; break;
            case '1': getselect(syscfg.logon_c,2,21,sizeof(syscfg.logon_c)); break;
            case '2': getselect(syscfg.upload_c,3,21,sizeof(syscfg.upload_c)); break;
            case '3': getselect(syscfg.beginday_c,4,21,sizeof(syscfg.beginday_c)); break;
            case '4': getselect(syscfg.newuser_c,5,21,sizeof(syscfg.newuser_c)); break;
            case '5': getselectd(&syscfg.executetime,7,30,30); break;
            case '6': getselect(syscfg.executestr,8,30,sizeof(syscfg.executestr)); break;
        }
    } while(!done);
}

void modeminfo()
{
    int done=0;
    char s[81];

    do {
        clrscr();
        npr("5� 0Modem Information");
        nl();
        npr("1. Com Port     : %d",syscfg.primaryport);
        npr("2. Interupt     : %d",syscfg.com_ISR[syscfg.primaryport]);
        npr("3. Base Address : %x",syscfg.com_base[syscfg.primaryport]);
        nl();
        outstr("5 Select (Q=Quit)0  ");
        switch(toupper(getch())) {
            case 'Q': done=1; break;
            case '1': getselectd(&syscfg.primaryport,2,18,2); break;
            case '2': getselectd(&syscfg.com_ISR[syscfg.primaryport],3,18,2); break;
            case '3': getselect(s,4,18,4);
                      sscanf(s,"%x",&syscfg.com_base[syscfg.primaryport]);
                      break;
        }
    } while(!done);
}

void autoval()
{
    char ar[17],dar[17],res[17],s[16];
    int i,done=0,i1,numed=0;

    strcpy(s,restrict_string);

    do {
        clrscr();
        pl("5� 0AutoValidation Data");
        nl();
        for(i1=0;i1<10;i1++) {
            for (i=0; i<=15; i++) {
                if (syscfg.autoval[i1].ar & (1 << i)) ar[i]='A'+i;
                else ar[i]='-';
                if (syscfg.autoval[i1].dar & (1 << i)) dar[i]='A'+i;
                else dar[i]='-';
                if (syscfg.autoval[i1].restrict & (1 << i)) res[i]=s[i];
                else res[i]='-';
            }
            ar[16]=0;
            dar[16]=0;
            res[17]=0;
            pr("%d%2d. SL=%3d DSL=%3d AR=%s IAR=%s",i1==numed?0:3,i1+1,syscfg.autoval[i1].sl,syscfg.autoval[i1].dsl,ar,dar,res);
            nl();
        }
        nl();
        outstr("5Select (Q=Quit, Up/Down to Select)0 ");
        i1=numed;
        switch(toupper(getch())) {
            case 'Q': done=1; break;
            case 0  : i=getch(); if(i==80) if(numed<9) numed++; else if(i==72) if(numed>0) numed--; break;
            case 'S': getselectd(&syscfg.autoval[i1].sl,i1+2,7,3); break;
            case 'D': getselectd(&syscfg.autoval[i1].dsl,i1+2,15,3); break;
            case 'A': setbit(i1+2,22,"ABCDEFGHIJKLMNOP",&syscfg.autoval[i1].ar); break;
            case 'I': setbit(i1+2,22,"ABCDEFGHIJKLMNOP",&syscfg.autoval[i1].dar); break;
        }
  } while(!done);
}

void archive()
{
    char s[81];
    int i,done=0,i1=0;

    do {
        clrscr();
        pl("5� 0Archive Configuration");
        nl();
        npr("1. Extension  : %s",syscfg.arcs[i1].extension);
        npr("2. Add to Arc : %s",syscfg.arcs[i1].arca);
        npr("3. Extract Arc: %s",syscfg.arcs[i1].arce);
        npr("4. View Arc   : %s",syscfg.arcs[i1].arcl);
        npr("5. Test Arc   : %s",nif.arc[i1].arct);
        npr("6. Comment Arc: %s",nif.arc[i1].arcc);
        nl();
        pl(" %1 = Archive File Name");
        pl(" %2 = File to Touch");
        pl(" %5 = Comment File Name");
        nl();
        outstr("5Select (Q=Quit, [,])0 ");
        switch(toupper(getch())) {
            case 'Q': done=1; break;
            case '[': if(i1) i1--; break;
            case ']': if(i1<3) i1++; break;
            case '1': getselect(syscfg.arcs[i1].extension,2,16,sizeof(syscfg.arcs[i1].extension)); break;
            case '2': getselect(syscfg.arcs[i1].arca,3,16,sizeof(syscfg.arcs[i1].arca)); break;
            case '3': getselect(syscfg.arcs[i1].arce,4,16,sizeof(syscfg.arcs[i1].arce)); break;
            case '4': getselect(syscfg.arcs[i1].arcl,5,16,sizeof(syscfg.arcs[i1].arcl)); break;
            case '5': getselect(nif.arc[i1].arct,6,16,sizeof(nif.arc[i1].arct)); break;
            case '6': getselect(nif.arc[i1].arcc,7,16,sizeof(nif.arc[i1].arcc)); break;
        }
    } while(!done);
}

void secleved()
{
    char s[81];
    int i,done=0,i1=0;

    do {
        clrscr();
        pl("5� 0Security Level Data");
        nl();
        npr("3Number 9%d0",i1);
        nl();
        npr("1. Time Per Day          : %d",syscfg.sl[i1].time_per_day);
        npr("2. Time Per Call         : %d",syscfg.sl[i1].time_per_logon);
        npr("3. Max Messages Read     : %d",syscfg.sl[i1].messages_read);
        npr("4. Max Emails            : %d",syscfg.sl[i1].emails);
        npr("5. Max Posts             : %d",syscfg.sl[i1].posts);
        bitset("6. Post Anonymos",syscfg.sl[i1].ability,ability_post_anony);
        bitset("7. Email Anonymos",syscfg.sl[i1].ability,ability_email_anony);
        bitset("8. Read Anonymos Posts",syscfg.sl[i1].ability,ability_read_post_anony);
        bitset("9. Read Anonymos Email",syscfg.sl[i1].ability,ability_read_email_anony);
        bitset("0. Posts Need Validation",syscfg.sl[i1].ability,ability_val_net);
        nl();
        outstr("5Select (Q=Quit, [,])0 ");
        switch(toupper(getch())) {
            case 'Q': done=1; break;
            case '[': if(i1) i1--; break;
            case ']': if(i1<3) i1++; break;
            case '{': if(i1-10) i1-=10; break;
            case '}': if(i1+10<255) i1+=10; break;
        }
    } while(!done);

}

void fsed(){}
void fidocfg(){}
  

void main()
{
    int i,done=0;
    FILE *f;

    f=fopen("config.dat","rb");
    fread(&syscfg,sizeof(configrec),1,f);
    fread(&nif,sizeof(niftyrec),1,f);
    fclose(f);

    do {
        clrscr();
        pl("5� 0Dominion System Configuration");
        nl();
        pl("71.0 Names and Paths                 72.0 Flagged Info");
        pl("73.0 Varible System Data             74.0 Event Manager");
        pl("75.0 Modem Info                      76.0 AutoVal Data");
        pl("77.0 Archive Configuration           78.0 FullScreen Editors");
        pl("79.0 Security Level Data             70.0 FidoNet Configuration");
        nl();
        outstr("5Select (Q=Quit)0  ");
        switch(toupper(getch())) {
            case 'Q': done=1; break;
            case '1': namepath(); break;
            case '2': flagged(); break;
            case '3': varible(); break;
            case '4': events(); break;
            case '5': modeminfo(); break;
            case '6': autoval(); break;
            case '7': archive(); break;
            case '8': fsed(); break;
            case '9': secleved(); break;
            case '0': fidocfg(); break;
        }
    } while(!done);

    f=fopen("config.dat","wb");
    fwrite(&syscfg,sizeof(configrec),1,f);
    fwrite(&nif,sizeof(niftyrec),1,f);
    fclose(f);
}
