#include "vars.h"
#pragma hdrstop

extern mmrec pp;
extern menurec tg[50];
extern char avail[50][8],maxcmd,menuat[15];

unsigned char bo(unsigned char c) {
    switch(c) {
        case '<': return '>';
        case '[': return ']';
        case '(': return ')';
        case '�': return '�';
        case '�': return '�';
        case '�': return '�';
        case '�': return '�';
    }
    return(c);
}

char *noc2(char s1[100])
{
  int r=0,w=0;
  char s[100];

  while (s1[r]!=0) {
    if (s1[r]==3||s1[r]==14) {
      ++r;
      s[w]=0;
      r++;
    } else
      s[w++]=s1[r++];
  }
  s[w]=0;
  return(s);
}


void filter(char *s,unsigned char c)
{
 int x=0;

 while(s[x++]!=c);
 s[x-1]=0;

}


int readmenu(char fn[15])
{
    int menu;
    char s[255];
    mmrec f;
    int x;


    sprintf(s,"%s%s",nifty.menudir,fn);
    if(!exist(s)) {
        npr("8Menu %s not found!  Please inform the SysOp!!");
        logpr("7! 0Menu 4%s 0Not Found!",fn);
        readmenu(nifty.firstmenu);
        return 0;
    }
    menu=open(s,O_BINARY|O_RDONLY);

    maxcmd=0;
    lseek(menu,0L,SEEK_SET);
    read(menu,(void *)&pp,sizeof(mmrec));
    if(!slok(pp.slneed,1)) {
        pl("8Sorry, you do not have the proper access to enter this menu.");
        logpr("7!0 Tried entering menu (4%s0) that did not have access for.",fn);
        readmenu(nifty.firstmenu);
        return 0;
    }
    strcpy(menuat,fn);

    while(read(menu,(void *)&tg[maxcmd],sizeof(menurec))&&maxcmd<64) {
      if(tg[maxcmd].at=='F') ex(tg[maxcmd].type,tg[maxcmd].ms);
      else if(slok(tg[maxcmd].sl,1)) maxcmd++;
    }

    close(menu);

    sprintf(s,"%sglobal.mnu",nifty.menudir);
    if(exist(s)) {
    menu=open(s,O_RDONLY|O_BINARY);
    read(menu,&f,sizeof(mmrec));
    while(read(menu,&tg[maxcmd],sizeof(menurec))&&maxcmd<64)
        if(slok(tg[maxcmd].sl,1)) maxcmd++;
    close(menu);
    }


    close(menu);


    for(x=0;x<=maxcmd;x++) {
      strcpy(avail[x],tg[x].key);
    }

    return 1;
}

char cmded[50];

void aligncmd(char s[50], mmrec p)
{
    int r=1,w=0,init=0;
    char s1[80],s2[12],s3[50];

    strcpy(s1,noc2(s));
    init=s1[0];
    while(s1[r]!=bo(init)&&r<strlen(s1)) s2[w++]=s1[r++];
    s2[w]=0;
    r++;
    strcpy(s3,s1+r);

    if(!pp.fallback[4])
        sprintf(s1,"%c%c%c%s%c%c%c%s",p.fallback[0]+1,init,p.fallback[1]+1,s2,p.fallback[0]+1,bo(init),p.fallback[2]+1,s3);
    else
        sprintf(s1,"�p%s�%s",s2,s3);

    switch(p.fallback[3]) {
        case 1: strcpy(s,s1); break;
        case 2: sprintf(s,"%-47.47s",s1); break;
        case 3: sprintf(s,"%-34.34s",s1); break;
        case 4: sprintf(s,"%-27.27s",s1); break;
        case 5: sprintf(s,"%-15.15s",s1); break;
    }
    strcpy(cmded,s);
}


void showmenucol(menurec *mf,mmrec pf,int num)
{
    int x=0,abort=0,y=0,ok=1,x1;
    char s[60];

    if(pf.fallback[4]) outchr(12);
    nl();
    pl(pf.title1);
    pl(pf.title2);
    ansic(pf.fallback[5]);
    if(pf.fallback[4]) {
        for(x=0;x<78;x++) outchr(pf.fallback[4]);
    }
    nl();

    for(x=0;x<num&&!abort;x++) {
        ok=0;
        if(slok(mf[x].sl,1)) ok=1;
        if(mf[x].at=='H') ok=0;
        if(mf[x].at=='U') ok=1;
        if(mf[x].at=='P') ok=0;

        if(ok) {
          if(mf[x].at!='T') {
              strcpy(s,mf[x].desc);
              aligncmd(s,pf);
              mla(cmded,&abort);
              y++;
          } else {
            if(y!=0) nl();
            ansic(pf.fallback[5]);
            if(pf.fallback[4]) {
                for(x1=0;x1<78;x1++) outchr(pf.fallback[4]);
                nl();
            }
            pl(mf[x].ms);
            y=pf.fallback[3];
          }
          if(y==pf.fallback[3]) {
            if(mf[x].at=='T') {
                ansic(pf.fallback[5]);
                if(pf.fallback[4]) {
                    for(x1=0;x1<78;x1++) outchr(pf.fallback[4]);
                    nl();
                }
            } else
            nl();
            y=0;
          }
        }
    }
    if(y<pf.fallback[3]&&y!=0) nl();
    ansic(pf.fallback[5]);
    if(pf.fallback[4])
        for(x=0;x<78;x++) outchr(pf.fallback[4]);
    nl();
}

void showmenu(menurec *mr,mmrec pr,int num)
{
    if(!printfile(pr.altmenu))
        showmenucol(mr,pr,num);
}

