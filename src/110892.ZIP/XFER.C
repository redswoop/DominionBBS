/*****************************************************************************

				WWIV Version 4
                    Copyright (C) 1988-1991 by Wayne Bell

Distribution of the source code for WWIV, in any form, modified or unmodified,
without PRIOR, WRITTEN APPROVAL by the author, is expressly prohibited.
Distribution of compiled versions of WWIV is limited to copies compiled BY
THE AUTHOR.  Distribution of any copies of WWIV not compiled by the author
is expressly prohibited.


*****************************************************************************/



#include "vars.h"

#pragma hdrstop

#include <dir.h>



#define SETREC(i)  lseek(dlf,((long) (i))*((long)sizeof(uploadsrec)),SEEK_SET);


/* How far to indent extended descriptions */
#define INDENTION 24

/* Max # of lines for extended description */
#define MAX_LINES 10

/* If its OK to use the FSED for editing extended descriptions */
#define FSED_OK ((okfsed()) && (0))

/* If this is defined, the system will put in "ASK" if a file isn't there */
#define CHECK_FOR_EXISTANCE

/* the archive type to use */
#define ARC_NUMBER 0

int foundany;


int check_batch_queue(char *fn)
{
  int i;

  for (i=0; i<numbatch; i++) {
    if (strcmp(fn,batch[i].filename)==0)
      if (batch[i].sending)
        return(1);
      else
        return(-1);
  }

  return(0);
}


int check_ul_event(int dn, uploadsrec *u)
{
  char s[161];

  if (syscfg.upload_c[0]) {
    stuff_in(s,syscfg.upload_c,create_chain_file("CHAIN.TXT"),
             directories[dn].path,stripfn(u->filename),"","");
    run_external(s);
    topscreen();
    sprintf(s,"%s%s",directories[dn].path, stripfn(u->filename));
    if (!exist(s)) {
      sprintf(s,"File '%s' to %s deleted by UL event.",
              u->filename, directories[dn].name);
      sysoplog(s);
      npr("File '%s' was deleted by upload event.\r\n",u->filename);
      return(1);
    }
  }

  return(0);
}

char (*devices)[9];
int num_devices;

void finddevs(char (*devs)[9], int *count)
{
  char s[9];
  int i;
  char far *ss;
  long far *l;
  union REGS regs;
  struct SREGS sregs;

  *count=0;
  regs.x.ax=0x5200;
  int86x(INT_REAL_DOS, &regs, &regs, &sregs);
  ss=MK_FP(sregs.es, regs.x.bx);
  ss += 34;
  l=(long far *) ss;

  while (((unsigned short) l) != 0xffff) {
    ss=(char far *) l;
    ss += 10;
    if (*ss>32) {
      strncpy(s,ss,8);
      s[8]=0;
      for (i=7; i; i--)
        if (s[i]==' ')
          s[i]=0;
        else
          break;
      if (devs) {
        strcpy(devs[*count],s);
      }
      ++(*count);
    }
    l=(long far *) *l;
  }
}

void find_devices()
{
  finddevs(NULL, &num_devices);
  devices=farmalloc((num_devices+2)*9);
  finddevs(devices,&num_devices);
}

int okfn(char *s)
{
  int i,l;
  unsigned char ch;

  l=strlen(s);
  if ((s[0]=='-') || (s[0]==' ') || (s[0]=='.') || (s[0]=='@'))
    return(0);
  for (i=0; i<l; i++) {
    ch=s[i];
    if ((ch==' ') || (ch=='/') || (ch=='\\') || (ch==':') ||
        (ch=='>') || (ch=='<') || (ch=='|')  || (ch=='+') ||
        (ch==',') || (ch==';') || (ch=='^')  || (ch>126))
      return(0);
  }

  for (i=0; i<num_devices; i++) {
    l=strlen(devices[i]);
    if (strncmp(devices[i],s,l)==0) {
      if ((s[l]==0) || (s[l]=='.') || (l==8))
        return(0);
    }
  }
  return(1);
}

void print_devices()
{
  int i;
  for (i=0; i<num_devices; i++)
    npr("%s\r\n",devices[i]);
}


char *make_abs_cmd(char *out)
{
  char s[161],s1[161],*ss,*ss1;

  strcpy(s1,out);
  ss=strchr(s1,' ');
  if (ss)
    *ss=0;
  strcpy(s,s1);
  ss1=searchpath(s);
  if (!ss1) {
    sprintf(s,"%s.COM",s1);
    ss1=searchpath(s);
  }
  if (!ss1) {
    sprintf(s,"%s.EXE",s1);
    ss1=searchpath(s);
  }
  if (!ss1) {
    sprintf(s,"%s.BAT",s1);
    ss1=searchpath(s);
  }
  if (ss1)
    strcpy(s,ss1);
  else {
    strcpy(s,cdir);
    strcat(s,s1);
  }
  if (ss) {
    strcat(s," ");
    strcat(s,ss+1);
  }
  strcpy(out,s);

  return(out);
}

void get_arc_cmd(char *out, char *arcfn, int cmd, char *ofn)
{
  char *ss,*ss1,s[161],s1[161];
  int i;

  out[0]=0;
  ss=strchr(arcfn,'.');
  if (ss==NULL)
    return;
  ++ss;
  ss1=strchr(ss,'.');
  while (ss1!=NULL) {
    ss=ss1;
    ++ss1;
    ss1=strchr(ss,'.');
  }
  for (i=0; i<4; i++)
    if (stricmp(ss,syscfg.arcs[i].extension)==0) {
      switch(cmd) {
        case 0: strcpy(s,syscfg.arcs[i].arcl); break;
        case 1: strcpy(s,syscfg.arcs[i].arce); break;
        case 2: strcpy(s,syscfg.arcs[i].arca); break;
      }
      if (s[0]==0)
        return;
      stuff_in(out,s,arcfn,ofn,"","","");
      make_abs_cmd(out);
      return;
    }

}


int list_arc_out(char *fn, char *dir)
{
  char s[161],s1[81];
  int i=0;

  sprintf(s1,"%s%s",dir,fn);
  get_arc_cmd(s,s1,0,"");
  if (!okfn(fn))
    s[0]=0;
  if (exist(s1) && (s[0]!=0)) {
    nl();
    nl();
    npr("Archive listing for %s:\r\n",fn);
    nl();
    i=do_external(s,1);
    nl();
  } else {
    nl();
    outs("Unknown archive: ");
    pl(fn);
    nl();
    i=0;
  }
  return(i);
}


int ratio_ok()
{
  int ok=1;
  char s[101];

  if (!(thisuser.exempt & exempt_ratio))
    if ((syscfg.req_ratio>0.0001) && (ratio()<syscfg.req_ratio)) {
      ok=0;
      nl();
      nl();
      sprintf(s,"Your up/download ratio is %-5.3f.  You need a ratio of %-5.3f to download.",
        ratio(), syscfg.req_ratio);
      pl(s);
      nl();
    }

  if (!(thisuser.exempt & exempt_post))
    if ((syscfg.post_call_ratio>0.0001) && (post_ratio()<syscfg.post_call_ratio)) {
      ok=0;
      nl();
      nl();
      sprintf(s,"Your post/call ratio is %-5.3f.  You need a ratio of %-5.3f to download.",
        post_ratio(), syscfg.post_call_ratio);
      pl(s);
      nl();
    }


  return(ok);
}


int dcs()
{
  if (cs())
    return(1);
  if (thisuser.dsl>=100)
    return(1);
  else
    return(0);
}


void dliscan1(int dn)
{
  char s[81];
  int i;
  uploadsrec u;
  long l;

  closedl();

  sprintf(s,"%s%s.DIR",syscfg.datadir,directories[dn].filename);
  dlf=open(s,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
  i=filelength(dlf)/sizeof(uploadsrec);
  if (i==0) {
    memset(&u, 0, sizeof(uploadsrec));
    strcpy(u.filename,"|MARKER|");
    time(&l);
    u.daten=l;
    SETREC(0);
    write(dlf,(void *)&u,sizeof(uploadsrec));
  } else {
    SETREC(0);
    read(dlf,(void *)&u,sizeof(uploadsrec));
    if (strcmp(u.filename,"|MARKER|")) {
      numf=u.numbytes;
      memset(&u, 0, sizeof(uploadsrec));
      strcpy(u.filename,"|MARKER|");
      time(&l);
      u.daten=l;
      u.numbytes = numf;
      SETREC(0);
      write(dlf, &u, sizeof(uploadsrec));
    }
  }
  numf=u.numbytes;
  this_date = u.daten;
  dir_dates[dn]=this_date;

  sprintf(s,"%s%s.EXT",syscfg.datadir,directories[dn].filename);
  edlf=open(s,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
}

void dliscan_hash(int dn)
{
  char s[81];
  int i,dlf;
  uploadsrec u;

  if ((dn>=num_dirs) || (dir_dates[dn]))
    return;

  sprintf(s,"%s%s.DIR",syscfg.datadir,directories[dn].filename);
  dlf=open(s,O_RDWR | O_BINARY);
  if (dlf<0) {
    time(&(dir_dates[dn]));
    return;
  }
  i=filelength(dlf)/sizeof(uploadsrec);
  if (i<1) {
    time(&(dir_dates[dn]));
  } else {
    SETREC(0);
    read(dlf,(void *)&u,sizeof(uploadsrec));
    if (strcmp(u.filename,"|MARKER|")==0) {
      dir_dates[dn]=u.daten;
    } else {
      time(&(dir_dates[dn]));
    }
  }
  close(dlf);
}


void dliscan()
{
  dliscan1(udir[curdir].subnum);
}


void closedl()
{
  if (dlf>0) {
    close(dlf);
    dlf=-1;
  }
  if (edlf>0) {
    close(edlf);
    edlf=-1;
  }
}

void add_extended_description(char *fn, char *desc)
{
  ext_desc_type ed;

  strcpy(ed.name,fn);
  ed.len=strlen(desc);
  lseek(edlf,0L,SEEK_END);
  write(edlf,&ed,sizeof(ext_desc_type));
  write(edlf,desc,ed.len);
}


void delete_extended_description(char *fn)
{
  ext_desc_type ed;
  long r,w,l1;
  char *ss=NULL;

  r=w=0;
  if ((ss=malloca(10240L))==NULL)
    return;
  l1=filelength(edlf);
  while (r<l1) {
    lseek(edlf,r,SEEK_SET);
    read(edlf,&ed,sizeof(ext_desc_type));
    if (ed.len<10000) {
      read(edlf,ss,ed.len);
      if (strcmp(fn,ed.name)) {
        if (r!=w) {
          lseek(edlf,w,SEEK_SET);
          write(edlf,&ed,sizeof(ext_desc_type));
          write(edlf,ss,ed.len);
        }
        w +=(sizeof(ext_desc_type) + ed.len);
      }
    }
    r += (sizeof(ext_desc_type) + ed.len);
  }
  farfree(ss);
  chsize(edlf,w);
}


char *read_extended_description(char *fn)
{
  ext_desc_type ed;
  long l,l1;
  char *ss=NULL;

  l=0;
  l1=filelength(edlf);
  while (l<l1) {
    lseek(edlf,l,SEEK_SET);
    l += (long) read(edlf,&ed,sizeof(ext_desc_type));
    if (strcmp(fn,ed.name)==0) {
      ss=malloca((long) ed.len+10);
      if (ss) {
        read(edlf,ss,ed.len);
        ss[ed.len]=0;
      }
      return(ss);
    } else
      l += (long) ed.len;
  }
  return(NULL);
}



void print_extended(char *fn, int *abort, unsigned char numlist, int indent)
{
  char *ss;
  int next=0;
  unsigned char numl=0;
  int cpos=0;
  char ch,s[81];
  int i;

  ss=read_extended_description(fn);
  if (ss) {
    ch=10;
    while ((ss[cpos]) && (!(*abort)) && (numl<numlist)) {
      if ((ch==10) && (indent)) {
        if (okansi())
          sprintf(s,"\x1b[%dC",INDENTION);
        else {
          for (i=0; i<INDENTION; i++)
            s[i]=32;
          s[INDENTION]=0;
        }
        osan(s,abort,&next);
        if ((thisuser.sysstatus & sysstatus_funky_colors) && (!(*abort)))
          ansic(2);
      }
      outchr(ch=ss[cpos++]);
      checka(abort,&next);
      if (ch==10)
        ++numl;
      else
        if ((ch!=13) && (wherex()>=78)) {
          osan("\r\n",abort,&next);
          ch=10;
        }
    }
    if (wherex())
      nl();
  }
  farfree(ss);
}



void modify_extended_description(char **sss)
{
  char s[161],s1[161];
  int f,ii,i,i1,i2;

  if (*sss)
    ii=1;
  else
    ii=0;
  do {
    if (ii) {
      nl();
      if (FSED_OK)
        prt(5,"Modify the extended description? ");
      else
        prt(5,"Enter a new extended description? ");
      if (!yn())
        return;
    } else {
      nl();
      prt(5,"Enter an extended description? ");
      if (!yn())
        return;
    }
    if (FSED_OK) {
      sprintf(s,"%sEXTENDED.DSC", syscfg.tempdir);
      if (*sss) {
        f=open(s,O_RDWR | O_BINARY | O_CREAT | O_TRUNC, S_IREAD | S_IWRITE);
        write(f,*sss,strlen(*sss));
        close(f);
        farfree(*sss);
        *sss=NULL;
      } else
        unlink(s);
      i=thisuser.screenchars;
      if (thisuser.screenchars>(76-INDENTION))
        thisuser.screenchars=76-INDENTION;
      i1=external_edit("extended.dsc",syscfg.tempdir,(int) thisuser.defed-1,MAX_LINES);
      thisuser.screenchars=i;
      if (i1) {
        if ((*sss=malloca(10240))==NULL)
          return;
        f=open(s,O_RDWR | O_BINARY);
        read(f,*sss,(int) filelength(f));
        (*sss)[filelength(f)]=0;
        close(f);
      }
    } else {
      if (*sss)
        farfree(*sss);
      if ((*sss=malloca(10240))==NULL)
        return;
      *sss[0]=0;
      i=1;
      nl();
      sprintf(s,"Enter up to %d lines, %d chars each.",MAX_LINES,78-INDENTION);
      pl(s);
      nl();
      s[0]=0;
      i1=thisuser.screenchars;
      if (thisuser.screenchars>(76-INDENTION))
        thisuser.screenchars=76-INDENTION;
      do {
        ansic(2);
        npr("%d: ",i);
        ansic(0);
        s1[0]=0;
        inli(s1,s,90,1);
        i2=strlen(s1);
        if (i2 && (s1[i2-1]==1))
          s1[i2-1]=0;
        if (s1[0]) {
          strcat(s1,"\r\n");
          strcat(*sss,s1);
        }
      } while ((i++<10) && (s1[0]));
      thisuser.screenchars=i1;
      if (*sss[0]==0) {
        farfree(*sss);
        *sss=NULL;
      }
    }
    prt(5,"Is this what you want? ");
    i=!yn();
    if (i) {
      farfree(*sss);
      *sss=NULL;
    }
  } while (i);
}


void align(char *s)
{
  char f[40],e[40],s1[20],*s2;
  int i,i1,i2;

  i1=0;
  if (s[0]=='.')
    i1=1;
  for (i=0; i<strlen(s); i++)
    if ((s[i]=='\\') || (s[i]=='/') || (s[i]==':') || (s[i]=='<') ||
      (s[i]=='>') || (s[i]=='|'))
      i1=1;
  if (i1) {
    strcpy(s,"        .   ");
    return;
  }
  s2=strchr(s,'.');
  if (s2==NULL) {
    e[0]=0;
  } else {
    strcpy(e,&(s2[1]));
    e[3]=0;
    s2[0]=0;
  }
  strcpy(f,s);

  for (i=strlen(f); i<8; i++)
    f[i]=32;
  f[8]=0;
  i1=0;
  i2=0;
  for (i=0; i<8; i++) {
    if (f[i]=='*')
      i1=1;
    if (f[i]==' ')
      i2=1;
    if (i2)
      f[i]=' ';
    if (i1)
      f[i]='?';
  }

  for (i=strlen(e); i<3; i++)
    e[i]=32;
  e[3]=0;
  i1=0;
  for (i=0; i<3; i++) {
    if (e[i]=='*')
      i1=1;
    if (i1)
      e[i]='?';
  }

  for (i=0; i<12; i++)
    s1[i]=32;
  strcpy(s1,f);
  s1[8]='.';
  strcpy(&(s1[9]),e);
  strcpy(s,s1);
  for (i=0; i<12; i++)
    s[i]=upcase(s[i]);
}


int compare(char *s1, char *s2)
{
  int ok,i;

  ok=1;
  for (i=0; i<12; i++)
    if ((s1[i]!=s2[i]) && (s1[i]!='?') && (s2[i]!='?'))
      ok=0;
  return(ok);
}


void printinfo(uploadsrec *u, int *abort)
{
  char s[85],s1[40],s2[81];
  int i,next,fc;

  fc=thisuser.sysstatus & sysstatus_funky_colors;

  if (fc)
    ansic(1);
  strncpy(s,u->filename,8);
  s[8]=0;
  osan(s,abort,&next);
  strncpy(s,&((u->filename)[8]),4);
  s[4]=0;
  if (fc)
    ansic(2);
  osan(s,abort,&next);
  if (fc)
    ansic(0);
  osan(": ",abort,&next);

  ltoa((((u->numbytes)+1023)/1024),s1,10);
  strcat(s1,"k");

#ifdef CHECK_FOR_EXISTANCE
  strcpy(s2,directories[udir[curdir].subnum].path);
  strcat(s2,u->filename);
  if (!exist(s2))
    strcpy(s1,"N/A");
#endif

  for (i=0; i<5-strlen(s1); i++)
    s[i]=32;
  s[i]=0;
  strcat(s,s1);
  if (fc)
    ansic(3);
  osan(s,abort,&next);

  if (fc)
    ansic(0);
  osan(" :",abort,&next);
  if (fc)
    ansic(5);
  pla(u->description,abort);
  if ((!*abort) && (thisuser.num_extended) && (u->mask & mask_extended))
    print_extended(u->filename,abort,thisuser.num_extended,1);
  if (!(*abort))
    ++num_listed;
}


void printtitle(int *abort)
{
  char s[81],s1[20];
  int i,i1;

  pla("",abort);
  pla("",abort);
  sprintf(s,"%s - #%s, %d files.",directories[udir[curdir].subnum].name,
                                  udir[curdir].keys,numf);
  i=strlen(s);
  if (thisuser.sysstatus & sysstatus_funky_colors)
    ansic(2);
  pla(s,abort);
  for (i1=0; i1<i; i1++)
    s[i1]='=';
  s[i]=0;
  if (thisuser.sysstatus & sysstatus_funky_colors)
    ansic(2);
  pla(s,abort);
  pla("",abort);
}


void file_mask(char *s)
{
  nl();
  helpl=9;
  prt(2,"File mask: ");
  input(s,12);
  if (s[0]==0)
    strcpy(s,"*.*");
  if (strchr(s,'.')==NULL)
    strcat(s,".*");
  align(s);
  nl();
}


void listfiles()
{
  char s[81];
  int i,abort,next=0;
  uploadsrec u;

  dliscan();
  file_mask(s);
  abort=0;
  num_listed=0;
  printtitle(&abort);
  for (i=1; (i<=numf) && (!abort) && (!hangup); i++) {
    SETREC(i);
    read(dlf,(void *)&u,sizeof(uploadsrec));
    if (compare(s,u.filename))
      printinfo(&u,&abort);
    else if (!empty())
      checka(&abort,&next);
  }
  closedl();
  if (!abort) {
    nl();
    nl();
    sprintf(s,"Files listed: %d",num_listed);
    pl(s);
    nl();
  }
}


void nscandir(int d, int *abort,int title)
{
  int i,od,dt,next=0;
  uploadsrec u;
  char s[81];

  if ((dir_dates[udir[d].subnum]) && (dir_dates[udir[d].subnum]<nscandate))
    return;

  od=curdir;
  curdir=d;
  dt=title;
  dliscan();
  if (this_date>=nscandate) {
    for (i=1; (i<=numf) && (!(*abort)) && (!hangup); i++) {
      SETREC(i);
      read(dlf,(void *)&u,sizeof(uploadsrec));
      if (u.daten>=nscandate) {
        if (dt) {
          printtitle(abort);
          dt=0;
        }
        printinfo(&u,abort);
      } else if (!empty())
        checka(abort,&next);

    }
  }
  closedl();
  curdir=od;
}


void nscanall()
{
  int abort,i,i1;
  char s[81];

  abort=0;
  num_listed=0;
  for (i=0; (i<64) && (!abort) && (udir[i].subnum!=-1); i++) {
    i1=udir[i].subnum;
    if (i1>=32) {
      if (thisuser.nscn2 & (1L << (i1-32)))
        nscandir(i,&abort,1);
    } else {
      if (thisuser.nscn1 & (1L << i1))
        nscandir(i,&abort,1);
    }
  }
  if ((num_listed) && (!abort)) {
    nl();
    nl();
    sprintf(s,"Files listed: %d",num_listed);
    pl(s);
    nl();
  }
}


void searchall()
{
  int i,i1,pts,abort,pty,ocd,next=0;
  char s[81],s1[81];
  uploadsrec u;

  abort=0;
  ocd=curdir;
  if (x_only) {
    strcpy(s,"*.*");
    align(s);
  } else {
    nl();
    nl();
    pl("Search all directories.");
    file_mask(s);
  }
  num_listed=0;
  for (i=0; (i<64) && (!abort) && (!hangup) && (udir[i].subnum!=-1); i++) {
    i1=udir[i].subnum;
    pts=0;
    if (i1>=32) {
      if (thisuser.nscn2 & (1L << (i1-32)))
        pts=1;
    } else {
      if (thisuser.nscn1 & (1L << i1))
        pts=1;
    }
    pts=1;
    /* remove pts=1 to search only marked directories */
    if (pts) {
      curdir=i;
      dliscan();
      pty=1;
      for (i1=1; (i1<=numf) && (!abort) && (!hangup); i1++) {
        SETREC(i1);
        read(dlf,(void *)&u,sizeof(uploadsrec));
        if (compare(s,u.filename)) {
          if (pty) {
            printtitle(&abort);
            pty=0;
          }
          printinfo(&u,&abort);
        } else if (!empty())
          checka(&abort,&next);
      }
      closedl();
    }
  }
  curdir=ocd;
  if ((num_listed) && (!abort)) {
    nl();
    nl();
    sprintf(s,"Files listed: %d",num_listed);
    pl(s);
    nl();
  }
}



int recno(char *s)
{
  int i;
  uploadsrec u;

  i=1;
  if (numf<1)
    return(-1);
  SETREC(i);
  read(dlf,(void *)&u,sizeof(uploadsrec));
  while ((i<numf) && (compare(s,u.filename)==0)) {
    ++i;
    SETREC(i);
    read(dlf,(void *)&u,sizeof(uploadsrec));
  }
  if (compare(s,u.filename))
    return(i);
  else
    return(-1);
}


int nrecno(char *s,int i1)
{
  int i;
  uploadsrec u;

  i=i1+1;
  if ((numf<1) || (i1>=numf))
    return(-1);

  SETREC(i);
  read(dlf,(void *)&u,sizeof(uploadsrec));
  while ((i<numf) && (compare(s,u.filename)==0)) {
    ++i;
    SETREC(i);
    read(dlf,(void *)&u,sizeof(uploadsrec));
  }
  if (compare(s,u.filename))
    return(i);
  else
    return(-1);
}


int printfileinfo(uploadsrec *u, int dn)
{
  char s[81];
  double d;
  int i,abort;

  if (modem_speed)
    d=((double) (((u->numbytes)+127)/128)) *
      (1620.0) /
      ((double) (modem_speed));
  else
    d=0.0;
  npr("Filename   : %s\r\n", stripfn(u->filename));
  npr("Description: %s\r\n", u->description);
  npr("File size  : %dk\r\n", ((u->numbytes)+1023)/1024);
  npr("Apprx. time: %s\r\n", ctim(d));
  npr("Uploaded on: %s\r\n", u->date);
  npr("Uploaded by: %s\r\n", u->upby);
  npr("Times D/L'd: %d\r\n", u->numdloads);
  nl();
  abort=0;
  if (u->mask & mask_extended) {
    pl("Extended Description: ");
    print_extended(u->filename,&abort,255,0);
  }

  sprintf(s,"%s%s",directories[dn].path,u->filename);
  if (!exist(s)) {
    nl();
    pl("->FILE NOT THERE<-");
    nl();
    return(-1);
  }

  if (nsl()>=d)
    return(1);
  else
    return(0);
}


void upload(int dn)
{
  directoryrec d;
  uploadsrec u,u1;
  int i,i1,i2,i3,i4,ok,xfer,f;
  char s[255],s1[81],*ss;
  long l;
  double ti;

  dliscan1(dn);
  d=directories[dn];
  if (numf>=d.maxfiles) {
    nl();
    nl();
    pl("This directory is currently full.");
    nl();
    closedl();
    return;
  }
  if ((d.mask & mask_no_uploads) && (!dcs())) {
    nl();
    nl();
    pl("Uploads are not allowed to this directory.");
    nl();
    closedl();
    return;
  }
  nl();
  l=(long)freek1(d.path);
  sprintf(s,"Upload - %ldk free.",l);
  pl(s);
  nl();
  if (l<100) {
    pl("Not enough disk space to upload here.");
    nl();
    closedl();
    return;
  }
  prt(2,"Filename: ");
  input(s,12);
  if (!okfn(s))
    s[0]=0;
  align(s);
  if (strchr(s,'?')) {
    closedl();
    return;
  }
  if (d.mask & mask_archive) {
    ok=0;
    s1[0]=0;
    for (i=0; i<4; i++) {
      if (syscfg.arcs[i].extension[0] && syscfg.arcs[i].extension[0]!=' ') {
        if (s1[0])
          strcat(s1,", ");
        strcat(s1,syscfg.arcs[i].extension);
        if (strcmp(s+9,syscfg.arcs[i].extension)==0)
          ok=1;
      }
    }
    if (!ok) {
      nl();
      pl("Sorry, all uploads to this dir must");
      pl("be archived.  Supported types are:");
      pl(s1);
      nl();
      closedl();
      return;
    }
  }
  strcpy(u.filename,s);
  u.ownerusr=usernum;
  u.ownersys=0;
  u.numdloads=0;
  u.filetype=0;
  u.mask=0;
  strcpy(u.upby,nam1(&thisuser,usernum,syscfg.systemnumber));
  strcpy(u.date,date());
  nl();
  ok=1;
  xfer=1;
  if (check_batch_queue(u.filename)) {
    ok=0;
    nl();
    pl("That file is already in the batch queue.");
    nl();
  } else {
    sprintf(s1,"Upload '%s' to %s? ",s,d.name);
    if (strcmp(s,"        .   "))
      prt(5,s1);
    else
      ok=0;
  }
  if ((ok) && (yn())) {
    sprintf(s1,"%s%s",d.path,s);
    if (exist(s1)) {
      if (dcs()) {
        xfer=0;
        nl();
        nl();
        pl("File already exists.");
        prt(5,"Add to database anyway? ");
        if (yn()==0)
          ok=0;
      } else {
        nl();
        nl();
        pl("That file is already here.");
        nl();
        ok=0;
      }
    } else
      if (!incom) {
        nl();
        pl("File isn't already there.");
        pl("Can't upload locally.");
        nl();
        ok=0;
      }
    if ((d.mask & mask_PD) && (ok)) {
      nl();
      prt(5,"Is this program PD/Shareware? ");
      if (!yn()) {
        nl();
        pl("This directory is for Public Domain/");
        pl("Shareware programs ONLY.  Please do not");
        pl("upload other programs.  If you have");
        pl("trouble with this policy, please contact");
        pl("the sysop.");
        nl();
        sprintf(s,"Wanted to upload '%s'",u.filename);
        add_ass(5,s);
        ok=0;
      } else
        u.mask=mask_PD;
    }
    if (ok) {
      nl();
      pl("Checking for same file in other directories...");
      nl();
      closedl();
      i2=0;
      for (i=0; (i<MAX_DIRS) && (udir[i].subnum!=-1); i++) {
        sprintf(s,"Scanning %s",directories[udir[i].subnum].name);
        for (i3=i4=strlen(s); i3<i2; i3++) {
          s[i3]=' ';
          s[i3+1]=0;
        }
        i2=i4;
        npr("%s\r",s);

        dliscan1(udir[i].subnum);
        i1=recno(u.filename);
        closedl();
        if (i1>=0) {
          npr("\r\nSame file found on %s.\r\n",directories[udir[i].subnum].name);
          if (dcs()) {
            nl();
            prt(5,"Upload anyway? ");
            if (!yn()) {
              ok=0;
              break;
            }
            nl();
          } else {
            ok=0;
            break;
          }
        }
      }
      for (i1=0; i1<i2; i1++)
        s[i1]=' ';
      s[i1]=0;
      npr("%s\r",s);
      if (ok)
        dliscan1(dn);
      nl();
    }
    if (ok) {
      nl();
      pl("Please enter a one line description.");
      outstr(": ");
      inputl(u.description,58);
      nl();
      ss=NULL;
      modify_extended_description(&ss);
      if (ss) {
        add_extended_description(u.filename,ss);
        u.mask |= mask_extended;
        farfree(ss);
      }
      nl();
      if (xfer) {
        ti=timer();
        receive_file(s1,&ok,&u.filetype, u.filename, dn);
        ti=timer()-ti;
        if (ti<0)
          ti += 24.0*3600.0;
        thisuser.extratime += ti;
      }
      if (ok) {
        if (ok==1) {
          f=open(s1,O_RDONLY | O_BINARY);
          if (f<0) {
            ok=0;
            nl();
            nl();
            pl("DOS error - File not found.");
            nl();
            if (u.mask & mask_extended)
              delete_extended_description(u.filename);
          }
          if (ok && syscfg.upload_c[0]) {
            close(f);
            pl("Please wait...");
            if (check_ul_event(dn,&u)) {
              if (u.mask & mask_extended)
                delete_extended_description(u.filename);
              ok=0;
            } else {
              f=open(s1,O_RDONLY | O_BINARY);
            }
          }
        }
        if (ok) {
          if (ok==1) {
            l=filelength(f);
            u.numbytes=l;
            close(f);
            ++thisuser.uploaded;
            thisuser.uk += ((l+1023)/1024);
          } else
            u.numbytes=0;
          time(&l);
          u.daten=l;
          for (i=numf; i>=1; i--) {
            SETREC(i);
            read(dlf,(void *)&u1,sizeof(uploadsrec));
            SETREC(i+1);
            write(dlf,(void *)&u1,sizeof(uploadsrec));
          }
          SETREC(1);
          write(dlf,(void *)&u,sizeof(uploadsrec));
          ++numf;
          SETREC(0);
          read(dlf, &u1, sizeof(uploadsrec));
          u1.numbytes=numf;
          u1.daten=l;
          dir_dates[dn]=l;
          SETREC(0);
          write(dlf,(void *)&u1,sizeof(uploadsrec));
          if (ok==1) {
            ++status.uptoday;
            save_status();
            sprintf(s,"+%s uploaded on %s",u.filename,directories[dn].name);
            sysoplog(s);
            nl();
            nl();
            pl("File uploaded.");
            nl();
            npr("Your ratio is now: %-6.3f\r\n", ratio());
            nl();
            nl();
            if (useron)
              topscreen();
          }
        }
      } else {
        nl();
        nl();
        pl("File transmission aborted.");
        nl();
        if (u.mask & mask_extended)
          delete_extended_description(u.filename);
      }
    }
  }
  closedl();
}


/****************************************************************************/
int try_to_download(char *s, int dn,int title)
{
  int i,ok,sent,abort=0,next=0,i1;
  uploadsrec u;
  char s1[81];

  dliscan1(dn);
  i=recno(s);
  if (i<=0) {
    closedl();
    abort=next=0;
    checka(&abort,&next);
    if (abort)
      return(-1);
    else
      return(0);
  }
  ok=1;
  foundany=1;
  while ((i>0) && (ok) && (!hangup)) {
    if (!ratio_ok()) {
      closedl();
      return(-1);
    }
    tleft(1);
    SETREC(i);
    read(dlf,(void *)&u,sizeof(uploadsrec));
    nl();
    if (title)
      npr("Directory  : %s\r\n",directories[dn].name);
    i1=printfileinfo(&u,dn);
    {
      if ((i1) || (strncmp(u.filename,"WWIV4",5)==0)) {
        sprintf(s1,"%s%s",directories[dn].path,u.filename);
        sent=0;
        abort=0;
        if (i1==-1)
          send_file(s1,&sent,&abort,u.filetype,u.filename,dn, -2L);
        else
          send_file(s1,&sent,&abort,u.filetype,u.filename,dn, u.numbytes);
        if (sent) {
          ++thisuser.downloaded;
          thisuser.dk += (int) ((u.numbytes+1023)/1024);
          ++u.numdloads;
          SETREC(i);
          write(dlf,(void *)&u,sizeof(uploadsrec));
          sprintf(s1,"Downloaded '%s'",u.filename);
          sysoplog(s1);
          nl();
          nl();
          npr("Your ratio is now: %-6.3f\r\n", ratio());
          if (syscfg.sysconfig & sysconfig_log_dl) {
            sprintf(s1,"%s downloaded '%s' on %s",
              nam(&thisuser,usernum), u.filename, date());
            ssm(u.ownerusr,0,s1);
          }
          if (useron)
            topscreen();
        }
      } else {
        nl();
        nl();
        pl("Not enough time left to D/L.");
        nl();
      }
    }
    if (abort)
      ok=0;
    else
      i=nrecno(s,i);
  }
  closedl();
  if (abort)
    return(-1);
  else
    return(1);
}
/****************************************************************************/


void download()
{
  char s[81];
  int dn;

  nl();
  pl("Download -");
  nl();
  prt(2,"Filename: ");
  input(s,12);
  if (s[0]==0)
    return;
  if (strchr(s,'.')==NULL)
    strcat(s,".*");
  align(s);
  if (try_to_download(s,udir[curdir].subnum,0)==0) {
    nl();
    pl("Searching all directories.");
    nl();
    foundany=dn=0;
    while ((dn<64) && (udir[dn].subnum!=-1)) {
      if (try_to_download(s,udir[dn].subnum,1)<0)
        dn=100;
      else
        dn++;
    }
    if (!foundany) {
      pl("File not found.");
      nl();
    }
  }
}


void setldate()
{
  struct date d;
  struct time t;
  char s[81];
  int m,dd,y;

  nl();
  nl();
  unixtodos(nscandate,&d,&t);
  nl();
  sprintf(s,"Current limiting date = %02d/%02d/%02d",d.da_mon,d.da_day,(d.da_year-1900));
  pl(s);
  nl();
  pl("Enter new limiting date in the format:");
  pl(" MM/DD/YY");
  outstr(":");
  input(s,8);
  m=atoi(s);
  dd=atoi(&(s[3]));
  y=atoi(&(s[6]))+1900;
  if ((strlen(s)==8) && (m>0) && (m<=12) && (dd>0) && (dd<32) && (y>=1980)) {
    t.ti_min=0;
    t.ti_hour=0;
    t.ti_hund=0;
    t.ti_sec=0;
    d.da_year=y;
    d.da_day=dd;
    d.da_mon=m;
    sprintf(s,"Current limiting date = %02d/%02d/%02d",m,dd,(y-1900));
    nl();
    pl(s);
    nl();
    nscandate=dostounix(&d,&t);
  }
}


void finddescription()
{
  uploadsrec u;
  int i,i1,i2,abort,pty,d,ocd,pts,next=0;
  char s[81],s1[81];

  nl();
  nl();
  pl("Find description -");
  nl();
  pl("Enter string to search for in file description:");
  outstr(":");
  input(s1,58);
  if (s1[0]==0)
    return;

  ocd=curdir;
  abort=0;
  num_listed=0;
  for (i=0; (i<64) && (!abort) && (!hangup) && (udir[i].subnum!=-1); i++) {
    i1=udir[i].subnum;
    pts=0;
    if (i1>=32) {
      if (thisuser.nscn2 & (1L << (i1-32)))
        pts=1;
    } else {
      if (thisuser.nscn1 & (1L << i1))
        pts=1;
    }
    pts=1;
    /* remove pts=1 to search only marked directories */
    if (pts) {
      curdir=i;
      dliscan();
      pty=1;
      for (i1=1; (i1<=numf) && (!abort) && (!hangup); i1++) {
        SETREC(i1);
        read(dlf,(void *)&u,sizeof(uploadsrec));
        strcpy(s,u.description);
        for (i2=0; i2<strlen(s); i2++)
          s[i2]=upcase(s[i2]);
        if (strstr(s,s1)!=NULL) {
          if (pty) {
            printtitle(&abort);
            pty=0;
          }
          printinfo(&u,&abort);
        } else if (!empty())
          checka(&abort,&next);
      }
      closedl();
    }
  }
  curdir=ocd;
  if ((num_listed) && (!abort)) {
    nl();
    nl();
    sprintf(s,"Files listed: %d",num_listed);
    pl(s);
    nl();
  }
}


void arc_l()
{
  char s[81],s1[81],s2[81];
  int i,abort,next,i1;
  uploadsrec u;

  nl();
  prt(2,"File for listing: ");
  input(s,12);
  if (strchr(s,'.')==NULL)
    strcat(s,".*");
  if (!okfn(s))
    s[0]=0;
  align(s);
  dliscan();
  abort=0;
  next=0;
  i=recno(s);
  do {
    if (i>0) {
      SETREC(i);
      read(dlf,(void *)&u,sizeof(uploadsrec));
      i1=list_arc_out(stripfn(u.filename),directories[udir[curdir].subnum].path);
      if (i1)
        abort=1;
      checka(&abort,&next);
      i=nrecno(s,i);
    }
  } while ((i>0) && (!hangup) && (!abort));
  closedl();
}


/****************************************************************************/


void yourinfodl()
{

  nl();
  nl();
  npr("Uploads  : %ldk in %d files\r\n",thisuser.uk, thisuser.uploaded);
  npr("Downloads: %ldk in %d files\r\n",thisuser.dk, thisuser.downloaded);
  npr("Ratio    : %-6.3f\r\n",ratio());
  npr("Your DSL : %d\r\n",thisuser.dsl);
  nl();
}

void l_config_nscan()
{
  int i,abort,i1;
  char s[81], s2[81];

  abort=0;
  nl();
  pl("Dirs to n-scan marked with '*'");
  nl();
  for (i=0; (i<64) && (udir[i].subnum!=-1) && (!abort); i++) {
    i1=udir[i].subnum;
    if (i1<32) {
      if ((1L << (i1)) & thisuser.nscn1)
        strcpy(s,"* ");
      else
        strcpy(s,"  ");
    } else {
      if ((1L << (i1-32)) & thisuser.nscn2)
        strcpy(s,"* ");
      else
        strcpy(s,"  ");
    }
    sprintf(s2,"%s%s. %s",s,udir[i].keys, directories[i1].name);
    pla(s2,&abort);
  }
  nl();
  nl();
}

void config_nscan()
{
  char *s;
  int i,done,i1;

  l_config_nscan();
  done=0;
  do {
    nl();
    pl("Enter directory identifier, ? to list, or Q to Quit");
    prt(2,"Config: ");
    s=mmkey(1);
    if (s[0])
      for (i=0; i<64; i++)
        if (strcmp(udir[i].keys,s)==0) {
          i1=udir[i].subnum;
          if (i1<32)
            thisuser.nscn1 ^= ((1L) << i1);
          else
            thisuser.nscn2 ^= ((1L) << (i1-32));
        }
    if (strcmp(s,"Q")==0)
      done=1;
    if (strcmp(s,"?")==0)
      l_config_nscan();
  } while ((!done) && (!hangup));
}


void xfer_defaults()
{
  char s[81],s1[81],ch;
  int i,i1,i2,done;

  done=0;
  do {
    outchr(12);
    pl("1. Set N-Scan Directories.");
    pl("2. Set Default Protocol.");
    sprintf(s,"3. N-Scan Transfer after Message Base (%s).",
      thisuser.sysstatus & sysstatus_nscan_file_system?"Yes":"No");
    pl(s);
    sprintf(s,"4. Number of lines of extended description to print (%d line%s).",
      thisuser.num_extended,thisuser.num_extended==1?"":"s");
    pl(s);
    pl("Q. Quit.");
    nl();
    prt(2,"Which? ");
    helpl=32;
    ch=onek("Q1234");
    switch(ch) {
      case 'Q':
        done=1;
        break;
      case '1':
        helpl=24;
        config_nscan();
        break;
      case '2':
        nl();
        nl();
        pl("Enter your default protocol, 0 for none.");
        nl();
        helpl=40;
        i=get_protocol(xf_down);
        if (i>=0)
          thisuser.defprot=i;
        break;
      case '3':
        nl();
        nl();
        pl("Do you want to perform a newscan of all selected transfer");
        outstr("directories after an N-scan of the message base? ");
        if (thisuser.sysstatus & sysstatus_nscan_file_system)
          thisuser.sysstatus -= sysstatus_nscan_file_system;
        if (yn())
          thisuser.sysstatus += sysstatus_nscan_file_system;
        break;
      case '4':
        nl();
        nl();
        pl("How many lines of an extended description");
        pl("do you want to see when listing files (0-10)");
        npr("(Currently set to %d lines)\r\n",thisuser.num_extended);
        prt(5,"? ");
        helpl=41;
        input(s,3);
        if (s[0]) {
          i=atoi(s);
          if ((i>=0) && (i<=10))
            thisuser.num_extended=i;
        }
        break;
    }
  } while ((!done) && (!hangup));

}


void removefile()
{
  int i,i1,ok,rm,abort,rdlp;
  char ch,s[81],s1[81];
  uploadsrec u;
  userrec uu;

  dliscan();
  nl();
  pl("Enter filename to remove.");
  outstr(":");
  mpl(12);
  input(s,12);
  if (s[0]==0) {
    closedl();
    return;
  }
  if (strchr(s,'.')==NULL)
    strcat(s,".*");
  align(s);
  i=recno(s);
  abort=0;
  while ((!hangup) && (i>0) && (!abort)) {
    SETREC(i);
    read(dlf,(void *)&u,sizeof(uploadsrec));
    if ((dcs()) || ((u.ownersys==0) && (u.ownerusr==usernum))) {
      nl();
      if (check_batch_queue(u.filename)) {
        pl("That file is in the batch queue; remove it from there.");
        nl();
      } else {
        printfileinfo(&u,udir[curdir].subnum);
        prt(2,"Remove (Y/N/Q) : ");
        ch=onek("QNY");
        if (ch=='Q')
          abort=1;
        if (ch=='Y') {
          rdlp=1;
          if (dcs()) {
            prt(5,"Delete file too? ");
            rm=yn();
            if (rm) {
              prt(5,"Remove DL points? ");
              rdlp=yn();
            }
          } else
            rm=1;
          if (rm) {
            sprintf(s1,"%s%s",directories[udir[curdir].subnum].path,u.filename);
            unlink(s1);
            if ((rdlp) && (u.ownersys==0)) {
              read_user(u.ownerusr,&uu);
              if ((uu.inact & inact_deleted)==0) {
                --uu.uploaded;
                uu.uk -= ((u.numbytes+1023)/1024);
                write_user(u.ownerusr,&uu);
              }
              close_user();
            }
          }
          if (u.mask & mask_extended)
            delete_extended_description(u.filename);
          sprintf(s1,"-%s Removed off of %s",u.filename,
                            directories[udir[curdir].subnum].name);
          sysoplog(s1);
          for (i1=i; i1<numf; i1++) {
            SETREC(i1+1);
            read(dlf,(void *)&u,sizeof(uploadsrec));
            SETREC(i1);
            write(dlf,(void *)&u,sizeof(uploadsrec));
          }
          --i;
          --numf;
          SETREC(0);
          read(dlf, &u, sizeof(uploadsrec));
          u.numbytes=numf;
          SETREC(0);
          write(dlf,(void *)&u,sizeof(uploadsrec));
        }
      }
    }
    i=nrecno(s,i);
  }
  closedl();
}


