#include "vars.h"

#pragma hdrstop


void read_automessage()
{
  int i;
  messagerec m;

  m.storage_type=3;
  read_message1(&m,0,0,&i,"Auto.msg",0,"",0,"");
}


void write_automessage()
{
  int i,i1,f;
  messagerec m;
  postrec p;

  m.storage_type=3;
  upload_post();
  i=inmsg(&m,p.title,&i1,0,"auto.msg",1);
  if(i) {
     status.amsganon=i1;
     status.amsguser=usernum;
     logpr("5�> Changed Automessage");
  }
}


void addbbs(char *fn)
{
  int i,i1,i2,f,ok;
  char s[150],s1[150],s2[150],ch,ch1,*ss,s3[40],s4[40],final[150],form[40];
  long l,l1;
  FILE *format;

   nl();
   npr("3Please enter phone number\r\n5: ");
   mpl(12);
   input(s,12);

   if ((s[3]!='-') || (s[7]!='-'))
     s[0]=0;

   if (strlen(s)==12) {
     ok=1;
     sprintf(s1,"%s%s",syscfg.gfilesdir,fn);

     f=open(s1,O_RDWR | O_CREAT | O_BINARY, S_IREAD | S_IWRITE);
     if (f>0) {
       lseek(f,0L,SEEK_SET);
       l=filelength(f);
       if ((ss=malloca(l+500L))==NULL) {
         close(f);
         return;
       }
       read(f,ss,(int)l);
       l1=0L;
       while ((l1<l) && (ok)) {
         i=0;
         do {
           ch=ss[l1++]; s1[i]=ch;
           if (ch==13) s1[i]=0;
           ++i;
         } while ((ch!=10) && (i<120) && (l1<l));
         if (strstr(s1,s)!=NULL)
           ok=0;
        if (!strncmp(s1,s,12))
            ok=0;
     }
       farfree(ss);
       close(f);
     }

     if(!ok) {
        nl();
        pl("7Sorry, but that number is already in the BBS list.");
        nl();
        return;
     }

     if(ok) {
       pl("Number not yet in BBS list.");
       nl();
       npr("3Enter BBS name and comments\r\n5: ");
       mpl(46);
       inputl(s1,40);
       npr("3Enter maximum speed of the BBS\r\n5: ");
       mpl(5);
       input(s2,5);
       npr("3Enter BBS type (Dominion)\r\n5: ");
       mpl(8);
       input(s3,8);
       nl();

       sprintf(form,"%sbbslist.fmt",syscfg.gfilesdir);
       format=fopen(form,"rt");
       fgets(form,41,format);
       fclose(format);
       filter(form,'\n');

       strcpy(final,s1);
       sprintf(s1,"%-40s",final);
       strcpy(final,s2);
       sprintf(s2,"%-5s",final);
       strcpy(final,s3);
       sprintf(s3,"%-8s",final);

       stuff_in(final,form,s,s1,s2,s3,"");
       pl(final);
       nl();
       prt(5,"Is this correct? ");
       if (yn()) {
         logpr("5�> Added to BBSlist:0 %s, %s",s,s1);
         strcat(final,"\n");
         sprintf(s1,"%s%s",syscfg.gfilesdir,fn);
         f=open(s1,O_RDWR | O_CREAT | O_BINARY, S_IREAD | S_IWRITE);
         if (filelength(f)) {
           lseek(f,-1L,SEEK_END);
           read(f,((void *)&ch1),1);
           if (ch1==26)
             lseek(f,-1L,SEEK_END);
         }
         write(f,(void *)final,strlen(final));
         close(f);
         nl();
         pl("Added to BBS list.");
         nl();
       }
     }
  }
}

void searchbbs(char *fn)
{
    FILE *f;
    char s[150],s1[20],s2[150];


    nl();
    npr("3Enter Text to Search For\r\n5: ");
    mpl(20);
    input(s1,20);
    if(!s1[0]) return;

    sprintf(s,"%s%s",syscfg.gfilesdir,fn);
    f=fopen(s,"rt");
    while((fgets(s2,150,f))!=NULL) {
        filter(s2,'\n');
        strcpy(s,noc2(s2));
        strupr(s);
        if(strstr(s,s1)) {
            pl(s2);
            pausescr();
        }
    }
    nl();
    fclose(f);
}



void kill_old_email()
{
  int cur,max,i,i1,f,done,done1,forward;
  char s[81],s1[81],ch;
  long l;
  mailrec m;
  userrec u;
  slrec ss;

  prt(5,"List mail starting at most recent? ");
  forward=(yn());
  ss=syscfg.sl[actsl];
  sprintf(s,"%sEMAIL.DAT",syscfg.datadir);
  f=open(s,O_RDWR | O_BINARY);
  if (f==-1) {
    nl();
    pl("No mail.");
    return;
  }
  max=(int) (filelength(f) / sizeof(mailrec));
  if (forward)
    cur=max-1;
  else
    cur=0;
  done=0;
  do {
    lseek(f,((long) cur) * sizeof(mailrec), SEEK_SET);
    read(f,(void *)&m,sizeof(mailrec));
    while (((m.fromsys!=0) || (m.fromuser!=usernum) || (m.touser==0)) && (cur<max) && (cur>=0)) {
      if (forward)
        --cur;
      else
        ++cur;
      if ((cur<max) && (cur>=0)) {
        lseek(f,((long) cur) * sizeof(mailrec), SEEK_SET);
        read(f,(void *)&m,sizeof(mailrec));
      }
    }
    if ((m.fromsys!=0) || (m.fromuser!=usernum) || (m.touser==0) || (cur>=max) || (cur<0))
      done=1;
    else {
      do {
        done1=0;
        nl();
        if (m.tosys==0) {
          read_user(m.touser,&u);
          strcpy(s1,nam(&u,m.touser));
          if ((m.anony & (anony_receiver | anony_receiver_pp | anony_receiver_da))
              && ((ss.ability & ability_read_email_anony)==0))
            strcpy(s1,">UNKNOWN<");
          npr("To   : %s\r\n",s1);
        } else {
          npr("To   : User %d, system %d\r\n", m.touser, m.tosys);
        }
        npr("Title: %s\r\n",m.title);
        time(&l);
        i=(int) ((l-m.daten)/24.0/3600.0);
        npr("Sent : %d days ago\r\n",i);
        nl();
        prt(2,"R:ead, D:elete, N:ext, Q:uit : ");
        ch=onek("QRDN");
        switch(ch) {
          case 'Q':
            done1=1;
            done=1;
            break;
          case 'N':
            done1=1;
            if (forward)
              --cur;
            else
              ++cur;
            if ((cur>=max) || (cur<0))
              done=1;
            break;
          case 'D':
            done1=1;
            delmail(f,cur);
            nl();
            pl("Mail deleted.");
            nl();
            sysoplog("Deleted mail.");
            break;
          case 'R':
            nl();
            setorigin(0,0);
            read_message1(&m.msg,(m.anony & 0x0f), 0, &i1,"EMAIL",1,"",0,nam(&thisuser,usernum));
            break;
        }
      } while ((!hangup) && (!done1));
    }
  } while ((!done) && (!hangup));
  close(f);
}

void list_users()
{
  subboardrec s;
  userrec u;
  int i,nu,abort,ok,num;
  char st[161];

  if (usub[cursub].subnum==-1) {
    nl();
    pl("No sub!");
    nl();
    return;
  }
  s=subboards[usub[cursub].subnum];
  nl();
  pl("Users with access to current sub:");
  nl();
  npr("%-40s [%-20s]\r\n","Users Name","Computer Type");
  abort=0;
  num=0;
  for (i=0; (i<status.users) && (!abort) && (!hangup); i++) {
    read_user(smallist[i].number,&u);
    ok=1;
    if (u.sl<s.readsl)
      ok=0;
    if (u.age<s.age)
      ok=0;
    if ((s.ar!=0) && ((u.ar & s.ar)==0))
      ok=0;
    if (ok) {
      sprintf(st,"3%-40s 1[2%-20s1]",nam(&u,smallist[i].number),ctypes[u.comp_type]);
      pla(st,&abort);
      ++num;
    }
  }
  if (!abort) {
    nl();
    npr("%d users.\r\n",num);
    nl();
  }
}

void print_quest(int f, int mapp, int map[21])
{
  char s[100];
  int i,abort;
  votingrec v;

  outchr(12);
  abort=0;
  for (i=1; (i<=mapp) && (abort==0); i++) {
    lseek(f,((long) (map[i])) * sizeof(votingrec), SEEK_SET);
    read(f,(void *)&v,sizeof(votingrec));
    sprintf(s,"%c %2d: %s",thisuser.votes[map[i]]?' ':'*',i, v.question);
    pla(s,&abort);
  }
  nl();
  if (abort)
    nl();
}


int print_question(int f, int i, int ii)
{
  char s[81],s1[81],s2[81],s3[81];
  char item[81],item1[81],item2[81],item3[81];
  int i1,i2,i3,t,t1,abort;
  unsigned int percentile;
  votingrec v;
  voting_response vr;

  lseek(f,((long) ii)*sizeof(votingrec),SEEK_SET);
  read(f,(void *)&v,sizeof(votingrec));
  abort=0;

  outchr(12);
  sprintf(s,"[%02d]:  %s",i,v.question);
  dtitle(s);
  t=0;
  for (i1=0; i1<v.numanswers; i1++) {
    vr=v.responses[i1];
    t+=vr.numresponses;
  }

  if (t)
    t1=t;
  else
    t1=1;
  for (i1=0; i1<5; i1++)
    odc[i1]=0;

  for (i1=0; (i1<v.numanswers) && (!abort); i1++) {
/*    if (((i1+1) % 10)==0)
      odc[((i1+1)/10)-1]='0'+((i1+1)/10);*/
    sprintf(item,"  %2d.  ",(i1+1));
    vr=v.responses[i1];
    sprintf(item3,"%3d",vr.numresponses);
    ltoa((((long)vr.numresponses) * 1000L) / ((long)t1),s1,10);
    i2=strlen(s1);
    if (i2>1) {
      strcpy(s2,s1);
      s2[i2-1]='.';
      s2[i2]=s1[i2-1];
      s2[i2+1]=0;
    } else {
      strcpy(s2,"0.");
      strcat(s2,s1);
    }
    for (i2=0; i2<5-strlen(s2); i2++)
      strcat(s," ");
    strcpy(s,s2);
    strcat(s,"%");
    sprintf(item1,"%6s",s);
    strcat(s,vr.response);
    sprintf(item2,"%s",vr.response);
    sprintf(s,"0%s5[4%s:%s5]4 %s",item,item3,item1,item2);
    for (i2=strlen(s); i2<78; i2++)
      s[i2]=32;
    s[78]=0;
    pla(s,&abort);

  }
  pl("Here 1");

  npr("  0%2d.  5[1���:������5]2 <Pick This to Add Your Own Answer>",i1+1);

  nl();
  nl();
  pl("here");
/*  ltoa( (((long)t) * 1000L) / ((long)status.users),s1,10);
  pl("Figuring out average");
  i2=strlen(s1);
  if (i2>1) {
    strcpy(s2,s1);
    s2[i2-1]='.';
    s2[i2]=s1[i2-1];
    s2[i2+1]=0;
  } else {
    strcpy(s2,"0.");
    strcat(s2,s1);
  }
  pl("copying to make average");
  strcpy(s,"Users voting: ");
  strcat(s,s2);
  strcat(s,"%");
  pla(s,&abort);
  if (abort)
    nl();   */
  pl("Here 2");
//  return(!abort);
}



void vote_question(int f, int i, int ii)
{
  int ok,pqo,i1,i2;
  char s[81],*ss;
  votingrec v;
  voting_response vr;

  pqo=print_question(f,i,ii);
  pl("Done with p_q");
  ok=pqo;
  ok=1;
  if (restrict_vote & thisuser.restrict)
    ok=0;
  if (actsl<=10)
    ok=0;
  if (!ok)
    return;

  lseek(f,((long) ii)*sizeof(votingrec),SEEK_SET);
  read(f,(void *)&v,sizeof(votingrec));

  if(thisuser.votes[ii]) {
    npr("Your Vote: %s",v.responses[thisuser.votes[ii]-1].response);
    nl();
    prt(5,"Change it? ");
    if (!yn())
      return;
  }

  prt(2,"Which? ");
  input(ss,2);
  nl();
  i1=atoi(ss);
  if(i1==v.numanswers+1) {
    thisuser.votes[ii]=add_question(ii,v);
    nl();
    nl();
    return;
  }
  if (i1>v.numanswers)
    i1=0;
  if ((i1==0) && (strcmp(ss,"0")))
    return;

  if (thisuser.votes[ii]) {
    vr=v.responses[thisuser.votes[ii]-1];
    --vr.numresponses;
    v.responses[thisuser.votes[ii]-1]=vr;
  }
  thisuser.votes[ii]=i1;
  if (i1) {
    vr=v.responses[thisuser.votes[ii]-1];
    ++vr.numresponses;
    v.responses[thisuser.votes[ii]-1]=vr;
  }
  lseek(f,((long) ii)*sizeof(votingrec),SEEK_SET);
  write(f,(void *)&v,sizeof(votingrec));
  nl();
  nl();
}


void vote()
{
  int i,i1,i2,f,map[21],mapp,abort,n,done;
  char s[81],s1[81],s2[81],sodc[10],*ss;
  votingrec v;

  readvotingdata();
  sprintf(s,"%sVOTING.DAT",syscfg.datadir);
  f=open(s,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
  n=(int) (filelength(f) / sizeof(votingrec)) -1;
  if (n<20) {
    v.question[0]=0;
    v.numanswers=0;
    for (i=n; i<20; i++)
      write(f,(void *)&v,sizeof(votingrec));
  }
  mapp=0;
  for (i=0; i<5; i++) odc[i]=0;
  for (i=0; i<20; i++) {
    lseek(f,((long) i) * sizeof(votingrec),SEEK_SET);
    read(f,(void *)&v,sizeof(votingrec));
    if (v.numanswers) {
      map[++mapp]=i;
      if ((mapp % 10)==0)
        odc[(mapp/10)-1]='0'+(mapp/10);
    }
  }
  strcpy(sodc,odc);
  if (mapp==0) {
    nl();
    nl();
    pl(get_string(46));
    nl();
    close(f);
    return;
  }
  print_quest(f,mapp,&map[0]);
  done=0;
  do {
    nl();
    nl();
    outstr(get_string(45));
    strcpy(odc,sodc);
    ss=mmkey(2);
    i=atoi(ss);
    if ((i>0) && (i<=mapp)) vote_question(f,i,map[i]);
    else if(!strcmp(ss,"Q")) done=1;
    else if(!strcmp(ss,"?")) print_quest(f,mapp,&map[0]);
    else if(!strcmp(ss,"A"))
         for(i=0;i<=mapp;i++) if(!thisuser.votes[i-1]) vote_question(f,i,map[i]);
  } while ((!done) && (!hangup));
  close(f);
}

void dtitle(char msg[81])
{
    FILE *f;
    char s[81],b1,b2,s1[81],bs2[81],bs1[81];
    int i;

    sprintf(s,"%sbox.fmt",syscfg.gfilesdir);
    f=fopen(s,"rt");
    strcpy(s,msg);
    noc(msg,s);
    fgets(s,4,f);
    b1=s[0];
    b2=s[1];
    for(i=0;i<strlenc(msg);i++) {
        bs1[i]=b1;
        bs2[i]=b2;
    }
    bs1[i]=0;
    bs2[i]=0;
    while(fgets(s,81,f)!=NULL) {
        filter(s,'\n');
        stuff_in(s1,s,msg,bs1,bs2,"","");
        pl(s1);
    }
    fclose(f);
}


