#include "vars.h"
#pragma hdrstop
#include <dir.h>


#define LEN 161
#define ALLOW_FULLSCREEN 1
#define EMAIL_STORAGE 2

int deleted_flag;
extern commstr[41];


char *ini(char name[81])
{
    char o[81];
    int i=0,p=0;

    memset(o,0,81);

    for(i=0;name[i];i++) {
        if ((name[i]>='A') && (name[i]<='Z'))
            o[p++]=name[i];
    }

    return(o);
}

void quote_message(messagerec *m1, char *aux)
{
    char *b,*c,s1[81],quotefrom[10],s[81];
    int cc,dq,lc,f,ok,mc,i;
    long l,l1,l2,l3,l4;
    messagerec m;

    m=*m1;
    b=readfile(&m,aux,&l);
    if (b==NULL)
        return;
    if ((c=malloca(l+1000L))==NULL) {
        farfree(b);
        return;
    }
    lc=0; 
    l1=0; 
    l2=0; 
    ok=1;

    do {
        if (b[l1]==10)
            lc++;
        l1++;
    } 
    while (lc<3);

    lc=0; 
    dq=1; 
    cc=48;

    strcpy(quotefrom,ini(irt_name));

    do {
        if (lc==0) {
            for (f=0; f<dq; f++) {
                c[l2++]=3; 
                lc++;
                c[l2++]='5'; 
                lc++;
                for(i=0;i<strlen(quotefrom);i++)
                    c[l2++]=quotefrom[i]; 
                lc++;
                c[l2++]=3; 
                lc++;
                c[l2++]='3'; 
                lc++;
                c[l2++]='�'; 
                lc++;
                c[l2++]=3; 
                lc++;
                c[l2++]='0'; 
                lc++;
            }
            if (dq==1) {
                c[l2++]=' '; 
                lc++;
            }
            if (cc!=48) {
                c[l2++]=3;
                c[l2++]=cc;
            }
        }
        switch(b[l1]) {
        case 1:
            if (b[l1-1]!=32)
                c[l2++]=' ';
            l1+=3;
            break;
        case 3:
            l1++;
            cc=b[l1++];
            c[l2++]=3;
            c[l2++]=cc;
            break;
        case 14:
            l1++;
            cc=b[l1++];
            c[l2++]=14;
            c[l2++]=cc;
            break;
        case 4:
            l1+=2;
            break;
        case 13:
            if ((b[l1+2]>96) && (b[l1+2]<123)) {
                if (b[l1-1]!=32)
                    c[l2++]=' ';
                l1+=2;
            } 
            else {
                lc=0; 
                l1+=2;
                if (dq==1) {
                    cc=48;
                    c[l2++]=3;
                    c[l2++]=48;
                }
                dq=1;
                /*          while (b[l1]=='>') {
                            dq++; l1++;
                          }*/
                if (dq>=6)
                    ok=0;
                c[l2++]=13;
                c[l2++]=10;
            }
            break;
        default:
            c[l2++]=b[l1++];
            lc++;
            break;
        }
        if (dq==1)
            mc=72;
        else
            mc=78;
        if (lc>=mc) {
            l3=l1; 
            l4=l2;
            while ((b[l1]!=32) && (lc>0)) {
                --l1; 
                --l2; 
                --lc;
                if ((b[l1]==3) || (b[l1]==4))
                    lc+=2;
                if (b[l1]==1) {
                    l2+=3; 
                    lc+=3;
                }
                if ((b[l1]==13) && (b[l1-1]>4)) {
                    lc+=2;
                }
            }
            if (lc<=1) {
                l1=l3; 
                l2=l4;
            } 
            else {
                lc=0;
                l1++;
            }
            c[l2++]=13;
            c[l2++]=10;
        }
    } 
    while ((l1<l) && (l2<l+998L) && (ok));
    c[l2++]=0;
    if (ok) {
        sprintf(s1,"%sQUOTE.MSG",syscfg.tempdir);
        f=open(s1,O_RDWR | O_BINARY | O_CREAT | O_TRUNC, S_IREAD | S_IWRITE);
//        sprintf(s,"%s Was Saying...",irt_name);
//        write(f,&s,strlen(s));
        write(f,(void *)c,l2);
        close(f);
        farfree(b);
        farfree(c);
        f=open(s1,O_RDONLY | O_BINARY);
        l2=filelength(f);
        if ((quote=malloca(l2))!=NULL)
            read(f,(void *) quote,l2);
        close(f);
        unlink(s1);
    }
}

unsigned short find_host(unsigned int type)
{
    char s[121],*ss,*b;
    int f;
    FILE *fi;
    unsigned int ui=0,ui1;
    long len1,len2;

    sprintf(s,"%sNNALL.NET", syscfg.datadir);
    fi=fopen(s,"r");
    if (fi) {
        while (fgets(s,120,fi)) {
            ss=strtok(s," \r\n\t");
            if (ss) {
                ui1=(unsigned short) atol(ss);
                if (ui1==type) {
                    ss=strtok(NULL," \r\n\t");
                    if (ss) {
                        ui=(unsigned short) atol(ss);
                    }
                }
            }
        }
        fclose(fi);
    }

    if (!ui) {
        sprintf(s,"%sNN%u.NET",syscfg.datadir,type);
        f=open(s,O_RDONLY | O_BINARY);
        if (f>0) {
            len1=filelength(f);
            if ((b=malloca(len1+100L))!=NULL) {
                lseek(f,0L,SEEK_SET);
                read(f,(void *)b,len1);
                b[len1]=0;
                close(f);
                len2=0;
                while ((len2<len1) && (!ui)) {
                    while ((len2<len1) && ((b[len2]<'0') || (b[len2]>'9')))
                        ++len2;
                    if ((b[len2]>='0') && (b[len2]<='9') && (len2<len1)) {
                        ui=atoi(&(b[len2]));
                        if (ui==syscfg.systemnumber)
                            ui=0;
                        while ((len2<len1) && (b[len2]>='0') && (b[len2]<='9'))
                            ++len2;
                    }
                }
                farfree(b);
            } 
            else {
                close(f);
            }
        }
    }

    return(ui);
}

/****************************************************************************/

void send_net_post(postrec *p, unsigned int type, char *extra)
{
    net_header_rec nh;
    char *b, *b1,*ss;
    long len1, len2;
    char s[81];
    int f,i;
    unsigned int ui;
    unsigned int *list;

    b=readfile(&(p -> msg),extra,&len1);
    if (b==NULL)
        return;
    nh.tosys=0;
    nh.touser=0;
    if (p -> ownersys)
        nh.fromsys=p -> ownersys;
    else
        nh.fromsys =syscfg.systemnumber;
    nh.fromuser=p -> owneruser;
    nh.main_type=main_type_post;
    nh.minor_type=type;
    nh.list_len=0;
    nh.daten=p -> daten;
    nh.length=len1+1+strlen(p -> title);
    if (nh.length > 32760) {
        npr("Message truncated by %lu bytes for the network.\r\n",nh.length-32760L);
        nh.length = 32760;
        len1=nh.length-strlen(p->title);
    }
    nh.method=0;
    if ((b1=malloca(nh.length+100))==NULL) {
        farfree(b);
        return;
    }
    strcpy(b1,p -> title);
    memmove(&(b1[strlen(p -> title)+1]),b,(unsigned int) len1);
    farfree(b);
    if ((list=malloca(2*(num_sys_list+2)))==NULL) {
        farfree(b1);
        return;
    }
    sprintf(s,"%sN%u.NET",syscfg.datadir,type);
    f=open(s,O_RDONLY | O_BINARY);
    if (f>0) {
        len1=filelength(f);
        if ((b=malloca(len1+100L))==NULL) {
            farfree(list);
            farfree(b1);
            return;
        }
        lseek(f,0L,SEEK_SET);
        read(f,(void *)b,len1);
        b[len1]=0;
        close(f);
        len2=0;
        while (len2<len1) {
            while ((len2<len1) && ((b[len2]<'0') || (b[len2]>'9')))
                ++len2;
            if ((b[len2]>='0') && (b[len2]<='9') && (len2<len1)) {
                i=atoi(&(b[len2]));
                if ((i!=syscfg.systemnumber) && (i != p -> ownersys))
                    list[nh.list_len++]=i;
                while ((len2<len1) && (b[len2]>='0') && (b[len2]<='9'))
                    ++len2;
            }
        }
        farfree(b);
    }
    if (nh.list_len) {
        send_net(&nh, list, b1);
    }

    ui=find_host(type);
    if (ui) {
        nh.list_len=0L;
        nh.main_type = main_type_pre_post;
        nh.tosys=ui;
        nh.touser=0;
        send_net(&nh, NULL, b1);
    }

    farfree(list);
    farfree(b1);
}

void extract_out(char *b, long len, char *title)
{
    char s1[81],s2[81],ch=26,ch1;
    int i;

    do {
        prt(2,"Save under what filename? ");
        input(s1,12);
        if (s1[0]) {
            sprintf(s2,"%s%s",syscfg.gfilesdir,s1);
            if (exist(s2)) {
                nl();
                pl("Filename already in use.");
                nl();
                prt(2,"O)verwrite, A)ppend, N)ew name, Q)uit? ");
                ch1=onek("QOAN");
                switch(ch1) {
                case 'Q':
                    s2[0]=0;
                    s1[0]=0;
                    break;
                case 'N':
                    s1[0]=0;
                    break;
                case 'A':
                    break;
                case 'O':
                    unlink(s2);
                    break;
                }
                nl();
            }
        } 
        else
            s2[0]=0;
    } 
    while ((!hangup) && (s2[0]!=0) && (s1[0]==0));
    if ((s1[0]) && (!hangup)) {
        i=open(s2,O_RDWR | O_BINARY | O_CREAT , S_IREAD | S_IWRITE);
        if (filelength(i)) {
            lseek(i, -1L, SEEK_END);
            read(i, ((void *)&ch1), 1);
            if (ch1 == 26)
                lseek(i, -1L, SEEK_END);
        }
        write(i,title,strlen(title));
        write(i,"\r\n",2);
        write(i,(void *)b,len);
        write(i,&ch,1);
        close(i);
        npr("Message written to: %s.\r\n",s2);
    }
    farfree(b);
}


void grab_user_name(messagerec *m, char *fn)
{
    char *ss,*ss1;
    long len;

    ss=readfile(m,fn,&len);
    if (ss) {
        ss1=strchr(ss,'\r');
        if (ss1) {
            *ss1=0;
            strcpy(net_email_name,ss);
        } 
        else
            net_email_name[0]=0;
        farfree(ss);
    } 
    else
        net_email_name[0]=0;
}


void nscan(int ss)
{
    int i,nextsub,abort,next;

    nl();
    nextsub=1;
    pl(get_string(15));
    for (i=ss; (usub[i].subnum!=-1) && (i<MAX_SUBS) && (nextsub) && (!hangup); i++) {
        if (((usub[i].subnum<32) && (thisuser.qscn & (1L<<(usub[i].subnum)))) ||
            ((usub[i].subnum>=32) && (thisuser.qscn2 & (1L<<(usub[i].subnum-32)))))
            qscan(i,&nextsub);
        abort=next=0;
        checka(&abort,&next,0);
        if (abort)
            nextsub=0;
    }
    nl();
    pl(get_string(16));
    nl();
}

void scan2()
{
    char s[81],c;
    int i,i1;

    iscan(cursub);
    nl();
    if (curlsub<0) {
        pl("No subs available.");
        nl();
        return;
    }

    npr("%d msgs on %s\r\n",nummsgs, subboards[curlsub].name);
    if (nummsgs==0)
        return;
    nl();

    outstr("5Read 3F5oward, 3B5ackward, 3N5ew? ");
    c=onek("FBNQ\r");
    switch(c) {
        case '\r':
        default: break;
        case 'N': qscan(cursub,0); return;
        case 'Q': return;
    }
    prt(2,"Start listing at ? ");
    input(s,4);
    i=atoi(s);
    if(!i) i=1;
    if (i>=nummsgs) i=nummsgs;
    i1=0;
    scan(i,2,&i1);
}


void printmenu(int i)
{
    char s[81],s1[81];
    int next;

    next=0;
    commstr[0]=0;

    sprintf(s,"%smenu%d.ans",syscfg.gfilesdir,i);
    if(exist(s)) {
        printfile(s);
        return;
    }
    sprintf(s,"%sMENUS.MSG",syscfg.gfilesdir);
    if(menus[i].stored_as) read_message1(&menus[i],0,0,&next,s,0,"",0,"");
}


void delmail(int f, int loc)
{
    mailrec m,m1;
    userrec u;
    int rm,i,t,otf;

    lseek(f,((long) loc) * ((long) sizeof(mailrec)), SEEK_SET);
    read(f,(void *)&m,sizeof(mailrec));

    rm=1;
    if (m.status & status_multimail) {
        t=filelength(f)/sizeof(mailrec);
        otf=0;
        for (i=0; i<t; i++)
            if (i!=loc) {
                lseek(f,((long)i)*((long)sizeof(mailrec)),SEEK_SET);
                read(f,(void *)&m1,sizeof(mailrec));
                if ((m.msg.stored_as==m1.msg.stored_as) && (m.msg.storage_type==m1.msg.storage_type) && (m1.daten!=0xffffffff))
                    otf=1;
            }
        if (otf)
            rm=0;
    }

    if (rm)
        remove_link(&m.msg,"EMAIL");

    if (m.tosys==0) {
        read_user(m.touser,&u);
        if (u.waiting) {
            --u.waiting;
            write_user(m.touser,&u);
            close_user();
        }
        if (m.touser==1)
            --fwaiting;
    }

    lseek(f,((long) loc) * ((long) sizeof(mailrec)), SEEK_SET);
    m.touser=0;
    m.tosys=0;
    m.daten=0xffffffff;
    m.msg.storage_type=0;
    m.msg.stored_as=0xffffffff;
    write(f,(void *)&m,sizeof(mailrec));
    mailcheck=1;
}

void purgemail(int f,int *mloc,int mw,int *curmail, mailrec *m1, slrec *ss)
{
    int i;
    mailrec m;

    ansic(5);
    if ((m1->anony & anony_sender) && ((ss->ability & ability_read_email_anony)==0)) {
        npr("5Delete all mail to you from this user? ");
    } 
    else if (m1->fromsys) {
        npr("5Delete all mail to you from #%u @%u? ",m1->fromuser, m1->fromsys);
    } 
    else {
        npr("5Delete all mail to you from #%u? ",m1->fromuser);
    }
    if (yn()) {
        for (i=0; i<mw; i++) {
            if (mloc[i]>=0) {
                lseek(f,((long) mloc[i]) * sizeof(mailrec),SEEK_SET);
                read(f,(void *) (&m),sizeof(mailrec));
                if ((m.fromuser==m1->fromuser) && (m.fromsys==m1->fromsys)) {
                    npr("Deleting mail msg #%d\r\n",i+1);
                    delmail(f,mloc[i]);
                    mloc[i]=-1;
                    if (*curmail==i)
                        ++(*curmail);
                }
            } 
            else {
                if (*curmail==i)
                    ++(*curmail);
            }
        }
    }
}


void remove_post()
{
    int i,i1,any,abort;
    char s[161];

    iscan(cursub);
    if (curlsub<0) {
        nl();
        pl("No subs available.");
        nl();
        return;
    }
    any=0;
    abort=0;
    nl();
    nl();
    npr("Posts by you on %s\r\n", subboards[curlsub].name);
    nl();
    for (i=1; (i<=nummsgs) && (!abort); i++) {
        if ((msgs[i].ownersys==0) && (msgs[i].owneruser==usernum)) {
            any=1;
            sprintf(s,"%u: %s",i,msgs[i].title);
            pla(s,&abort);
        }
    }
    if (!any) {
        pl("None.");
        if (!cs())
            return;
    }
    nl();
    prt(2,"Remove which? ");
    input(s,3);
    i=atoi(s);
    if ((i>0) && (i<=nummsgs)) {
        if (((msgs[i].ownersys==0) && (msgs[i].owneruser==usernum)) || (lcs())) {
            sprintf(s,"-%s removed from %s",msgs[i].title,subboards[curlsub].name);
            sysoplog(s);
            delete(i);
            savebase();
            nl();
            pl("Message removed.");
            nl();
        }
    }
}



int external_edit(char *fn1, char *direc, int ednum, int numlines)
{
    char s[255],s1[128],fn[128],s2[128],s3[81],sx1[21],sx2[21],sx3[21],ch;
    int i,i1,i2,r,w,filethere,mod,newtl;
    struct ftime ftimep,ftimep1;

    if(!readeditor)
        readeditors();
    if ((ednum>=numed) || (!okansi())) {
        nl();
        pl("You can't use that full screen editor.");
        nl();
        return(0);
    }
    i1=0;
    for (i2=0; i2<81; i2++) {
        i1+=editors[ednum].filename[i2];
        i1+=editors[ednum].filenamecon[i2];
    }
    if (incom)
        strcpy(s1,(editors[ednum].filename));
    else
        strcpy(s1,(editors[ednum].filenamecon));
    if (s1[0]==0) {
        nl();
        pl("You can't use that full screen editor.");
        nl();
        return(0);
    }
    strcpy(s3,fn1);
    stripfn1(s3);
    if (direc[0]) {
        cd_to(direc);
        get_dir(fn,1);
        cd_to(cdir);
    } 
    else
        fn[0]=0;
    strcat(fn,s3);
    filethere=exist(fn);
    if (filethere) {
        i=open(fn,O_RDONLY | O_BINARY);
        getftime(i,&ftimep);
        close(i);
    }
    itoa(thisuser.screenchars,sx1,10);
    if (screenlinest>defscreenbottom-topline)
        newtl=0;
    else
        newtl=topline;
    if (using_modem)
        itoa(thisuser.screenlines,sx2,10);
    else
        itoa(defscreenbottom+1-newtl,sx2,10);
    itoa(numlines,sx3,10);
    stuff_in(s,s1,fn,sx1,sx2,sx3,"");
    runprog(s,0);
    if (!wfc)
        topscreen();
    mod=0;
    if (!filethere) {
        mod=exist(fn);
    } 
    else {
        i=open(fn,O_RDONLY | O_BINARY);
        getftime(i,&ftimep1);
        close(i);
        if ((ftimep.ft_year!=ftimep1.ft_year) ||
            (ftimep.ft_month!=ftimep1.ft_month) ||
            (ftimep.ft_day!=ftimep1.ft_day) ||
            (ftimep.ft_hour!=ftimep1.ft_hour) ||
            (ftimep.ft_min!=ftimep1.ft_min) ||
            (ftimep.ft_tsec!=ftimep1.ft_tsec))
            mod=1;
    }
    return(mod);
}

void describe_area_code(int areacode, char *description)
{
  int f,done=0,i;
  char s[81],*ss,*ss1;

  description[0]=0;
  sprintf(s,"%sREGIONS.DAT",syscfg.datadir);
  f=open(s,O_RDWR | O_TEXT);
  if (f<1)
    return;
  ss=malloca(filelength(f));
  i=read(f,ss,filelength(f));
  ss[i]=0;
  close(f);
  ss1=strtok(ss,"\n");
  while (ss1 && (!done)) {
    i=atoi(ss1);
    if (i) {
      if (i==areacode)
        done=1;
    } else
      strcpy(description,ss1);
    ss1=strtok(NULL,"\n");
  }

  farfree(ss);
}



/****************************************************************************/
static char origin_str[81];

void setorigin(int sysnum, int usernum)
{
  int i;
  char s[81],ch;
  net_system_list_rec *csne;

  origin_str[0]=0;

  if (sysnum) {
    csne=next_system(sysnum);
    if (csne) {
      ch=' ';
      if (usernum==1) {
        if (csne->other & other_net_coord)
          ch='&';
        else if (csne->other & other_group_coord)
          ch='%';
        else if (csne->other & other_coordinator)
          ch='^';
      }

      describe_area_code(atoi(csne->phone),s);
      if (s[0])
        sprintf(origin_str,"%c%s (%s) [%s]",ch,csne->name,s, csne->phone);
      else
        sprintf(origin_str,"%c%s [%s]",ch,csne->name,csne->phone);


    } else
      strcpy(origin_str," Unknown System");
  }
}


int okfsed()
{
  int ok;

  ok=ALLOW_FULLSCREEN;
  if (!okansi())
    ok=0;
  if (!thisuser.defed)
    ok=0;
  if (thisuser.defed>numed)
    ok=0;
  return(ok);
}


void remove_link(messagerec *m1, char *aux)
{
  messagerec m;
  char s[81],s1[81];
  int f;
  long csec,nsec;

  m=*m1;
  strcpy(s,syscfg.msgsdir);
  switch(m.storage_type) {
    case 0:
    case 1:
      ltoa(m.stored_as,s1,16);
      if (m.storage_type==1) {
        strcat(s,aux);
        strcat(s,"\\");
      }
      strcat(s,s1);
      unlink(s);
      break;
    case 2:
      f=open_file(aux);
      set_gat_section(f,m.stored_as/2048);
      csec=m.stored_as % 2048;
      while ((csec>0) && (csec<2048)) {
        nsec=(long) gat[csec];
    gat[csec]=0;
    csec=nsec;
      }
      save_gat(f);
      close(f);
      break;
    default:
      /* illegal storage type */
      break;
  }
}


void change_storage(messagerec *oldm, char *olda, messagerec *newm, char *newa)
{
  long len;
  char *b;

  b=readfile(oldm,olda,&len);
  remove_link(oldm,olda);
  savefile(b,len,newm,newa);
}


void load_workspace(char *fnx, int no_edit)
{
  int i,i5;
  long l;
  char *b,s[81];

  i5=open(fnx,O_RDONLY | O_BINARY);
  if (i5<1) {
    nl();
    pl("File not found.");
    nl();
    return;
  }
  l=filelength(i5);
  if ((b=malloca(l+1024))==NULL) {
    close(i5);
    return;
  }
  read(i5, (void *) b,l);
  close(i5);
  if (b[l-1]!=26)
    b[l++]=26;
  sprintf(s,"%sINPUT.MSG",syscfg.tempdir);
  i5=open(s,O_RDWR | O_CREAT | O_BINARY,S_IREAD | S_IWRITE);
  write(i5, (void *)b,l);
  close(i5);
  farfree(b);
  if ((no_edit) || (!okfsed()))
    use_workspace=1;
  else
    use_workspace=0;
  nl();
  pl("File loaded into workspace.");
  nl();
  if (!use_workspace)
    pl("Editing will be allowed.");

}

void stuff(char *s, char *old, char *new)
{
  char s1[LEN],*ss;

  if (strlen(s)-strlen(old)+strlen(new)>=LEN)
    return;
  ss=strstr(s,old);
  if (ss==NULL)
    return;
  ss[0]=0;
  sprintf(s1,"%s%s%s",s,new,ss+strlen(old));
  strcpy(s,s1);
}

int forwardm(unsigned short *u, unsigned short *s)
{
  userrec ur;
  char *ss;
  int i,i1,cu;

  if (*s)
    return(0);
  read_user(*u,&ur);
  if (ur.inact & inact_deleted)
    return(0);
  if ((ur.forwardusr==0) && (ur.forwardsys==0))
    return(0);
  if (ur.forwardsys) {
    if ((ur.forwardusr>0) && (ur.forwardusr<32767)) {
      if (!next_system(ur.forwardsys))
        return(0);
      *u=ur.forwardusr;
      *s=ur.forwardsys;
      return(1);
    } else {
      *u=0;
      *s=0;
      return(0);
    }
  }
  cu=ur.forwardusr;
  if (cu==-1) {
    pl("Mailbox Closed.");
    if (so()) {
      pl("(Forcing)");
    } else {
      *u=0;
      *s=0;
    }
    return(0);
  }
  if ((ss=malloca((long) syscfg.maxusers+ 300L))==NULL)
    return(0);
  for (i=0; i<syscfg.maxusers+300; i++)
    ss[i]=0;
  ss[*u]=1;
  read_user(cu,&ur);
  while ((ur.forwardusr) || (ur.forwardsys)) {
    if (ur.forwardsys) {
      if (!next_system(ur.forwardsys))
        return(0);
      *u=ur.forwardusr;
      *s=ur.forwardsys;
      farfree(ss);
      return(1);
    }
    if (ss[cu]) {
      farfree(ss);
      return(0);
    }
    ss[cu]=1;
    if (ur.forwardusr==65535) {
      pl("Mailbox Closed.");
      if (so()) {
        pl("(Forcing)");
        *u=cu;
        *s=0;
      } else {
        *u=0;
        *s=0;
      }
      farfree(ss);
      return(0);
    }
    cu=ur.forwardusr;
    read_user(cu,&ur);
  }
  farfree(ss);
  *s=0;
  *u=cu;
  return(1);
}


void sendout_email(char *title, messagerec *msg, int anony, unsigned un, unsigned sy, int an)
{
  mailrec m,m1;
  net_header_rec nh;
  int f,len,i,i1;
  char *b,*b1,s[129],s2[129],s1[129];
  long len1;
  userrec ur;


  strcpy(m.title, title);
  m.msg=*msg;
  m.anony=anony;
  m.fromsys=0;
  m.fromuser=usernum;
  m.tosys=sy;
  m.touser=un;
  m.status=0;
  time((long *)&(m.daten));
  sprintf(s,"%sEMAIL.DAT",syscfg.datadir);
  if (sy==0) {
    f=open(s,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
    if (!f) {
      return;
    }
    len=(int) filelength(f)/sizeof(mailrec);
    if (len==0)
      i=0;
    else {
      i=len-1;
      lseek(f,((long) (i))*(sizeof(mailrec)), SEEK_SET);
      read(f,(void *)&m1,sizeof(mailrec));
      while ((i>0) && (m1.tosys==0) && (m1.touser==0)) {
        --i;
        lseek(f,((long) (i))*(sizeof(mailrec)), SEEK_SET);
        i1=read(f,(void *)&m1,sizeof(mailrec));
        if (i1==-1)
          pl("DIDN'T READ RIGHT.");
      }
      if ((m1.tosys) || (m1.touser))
        ++i;
    }
    lseek(f,((long) (i))*(sizeof(mailrec)), SEEK_SET);
    i1=write(f,(void *)&m,sizeof(mailrec));
    if (i1==-1) {
      pl("DIDN'T SAVE RIGHT!");
    }
    close(f);
  } else {
    if ((b=readfile(&(m.msg),"EMAIL",&len1))==NULL)
      return;
    remove_link(&(m.msg),"EMAIL");
    nh.tosys=sy;
    nh.touser=un;
    nh.fromsys=syscfg.systemnumber;
    nh.fromuser=usernum;
    nh.main_type=main_type_email;
    nh.minor_type=0;
    nh.list_len=0;
    nh.daten=m.daten;
    nh.method=0;
    if ((b1=malloca(len1+300))==NULL) {
      farfree(b);
      return;
    }
    i=0;
    if (un==0) {
      nh.main_type=main_type_email_name;
      strcpy(&(b1[i]),net_email_name);
      i+= strlen(net_email_name)+1;
    }
    strcpy(&(b1[i]),m.title);
    i += strlen(m.title)+1;
    memmove(&(b1[i]),b,(unsigned int) len1);
    nh.length=len1+(long)i;
    if (nh.length > 32760) {
      npr("Message truncated by %lu bytes for the network.\r\n",nh.length-32760L);
      nh.length = 32760;
    }
    sprintf(s,"%sP0.NET",syscfg.datadir);
    f=open(s,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
    lseek(f,0L,SEEK_END);
    write(f,(void *)&nh,sizeof(net_header_rec));
    write(f,(void *)b1,nh.length);
    close(f);
    farfree(b);
    farfree(b1);
  }
  s2[0]=0;
  strcpy(s,"Mail sent to ");
  if (sy==0) {
    read_user(un,&ur);
    ++ur.waiting;
    write_user(un,&ur);
    close_user();
    if (un==1)
      ++fwaiting;
    if (an) {
      strcat(s,nam(&ur,un));
      sysoplog(s);
    } else {
      strcpy(s1,s);
      strcat(s1,nam(&ur,un));
      sysoplog(s1);
      strcat(s,">UNKNOWN<");
    }
  } else {
    if (un==0)
      sprintf(s1,"%s @%u",net_email_name,sy);
    else
      sprintf(s1,"User %u @%u",un,sy);
    strcat(s,s1);
    sysoplog(s);
  }
  if ((un==1) && (sy==0)) {
    ++status.fbacktoday;
    ++thisuser.feedbacksent;
    ++thisuser.fsenttoday1;
    ++fsenttoday;
  } else {
    ++status.emailtoday;
    ++thisuser.etoday;
    if (sy==0) {
      ++thisuser.emailsent;
    } else {
      ++thisuser.emailnet;
      /* len1=nh.length+sizeof(net_header_rec); */
      /* fl = (csne->cost) * ((float)len1) / 1024.0; */
      /* sprintf(s2,"Total cost: $%6.2f",fl); */
    }
  }
  save_status();
  if (!wfc)
    topscreen();
  pl(s);
  if (s2[0])
    pl(s2);
}


int ok_to_mail(unsigned un, unsigned sy, int forceit)
{
  userrec ur;
  slrec ss;

  ss=syscfg.sl[actsl];
  if ((sy!=0) && (syscfg.systemnumber==0)) {
    nl();
    pl("Sorry, this system is not a part of a network.");
    nl();
    return(0);
  }
  if (sy==0) {
    if (un==0)
      return(0);
    read_user(un,&ur);
    if (((ur.sl==255) && (ur.waiting>(syscfg.maxwaiting * 5))) ||
        ((ur.sl!=255) && (ur.waiting>syscfg.maxwaiting)) ||
        (ur.waiting>200)) {
      if (!forceit) {
        nl();
        pl("Mailbox full.");
        nl();
        return(0);
      }
    }
    if (ur.inact & inact_deleted) {
      nl();
      pl("Deleted user.");
      nl();
      return(0);
    }
  } else {
    if (next_system(sy)==NULL) {
      nl();
      pl("Unknown system number.");
      nl();
      return(0);
    }
    if (thisuser.restrict & restrict_net) {
      nl();
      pl("You can't send mail off the system.");
      return(0);
    }
  }
  if (forceit==0) {
    if ((((un==1) && (sy==0) && ((fsenttoday>=5) || (thisuser.fsenttoday1>=10))) ||
         (((un!=1) || (sy!=0)) && (thisuser.etoday>=ss.emails))) && (!cs())) {
      nl();
      pl("Too much mail sent today.");
      nl();
      return(0);
    }
    if ((restrict_email & thisuser.restrict) && (un!=1)) {
      nl();
      pl("You can't send mail.");
      nl();
      return(0);
    }
  }
  return(1);
}


void osan(char *s, int *abort, int *next)
{
  int i;

  i=0;
  checkhangup();
  if (hangup)
    *abort=1;
  checka(abort,next,0);
  while ((s[i]) && (!(*abort))) {
    outchr(s[i++]);
    checka(abort,next,0);
  }
}

void cosan(char *s, int *abort, int *next)
{
  int i;
  char s1[81];

  i=0;
  checkhangup();
  if (hangup)
    *abort=1;
  checka(abort,next,1);
  while ((s[i]) && (!(*abort))) {
    outchr(s[i++]);
    checka(abort,next,1);
  }
}


void addline(char *b, char *s, long *ll)
{
  strcpy(&(b[*ll]),s);
  *ll +=strlen(s);
  strcpy(&(b[*ll]),"\r\n");
  *ll += 2;
}


void yourinfomsg()
{
    nl();
    dtitle("Your Message Status");
    npr("0Total Posts   5: 4%d\r\n",thisuser.msgpost);
    npr("0Posts Today   5: 4%d\r\n",thisuser.posttoday);
    npr("0FeedBack      5: 4%d\r\n",thisuser.feedbacksent);
    npr("0Email Sent    5: 4%d\r\n",thisuser.emailsent);
    npr("0Messages Read 5: 4%d\r\n",thisuser.msgread);
    npr("0Mail Waiting  5: 4%d\r\n",thisuser.waiting);
    npr("0Your PCR      5: 4%-6.3f\r\n",post_ratio());
    npr("0Required PCR  5: 4%-6.3f\r\n",syscfg.post_call_ratio);
    nl();
    nl();
}

