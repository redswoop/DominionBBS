#include "vars.h"
#pragma hdrstop

#define SETREC(i)  lseek(dlf,((long) (i))*((long)sizeof(uploadsrec)),SEEK_SET);

void batrec(int rw, int bnum)
{
  int f;
  char s[81];

  sprintf(s,"%sBATREC.DAT",syscfg.datadir);
  f=open(s,O_RDWR | O_CREAT | O_BINARY,S_IREAD | S_IWRITE);
  lseek(f,(bnum)*(long)sizeof(batchrec),SEEK_SET);
  switch (rw) {
  case 0: write(f,(void *)(&batch),sizeof(batchrec));
          break;
  case 1: read(f,(void *)(&batch),sizeof(batchrec));
          break;
  }
  close(f);
}

void verify_hangup()
{
    int i;

    npr("7Commencing with Automatic Logoff\r\n0Hit Anykey to abort.\r\n");
    for(i=19;i>0&&!inkey();i--) {
     npr("%2d Seconds till Automatic Disconnection.\r",i);
     delay(1000);
    }
    if(i<=0) {
        nl();
        npr("Automatic Logoff Time Expired, Disconnecting");
        hangup=1;
        logpr("7!0 Automatic Logoff Time Expired, System Disconnected");
    }
}


void listbatch()
{
  char s[81];
  int abort,i;

  abort=0;
  nl();
  sprintf(s,"Batch: Files - %d  DL Size - %-1.0fk  DL Time - %s",
    numbatch,batchsize,ctim(batchtime));
  dtitle(s);
  nl();
  for (i=0; (i<numbatch) && (!abort) && (!hangup); i++) {
    batrec(1,i);
    if (batch.sending)
      sprintf(s,"5%d9.0 (D) 2%-13s  %-1.0fk  %s %s",i+1,batch.filename,
        batch.size,ctim(batch.time),directories[batch.dir].name);
    else
      sprintf(s,"5%d9.0 (U) 2%-13s: %s %s",i+1,batch.filename,
        batch.batchdesc,directories[batch.dir].name);
      pla(s,&abort);
  }
}

void delbatch(int i)
{
  int f,i1;
  char s[81];

  if (i<numbatch) {
    batrec(1,i);
    batchtime -= batch.time;
    batchsize -= batch.size;
    if (batch.sending)
      --numbatchdl;
    --numbatch;
    sprintf(s,"%sBATREC.DAT",syscfg.datadir);
    f=open(s,O_RDWR | O_CREAT | O_BINARY,S_IREAD | S_IWRITE);
    for (i1=i; i1<=numbatch; i1++) {
      lseek(f,(i1+1)*(long)sizeof(batchrec),SEEK_SET);
      read(f,(void *)(&batch),sizeof(batchrec));
      lseek(f,(i1)*(long)sizeof(batchrec),SEEK_SET);
      write(f,(void *)(&batch),sizeof(batchrec));
    }
    close(f);
  }
}

void downloaded(char *fn)
{
  int i,i1;
  uploadsrec u;
  char s[81];

  for (i1=0; i1<numbatch; i1++) {
    batrec(1,i1);
    if ((strcmp(fn,batch.filename)==0) && (batch.sending)) {
      dliscan1(batch.dir);
      i=recno((batch.filename));
      if (i>0) {
        SETREC(i);
        read(dlf,(void *)&u,sizeof(uploadsrec));
        if(!(directories[batch.dir].mask & mask_no_ratio)) {
           ++thisuser.downloaded;
           thisuser.dk += (int) ((u.numbytes+1023)/1024);
           thisuser.fpts -= (int) ((u.numbytes+1023)/10240)/nifty.fptsratio;
        }
        ++u.numdloads;
        status.dltoday++;
        SETREC(i);
        write(dlf,(void *)&u,sizeof(uploadsrec));
        closedl();
        npr("7�0%s Succesfully Transfered - 4%ldK0 - 2 %d Points\r\n",u.filename,((u.numbytes+1023)/1024),u.points);
        sprintf(s,"%s downloaded '%s' on %s",nam(&thisuser,usernum), u.filename, date());
        ssm(u.ownerusr,0,s);
        logpr("2-3 Downloaded %s from %s - %ldk",u.filename,directories[batch.dir].name,(u.numbytes+1023)/1024);
      }
      delbatch(i1);
      return;
    }
  }
  logpr("7!0 File '4%s0' was downloaded, but was not in Batch Queue!.",fn);
}


void upload_batch_file()
{
  int f,i,ok;
  uploadsrec u,u1;
  directoryrec d;
  char *ss,s[81],s1[81];
  long l,len;

  ss=NULL;

  npr("5� 0Processing: 4%s\r\n",batch.filename);
  d=directories[batch.dir];
  dliscan1(batch.dir);
  sprintf(s,"copy %s%s %s",syscfg.batchdir,stripfn(batch.filename),d.dpath);
  if(s[strlen(s)-1]=='\\')
    s[strlen(s)-1]=0;
  system(s);
  time(&l);
  u.daten=l;
  strcpy(u.filename,batch.filename);
  strcpy(u.description,batch.batchdesc);
  u.ownerusr=usernum;
  u.ownersys=0;
  u.numdloads=0;
  u.filetype=0;
  u.mask=0;
  u.points=0;
  u.ats[0]=0;
  if (!hangup) {
    if(ss==NULL) modify_extended_description(&ss);
    if (ss) {
      add_extended_description(u.filename,ss);
      u.mask |= mask_extended;
      farfree(ss);
    }
  }

  strcpy(u.upby,nam1(&thisuser,usernum,syscfg.systemnumber));
  strcpy(u.date,date());
  sprintf(s,"%s%s",d.dpath,u.filename);

  ok=1;

  pl("2� 0Scanning for Duplicate");
  if(finddup(u.filename,1)) {
    pl("0Sorry, the file already exists. 8Deleting0.");
    unlink(s);
    logpr("7!0 File 4%s0 already exists, upload deleted.",u.filename);
  }

  dliscan1(batch.dir);
  pl("2� 0Testing File Integrity");
  if(testarc(stripfn(u.filename),d.dpath)!=0) {
     pl("Error in Upload.");/*
     outstr("5Save File for Resume Upload? ");
      if(yn())
         u.numbytes=-1;
      else */{
        unlink(s);
        logpr("7!0 File 4%s0 failed Integrity Test, upload deleted.",u.filename);
        if (u.mask & mask_extended)
            delete_extended_description(u.filename);
        ok=0;
        }
  }

  if(ok) {
    if(u.numbytes!=-1) {
        pl("2� 0Adding Zip Comment");
            comment_arc(stripfn(u.filename),d.dpath);
        if(strstr(u.filename,".GIF")) {
            pl("2� 0Adding Gif Specs");
            sprintf(s,"%s%s",d.dpath,stripfn(u.filename));
            addgif(s,u.description);
        }
    }
    if(u.numbytes!=-1) {
        f=open(s,O_RDONLY | O_BINARY);
        u.numbytes=filelength(f);
        close(f);
    }
    for (i=numf; i>=1; i--) {
      SETREC(i);
      read(dlf,(void *)&u1,sizeof(uploadsrec));
      SETREC(i+1);
      write(dlf,(void *)&u1,sizeof(uploadsrec));
    }
    SETREC(1);
    write(dlf,(void *)&u,sizeof(uploadsrec));
    ++numf;
    u1.numbytes=numf;
    u1.daten=l;
    SETREC(0);
    write(dlf,(void *)&u1,sizeof(uploadsrec));
    if(u.numbytes!=-1) {
        ++thisuser.uploaded;
        thisuser.uk += (int) ((u.numbytes+1023)/1024);
        if(d.mask & mask_autocredit)
            thisuser.fpts += (int) ((u.numbytes+1023)/10240);
    }

    ++status.uptoday;
    save_status();
    if(u.numbytes!=-1)
        logpr("2+ 3Uploaded 9%s 3to 9%s 3- %ldk",u.filename,d.name,(u.numbytes+1023)/1024);
    else
        logpr("7!0 Upload of 4%s0 to 9%s0 not successful!  Saving for Resume",u.filename,d.name);

  }

  closedl();
  i=curdir;
  if (batchdir==0)
    curdir=0;
}

void uploaded(char *fn)
{
  int i,i1,done=0;
  char *ss,s[81];

  dliscan1(batchdir);
  for (i1=0; i1<numbatch; i1++) {
    batrec(1,i1);
    if ((strcmp(fn,batch.filename)==0) && (!batch.sending)) {
      i=recno(batch.filename);
      if (i==-1)
        upload_batch_file();
      closedl();
      delbatch(i1);
      return;
    }
  }


  strcpy(batch.filename,fn);
  sprintf(s,"0Enter a description for 7%s -",fn);
  do {
    pl(s);
    outstr("5>0 ");
    inputl(batch.batchdesc,39);
  } while ((!hangup) && (batch.batchdesc[0]==0));
  batch.dir=0;

  if(!hangup)
    do {
        nl();
        dirlist('l');
        nl();
        npr("3Place in which area? ");
        ss=mmkey(1);
        if(!ss[0]) {
            batch.dir=0;
            done=1;
        }
        nl();
        nl();
        for(i=0;i<num_dirs&&udir[i].subnum>=0;i++)
            if(strcmp(ss,udir[i].keys)==0) {
                batch.dir=udir[i].subnum;
                done=1;
            }
    } while(!done&&!hangup);



  if (batch.batchdesc[0]==0) {
    strcpy(batch.batchdesc,"1�������2[4User Hung Up2]1�������");
    sprintf(s,"%s needs a description!",fn);
    ssm(usernum,0,s);
  }
  upload_batch_file();
}


int check_aborted_upload(char *fn)
{
  directoryrec d;
  char s[81];

  dliscan1(batchdir);
  if (recno(fn)!=-1) {
    closedl();
    return(1);
  }
  d=directories[batchdir];
  sprintf(s,"%s%s",d.dpath,fn);
  if (!exist(s)) {
    closedl();
    return(1);
  }
  closedl();
  uploaded(fn);
  return(0);
}


void handle_dszline(char *l)
{
  char *ss;
  int i;
  char s[161];

  ss=strtok(l," \t");
  for (i=0; (i<10) && (ss); i++)
    ss=strtok(NULL," \t");

  if (ss) {
    strcpy(s,stripfn(ss));
    align(s);

    switch(*l) {
      case 'Z':
      case 'X':
      case 'R':
      case 'B':
      case 'H':
        uploaded(s);
        break;

      case 'z':
      case 'x':
      case 'b':
      case 'S':
      case 'Q':
      case 'h':
        downloaded(s);
        break;

      case 'E':
      case 'e':
      case 'L':
      case 'U':
        if(check_aborted_upload(s)) {
            logpr("7! 0Error transferring '4%s0'",ss);
            npr("7>>4*7<<0 Error Occured Transfering %s!\r\n",s);
        }
        break;
    }
  }
}

void process_dszlog()
{
  FILE *f;
  char s[140];

  outchr(12);
  if ((f=fopen(dszlog,"rt"))!=0) {
    while (fgets(s,138,f))
      handle_dszline(s);
    fclose(f);
  }
}

void batchul(int t)
{
  int f,i;
  char s[81],s1[81],s2[81],sx1[40],sx2[40],sx3[40];
  double ti;
  long l;
  directoryrec d;

  ti=timer();
  strcpy(s1,proto[t].receivebatch);

  _chmod(dszlog,1,0);
  unlink(dszlog);

  ultoa(com_speed,sx1,10);
  ultoa(modem_speed,sx3,10);
  sx2[0]='0'+syscfg.primaryport;
  sx2[1]=0;
  sprintf(s2,"%s\\BATCH.LST",cdir);
  stuff_in(s,s1,sx1,sx2,"",sx3,s2);
  cd_to(syscfg.batchdir);

  npr("2� Ready to Receive Now\r\n\r\n");
  savescreen(&screensave);
  clrscr();
  printf("[0;33;44;1m[K%s Is Batch Uploading[0;1m\n\n",nam(&thisuser,usernum));
  printf("%s\r\n",s);
  runprog(s,0);
  restorescreen(&screensave);
  process_dszlog();
  topscreen();
  ti=timer()-ti;
  if (ti<0) ti += 24.0*3600.0;
  thisuser.extratime += ti;
}

void batchdl(int t)
{
  int ok,f,i;
  char s[81],s1[81],sx1[40],sx2[40],sx3[40],s2[80];


  if (nsl()<=batchtime&&!(thisuser.exempt & exempt_time)) {
    nl();
    pl("Not enough time to D/L batch.");
    return;
  }

  sprintf(s,"%s\\BATCH.LST",cdir);
  unlink(s);
  f=open(s,O_RDWR | O_BINARY | O_CREAT | O_TRUNC, S_IREAD | S_IWRITE);
  if (f<0) {
    pl("Unable to create transfer list.");
    return;
  }

  for (i=0; i<numbatch; i++) {
    batrec(1,i);
    if (batch.sending) {
      sprintf(s1,"%s%s\r\n",directories[batch.dir].dpath,stripfn(batch.filename));
      write(f,s1,strlen(s1));
    }
  }

  close(f);
  strcpy(s1,proto[t].sendbatch);

  ultoa(com_speed,sx1,10);
  ultoa(modem_speed,sx3,10);
  sx2[0]='0'+syscfg.primaryport;
  sx2[1]=0;
  sprintf(s2,"%s\\BATCH.LST",cdir);
  stuff_in(s,s1,sx1,sx2,"",sx3,s2);
  _chmod(dszlog,1,0);
  unlink(dszlog);
  npr("2� Begining to Send Now\r\n\r\n");
  savescreen(&screensave);
  clrscr();
  cd_to(syscfg.batchdir);
  printf("[0;33;44;1m[K%s Is Batch Downloading\n[0;1m\n\n",nam(&thisuser,usernum));
  printf("%s\r\n",s);
  cd_to(syscfg.batchdir);
  runprog(s,0);
  cd_to(cdir);
  restorescreen(&screensave);
  process_dszlog();
  topscreen();
}

void bidl()
{
  char s[141],listfn[81],sx1[21],sx2[21],dl[100];
  int i,i1,f;
  double ti;
  long l;
  unsigned long ouk, odk;
  bimodrec bilist;
  bicfgrec bicfg;
  directoryrec d;

  if (!incom) {
    return;
  }

  if (nsl()<=batchtime) {
    nl();
    pl("Not enough time for Bimodem D/L.");
    return;
  }

  sprintf(s,"%sbimodem.cfg",syscfg.datadir);
  if(!exist(s)) {
    pl("Configuration File is Missing");
    sysoplog("**>>Bimodem Config File Not Found, Aborting Bimodem Transfers");
    sysoplog("**>>The file Bimodem.Cfg must be in your Data Directory for all to Work Fine");
    return;
  }
  dliscan1(batchdir);
  d=directories[batchdir];
  nl();
  sprintf(s,"BiModem Files - %d  DL Size - %-1.0fk  DL Time - %s",
    numbatch,batchsize,ctim(batchtime));
  sysoplog(s);
  sprintf(listfn,"%sBIMODEM.CFG",syscfg.datadir);
  f=open(listfn,O_RDWR | O_BINARY,S_IREAD|S_IWRITE);
  if (f>0) {
    read(f,(void *) &bicfg, sizeof(bicfgrec));
    for (i1=0;i1<80;i1++)
      bicfg.uppath[i1]=32;
    strncpy(bicfg.uppath,syscfg.batchdir,70);
    lseek(f,0L,SEEK_SET);
    write(f,(void *) &bicfg, sizeof(bicfgrec));
    close(f);
  }
  sprintf(listfn,"%s\\BIMODEM.PTH",cdir);
  _chmod(listfn,1,0);
  unlink(listfn);
  _chmod(dszlog,1,0);
  unlink(dszlog);
  f=open(listfn,O_RDWR | O_BINARY | O_CREAT | O_TRUNC, S_IREAD | S_IWRITE);
  if (f<0) {
    pl("Unable to create Bimodem list file.");
    nl();
    return;
  }
  for (i=0; i<numbatch; i++) {
    batrec(1,i);
    bilist.refresh=' ';
    bilist.replace='N';
    bilist.verify='Y';
    bilist.delete='N';
    bilist.unused=' ';
    bilist.fulldir='N';
    bilist.subdir='Y';
    if (batch.sending) {
      bilist.direction='U';
      sprintf(s,"%s%s",directories[batch.dir].dpath,stripfn(batch.filename));
    } else {
      bilist.direction='D';
      sprintf(s,"%s%s",d.dpath,stripfn(batch.filename));
    }
    strupr(s);
    strupr(batch.filename);
    for (i1=0;i1<80;i1++) {
      bilist.sourcepath[i1]=32;
      bilist.descr[i1]=32;
      bilist.destpath[i1]=32;
    }
    if (batch.sending) {
      sprintf(bilist.sourcepath,"%-70s",s);
      sprintf(bilist.destpath,"%-70s",stripfn(batch.filename));
    } else {
      sprintf(bilist.sourcepath,"%-70s",stripfn(batch.filename));
      sprintf(bilist.destpath,"%-70s",s);
    }
    write(f,(void *) &bilist, sizeof(bimodrec));
  }
  close(f);
  ultoa(com_speed,sx1,10);
  sx2[0]='0'+syscfg.primaryport;
  sx2[1]=0;
  sprintf(s,"BIMODEM /B%s /CBIMODEM.CFG /L%s /PBIMODEM.PTH",sx1,sx2);
  if (s[0]) {
    ti=timer();
    topdata=0;
    pl("Bi-Directional Transfer Now Begining: Start Transfer");
    topscreen();
    printf("[2J[31;44;1m[K%s is BiModeming!",nam(&thisuser,usernum));
    runprog(s,0);
    ouk=thisuser.uk;
    odk=thisuser.dk;
    process_dszlog();
    ti=timer()-ti;
    if (ti<0)
      ti += 24.0*3600.0;
    odk=thisuser.dk-odk;
    ouk=thisuser.uk-ouk;
    if (odk<=ouk)
      thisuser.extratime += ti;
    else
      thisuser.extratime += ti*(((float) ouk)/((float) odk));
  }
}


void batchdled()
{
  int i;
  char s[81],c;

 nl();
 outstr(get_string(55));
 c=onek("LCRH\r");
    switch(c) {
      case '\r': return;
      case 'H': verify_hangup(); break;
      case 'L':
        listbatch();
        return;
      case 'R':
        nl();
        if (numbatch==0)
          pl("No files in batch queue.");
        else {
          prt(2,"Remove which? ");
          input(s,2);
          i=atoi(s);
          if ((i>0) && (i<=numbatch))
            delbatch(i-1);
        }
        return;
      case 'C':
        prt(5,"Clear queue? ");
        if (yn()) {
          while (numbatch>0)
            delbatch(0);
          nl();
          pl("Queue cleared.");
        }
    }
}

void newdl(int dn)
{
    download(dn,0);
}

void mark(int dn)
{
    download(dn,1);
}

int findfile(int dn,char s[15])
{
    int i,i2;
    uploadsrec u;

    dliscan1(dn);
    if(atoi(s)) {
          SETREC(atoi(s));
          read(dlf,(void *)&u,sizeof(uploadsrec));
          if(checkdl(u,dn)) addtobatch(u,dn,1);
          else {
            npr("\r\n%s Rejected\r\n\r\n",u.filename);
            logpr("7-0 Tried to dl 4%s0, but was rejected",u.filename);
          }
          closedl();
          return 1;
    }
    i=recno(s);
    i2=0;
    while(i!=-1) {
          i2=1;
          SETREC(i);
          read(dlf,(void *)&u,sizeof(uploadsrec));
          if(checkdl(u,dn)) addtobatch(u,dn,1);
          else {
            npr("\r\n%s Rejected\r\n\r\n",u.filename);
            logpr("7-0 Tried to dl 4%s0, but was rejected",u.filename);
          }
          i=nrecno(s,i);
    }
    closedl();
    return i2;
}

void printbatchstat(int dl)
{
  if(dl) {
      npr("2>>>0Files   : 5%d\r\n",numbatchdl);
      npr("2>>>0Size    : 5%-1.0fk\r\n",batchsize);
      npr("2>>>0Est Time: 5%s\r\n",ctim(batchtime));
  } else
      npr("2>>>0Files   : 5%d\r\n",numbatch-numbatchdl);
}


void download(int dn,int mark)
{
  char *p;
  char s[162],s1[162];
  int i,i1,i2;
  uploadsrec u;


  batchdir=udir[dn].subnum;
  if(numbatchdl) printbatchstat(1);
  nl();

  npr("0Enter File Names/Numbers to 5%s0:7 <Multiple File Names Ok>",mark?"Mark":"Download");
  nl();
  mpl(78);
  input(s,78);

  if (!s[0]&&numbatch==0)
    return;
  strcpy(s1,s);
  p=strtok(s1," ,;");
  while (p) {
    i1=0;
    strcpy(s,p);
    if (!okfn(s))
      break;
    if (strchr(s,'.')==NULL)
      strcat(s,".*");
    align(s);
    i1=0;
    i2=findfile(batchdir,s);
    if(!i2) {
        pl("Searching All Directories");
        for(i1=0;i1<umaxdirs;i1++) findfile(udir[i1].subnum,s);
    }
    p=strtok(NULL," ,;");
  }

  if(numbatch<1) return;
  printbatchstat(1);

  if(!mark) {
    if(numbatch<1) return;
    nl();
    i=get_batchprotocol(1,&i2);
    if(i==-1) return;
    if(i==-2) bidl();
    else batchdl(i);
    if(i2) verify_hangup();
  }

}



void newul(int dn)
{
  char *p;
  char s[162],s1[162];
  int i,i2,ok=1;
  uploadsrec u;
  directoryrec d;
  double t;
  long l;

  if(dn==-1) dn=curdir;
  batchdir=udir[dn].subnum;
  d=directories[batchdir];
  dliscan1(batchdir);

  if (numf>=d.maxfiles) {
    nl();
    pl("This directory is currently full.");
    nl();
    closedl();
    return;
  }

  if (d.mask & mask_no_uploads) {
    nl();
    pl("Uploads are not allowed to this directory.");
    nl();
    closedl();
    return;
  }

  closedl();

  l=(long)freek1(d.dpath);
  sprintf(s,"Upload - %ldk free.",l);
  dtitle(s);
  npr("0Enter File Names to 2Upload0:5 <Multiple File Names Ok>\r\n");
  mpl(78);
  input(s,78);

  if (s[0]) {

    strcpy(s1,s);

    p=strtok(s1," ,;");
    while (p) {
      strcpy(s,p);

      if(!okfn(s)) break;
      align(s);

      ok=1;

      if (d.mask & mask_archive) {
          ok=0;
          s1[0]=0;
          for (i=0; i<4; i++) {
            if (syscfg.arcs[i].extension[0] && syscfg.arcs[i].extension[0]!=' ') {
            if (s1[0])
                strcat(s1,", ");
            strcat(s1,syscfg.arcs[i].extension);
            if (strcmp(s+9,syscfg.arcs[i].extension)==0)
                ok=1;
          }
      }

      if (!ok) {
        nl();
        pl("Sorry, all uploads to this directory must be Archived");
        pl("Supported types are:");
        pl(s1);
        break;
       }
      }

      if(ok) {
          strcpy(batch.filename,s);
          if(finddup(batch.filename,0)) {
            npr("8Sorry, you cannot upload that file\r\n");
            nl();
            break;
          }
          npr("7%s5:0Enter a Short Description",s);
          outchr('>');
          inputl(batch.batchdesc,39);
          batch.dir=batchdir;
          batch.sending=0;
          batrec(0,numbatch);
          numbatch++;
          p=strtok(NULL," ,;");
      }
    }

    if(numbatch==0) return;
  }

  printbatchstat(0);
  nl();
  i=get_batchprotocol(1,&i2);
  if(i==-1) return;
  if(i==-2) bidl();
  else batchul(i);
  if(i2) verify_hangup();
}

void addtobatch(uploadsrec u,int dn,int sending)
{
    double t;
    int i;

    for(i=0;i<numbatch;i++) {
        batrec(1,i);
        if(strcmp(u.filename,batch.filename)==0) {
            pl("8File Already in batch queue!");
            return;
        }
    }
    t=((double) (((u.numbytes)+127)/128)) * (1620.0) /
                ((double) (modem_speed));
    batchtime += t;
    batchsize += ((u.numbytes+1023L) /1024L);
    strcpy(batch.filename,u.filename);
    batch.dir=dn;
    batch.time=t;
    batch.sending=sending;
    batch.len=u.numbytes;
    batch.size=((u.numbytes+1023L) /1024L);
    batrec(0,numbatch);
    numbatch++;
    numbatchdl++;
}

void upload()
{
/*    int dir;

    dir=curdir;
    if(thisuser.restrict & restrict_upload) dir=0;
    if(syscfg.sysconfig & sysconfig_all_sysop) dir=0;*/
    newul(-1);
}
