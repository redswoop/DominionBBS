#include "vars.h"
#pragma hdrstop

void noc(char *s, char *s1)
{
  int r=0,w=0;

  while (s1[r]!=0) {
    if (s1[r]==3||s1[r]==14) {
      ++r;
      s[w]=0;
      r++;
    } else
      s[w++]=s1[r++];
  }
  s[w]=0;
}

void boarddata(int n, char *s)
{
  char x,y,k,i,s1[81];
  subboardrec r;

  r=subboards[n];
  if (r.ar==0)
    x=32;
  else {
    for (i=0; i<16; i++)
      if ((1 << i) & r.ar)
        x='A'+i;
  }
  noc(s1,r.name);
  sprintf(s,"3%2d 3%-40s  3%-8s 3%-3d 3%-3d 3%-3d",
            n,s1,r.filename,r.readsl,r.postsl,r.maxmsgs);
}

void showsubs()
{
  int abort,i;
  char s[180];

  outchr(12);
  abort=0;
  pla("0NN2�0Name2��������������������������������������0FileName2�0Rsl2�0Psl2�0Max",
      &abort);
  for (i=0; (i<num_subs) && (!abort); i++) {
    boarddata(i,s);
    pla(s,&abort);
  }
}




void modify_sub(int n)
{
  subboardrec r;
  char s[81],s1[81],ch,ch2;
  int i,i1,done;

  done=0;
  r=subboards[n];

  do {
    outchr(12);
    npr("31. Name         : 0%s\r\n",r.name);
    npr("32. Filename     : 0%s\r\n",r.filename);
    npr("33. Conference   : 0%c\r\n",r.key);
    npr("34. Read SL      : 0%d\r\n",r.readsl);
    npr("35. Post SL      : 0%d\r\n",r.postsl);
    npr("36. Min. Age     : 0%d\r\n",r.age);
    npr("37. Max Msgs     : 0%d\r\n",r.maxmsgs);
    strcpy(s,"None.");
    if (r.ar!=0) {
      for (i=0; i<16; i++)
        if ((1 << i) & r.ar)
          s[0]='A'+i;
      s[1]=0;
    }
    npr("38. AR           : 0%s\r\n",s);
    npr("39. Net Sub Type : 0%d\r\n",r.type);
    npr("30. Storage type : 0%d\r\n",r.storage_type);
    if(r.anony & anony_val_net) s[0]='V'; else s[0]='�';
    if(r.anony & anony_ansi_only) s[1]='G'; else s[1]='�';
    if(r.anony & anony_no_tag) s[2]='A'; else s[2]='�';
    if(r.anony & anony_enable_anony) s[3]='U'; else s[3]='�';
    s[4]=0;
    npr("3Flags           :0 %s\r\n",s);
    nl();
    nl();
    prt(5,"Message Base Edit (?=Help) ? ");
    ch=onek("Q123456789A0AVUGJ[]?");
    switch(ch) {
      case '?': printmenu(28); pausescr(); break;
      case ']': if((n>=0) &&(n<num_subs-1)) {
                      subboards[n++]=r;
                      r=subboards[n];
                   } break;
      case '[': if(n>0) { subboards[n--]=r;
                          r=subboards[n];
                          } break;
      case 'J': nl(); outstr("To Which Sub? ");
                input(s,3);
                if(s[0]) {
                    i=atoi(s);
                    subboards[n]=r;
                    r=subboards[i];
                } break;
      case 'Q':done=1; break;
      case '1':
        nl();
        strcpy(s1,"");
        prt(2,"New Name? ");
        inli(s,s1,40,1);
        if (s[0])
          strcpy(r.name,s);
        break;
      case '2':
        nl();
        prt(2,"New Filename? ");
        input(s,8);
        if ((s[0]!=0) && (strchr(s,'.')==0))
          strcpy(r.filename,s);
        break;
      case '3':
        nl();
        prt(2,"New Conference (@=All): ");
        r.key=onek("ABCDEFGHIJKLMNOPQRSTUVWXYZ@!1234567890");
        break;
      case '4':
        nl();
        prt(2,"New Read SL? ");
        input(s,3);
        i=atoi(s);
        if ((i>=0) && (i<256) && (s[0]))
          r.readsl=i;
        break;
      case '5':
        nl();
        prt(2,"New Post SL? ");
        input(s,3);
        i=atoi(s);
        if ((i>=0) && (i<256) && (s[0]))
          r.postsl=i;
        break;
      case '6':
        nl();
        prt(2,"New Min Age? ");
        input(s,3);
        i=atoi(s);
        if ((i>=0) && (i<128) && (s[0]))
          r.age=i;
        break;
      case '7':
        nl();
        prt(2,"New Max Msgs? ");
        input(s,3);
        i=atoi(s);
        if ((i>0) && (i<512) && (s[0]))
          r.maxmsgs=i;
        break;
      case '8':
        nl();
        prt(2,"New AR (<SPC>=None) ? ");
        ch2=onek("ABCDEFGHIJKLMNOP ");
        if (ch2==32)
          r.ar=0;
        else
          r.ar=1 << (ch2-'A');
        break;

      case '9':
        nl();
        prt(2,"New Sub Type? ");
        input(s,5);
        i=atoi(s);
        if (s[0])
        r.type=i;
        break;
      case '0':
        nl();
        prt(2,"New Storage Type (0,1,2,3) ? ");
        input(s,4);
        i=atoi(s);
        if ((s[0]) && (i>=0) && (i<=2))
          r.storage_type=i;
        break;
      case 'V':
        togglebit(&r.anony,anony_val_net);
        break;
      case 'G':
        togglebit(&r.anony,anony_ansi_only);
        break;
      case 'A':
        togglebit(&r.anony,anony_no_tag);
        break;
      case 'U': togglebit(&r.anony,anony_enable_anony); break;
    }
  } while ((!done) && (!hangup));
  subboards[n]=r;
  if (!wfc)
    changedsl();
}


void insert_sub(int n)
{
  subboardrec r;
  int i,i1,nu;
  userrec u;
  long l1,l2,l3;

  for (i=num_subs-1; i>=n; i--) {
    subboards[i+1]=subboards[i];
    sub_dates[i+1]=sub_dates[i];
  }
  npr("\r\n0Name for New Sub\r\n5: ");
  mpl(41);
  inli(r.name,"",41,1);
  if(!r.name[0]) strcpy(r.name,"New Sub!");
  npr("\r\n0Filename/FidoPath for New Sub\r\n5: ");
  mpl(8);
  input(r.filename,8);
  if(!r.filename[0]) strcpy(r.filename,"NONAME");
  r.key='@';
  r.readsl=10;
  r.postsl=20;
  r.anony=0;
  r.age=0;
  r.maxmsgs=50;
  r.ar=0;
  r.type=0;
  r.storage_type=2;
  subboards[n]=r;
  ++num_subs;
  read_user(1,&u);
  nu=number_userrecs();
  if (n>=32) {
#if MAX_SUBS>32
    l1=0xffffffff >>(64-n);
    l2=0xffffffff <<(n-31);
    l3=1L << (n-32);
    for (i=1; i<=nu; i++) {
      read_user(i,&u);
      if (u.sysopsub!=255)
        if (u.sysopsub>=n)
          ++u.sysopsub;
      for (i1=num_subs-1-32; i1>n-32; i1--)
        u.qscnptr2[i1]=u.qscnptr2[i1-1];
      u.qscnptr2[n-32]=0L;
      u.qscn2=(u.qscn2 & l1) | ((u.qscn2 << 1) & l2) | l3;
      write_user(i,&u);
    }
#endif
  } else {
    l1=0xffffffff >>(32-n);
    l2=0xffffffff <<(n+1);
    l3=1L << n;
    for (i=1; i<=nu; i++) {
      read_user(i,&u);
      if (u.sysopsub!=255)
        if (u.sysopsub>=n)
          ++u.sysopsub;
#if MAX_SUBS>32
      u.qscn2=(u.qscn2 << 1) | (u.qscn >> 31);
      for (i1=num_subs-1-32; i1>0; i1--)
        u.qscnptr2[i1]=u.qscnptr2[i1-1];
      u.qscnptr2[0]=u.qscnptr[31];
#endif
      for (i1=((num_subs<32)?num_subs:32)-1; i1>n; i1--)
        u.qscnptr[i1]=u.qscnptr[i1-1];
      u.qscnptr[n]=0L;
      u.qscn=(u.qscn & l1) | ((u.qscn << 1) & l2) | l3;
      write_user(i,&u);
    }
  }
  modify_sub(n);
}


void delete_sub(int n)
{
  int i,i1,i2,nu;
  userrec u;
  long l1,l2;
  char s[81];

  sprintf(s,"%s%s.SUB",syscfg.datadir,subboards[n].filename);
  unlink(s);
  sprintf(s,"%s%s.MSG",syscfg.msgsdir,subboards[n].filename);
  unlink(s);
  for (i=n; i<num_subs; i++) {
    subboards[i]=subboards[i+1];
    sub_dates[i]=sub_dates[i+1];
  }
  --num_subs;
  read_user(1,&u);
  nu=number_userrecs();
  if (n>=32) {
#if MAX_SUBS>32
    l1=0xffffffff >>(64-n);
    l2=0xffffffff <<(n-32);
    for (i=1; i<=nu; i++) {
      read_user(i,&u);
      if (u.sysopsub==n)
        u.sysopsub=255;
      else
        if ((u.sysopsub>n) && (u.sysopsub!=255))
          --u.sysopsub;
      for (i1=n-32; i1<num_subs-32; i1++)
        u.qscnptr2[i1]=u.qscnptr2[i1+1];
      u.qscnptr[MAX_SUBS-1]=0L;
      u.qscn2=(u.qscn2 & l1) | ((u.qscn2 >> 1) & l2);
      write_user(i,&u);
    }
#endif
  } else {
    l1=0xffffffff >>(32-n);
    l2=0xffffffff <<(n);
    for (i=1; i<=nu; i++) {
      read_user(i,&u);
      if (u.sysopsub==n)
        u.sysopsub=255;
      else
        if ((u.sysopsub>n) && (u.sysopsub!=255))
          --u.sysopsub;
      if (num_subs>31)
        i2=31;
      else
        i2=num_subs;
      for (i1=n; i1<i2; i1++)
        u.qscnptr[i1]=u.qscnptr[i1+1];
#if MAX_SUBS>32
      u.qscnptr[31]=u.qscnptr2[0];
      for (i1=0; i1<num_subs-32; i1++)
        u.qscnptr2[i1]=u.qscnptr[i1+1];
      u.qscnptr2[MAX_SUBS-33]=0L;
      u.qscn=(u.qscn & l1) | ((u.qscn >> 1) & l2) | (u.qscn2 << 31);
      u.qscn2=u.qscn2 >> 1;
#else
      u.qscn=(u.qscn & l1) | ((u.qscn >> 1) & l2);
      u.qscnptr[MAX_SUBS-1]=0L;
#endif
      write_user(i,&u);
    }
  }
}



void boardedit()
{
  int i,i1,i2,done,f;
  char s[81],s1[81],s2[81],ch;

  if (!checkpw())
    return;
  showsubs();
  done=0;
  do {
    nl();
    outstr(get_string2(1));
    ch=onek("QDIM?");
    switch(ch) {
      case '?':
        showsubs();
        break;
      case 'Q':
        done=1;
        break;
      case 'M':
        nl();
        prt(2,"Sub number? ");
        input(s,2);
        i=atoi(s);
        if ((s[0]!=0) && (i>=0) && (i<num_subs))
          modify_sub(i);
        break;
      case 'I':
        if (num_subs<50) {
          nl();
          prt(2,"Insert before which sub? ");
          input(s,2);
          i=atoi(s);
          if ((s[0]!=0) && (i>=0) && (i<=num_subs))
            insert_sub(i);
        }
        break;
      case 'D':
        nl();
        prt(2,"Delete which sub? ");
        input(s,2);
        i=atoi(s);
        if ((s[0]!=0) && (i>=0) && (i<num_subs)) {
          nl();
          sprintf(s1,"Delete %s? ",subboards[i].name);
          prt(5,s1);
          if (yn())
            delete_sub(i);
        }
        break;
    }
  } while ((!done) && (!hangup));
  sprintf(s,"%sSUBS.DAT",syscfg.datadir);
  f=open(s,O_RDWR | O_BINARY | O_CREAT | O_TRUNC, S_IREAD | S_IWRITE);
  write(f,(void *)&subboards[0], num_subs * sizeof(subboardrec));
  close(f);
}

void confdata(int n, char *s)
{
  char x,y,k,i,s1[81];
  confrec r;

  r=conf[n];
  noc(s1,r.name);
  sprintf(s,"3%2d  3%-40s 3%-8s 3%s",n,s1,r.sl,r.flagstr);
}

void showconf()
{
  int abort,i;
  char s[180];

  outchr(12);
  abort=0;
  pla("0NN2��0Name2�������������������������������������0SL2�������0Flags2������������������",&abort);
  for (i=0; (i<num_conf) && (!abort); i++) {
    confdata(i,s);
    pla(s,&abort);
  }
}



void modify_conf(int n)
{
  confrec r;
  char s[81],s1[81],ch,ch2;
  int i,i1,done;

  done=0;
  r=conf[n];

  do {
    outchr(12);
    npr("1. Name       : %s\r\n",r.name);
    npr("2. SL         : %s\r\n",r.sl);
    npr("3. Flags      : %s\r\n",r.flagstr);
    nl();
    prt(2,"Which (1-3,Q,[,],J) ?");
    ch=onek("Q123J[]T");
    switch(ch) {
      case ']': if((n>=0) && (n<num_conf-1))
      { conf[n++]=r;
        r=conf[n];
        } break;

      case '[': if(n>0) { conf[n--]=r;
                          r=conf[n];
                          } break;
      case 'J': nl(); outstr("To Which Conference? ");
                input(s,3);
                if(s[0]) {
                    i=atoi(s);
                    conf[n]=r;
                    r=conf[i];
                } break;
      case 'Q':done=1; break;
      case '1':
        nl();
        strcpy(s1,"");
        prt(5,"New Name? ");
        inli(s,s1,40,1);
        if (s[0]) strcpy(r.name,s);
        break;
      case '2':
        nl();
        prt(5,"New SL (Can Include Menu Type Codes)? ");
        input(s,10);
        if(s[0])  strcpy(r.sl,s);
        break;
      case '3':
        nl();
        prt(5,"Flags: ");
        input(s,10);
        if(s[0]) strcpy(r.flagstr,s);
        break;
    }
  } while ((!done) && (!hangup));
  conf[n]=r;
  if (!wfc)
    changedsl();
}


void insert_conf(int n)
{
  confrec r;
  int i,i1,nu;
  userrec u;
  long l1,l2,l3;

  for (i=num_conf-1; i>=n; i--)
    conf[i+1]=conf[i];

  strcpy(r.name,">New Conference<");
  strcpy(r.sl,"s20");
  strcpy(r.flagstr,"");
  conf[n]=r;
  ++num_conf;
  modify_conf(n);
}


void delete_conf(int n)
{
  int i,i1,nu;
  userrec u;
  long l1,l2;

  for (i=n; i<num_conf; i++)
    conf[i]=conf[i+1];
  --num_conf;
  if (!wfc)
    changedsl();
}


void confedit()
{
  int i,i1,i2,done,f;
  char s[81],s1[81],s2[81],ch;

  if (!checkpw())
    return;
  showconf();
  done=0;
  do {
    nl();
    outstr(get_string2(1));
    ch=onek("QDIM?");
    switch(ch) {
      case '?':
        showconf();
        break;
      case 'Q':
        done=1;
        break;
      case 'M':
        nl();
        prt(2,"Conference number? ");
        input(s,2);
        i=atoi(s);
        if ((s[0]!=0) && (i>=0) && (i<num_conf))
          modify_conf(i);
        break;
      case 'I':
        if (num_conf<50) {
          nl();
          prt(2,"Insert before which conf? ");
          input(s,2);
          i=atoi(s);
          if ((s[0]!=0) && (i>=0) && (i<=num_conf))
            insert_conf(i);
        }
        break;
      case 'D':
        nl();
        prt(2,"Delete which conf? ");
        input(s,2);
        i=atoi(s);
        if ((s[0]!=0) && (i>=0) && (i<num_conf)) {
          nl();
          sprintf(s1,"Delete %s? ",conf[i].name);
          prt(5,s1);
          if (yn())
            delete_conf(i);
        }
        break;
    }
  } while ((!done) && (!hangup));
  sprintf(s,"%sConf.DAT",syscfg.datadir);
  f=open(s,O_RDWR | O_BINARY | O_CREAT | O_TRUNC, S_IREAD | S_IWRITE);
  write(f,(void *)&conf[0], num_conf * sizeof(confrec));
  close(f);
}




