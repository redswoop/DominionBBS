#include "vars.h"
#pragma hdrstop

#include <dir.h>

menurec m[51];
mmrec pp2;
int maxcmd2=0;


void menuinfoed(char fn[15])
{
    mciok=0;

    outchr(12);
    npr("3Menu File Name: %s\r\n",fn);
    nl();
    npr("01. Prompt       : %s\r\n",pp2.prompt);
    npr("2. Pause File   : %s\r\n",pp2.pausefile);
    npr("3. Titles       : %s\r\n",pp2.title1);
    if(pp2.title2[0]) npr("                : %s\r\n",pp2.title2);
    npr("4. Ansi Menu    : %s\r\n",pp2.altmenu[0]?pp2.altmenu:"\"\"");
    npr("5. Security     : %s\r\n",pp2.slneed[0]?pp2.slneed:"None");
    npr("6. Change Style : %d,%d,%d - %d Columns\r\n",pp2.fallback[0],pp2.fallback[1],pp2.fallback[2],pp2.fallback[3]);
    npr("7. 3D Effects   : %s\r\n",pp2.fallback[4]?"Yes":"No");
    nl();
    mciok=1;
}


void edmenu (int x)
{
    int i,y,z;
    char ch,s[81],done=0,s1[81],fn[15];

    do {
        outchr(12);
        npr("Editing Command #%d\r\n",x); nl();
        npr("1. Desc     : %s\r\n",m[x].desc);
        npr("2. Key      : %s\r\n",m[x].key);
        npr("3. Type     : %s\r\n",m[x].type);
        npr("4. Attirbute: %c",m[x].at);
        nl();
        npr("5. Security : %s\r\n",m[x].sl);
        npr("6. Line     : %s\r\n",m[x].line);
        npr("7. Mstring  : %s\r\n",m[x].ms);
        nl();
        outstr("5Command Editor (?=Help) ");
        ch=onek("1234567QV?[]");
        nl();
        strcpy(s,"");
        strcpy(s1,"");
        switch(ch)
        {
            case 'V': showmenucol(m,pp2,maxcmd2); break;
            case ']': if(x<maxcmd2-1) x++; break;
            case '[': if(x>0) x--; break;
            case 'Q': done=1; break;
            case '1': npr("3Description\r\n5: ");
                      inli(s,m[x].desc,80,1);
                      if(s[0]) strcpy(m[x].desc,s); break;
            case '3': npr("3Type\r\n5: ");
                      mpl(3);
                      input(s,3);
                      if(s[0]) strcpy(m[x].type,s); break;
            case '2': npr("3Key\r\n5: ");
                      mpl(9);
                      input(s,9);
                      if(s[0]) strcpy(m[x].key,s); break;
            case '5': thespot:
                      npr("3Security (? on Blank=Help)\r\n5: ");
                      mpl(9);
                      input(s,9);
                      if(s[0]=='?') {
                        printmenu(27);
                        goto thespot;
                      }
                      if(s[0]) strcpy(m[x].sl,s); break;
            case '6': pl("Line: ");
                      outstr(": "); inli(s,m[x].line,50,1);
                      if(s[0]) strcpy(m[x].line,s); break;
            case '7': pl("Mstring: ");
                      outstr(": "); inli(s,m[x].ms,80,1);
                      strcpy(m[x].ms,s); break;
            case '4': npr("3Attribute (4H3idden, 4F3orced, 4U3nhidden, 4D3efault, 4T3itle5)\r\n: ");
                      s[0]=onek("\rHUDFTP ");
                      if(s[0]=='\r') s[0]=32;
                      m[x].at=s[0];
                      break;
        }
   } while(!done);
}

void top(char fn[15])
{
    int x;
    char s[81],s1[81],s2[81],s3[81];

        outchr(12);
        npr("5Current Menu: 3%s\r\n",fn);
        nl();
        for(x=0;x<=maxcmd2;x++) {
            noc(s3,m[x].ms);
            sprintf(s,"%2d. %-2s %-28.28s",x,m[x].type,s3);
            x++;
            noc(s3,m[x].ms);
            sprintf(s1,"%2d. %-2s %-28.28s",x,m[x].type,s3);
            npr("%-39.39s %-39.39s\r\n",s,s1);
        }
        nl();
}

void menu(char fn[15])
{
    char ch,s[81],done=0;
    struct ffblk f;

    if(!checkpw())
        return;

        sprintf(s,"%s*.mnu",nifty.menudir);
        findfirst(s,&f,0);
        outchr(12);
        pl("5Menu Files Available to Edit");
        nl();
        do npr("0%-20s",f.ff_name); while(findnext(&f)!=-1);

    do {
        nl();
        nl();
        npr("5Menu Editor (?=Help)0 ");
        ch=onek("QIMD?\r");
        switch(ch) {
            case 13 : sprintf(s,"%s*.mnu",nifty.menudir);
                      findfirst(s,&f,0);
                      outchr(12);
                      pl("5Menu Files Available to Edit");
                      nl();
                      do npr("0%-20s",f.ff_name); while(findnext(&f)!=-1);
                      nl();
                      nl();
                      break;
            case '?': printmenu(25); break;
            case 'Q': done=1; break;
            case 'M': nl();
                      npr("3File To Edit?\r\n5: ");
                      mpl(8);
                      input(fn,8);
                      sprintf(s,"%s%s.mnu",nifty.menudir,fn);
                      if(exist(s)) menued(fn);
                      else npr("\r\n4%s Not Found\r\n`P",fn);
                      break;
            case 'D': nl();
                      npr("3File To Delete?\r\n5: ");
                      mpl(8);
                      input(fn,8);
                      if(!fn[0]) break;
                      sprintf(s,"%s%s.mnu",nifty.menudir,fn);
                      if(exist(s)) unlink(s);
                      else npr("\r\n4%s Not Found\r\n`P",fn);
                      break;
             case 'I': nl();
                      npr("3File To Add?\r\n5: ");
                      mpl(8);
                      input(fn,8);
                      if(!fn[0]) break;  
                      sprintf(s,"%s%s.mnu",nifty.menudir,fn);
                      if(!exist(s)) addmenu(fn);
                      else npr("\r\n4%s All Ready Exists\r\n`P",fn);
                      break;
        }
    } while(!done&&!hangup);
}

void addmenu(char fn[15])
{
    int i;
    char s[81];

    sprintf(s,"%s%s.mnu",nifty.menudir,fn);
    i=open(s,O_RDWR|O_TRUNC|O_CREAT,S_IREAD|S_IWRITE);
    strcpy(pp2.prompt,"Select: ");
    strcpy(pp2.title1,"�Dominion Bulletin Board System");
    strcpy(pp2.title2,"�A New Menu");
    strcpy(pp2.altmenu,"");
    strcpy(pp2.pausefile,"");
    strcpy(pp2.slneed,"");
    pp2.fallback[0]=5;
    pp2.fallback[1]=2;
    pp2.fallback[2]=0;
    pp2.fallback[3]=4;
    pp2.fallback[4]=1;
    strcpy(m[0].desc,"<NEW> Menu Command");
    strcpy(m[0].type,"OL");
    strcpy(m[0].line,"A New Command");
    m[0].at=0;
    strcpy(m[0].ms,"A New Command");
    write(i,&pp2,sizeof(mmrec));
    write(i,&m[0],sizeof(menurec));
    write(i,&m[0],sizeof(menurec));
    close(i);
    menued(fn);
}

void extractheader(char *fn)
{
    FILE *f;
    char s[81];

    sprintf(s,"%s.hed",fn);
    f=fopen(s,"wt");
    fputs(pp2.prompt,f); fputs("\n",f);
    fputs(pp2.title1,f); fputs("\n",f);
    fputs(pp2.title2,f); fputs("\n",f);
    fputs(pp2.altmenu,f); fputs("\n",f);
    fprintf(f,"%d,%d,%d\n",pp2.fallback[0],pp2.fallback[1],pp2.fallback[2]);
    fprintf(f,"%d",pp2.fallback[3]);
    fputs(pp2.slneed,f); fputs("\n",f);
    fputs(pp2.pausefile,f); fputs("\n",f);
    fclose(f);
    npr("Menu Header Extracted to %s\r\n",s);
    pausescr();
}

void readheader(char *fn)
{
    FILE *f;
    char s[81];

    sprintf(s,"%s.hed",fn);
    f=fopen(s,"rt");

    fgets(s,161,f); filter(s,'\n'); strcpy(pp2.prompt,s);
    fgets(s,161,f); filter(s,'\n'); strcpy(pp2.title1,s);
    fgets(s,161,f); filter(s,'\n'); strcpy(pp2.title2,s);
    fgets(s,161,f); filter(s,'\n'); strcpy(pp2.altmenu,s);

    fgets(s,161,f); sscanf(s,"%d,%d,%d\n",&pp2.fallback[0],&pp2.fallback[1],&pp2.fallback[2]);
    fgets(s,161,f); sscanf(s,"%d\n",&pp2.fallback[3]);
    fgets(s,161,f); filter(s,'\n'); strcpy(pp2.slneed,s);
    fgets(s,161,f); filter(s,'\n'); strcpy(pp2.pausefile,s);
    fclose(f);
    npr("Menu Header Read from %s.hed\r\n",fn);
    pausescr();
}

void menued(char fn[15])
{
    int i,x=0,y,z,type=1,d1=0;
    char ch,s[161],s1[161],done=0;
    menurec back;
    maxcmd2=0;

    if(!strchr(fn,'.'))
    sprintf(s,"%s%s.mnu",nifty.menudir,fn);
    else sprintf(s,"%s%s",nifty.menudir,fn);
    i=open(s,O_RDWR|O_BINARY|O_CREAT,S_IREAD|S_IWRITE);

    lseek(i,0L,SEEK_SET);
    read(i,(void *)&pp2,sizeof(mmrec));
    while(read(i,(void *)&m[maxcmd2],sizeof(menurec))) maxcmd2++;
    if(type) top(fn); else menuinfoed(fn);
    do {
        outstr("5Menu Editor (?=Help):0 ");
        ch=onek("-PQMDI?XV1234567890ER\r");
        switch(ch) {
            case '-': for(x=0;x<maxcmd2;x++) m[x].at=32; break;
            case 'E': extractheader(fn); break;
            case 'R': readheader(fn); break;
            case  13: if(type) top(fn); else menuinfoed(fn); break;
            case '?': printmenu(8); break;
            case '1': pl("Prompt:");
                      outstr(": "); inli(s,s1,99,1);
                      if(s[0]) strcpy(pp2.prompt,s); break;
            case '2': pl("Animated Pause File Name (Enter=Standard Pause(pause.scr))");
                      outstr(": "); input(s,10);
                      strcpy(pp2.pausefile,s); break;
            case '3': pl("Title 1:");
                      outstr(": "); inli(s,pp2.title1,51,1);
                      if(s[0]) strcpy(pp2.title1,s);
                      pl("Title 2:");
                      outstr(": "); inli(s,pp2.title2,51,1);
                      if(s[0]) strcpy(pp2.title2,s);  break;
            case '4': pl("Ansi Menu File Name");
                      outstr(": "); input(s,10);
                      if(s[0]) strcpy(pp2.altmenu,s); break;
            case '5': pl("Security");
                      outstr(": "); input(s,10);
                      if(s[0]) strcpy(pp2.slneed,s); break;
            case '7': if(pp2.fallback[4]) pp2.fallback[4]=0; else pp2.fallback[4]=1; break;
            case '6': do {
                      outchr(12);
                      npr("0Menu Style Editor\r\n"); nl();
                      npr("1. Brackets    : %d\r\n",pp2.fallback[0]);
                      npr("2. Commands    : %d\r\n",pp2.fallback[1]);
                      npr("3. Description : %d\r\n",pp2.fallback[2]);
                      npr("4. Columns     : %d\r\n",pp2.fallback[3]);
                      npr("5. Border Char : %c\r\n",pp2.fallback[4]);
                      npr("6. Border Attr : %d\r\n",pp2.fallback[5]);
                      nl();
                      outstr("Select: ");
                      ch=onek("123456VQ\r");
                      switch(ch) {
                      case '5':  outstr("Enter new Border Character: ");
                                 input(s,2);
                                 pp2.fallback[4]=s[0];
                                 break;
                      case '6':  outstr("Enter new Border Attribute: ");
                                 input(s,2);
                                 pp2.fallback[5]=atoi(s);
                                 break;
                      case '4':  outstr("Enter Number of Columns (1,2,4) ");
                                 input(s,2);
                                 pp2.fallback[3]=atoi(s);
                                 break;
                      case '1':  outstr("Brackets: "); input(s,2);
                                 if(s[0]) pp2.fallback[0]=atoi(s);
                                 break;
                      case '2':  outstr("Command Key: "); input(s,2);
                                 if(s[0]) pp2.fallback[1]=atoi(s);
                                 break;
                      case '3':  outstr("Description: "); input(s,2);
                                 if(s[0]) pp2.fallback[2]=atoi(s);
                                 break;
                      case 'V': showmenucol(m,pp2,maxcmd2); break;
                      case '\r':
                      case 'Q': d1=1; break;
                      }
                   } while(!d1);
                   break;
            case 'Q': done=1; break;
            case 'X': type=opp(type);
                      if(type) top(fn); else menuinfoed(fn);
                      break;
            case 'M': nl();
                      outstr("Start at which Command: ");
                      input(s,3);
                      x=atoi(s);
                      edmenu(x); break;
            case 'I': if(maxcmd2<50)
                      nl();
                      outstr("Before which command? ");
                      input(s,2); if(!s[0]) break;
                      y=atoi(s);
                      maxcmd2++;
                      for(z=maxcmd2-1;z>=y; z--)
                        m[z+1]=m[z];
                      strcpy(m[y].desc,"<NEW> Command");
                      strcpy(m[y].key,"NEW");
                      strcpy(m[y].line,"A New Command");
                      strcpy(m[y].sl,"");
                      strcpy(m[y].type,"OL");
                      strcpy(m[y].ms,"A New Command");
                      m[y].at=0; break;
            case 'D': outstr("Which command? ");
                      input(s,2); if(!s[0]) break;
                      y=atoi(s);
                      for(x=y;x<maxcmd2;x++)
                        m[x]=m[x+1];
                       maxcmd2--;
                      break;
            case 'P': outstr("Which command? ");
                      input(s,2); if(!s[0]) break;
                      y=atoi(s);
                      back=m[y];
                      for(x=y;x<maxcmd2;x++)
                        m[x]=m[x+1];
                      outstr("Where? ");
                      input(s,2); if(!s[0]) break;
                      y=atoi(s);
                      for(z=maxcmd2-1;z>=y; z--)
                        m[z+1]=m[z];
                      m[y]=back;
                      break;
            case 'V': showmenucol(m,pp2,maxcmd2); break;
        }
   } while(!done&&!hangup);
   close(i);

   sprintf(s,"%s%s.mnu",nifty.menudir,fn);
   i=open(s,O_RDWR|O_BINARY|O_CREAT|O_TRUNC,S_IREAD|S_IWRITE);
   lseek(i,0L,SEEK_SET);
   write(i,(void *)&pp2,sizeof(mmrec));
   write(i,(void *)&m,sizeof(menurec)*maxcmd2);
   close(i);
}

