#include "vars.h"

#pragma hdrstop

#include <dir.h>
#include <math.h>
extern char menuat[15];

void bargraph1(int percent)
{
    int x;
    for(x=0;x<percent/2;x++)
         printf("%c",219);
}



void dotopinit(char fn[40],int per)
{
      int i;
      printf("[2;2H"); for(i=0;i<48;i++) printf(" ");
      printf("[2;2H[36mReading[37m %s[3;2H",fn);
      bargraph1(per);
}

void init(int show)
{
  char s[161],*buf,ch,*ss;
  int i,i1,i2,sm,cp,n,f;
  long l;
  union REGS r;
  struct date today;
  votingrec v;

  crttype=peekb(0x0040,0x0049);
  if (crttype==7)
    scrn=MK_FP(0xb000,0x0000);
  else
    scrn=MK_FP(0xb800,0x0000);
  r.h.ah=15;
  int86(0x10,&r,&r);
  sm=r.h.al;
  if (r.h.ah!=80) {
    printf("\n\nYou must be in 80 column mode to run BBS.\n\n");
    err(6,"","In Xinit.c");
  }
  if ((sm==4) || (sm==5) || (sm==6)) {
    printf("\n\nYou must be in text mode to run BBS.\n\n");
    err(6,"","In Xinit.c");
  }
  defscreenbottom=(int) peekb(0x0000,0x0484);
  if (defscreenbottom<24)
    defscreenbottom=24;
  if (defscreenbottom>63)
    defscreenbottom=24;
  if ((defscreenbottom!=42) && (defscreenbottom!=49))
    defscreenbottom=24;
  screenbottom=defscreenbottom;
  screenlen=160*(screenbottom+1);

  if(!exist("restore.dom")) restoring_shrink=0; else restoring_shrink=1;
  if (!exist("restore.dom")&&!show) {
    clrscr();
    makewindow(0,0,52,4);
    printf("[2;2H[33;1m%s",wwiv_version);
  }
  strcpy(cdir,"X:\\");
  cdir[0]='A'+getdisk();
  getcurdir(0,&(cdir[3]));
  userfile=-1;
  configfile=-1;
  statusfile=-1;
  dlf=-1;
  curlsub=-1;
  curldir=-1;
  oldx=0;
  oldy=0;
  itimer();
  use_workspace=0;
  input_extern=0;
  chat_file=0;
  do_event=0;
  sysop_alert=0;
  global_handle=0;

  sprintf(ver_no1,"BBS=%s",wwiv_version);

  getdate(&today);
  if (today.da_year<1992) {
    printf("\r\nYou need to set the date & time before running the BBS.\n");
    exit(7);
  }

  if(!restoring_shrink&&!show) {
      dotopinit("Config.dat",10);
  }

  printf("[3;2H");
  bargraph(0);
  configfile=open("CONFIG.DAT",O_RDWR | O_BINARY);
  if (configfile<0) {
    printf("\n\nConfig.Dat, Main Configuration File, Not Found!!.\n");
//    err(1,"Config.dat","In Xinit.c");
    exit(1);
  }

  read(configfile,(void *) (&syscfg), sizeof(configrec));
  read(configfile,&nifty,sizeof(niftyrec));
  close(configfile);

  /* update user info data */
  syscfg.userreclen=sizeof(userrec);
  syscfg.waitingoffset=FP_OFF(&(thisuser.waiting))-FP_OFF(&thisuser);
  syscfg.inactoffset=FP_OFF(&(thisuser.inact))-FP_OFF(&thisuser);
  syscfg.sysstatusoffset=FP_OFF(&(thisuser.sysstatus))-FP_OFF(&thisuser);

  /* store the new config.dat file */
  configfile=open("CONFIG.DAT",O_RDWR | O_BINARY);
  lseek(configfile,0L,SEEK_SET);
  write(configfile,(void *)&syscfg,sizeof(configrec));
  write(configfile,(void *)&nifty,sizeof(niftyrec));
  close(configfile);

  if (!syscfg.primaryport)
    ok_modem_stuff=0;

  dotopinit("Checking Directories",15);

  strcpy(s,syscfg.datadir);
  strcat(s,"nul");

  if (!exist(s)) {
    printf("\n\nYour Data directory isn't valid!  Now set to: %s\n",syscfg.datadir);
//    exit(1);
  }

  strcpy(s,syscfg.gfilesdir);
  strcat(s,"nul");


  if (!exist(s)) {
    printf("\n\nYour Afiles directory isn't valid!  Now set to: %s\n",syscfg.gfilesdir);
//    exit(1);
  }

  strcpy(s,nifty.menudir);
  strcat(s,"nul");

  if (!exist(s)) {
    printf("\n\nYour Menu directory isn't valid!  Now set to: %s\n",nifty.menudir);
//    exit(1);
  }


 if(!restoring_shrink&&!show) {
      dotopinit("Status.dat",20);
  }

  sprintf(s,"%sSTATUS.DAT",syscfg.datadir);
  statusfile=open(s,O_RDWR | O_BINARY);
  if (statusfile<0) {
//    err(1,s,"In Xinit.c");
    printf("\n\n\n%sStatus.Dat not found!\n\n",syscfg.datadir);
    exit(1);
  }

  read(statusfile,(void *)(&status), sizeof(statusrec));
  close(statusfile);
  status.wwiv_version=wwiv_num_version;
  gat=(short *) mallocx(2048 * sizeof(short));
  smallist=(smalrec *) mallocx((long)syscfg.maxusers * (long)sizeof(smalrec));

  screensave.scrn1=(char *)mallocx(screenlen);

  read_in_file("MENUS.MSG",(menus),50);

  sprintf(s,"%suser.idx",syscfg.datadir);
  i=open(s,O_RDWR | O_BINARY);
  if (i<0) {
    reset_files();
  } else {
      read(i,(void *) (smallist), (sizeof(smalrec) * status.users));
      close(i);
  }


  subboards=(subboardrec *) mallocx(MAX_SUBS*sizeof(subboardrec));
  directories=(directoryrec *)mallocx(MAX_DIRS*sizeof(directoryrec));
  if(!restoring_shrink&&!show) {
      dotopinit("Config.dat",40);
  }

  sprintf(s,"%sSUBS.DAT",syscfg.datadir);
  i=open(s,O_RDWR | O_BINARY);
  if (i<0) {
//    err(1,s,"In Xinit.c");
    printf("\n\n%sSubs.Dat not found!",syscfg.datadir);
    exit(1);
  }
  num_subs=(read(i,subboards, (MAX_SUBS*sizeof(subboardrec))))/
           sizeof(subboardrec);
  close(i);
  if(!restoring_shrink&&!show) {
      dotopinit("Subs.dat",50);
  }

  sprintf(s,"%sDIRS.DAT",syscfg.datadir);
  i=open(s,O_RDWR | O_BINARY);
  if (i<0) {
//    err(1,s,"In Xinit.c");
    printf("\n\n%sDirs.dat Not found!\n\n",syscfg.datadir);
    exit(1);
  }

  num_dirs=(read(i,directories, (MAX_DIRS*sizeof(directoryrec))))/
           sizeof(directoryrec);
  close(i);

  i=open("fnet.dat",O_BINARY|O_RDWR|O_CREAT,S_IREAD|S_IWRITE);
  read(i,&fnet,sizeof(fnet));
  close(i);

  if(!restoring_shrink&&!show) {
      dotopinit("Protocol.dat",60);
  }
  sprintf(s,"%sprotocol.dat",syscfg.datadir);
  i=open(s,O_RDWR | O_BINARY);
  if(i<0) {
        printf("\n\n%sProtocol.dat Not Found\n",syscfg.datadir);
//        err(1,s,"In Xinit.c");
        exit(1);
  }
  numextrn=(read(i,(void *)&proto,20*sizeof(protocolrec)))/
          sizeof(protocolrec);
  close(i);

  if(!restoring_shrink&&!show) {
      dotopinit("Conf.dat",70);
  }

  sprintf(s,"%sconf.dat",syscfg.datadir);
  i=open(s,O_RDWR | O_BINARY);
  if(i<0) {
    printf("\n\n%sConf.dat Not Found!\n\n",syscfg.datadir);
  //  err(1,s,"In Xinit.c");
  }
  num_conf=(read(i,(void *)&conf,20*sizeof(confrec)))/ sizeof(confrec);
  close(i);

  numed=0;

  sprintf(s,"%sVOTING.DAT",syscfg.datadir);
  f=open(s,O_RDWR | O_BINARY);
  if (f>0) {
    n=(int) (filelength(f) / sizeof(votingrec)) -1;
    for (i=0; i<n; i++) {
      lseek(f,(long) i * sizeof(votingrec),SEEK_SET);
      read(f,(void *)&v,sizeof(votingrec));
      if (v.numanswers)
        questused[i]=1;
    }
    close(f);
  }

  sprintf(s,"%sMODEM.DAT",syscfg.datadir);
  i=open(s,O_RDWR | O_BINARY);
  if (i>0) {
    l=filelength(i);
    modem_i = mallocx(l);
    read(i,modem_i, (unsigned) l);
    close(i);
  } else {
      printf("\n\n%sModem.Dat not found!\n\n",syscfg.datadir);
  }

  read_user(1,&thisuser);
  if (thisuser.inact & inact_deleted)
    fwaiting=0;
  else
    fwaiting=thisuser.waiting;
  sl1(2,status.date1);
  if (ok_modem_stuff) {
    initport(syscfg.primaryport);
    do_result(&(modem_i->defl));
  }
  if (syscfg.sysconfig & sysconfig_no_local)
    topdata=0;
  else
    topdata=2;
  ss=getenv("PROMPT");
  strcpy(newprompt,"PROMPT=BBS: ");
  if (ss)
    strcat(newprompt,ss);
  else
    strcat(newprompt,"$P$G");
  sprintf(dszlog,"%s\\BBSDSZ.LOG",cdir);
  sprintf(s,"DSZLOG=%s",dszlog);
  i=i1=0;
  while (environ[i]!=NULL) {
    if (strncmp(environ[i],"PROMPT=",7)==0)
      xenviron[i1++]=newprompt;
    else
      if (strncmp(environ[i],"DSZLOG=",7)==0)
        xenviron[i1++]=strdup(s);
      else {
        if (strncmp(environ[i],"BBS=",4) && (strncmp(environ[i],"WWIV_FP=",8)))
          xenviron[i1++]=environ[i];
      }
    ++i;
  }
  if (!getenv("DSZLOG"))
    xenviron[i1++]=strdup(s);
  if (!ss)
    xenviron[i1++]=newprompt;
  xenviron[i1++]=ver_no1;
  xenviron[i1]=NULL;

  for (i=0; i<20; i++)
    questused[i]=0;
  readinvoting=0;
  readeditor=0;

  if(!restoring_shrink&&!show) {
      dotopinit("Final Data",95);
  }
  if (syscfg.sysconfig & sysconfig_high_speed)
    high_speed=1;
  else
    high_speed=0;
  time_event=((double)syscfg.executetime)*60.0;
  last_time=time_event-timer();
  if (last_time<0.0)
    last_time+=24.0*3600.0;
  do_event=0;
  if (status.callernum!=65535) {
    status.callernum1=(long)status.callernum;
    status.callernum=65535;
    save_status();
  }
  msgs=(postrec *) mallocx((long)(255 * sizeof(postrec)));
  frequent_init();
  if (!restoring_shrink&&!show && !already_on) {
    remove_from_temp("*.*",syscfg.tempdir,0);
    remove_from_temp("*.*",syscfg.batchdir,0);
  }
  if(!restoring_shrink&&!show) menuat[0]=0;
  lecho=ok_local();
  quote=NULL;
  bquote=0;
  equote=0;
  quoting=0;

 daylight=0;
#ifdef MOUSE
 initpointer(1);
#endif
printf("[3;2H");
bargraph(100);
printf("[2;2HCompleted Loading - [36;1mEntering WFC[37m\n\n\n");

}

void remove_from_temp(char *fn, char *dir, int po)
{
  int i,i1,f1,ok;
  char s[81],s1[81];
  struct ffblk ff;
  uploadsrec u;

  sprintf(s1,"%s%s",dir,stripfn(fn));
  f1=findfirst(s1,&ff,0);
  ok=1;
  nl();
  while ((f1==0) && (ok)) {
    sprintf(s,"%s%s",dir,ff.ff_name);
    if (po)
      npr("Deleting %s\r\n",ff.ff_name);
    _chmod(s,1,0);
    unlink(s);
    f1=findnext(&ff);
  }
}

void readvotingdata()
{
  int f,i,n;
  char s[81];

  readinvoting=1;

}

void readeditors()
{
  int i;
  char s[81];
  long l;

  readeditor=1;
  sprintf(s,"%sEDITORS.DAT",syscfg.datadir);
  i=open(s,O_RDWR | O_BINARY);
  if (i>0) {
    l=filelength(i);
    if (l>10*sizeof(editorrec))
      l=10*sizeof(editorrec);
    editors=mallocx(l+10);
    numed=(read(i,(void *)editors, (unsigned) l))/sizeof(editorrec);
    close(i);
  }

}
