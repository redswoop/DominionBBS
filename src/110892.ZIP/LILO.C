#include "vars.h"

#pragma hdrstop

extern char withansi,MCISTR[161];

void oneliner();

int getmuser()
{
    char *s;

    if(usernum)
        return 1;

    nl();
    npr("3Name/User Number\r\n5: ");
    mpl(31);
    input(s,31);
    usernum=finduser(s);
    if(usernum) {
      read_user(usernum,&thisuser);
      nl();
      npr("3Password\r\n5: ");
      mpl(21);
      echo=0;
      input(s,21);
      echo=1;
      if(strcmp(s,thisuser.pw)) {
          nl();
          npr("7Incorrect.\r\n\r\n");
          usernum=0;
          return 0;
      }
      nl();
      if (thisuser.waiting) {
          ansic(5);
          outstr(get_string(50));
          if (yn())
            readmail();
      }
      return 1;
    }
    nl();
    pl("7Unknown User");
    return 0;
}

int matrix(void)
{
    int cnt,done=0;
    char s[161],*ss,c;


    nl();
    if(!printfile("matrix")) printmenu(30);
    usernum=0;

    setcolors(&thisuser);

    do {
      if(cnt>4) {
        hangup=1;
        sl1(0,"9### 0Too many Invalid Matrix Logon Attempts");
        return 0;
      }
      outstr("0Dominion Matrix 5[3?3=3Help5]1 ");
      ss=mmkey(0);
      nl();
      nl();
      switch(ss[0]) {
        case '?': if(!printfile("matrix")) printmenu(30); break;
        case 'L': nl();
                  npr("3Matrix Password?\r\n5: ");
                  mpl(31);
                  input(s,31);
                  if(strcmp(s,nifty.matrix)==0) {
                    done=1;
                    nl();
                    npr("7Correct.0  Welcome to %s",syscfg.systemname);
                    nl();
                    nl();
                  }
                  else {
                    nl();
                    pl("7Incorrect");
                    cnt++;
                  }
                  break;
        case 'C': if(getmuser()) {
                        nl();
                        if(thisuser.sl>syscfg.autoval[nifty.nulevel].sl) {
                            if(thisuser.inact & inact_lockedout) {
                                sprintf(s,"9### 0Locked Out user 4%s0 given Lockout Message",nam(&thisuser,usernum));
                                sl1(0,s);
                                printfile("lockout");
                                pausescr();
                                hangup=1;
                                return 0;
                            }
                            npr("0The Matrix Password is 7'%s'\r\n",nifty.matrix);
                            nl();
                            sprintf(s,"9### 0User 4%s0 received Matrix Password",nam(&thisuser,usernum));
                            sl1(0,s);
                            pausescr();
                            return 1;
                        } else {
                            nl();
                            pl("7Sorry, but you have not been validated yet.");
                            nl();
                            sprintf(s,"9### 0Unvalidated user 4%s0 tried loging on.",nam(&thisuser,usernum));
                            sl1(0,s);

                        }
                    } else cnt++;
                  break;
        case 'H': hangup=1;
                  return 0;
        case 'N': nl();
                  npr("5Logon as New? ");
                  if(yn())
                      newuser();
                  break;
        case 'P': reqchat("Matrix Chat Reason");
                  break;
        case 'E': if(getmuser()) {
                    strcpy(irt,"Matrix Feedback");
                    imail(1,0);
                  }
      }
    } while(!done&&!hangup);

    return 1;
}

void getuser()
{
  char s[81],s2[81],s3[161],*ss,getuseri=1;
  int ok,count,net_only,ans;
  long l;
  FILE *f;

  _setcursortype(2);

  thisuser.sysstatus &= (~sysstatus_ansi);
  thisuser.res[10]=0;

  ans=check_ansi();

  if(ans)
    thisuser.sysstatus |= sysstatus_ansi;


  if(modem_speed<=(int)nifty.lockoutrate&&incom) {
    npr("0Sorry, but %d baud is not Supported.",modem_speed);
    nl();
    sprintf(s,"7!0 Call at unsupported rate, 4%d0.",modem_speed);
    sl1(0,s);
    npr("Please Enter Lockout Password: ");
    input(s2,31);
    if(strcmp(s2,nifty.lockoutpw)) {
        pl("Sorry, Password Incorrect.");
        sl1(0,"9### 0Unsuccesfully tried to logon with invalid Lockout Password");
        nl();
        nl();
        pausescr();
        hangup=1;
        return;
    } else {
        pl("Correct.");
        sl1(0,"9###0 Loged onto system with Lockout Password");
    }
  }
  net_only=1;
  if (syscfg.netlowtime!= syscfg.nethightime) {
    if (syscfg.nethightime>syscfg.netlowtime) {
      if ((timer()<=(syscfg.netlowtime*60.0)) || (timer()>=(syscfg.nethightime*60.0)))
        net_only=0;
    } else {
      if ((timer()<=(syscfg.netlowtime*60.0)) && (timer()>=(syscfg.nethightime*60.0)))
        net_only=0;
    }
  } else
    net_only=0;
  count=0;
  ok=0;
  checkit=1;
  okmacro=0;
  actsl=syscfg.newusersl;

  if(nifty.matrixtype)
      switch(matrix()) {
        case 0: return;
        case 1: break;
        case 2: getuseri=0; break;
    }

  if ((!net_only) && (incom))
      printfile("welcome");

  if(getuseri)
  do {
    nl();
    if (net_only) {
      pl("This time is reserved for net-mail ONLY.");
      pl("Please try calling back again later.");
    } else
      pl(get_string(1));
      pl(get_string(2));
    outstr("NN:");
    backspace();
    backspace();
    backspace();
    outstr(get_string(3));

    input(s,30);
    usernum=finduser(s);
    if ((net_only) && (usernum!=-2))
      usernum=0;
    if (usernum>0) {
      read_user(usernum,&thisuser);
      actsl = syscfg.newusersl;
      topscreen();
      ok=1;
      if(1) {
      outstr(get_string(25));
      echo=0;
      input(s,19);
      if (strcmp(s,thisuser.pw))
        ok=0;
      if ((syscfg.sysconfig & sysconfig_free_phone)) {
        outstr(get_string(29));
        echo=0;
        input(s2,4);
        if (strcmp(s2,&thisuser.phone[8])!=0) {
          ok=0;
          if ((strlen(s2)==4) && (s2[3]=='-')) {
            nl();
            pl("7Enter the LAST 4 DIGITS of your phone number ONLY");
            nl();
            sl1(0,"7!0 User is incompentent.");
          }
        }
      }
      if ((thisuser.sl==255) && (incom) && (ok)) {
        outstr(get_string(8));
        echo=0;
        input(s,20);
        if (strcmp(s,syscfg.systempw)!=0)
          ok=0;
      }
      echo=1;
      }
      if (!ok) {
        ++thisuser.illegal;
        write_user(usernum,&thisuser);
        close_user();
        nl();
        pl(get_string(28));
        nl();
        sprintf(s3,"9###0 Illegal Logon Attempt for 7%s 0(4%s0) (4Pw=%s0)",nam(&thisuser,usernum),ctim(timer()),s);
        sl1(0,s3);
    usernum=0;
      }
    } else
      if (usernum==-1) {
        newuser();
        ok=1;
      } else
        if (usernum==0) {
          if (net_only)
            nl();
          else {
            sprintf(s2,"9###0 Unknown User 7%s",s);
            sl1(0,s2);
            pl(get_string(28));
          }
        } else
          if ((usernum==-2) || (usernum==-3) || (usernum==-4)) {
            if (incom) {
              save_status();
              time(&l);
              s2[0]=0;
              switch(usernum) {
                case -2:
                  sprintf(s2,"NETWORK /B%u /T%ld /F%u",modem_speed,l,modem_flag);
                  runprog(s2,0);
                  break;
                case -3:
                  sprintf(s2,"REMOTE /B%u /F%u",modem_speed,modem_flag);
                  runprog(s2,0);
                  break;
              }
              get_status();
              hangup=1;
              dtr(0);
              global_xx=0;
              wait(1.0);
              dtr(1);
              wait(0.1);
              cleanup_net();
              imodem(0);
        }
        hangup=1;
     }
  } while ((!hangup) && (!ok) && (++count<5));

  changedsl();
  reset_act_sl();

  if (count==5)
    hangup=1;
  checkit=0;
  okmacro=1;
  if ((!hangup) && (usernum>0) && (thisuser.restrict & restrict_logon) &&
    (strcmp(date(),thisuser.laston)==0) && (thisuser.ontoday>0)) {
    nl();
    pl(get_string(30));
    nl();
    hangup=1;
  }
}


void logon()
{
  char s[255],s1[181],s2[81],*ss;
  int i,i1,f,fast,abort;
  long len,pos;

  if (usernum<1) {
    hangup=1;
    return;
  }

  _setcursortype(2);

  if (live_user) {
    ansic(0);
    outchr(12);
  }

  fast=0;
  if((syscfg.sysconfig & sysconfig_no_xfer )||cs()) {
      outstr("5Fast Logon? 0");
      fast=ny();
  }

  if((timer()/3600)>19||(timer()/3600)<6) {
    printfile("dusk");
    setcolors1(&thisuser);
  } else {
    printfile("rise");
    setcolors(&thisuser);
  }


  if (strcmp(date(),status.date1)!=0) {
    if (live_user) {
      nl();
      pl(get_string(38));
      nl();
    }
    beginday();
  }

  if(thisuser.inact & inact_lockedout) {
    printfile("lockout");
    pausescr();
    hangup=1;
    sysoplog("7! 0User LockedOut!  Hungup.");
  }

  if (!fast && live_user) {
    i=printfile("LOGON");
    if (!i)
      pausescr();
  }

  strcpy(xdate,date());
  if (strcmp(xdate,thisuser.laston)==0)
    ++thisuser.ontoday;
  else {
    thisuser.ontoday=1;
    thisuser.timeontoday=0.0;
    thisuser.extratime=0.0;
    thisuser.posttoday=0;
    thisuser.etoday=0;
    thisuser.fsenttoday1=0;
    strcpy(thisuser.laston,xdate);
  }
  if(!outcom) thisuser.ontoday--;
  if(outcom) ++thisuser.logons;
  cursub=0;
  msgreadlogon=0;

  if (outcom) {
    ++status.callernum1;
    ++status.callstoday;
  }

  sprintf(s,"5%ld0: 7%s 0%s %s   4%s 0- %d",
       status.callernum1,
       nam(&thisuser,usernum),
       times(),
       date(),
       curspeed,
       thisuser.ontoday);

  sprintf(s2,"%sLASTON.TXT",syscfg.gfilesdir);
  ss=get_file(s2,&len);
  pos=0;
  abort=0;
  if (ss!=NULL&&!fast) {
    if (!cs())
      for (i=0; i<4; i++)
	copy_line(s1,ss,&pos,len);
    i=1;
    do {
      copy_line(s1,ss,&pos,len);
      if ((s1[0]) && live_user&&(nifty.nifstatus & nif_lastfew)) {
        if (i) {
          i=0;
          nl();
          nl();
          pl(get_string(34));
          nl();
        }
        pla(s1,&abort);
      }
    } while (pos<len);
  }
  pausescr();

  if ((actsl!=255) || (outcom)) {
    sl1(0,"");
    sl1(0,s);
    sl1(1,"");
    sprintf(s,"2[0%4ld2]: 3%-33.33s   4<0%-4s4> 1(0%d1)\r\n",
          status.callernum1,
          nam(&thisuser,usernum),
          curspeed,
          thisuser.ontoday);
    sprintf(s1,"%sUSER.LOG",syscfg.gfilesdir);
    f=open(s1,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
    lseek(f,0L,SEEK_END);
    i=strlen(s);
    if (actsl!=255) {
      write(f,(void *)s,i);
      close(f);
      f=open(s2,O_RDWR | O_BINARY | O_CREAT | O_TRUNC, S_IREAD | S_IWRITE);
      pos=0;
      copy_line(s1,ss,&pos,len);
      for (i=1; i<8; i++) {
        copy_line(s1,ss,&pos,len);
        strcat(s1,"\r\n");
        write(f,(void *)s1,strlen(s1));
      }
      write(f,(void *)s,strlen(s));
      close(f);
    } else
      close(f);
  }

  if (ss!=NULL)
    farfree(ss);

  if (live_user&&!fast)
    if(nifty.nifstatus & nif_automsg)
    read_automessage();
  timeon=timer();
  useron=1;
  if (live_user)
    topscreen();

  if ((syscfg.logon_c[0]) && live_user&&!fast) {
   ex("D1",syscfg.logon_c);
  }

  if (live_user&&!fast) {
    nl();
    if(nifty.nifstatus & nif_yourinfo)
    if(!printfile("loginf")) yourinfo();
    nl();
    nl();
    nl();
    strcpy(s1,"");
    if (thisuser.forwardusr) {
      if (thisuser.forwardsys) {
        if (!next_system(thisuser.forwardsys)) {
          thisuser.forwardusr=0;
          thisuser.forwardsys=0;
          strcpy(s1,"Forwarded to unknown system; forwarding reset.");
        } else {
          sprintf(s1,"Mail set to be forwarded to #%u @%u.",
              thisuser.forwardusr,thisuser.forwardsys);
        }
      } else {
        sprintf(s1,"Mail set to be forwarded to #%u.",thisuser.forwardusr);
      }
      pl(s1);
      nl();
    }
    if (ltime) {
      nl();
      pl("Your on-line time is limited by an external event.");
      nl();
    }
    fsenttoday=0;
    oneliner();

  }
  if (thisuser.year) {
      s[0]=years_old(thisuser.month,thisuser.day,thisuser.year);
      if (thisuser.age!=s[0]) {
        thisuser.age=s[0];
        printfile("bday");
        topscreen();
      }
    } else {
      nl();
      pl("Please enter the following information:");
      do {
        nl();
        withansi=0;
        input_age(&thisuser);
        sprintf(s,"%02d/%02d/%02d",(int) thisuser.month,
                                (int) thisuser.day,
                                (int) thisuser.year);
        nl();
        npr("5Birthdate: %s.  Correct? ",s);
        if (!yn())
          thisuser.year=0;
      } while ((!hangup) && (thisuser.year==0));
      topscreen();
      nl();
    }

    if(thisuser.defed==99) select_editor();
    if(!thisuser.res[3]) getfileformat();
    if(thisuser.res[10]==-1) input_ansistat();
    withansi=0;
    if(!thisuser.street[0]||!thisuser.city[0]) input_city();
    if(thisuser.comp_type==99) input_comptype();

  anscan(0);

  if(live_user) {
    rsm(usernum,&thisuser);
    if (thisuser.waiting) {
      ansic(5);
      outstr(get_string(50));
      if (yn())
        readmail();
    }
  }

  nscandate=thisuser.daten;
  batchtime=0.0;
  numbatchdl=numbatch=0;
  i1=0;
  if(!readinvoting)
      readvotingdata();
  for (i=0; i<20; i++) {
    if (questused[i])
      if (thisuser.votes[i]==0)
	i1=1;
  }
  if (restrict_vote & thisuser.restrict)
    i1=0;
  if (actsl<=10)
    i1=0;
  if (i1 && live_user) {
    nl();
    npr(get_string(21));
    nl();
  }
  save_status();
  setformat();
  create_chain_file("CHAIN.TXT");
  curconf=thisuser.res[15];
  cursub=thisuser.res[16];
  curdir=thisuser.res[17];
  changedsl();

  if (udir[cursub].subnum<0)
    curdir=0;

  if (usub[cursub].subnum<0)
    cursub=0;

  strcpy(status.lastuser,nam(&thisuser,usernum));
  if(!fast&&(nifty.nifstatus & nif_nuv)) nuv();
}


void logoff()
{
  long l;
  int f,r,w,t,i;
  char s[81];
  mailrec m;
  shortmsgrec sm;
  double ton;


  _setcursortype(0);
  dtr(0);
  hangup=1;

  if (usernum<1)
    return;

  thisuser.lastrate=modem_speed;
  strcpy(thisuser.laston,xdate);
  thisuser.illegal=0;
  if ((timer()-timeon)<-30.0)
    timeon-=24.0*3600.0;
  ton=timer()-timeon;
  thisuser.timeon += ton;
  thisuser.timeontoday += (ton-extratimecall);
  status.activetoday += (int) (ton/60.0);
  save_status();


  time(&l);
  thisuser.daten=l;
  thisuser.res[15]=curconf;
  thisuser.res[16]=cursub;
  thisuser.res[17]=curdir;
  close_user();
  write_user(usernum,&thisuser);
  close_user();


  if ((incom) || (actsl!=255))
      logpr("0Time Spent Online for 7%s0: 4%u0 minutes",nam(&thisuser,usernum),(int)((timer()-timeon)/60.0));

  if (mailcheck) {
    sprintf(s,"%sEMAIL.DAT",syscfg.datadir);
    f=open(s,O_BINARY | O_RDWR);
    if (f!=-1) {
      t=(int) (filelength(f)/sizeof(mailrec));
      r=0;
      w=0;
      while (r<t) {
        lseek(f,(long)(sizeof(mailrec)) * (long)(r),SEEK_SET);
        read(f,(void *)&m,sizeof(mailrec));
        if ((m.tosys!=0) || (m.touser!=0)) {
          if (r!=w) {
            lseek(f,(long)(sizeof(mailrec)) * (long)(w),SEEK_SET);
            write(f,(void *)&m,sizeof(mailrec));
          }
          ++w;
        }
        ++r;
      }
      chsize(f,(long)(sizeof(mailrec)) * (long)(w));
      close(f);
    }
  }

  if (smwcheck) {
    sprintf(s,"%sSMW.DAT",syscfg.datadir);
    f=open(s,O_BINARY | O_RDWR);
    if (f!=-1) {
      t=(int) (filelength(f)/sizeof(shortmsgrec));
      r=0;
      w=0;
      while (r<t) {
        lseek(f,(long)(sizeof(shortmsgrec)) * (long)(r),SEEK_SET);
        read(f,(void *)&sm,sizeof(shortmsgrec));
        if ((sm.tosys!=0) || (sm.touser!=0)) {
          if (r!=w) {
            lseek(f,(long)(sizeof(shortmsgrec)) * (long)(w),SEEK_SET);
            write(f,(void *)&sm,sizeof(shortmsgrec));
          }
          ++w;
        }
        ++r;
      }
      chsize(f,(long)(sizeof(shortmsgrec)) * (long)(w));
      close(f);
    }
  }

  remove_from_temp("*.*",syscfg.tempdir,0);
  remove_from_temp("*.*",syscfg.batchdir,0);
  unlink("chain.txt");
  unlink("door.sys");
  unlink("dorinfo1.def");
  unlink("domtemp.bat");
  unlink("batch.lst");

  numbatch=numbatchdl=0;
}

void scrollone(void)
{
    char *b,s[81];
    int i,crcnt=0;
    long l,l1;

    sprintf(s,"%soneline.lst",syscfg.gfilesdir);
    i=open(s,O_RDWR|O_BINARY);
    l=filelength(i);
    b=malloca(l);
    read(i,b,l);
    close(i);
    l1=0;
    while(l1++<l)
        if(b[l1]=='\r') crcnt++;
    if(crcnt>20) {
       sprintf(s,"%soneline.lst",syscfg.gfilesdir);
       i=open(s,O_RDWR|O_BINARY|O_TRUNC);
       l1=0;
       while(b[l1++]!='\r');
       write(i,&b[l1],l-l1);
       close(i);
    }
}

void oneliner()
{
  int i,f;
  char s[81],s1[81],ch;

  dtitle("Dominion OneLiners");
  nl();
  printfile("ONELINE.LST");
      prt(5,"Add a OneLiner? ");
      if (yn()) {
        npr("3Enter Your Oneliner now. 70 Chars Max\r\n5: ");
        inli(s1,"",71,1);
        for (i=strlen(s1); i<80; i++)
           s1[i]=32;
        s1[i]=0;
        nl();
        nl();
        pl(s1);
        prt(5,"Is this what you want? ");
        if (yn()) {
          strcpy(s,"OneLiners:");
          strncat(s,s1,69);
          sysoplog(s);
          strcpy(s,syscfg.gfilesdir);
          strcat(s,"ONELINE.LST");
          f=open(s,O_RDWR | O_CREAT | O_BINARY, S_IREAD | S_IWRITE);
          if (filelength(f)) {
            lseek(f,-1L,SEEK_END);
            read(f,((void *)&ch),1);
            if (ch==26)
              lseek(f,-1L,SEEK_END);
          }
          s1[79]='\r';
          s1[80]='\n';
          s1[81]=0;
          write(f,(void *)s1,81);
          close(f);
          nl();
          scrollone();
        }
    }
}

void fastscreen(char fn[13])
{
    char far *screen = (char far *)0xB8000000;
    char s[81],*ss;
    int i;

    sprintf(s,"%s%s",syscfg.gfilesdir,fn);
    i=open(s,O_RDWR|O_BINARY);
    if(i<0) return;
    ss=malloca(filelength(i));
    read(i,ss,4000);
    close(i);
    memcpy(screen,ss,4000);
    farfree(ss);
}

