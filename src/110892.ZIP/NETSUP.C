#include "vars.h"

#pragma hdrstop

#include <dir.h>



#define utoa(s,v,r) ultoa((unsigned long)(s),v,r)



void checkup(struct ftime *f1, struct ftime *f2, int *tf)
{
  if ((f1->ft_year)>(f2->ft_year))
    *tf=1;
  else
    if (f1->ft_year==f2->ft_year)
      if (f1->ft_month>f2->ft_month)
	*tf=1;
      else
	if (f1->ft_month==f2->ft_month)
	  if (f1->ft_day>f2->ft_day)
	    *tf=1;
	  else
	    if (f1->ft_day==f2->ft_day)
	      if (f1->ft_hour>f2->ft_hour)
		*tf=1;
	      else
		if (f1->ft_hour==f2->ft_hour)
		  if (f1->ft_min>f2->ft_min)
		    *tf=1;
		  else
		    if (f1->ft_min==f2->ft_min)
		      if (f1->ft_tsec>f2->ft_tsec)
			*tf=1;
}


int checkup2(struct ftime *f, char *x)
{
  int q;
  char s[81];
  struct ftime f2;

  sprintf(s,"%s%s",syscfg.datadir,x);
  q=open(s,O_RDONLY);
  if (q>0) {
    getftime(q,&f2);
    close(q);
    q=0;
    checkup(&f2,f,&q);
  } else
    q=1;
  return(q);
}


int check_bbsdata()
{
  char s[81];
  int ok,ok2;
  struct ftime ft;

  sprintf(s,"%sCONNECT.UPD",syscfg.datadir);
  if ((ok=exist(s))==0) {
    sprintf(s,"%sBBSLIST.UPD",syscfg.datadir);
    ok=exist(s);
  }
  if (ok  && status.net_edit_stuff) {
  } else {
    sprintf(s,"%sBBSDATA.NET",syscfg.datadir);
    ok=open(s,O_RDONLY);
    if (ok>0) {
      getftime(ok,&ft);
      close(ok);
      ok=checkup2(&ft,"BBSLIST.NET")||checkup2(&ft,"CONNECT.NET");
      ok2=checkup2(&ft,"CALLOUT.NET");
    } else
      ok=ok2=1;
  }
  sprintf(s,"%sBBSLIST.NET",syscfg.datadir);
  if (!exist(s))
    ok=ok2=0;
  sprintf(s,"%sCONNECT.NET",syscfg.datadir);
  if (!exist(s))
    ok=ok2=0;
  sprintf(s,"%sCALLOUT.NET",syscfg.datadir);
  if (!exist(s))
    ok=ok2=0;
  if (ok||ok2) {
    sprintf(s,"NETWORK3%s",(ok?" Y":""));
    holdphone(1,0);

    runprog(s,1);
    ok=0;

    if (csn!=NULL)
      farfree((void far *)csn);
    if (cnn!=NULL)
      farfree(cnn);
    if (con!=NULL)
      farfree(con);
    read_bbs_list_index();
    read_contacts();
    if (ok>=0)
      return(1);
  }
  return(0);
}

/****************************************************************************/

void cleanup_net()
{
  char s[81],s1[81];
  int ok,ok2,abort,f,i;
  long l,l1;
  struct ffblk ff;


  if (!syscfg.systemnumber)
    return;
  ok2=1;
  abort=0;
  set_protect(0);
  clrscrb();
  while ((ok2) && (!abort)) {
    ok2=0;
    ok=0;
    sprintf(s,"%sP*.NET",syscfg.datadir);
    ok=(findfirst(s,&ff,0)==0);
    if (ok) {
      holdphone(1,0);
      hangup=0;
      using_modem=0;
      if (runprog("NETWORK1",0)<0)
        abort=1;
      ok2=1;
    }
    sprintf(s,"%sLOCAL.NET",syscfg.datadir);
    if (exist(s)) {
      holdphone(1,0);
      ok=1;
      hangup=0;
      using_modem=0;
      save_status();
      close_user();
      sprintf(s,"%sNETUP.XXX",syscfg.datadir);
      if (exist(s))
        if (runprog("NETWORK2",0)<0)
          abort=1;
      ok2=1;
      l1=status.qscanptr;
      get_status();
      if (l1!=status.qscanptr) {
        /* a sub has probably been updated; invalidate sub cache */
        for (i=0; i<MAX_SUBS; i++) {
          if (subboards[i].type)
            sub_dates[i]=0L;
        }
        c_sub=0;
      }
      curlsub=-1;
      if (wfc) {
        wfc=0;
        read_user(1,&thisuser);
        fwaiting=thisuser.waiting;
        wfc=1;
      }
    }
    if (check_bbsdata())
      ok2=1;
    if (ok2) {
      read_contacts();
      clrscrb();
    }
  }
  holdphone(0,0);
}

unsigned int max_speed(int s1, int s2)
{
  int r1,r2,i,i1;
  unsigned ms;
  net_system_list_rec *csne1, *csne2,c1,c2;

  csne1=next_system(s1);
  if (!csne1)
    return(300);
  c1=*csne1;

  csne2=next_system(s2);
  if (!csne2)
    return(300);
  c2=*csne2;

  ms=c1.speed;
  if (c2.speed<ms)
    ms=c2.speed;

  i1=(c1.other) & (c2.other);

  if (i1 & other_Telebit_19200)
    return(19200);
  if (i1 & other_V32)
    return(9600);
  if (i1 & other_Hayes_9600)
    return(9600);
  if (i1 & other_USR_9600)
    return(9600);
  if (i1 & other_compucom)
    return(9600);

  if (ms<=2400)
    return(ms);
  else
    return(2400);
}

void do_callout(int sn)
{
  int i,i1,i2;
  char s[81],s1[81];
  float ffl;
  long l;
  net_system_list_rec *csne;

  time(&l);
  i=-1;
  for (i1=0; i1<num_call_sys; i1++)
    if (con[i1].sysnum==sn)
      i=i1;
  if (i!=-1) {
    csne=next_system(con[i].sysnum);
    if (csne) {
      sprintf(s,"NETWORK /N%u /A%s /P%s /S%u /T%ld",
        sn,
        (con[i].options & options_sendback)?"1":"0",
        csne->phone,
        modem_i->defl.com_speed,
        l);
      if (con[i].macnum) {
        sprintf(s1," /M%d",(int) con[i].macnum);
        strcat(s,s1);
      }
      if (strncmp(csne->phone,"000",3)) {
        pl(s);
        save_status();
        holdphone(1,0);
        wait(2.5);
       // run_external(s);
        runprog(s,0);
        read_contacts();
        get_status();
        last_time_c=l;
        global_xx=0;
        cleanup_net();
        holdphone(0,0);
        imodem(0);
      }
    }
  }
}


int ok_to_call(int i)
{
  int ok;
  struct time ti;
  char ch,h,l;

  ok=((con[i].options & options_no_call)==0);
  if (con[i].options & options_receive_only)
    ok=0;
  _AH=0x2a;
  geninterrupt(0x21);
  ch=_AL;
  gettime(&ti);
  if (con[i].options & options_ATT_night) {
    if ((ch!=0) && (ch!=6)) {
      if ((ti.ti_hour<23) && (ti.ti_hour>=7))
        ok=0;
    }
    if (ch==0) {
      if ((ti.ti_hour<23) && (ti.ti_hour>=16))
        ok=0;
    }
  }
  if (con[i].options & options_PCP_night) {
    if ((ch!=0) && (ch!=6)) {
      if ((ti.ti_hour<19) && (ti.ti_hour>=6))
        ok=0;
    }
  }

  l=con[i].min_hr;
  h=con[i].max_hr;
  if ((l>-1) && (h>-1) && (h!=l)) {
    if ((h==0) || (h==24)) {
      if (ti.ti_hour<l)
        ok=0;
      else
        if ((ti.ti_hour==l) && (ti.ti_min<12))
          ok=0;
        else
          if ((ti.ti_hour==23) && (ti.ti_min>30))
            ok=0;
    } else
      if ((l==0) || (l==24)) {
        if (ti.ti_hour>=h)
          ok=0;
        else
          if ((ti.ti_hour==h-1) && (ti.ti_min>30))
            ok=0;
          else
            if ((ti.ti_hour==0) && (ti.ti_min<12))
              ok=0;
      } else
        if (h>l) {
          if ((ti.ti_hour<l) || (ti.ti_hour>=h))
            ok=0;
          else
            if ((ti.ti_hour==l) && (ti.ti_min<12))
              ok=0;
            else
              if ((ti.ti_hour==h-1) && (ti.ti_min>30))
                ok=0;
        } else {
          if ((ti.ti_hour>=h) && (ti.ti_hour<l))
            ok=0;
          else
            if ((ti.ti_hour==l) && (ti.ti_min<12))
              ok=0;
            else
              if ((ti.ti_hour==h-1) && (ti.ti_min>30))
                ok=0;
        }
  }

  return(ok);
}



#define WEIGHT 30.0

void fixup_long(long *f, long l)
{
  if (*f>l)
    *f=l;

  if (*f+(86400L*30L)<l)
    *f=l-86400L*30L;
}

void attempt_callout()
{
  int *try,i,i1,i2,i3,index,ok,net_only;
  float *weight,fl,fl1,fl2,ffl;
  long l,l1;
  char ch,s[81],s1[81];
  struct time ti;

  net_only=1;
  if (syscfg.netlowtime!= syscfg.nethightime) {
    if (syscfg.nethightime>syscfg.netlowtime) {
      if ((timer()<=(syscfg.netlowtime*60.0)) || (timer()>=(syscfg.nethightime*60.0)))
        net_only=0;
    } else {
      if ((timer()<=(syscfg.netlowtime*60.0)) && (timer()>=(syscfg.nethightime*60.0)))
        net_only=0;
    }
  } else
    net_only=0;
  time(&l);
  if (last_time_c>l)
    last_time_c=0L;
  if (labs(last_time_c-l)<120)
    return;
  if (last_time_c==0L) {
    last_time_c=l;
    return;
  }
  if ((try=(int *)malloca(sizeof(int)*num_call_sys))==NULL)
    return;
  if ((weight=(float *)malloca(sizeof(float)*num_call_sys))==NULL) {
    farfree(try);
    return;
  }
  index=0;
  fl2=0.0;
  for (i=0; i<num_call_sys; i++) {
    ok=ok_to_call(i);
    i2=-1;
    for (i1=0; i1<num_ncn; i1++)
      if (ncn[i1].systemnumber==con[i].sysnum)
	i2=i1;
    if ((ok) && (i2!=-1)) {
      if (ncn[i2].bytes_waiting==0L)
	if (con[i].call_anyway) {
          l1=(l-ncn[i2].lastcontact+60*3)/3600/24;
	  if (((unsigned char)l1 < con[i].call_anyway) ||
	     ((con[i].options & options_sendback)==0))
            if (!net_only)
              ok=0;
	} else
	  ok=0;
      if (con[i].options & options_once_per_day) {
        if (labs(l-ncn[i2].lastcontactsent)<(20L*3600L/con[i].times_per_day))
	  ok=0;
      }

      fixup_long((long *)&(ncn[i2].lastcontactsent),l);
      fixup_long((long *)&(ncn[i2].lasttry),l);
      if (ok) {
	if (ncn[i2].bytes_waiting==0L)
	  fl=5.0*WEIGHT;
	else
	  fl=1024.0/((float)ncn[i2].bytes_waiting)*WEIGHT*60.0;
        fl1=(float) (l-ncn[i2].lasttry);
	if ((fl<fl1) || (net_only)) {
          try[index]=i;
	  fl1=fl1/fl;
          if (fl1<1.0)
	    fl1=1.0;
	  if (fl1>5.0)
	    fl1=5.0;
          weight[index]=fl1;
	  fl2 += weight[index];
	  ++index;
	}
      }
    }
  }
  if (index) {
    fl=fl2*((float)rand())/32767.0;
    fl1=0.0;
    i1=-1;
    for (i=0; (i<index) && (i1==-1); i++) {
      fl1 += weight[i];
      if (fl1>=fl)
	i1=i;
    }
    if (i1==-1)
      i1=index-1;
    i=try[i1];
    farfree(try);
    farfree(weight);
    do_callout(con[i].sysnum);
    time(&l);
    last_time_c=l;
  } else {
    farfree(try);
    farfree(weight);
  }
}

void force_callout()
{
  int i,i1,i2,i3,index,ok,sn;
  float fl,fl1,fl2,ffl;
  long l,l1;
  char ch,s[81],s1[81];
  struct time ti;

  time(&l);
  nl();
  prt(2,"Which system? ");
  input(s,5);
  sn=atoi(s);
  i=-1;
  for (i1=0; i1<num_call_sys; i1++)
    if (con[i1].sysnum==sn)
      i=i1;
  if (i==-1)
    return;
  ok=ok_to_call(i);
  i2=-1;
  for (i1=0; i1<num_ncn; i1++)
    if (ncn[i1].systemnumber==con[i].sysnum)
      i2=i1;
  if (i2==-1)
    ok=0;
  else
    if (!ok) {
      nl();
      prt(5,"Are you sure? ");
      if (yn())
        ok=1;
    }
  if (ok) {
    if (ncn[i2].bytes_waiting==0L)
      if (!(con[i].options & options_sendback))
	ok=0;
    if (ok) {
      do_callout(sn);
    }
  }
}


void print_pending_list()
{
  int i,any=0,i1,i2;
  char s[81],ch,s1[81];
  long l;


  if (syscfg.systemnumber) {
    time(&l);

    nl();
    nl();
    pl(" Network data pending transmission:");
    nl();
    pl(" System       Bytes     Hours");
    pl(" ------      -------    -----");

    for (i=0; i<num_ncn; i++) {
      if (ncn[i].bytes_waiting) {
        i2=-1;
        for (i1=0; i1<num_call_sys; i1++)
          if (con[i1].sysnum==ncn[i].systemnumber)
            i2=i1;
        if (i2!=-1) {
          if (ok_to_call(i2))
            ch='*';
          else
            ch=' ';
          any=1;
          if (ncn[i].lastcontactsent)
            ltoa((l-ncn[i].lastcontactsent)/3600,s1,10);
          else
            strcpy(s1,"-NEVER-");
          sprintf(s,"%c%-5d       %7ld    %s",
            ch,
            ncn[i].systemnumber,
            ncn[i].bytes_waiting,
            s1);
          pl(s);
        }
      }
    }
    sprintf(s,"%sDEAD.NET",syscfg.datadir);
    i=open(s,O_RDONLY | O_BINARY);
    if (i>0) {
      l=filelength(i);
      any=1;
      close(i);
      sprintf(s," DEAD        %7ld", l);
      pl(s);
    }
    if (!any)
      pl("--NONE--");
    nl();
    if (!useron)
      pausescr();
  }
}
