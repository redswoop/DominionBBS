#include "vars.h"

#pragma hdrstop
extern int colblock;

void change_colors(userrec *u1)
{
  int i,done,i1,i2,abort=0;
  char s[81],ch,nc,*ss,s1[81];
  userrec u;

  u=*u1;
  done=0;
  do {
    outchr(12);
    if ((u.sysstatus & sysstatus_color)==0) {
      strcpy(s,"Monochrome base color : ");
      if ((u.bwcolors[1] & 0x70) == 0)
        strcat(s,cn(u.bwcolors[1] & 0x07));
      else
        strcat(s,cn((u.bwcolors[1] >> 4) & 0x07));
      pl(s);
      nl();
    }
    printfile("Collist");
    nl();
    npr("3Enter Color # to Edit\r\n5:0 ");
    input(ss,2);
    i=atoi(ss);
    if (!strcmp(ss,"Q")||!ss[0]) done=1;
    else
    if(!strcmp(ss,"?"));
    else {
      if (u.sysstatus & sysstatus_color)  {
        color_list();
        ansic(0);
        nl();
        prt(2,"Foreground? ");
        ch=onek("01234567\r");
        if(ch=='\r') ch='0';
        nc=ch-'0';
        prt(2,"Background? ");
        ch=onek("01234567\r");
        if(ch=='\r') ch='0';
        nc=nc | ((ch-'0') << 4);
      } else {
         nl();
         prt(5,"Inversed? ");
           if (yn()) {
             if ((u.bwcolors[1] & 0x70) == 0)
               nc=0 | ((u.bwcolors[1] & 0x07) << 4);
             else
               nc=(u.bwcolors[1] & 0x70);
           } else {
             if ((u.bwcolors[1] & 0x70) == 0)
               nc=0 | (u.bwcolors[1] & 0x07);
             else
               nc=((u.bwcolors[1] & 0x70) >> 4);
           }
      }
      prt(5,"Intensified? ");
      if (yn())
        nc |= 0x08;

      prt(5,"Blinking? ");
      if (yn())
        nc |= 0x80;

      setc(nc);
      pl(describe(nc));
      ansic(0);
      prt(5,"Is this OK? ");
      if (yn()) {
        pl("Color saved.");
        if(colblock)
            nifty.defaultcol[i]=nc;
        else {
        if (u.sysstatus & sysstatus_color)
          u.colors[i]=nc;
        else
          u.bwcolors[i]=nc;
        }
      } else {
        pl("Not saved, then.");
      }
    }
  } while ((!done) && (!hangup));

  *u1=u;
}



void select_editor()
{
  char s[81],s1[81],*ss;
  int i;

  if(!readeditor)
    readeditors();
  if (numed==0) {
    nl();
    pl("No full screen editors available.");
    nl();
    return;
  }
  for (i=0; i<5; i++)
    odc[i]=0;
  pl("0. Normal non-full screen editor");
  for (i=0; i<numed; i++) {
    npr("%d. %s\r\n",i+1,editors[i].description);
    if (((i+1) %10)==0)
      odc[(i+1)/10-1]=(i+1)/10;
  }
  nl();
  ansic(2);
  npr("Which editor (1-%d, <C/R>=leave as is) ? ",numed);
  ansic(0);
  ss=mmkey(2);
  i=atoi(ss);
  if ((i>=1) && (i<=numed))
    thisuser.defed=i;
  else
    if (strcmp(ss,"0")==0)
      thisuser.defed=0;
}


void print_cur_stat()
{
  char s[81],s1[81],s2[81];
  userrec ur;

  outchr(12);
  dtitle("Preferences");

  npr("Screen size       : %d X %d\r\n",
        thisuser.screenchars,
        thisuser.screenlines);

  if(thisuser.res[10]) strcpy(s,"Avatar "); else
  if(thisuser.sysstatus & sysstatus_ansi) strcpy(s,"Ansi ");
  else strcpy(s,"Ascii");
  if(thisuser.sysstatus & sysstatus_color) strcat(s,"Colour");
  else strcat(s,"Mono");

  npr("Graphics          : %s\r\n",s);
  npr("Help Level        : ");
     switch(thisuser.res[1]) {
       case 0: pl("Expert"); break;
       case 1: pl("Regular"); break;
       case 2: pl("Idiot"); break;
       }
  npr("Comment           : %s\r\n",thisuser.comment);
  npr("Pause on screen   : %s\r\n",
     (thisuser.sysstatus & sysstatus_pause_on_page)?"On":"Off");
  outstr("Mailbox           : ");
  if ((thisuser.forwardsys==0) && (thisuser.forwardusr==0))
    pl("Normal");
  else {
    if (thisuser.forwardsys) {
      sprintf(s,"Forward to #%u @%u.",thisuser.forwardusr,thisuser.forwardsys);
      pl(s);
    } else {
      if (thisuser.forwardusr==65535) {
        pl("Closed");
      } else {
        read_user(thisuser.forwardusr,&ur);
        if (ur.inact & inact_deleted) {
          thisuser.forwardusr=0;
          pl("Normal");
        } else {
          sprintf(s,"Forward to %s",nam(&ur,thisuser.forwardusr));
          pl(s);
        }
      }
    }
  }
    npr("Full screen editor: %s\r\n",
      ((thisuser.defed) && (thisuser.defed<=numed))?
        editors[thisuser.defed-1].description:"None.");
    npr("Default Protocol  : %s\r\n",proto[thisuser.defprot].description);
    npr("File List Format  : Type %d\r\n",thisuser.res[3]);
    nl();
    if(thisuser.res[1]==2) pausescr();
}


char *cn(char c)
{

  switch(c) {
    case 0:
      return("Black");
    case 1:
      return("Blue");
    case 2:
      return("Green");
    case 3:
      return("Cyan");
    case 4:
      return("Red");
    case 5:
      return("Magenta");
    case 6:
      return("Yellow");
    case 7:
      return("White");
  }
  return("");
}

char *describe(char col)
{
  static char s[81];
  char s1[81];


  if (thisuser.sysstatus & sysstatus_color) {
    strcpy(s1,cn(col&0x07));
    sprintf(s,"%s on %s", s1, cn((col>>4)&0x07));
  } else {
    if ((col & 0x07) == 0)
      strcpy(s,"Inversed");
    else
      strcpy(s,"Normal");
  }
  if (col & 0x08) strcat(s,", Intense");
  if (col & 0x80) strcat(s,", Blinking");
  return(s);
}

void color_list()
{
  int i;

  nl();
  nl();
  for (i=0; i<8; i++) {
    if (i==0)
      setc(0x70);
    else
      setc(i);
    npr("%d. %s",i,cn(i));
    setc(0x07);
    nl();
  }
}





void config_qscan(int dl)
{
  char *s,c;
  int i,done;


  done=0;
  do {
    outchr(12);
    if(!dl) sublist('L');
    else dirlist('L');
    nl();
    outstr("5NewScan Configuration: 0# to Toggle, [Q]uit, [T]oggle All: ");
    s=mmkey(dl);
    nl();
    if (s[0])
      for (i=0; dl?i<MAX_DIRS:i<MAX_SUBS; i++)
       if(!dl) {
        if (strcmp(usub[i].keys,s)==0) {
          if (usub[i].subnum>=32)
            thisuser.qscn2 ^=((1L) << (usub[i].subnum-32));
          else
            thisuser.qscn ^=((1L) << (usub[i].subnum));
        }
       } else {
        if (strcmp(udir[i].keys,s)==0) {
          if (udir[i].subnum>=32)
            thisuser.nscn2 ^=((1L) << (udir[i].subnum-32));
          else
            thisuser.nscn1 ^=((1L) << (udir[i].subnum));
        }
       }
    if (strcmp(s,"Q")==0)
      done=1;
    if(!strcmp(s,"T")) {
        nl();
        outstr("0Toggle All 7O0n, O7f0f? ");
        c=onek("OF\r");
        switch(c) {
            case '\r': break;
            case 'O':
            case 'F':
              for(i=0;dl?i<MAX_DIRS:i<MAX_SUBS;i++) {
                if(!dl) {
                  if (usub[i].subnum>=32) {
                    if(thisuser.qscn2 & ((1L) << (usub[i].subnum-32)))
                       thisuser.qscn2 ^=((1L) << (usub[i].subnum-32));
                    if(c=='O')
                       thisuser.qscn2 |=((1L) << (usub[i].subnum-32));
                  } else {
                    if(thisuser.qscn & ((1L) << (usub[i].subnum)))
                       thisuser.qscn ^=((1L) << (usub[i].subnum));
                    if(c=='O')
                       thisuser.qscn |=((1L) << (usub[i].subnum));
                  }
                } else {
                    if (udir[i].subnum>=32) {
                    if(thisuser.nscn2 & ((1L) << (udir[i].subnum-32)))
                       thisuser.nscn2 ^=((1L) << (udir[i].subnum-32));
                    if(c=='O')
                       thisuser.nscn2 |=((1L) << (udir[i].subnum-32));
                  } else {
                    if(thisuser.nscn1 & ((1L) << (udir[i].subnum)))
                       thisuser.nscn1 ^=((1L) << (udir[i].subnum));
                    if(c=='O')
                       thisuser.nscn1 |=((1L) << (udir[i].subnum));
                  }
                }
              }
              break;
        }
    }

  } while ((!done) && (!hangup));
}


void list_macro(unsigned char *s)
{
  int i;

  i=0;
  outchr('\"');
  while ((i<80) && (s[i]!=0)) {
    if (s[i]>=32)
      outchr(s[i]);
    else {
      outchr('^');
      outchr(s[i]+64);
    }
    ++i;
  }
  outchr('"');
  nl();
}


void make_macros()
{
  unsigned char tempmac[81],s[81];
  unsigned char ch,ch1;
  int i,i1,done,done1;

  done=0;
  do {
    nl();
    prt(5,"Macro Editor 0(3L:ist, M:ake, Q:uit0)5 : ");
    ch=onek("QLM");
    switch(ch) {
      case 'Q':
        done=1;
        break;
      case 'L':
        nl();
        nl();
        pl("Ctrl-D macro: ");
        list_macro(&(thisuser.macros[0][0]));
        nl();
        pl("Ctrl-F macro: ");
        list_macro(&(thisuser.macros[1][0]));
        nl();
        pl("Ctrl-A macro: ");
        list_macro(&(thisuser.macros[2][0]));
        nl();
        pl("Ctrl-Y macro: ");
        list_macro(&(thisuser.macros[3][0]));
        break;
      case 'M':
        nl();
        prt(5,"Edit Which (A,D,F,Y, Q=quit): ");
        ch1=onek("QADFY");
        if (ch1!='Q') {
          switch(ch1) {
            case 'Y': i1=3; break;
            case 'A': i1=2; break;
            case 'D': i1=0; break;
            case 'F': i1=1; break;
          }
          strcpy(s,&(thisuser.macros[i1][0]));
          thisuser.macros[i1][0]=0;
          done1=0;
          i=0;
          nl();
          pl("Enter your macro now, hit ctrl-Z when done.");
          nl();
	  okskey=0;
          do {
            ch1=getkey();
            if (ch1==26)
              done1=1;
            else
              if (ch1==8) {
                if (i>0) {
                  i--;
                  backspace();
                  if (tempmac[i]<32)
                    backspace();
                }
              } else {
                if (ch1>=32) {
                  tempmac[i++]=ch1;
                  outchr(ch1);
                } else {
                  tempmac[i++]=ch1;
                  outchr('^');
                  outchr(ch1+64);
                }
              }
            if (i>=78)
              done1=1;
          } while ((!done1) && (!hangup));
          okskey=1;
          tempmac[i]=0;
          nl();
          pl("You entered:");
          nl();
          nl();
          list_macro(tempmac);
          nl();
          prt(5,"Is this OK? ");
          if (yn()) {
            strcpy(&(thisuser.macros[i1][0]),tempmac);
            nl();
            pl("Macro saved.");
          } else {
            nl();
            strcpy(&(thisuser.macros[i1][0]),s);
            pl("Nothing saved.");
          }
        }
        break;
    }
  } while ((!done) && (!hangup));
}


void input_pw1()
{
  char s[81],s1[81];
  int ok;

  nl();
  prt(5,"Change password? ");
  if (yn()) {
    nl();
    pl("You must now enter your current password.");
    outstr(": ");
    echo=0;
    input(s,19);
    if (strcmp(s,thisuser.pw)) {
      nl();
      pl("Incorrect.");
      nl();
      return;
    }
    nl();
    nl();
    pl("Enter your new password, 3 to 20 characters long.");
    outstr(": ");
    echo=0;
    input(s,19);
    nl();
    nl();
    pl("Repeat password for verification.");
    outstr(": ");
    echo=0;
    input(s1,19);
    if (strcmp(s,s1)==0) {
      if (strlen(s1)<3) {
        nl();
        pl("Password must be 3-20 characters long.");
        pl("Password was not changed.");
        nl();
      } else {
        strcpy(thisuser.pw,s);
        nl();
        pl("Password changed.");
        nl();
        sysoplog("Changed Password.");
      }
    } else {
      nl();
      pl("VERIFY FAILED.");
      pl("Password not changed.");
      nl();
    }
  }
}

void modify_mailbox()
{
  int i,i1,i2;
  unsigned int u;
  char s[81];
  net_system_list_rec *csne;

  nl();

  prt(5,"Do you want to close your mailbox? ");
  if (yn()) {
    prt(5,"Are you sure? ");
    if (yn()) {
      thisuser.forwardsys=0;
      thisuser.forwardusr=-1;
      return;
    }
  }
  prt(5,"Do you want to forward your mail? ");
  if (!yn()) {
    thisuser.forwardsys=0;
    thisuser.forwardusr=0;
    return;
  }
  nl();
  if (syscfg.systemnumber) {
    prt(5,"Forward to another system? ");
    if (yn()) {
      nl();
      prt(2,"Which system (number)? ");
      input(s,5);
      i2=atoi(s);
      if ((csne=next_system(i2))==NULL) {
        nl();
        pl("Unknown system.");
        nl();
        return;
      }
      nl();
      npr("System name: %s\r\n",csne -> name);
      nl();
      if (i2==syscfg.systemnumber) {
        nl();
        pl("That's this system.");
        nl();
        return;
      }
      prt(2,"Which user number on that system? ");
      input(s,5);
      i=atoi(s);
      if ((i>0) && (i<20000)) {
        thisuser.forwardsys=i2;
        thisuser.forwardusr=i;
        nl();
        pl("Saved.");
        nl();
      }
      return;
    }
  }
  nl();
  prt(2,"Forward to which user? ");
  input(s,40);
  i=finduser1(s);
  if (i==usernum) {
    thisuser.forwardsys=0;
    thisuser.forwardusr=0;
    nl();
    pl("Forwarding reset.");
    nl();
    return;
  }
  if (i>0) {
    thisuser.forwardsys=0;
    thisuser.forwardusr=i;
    nl();
    pl("Saved.");
    nl();
  }
}


void optional_lines()
{
  char s[81];
  int i;

  pl("You may specify your optional lines value from 0-10,");
  pl("0 being all, 10 being none.");
  prt(2,"What value? ");
  input(s,2);

  i=atoi(s);
  if ((s[0]) && (i>=0) && (i<11))
    thisuser.optional_val = i;

}

void getfileformat()
{
  FILE *f;
  char s[101],s1[101],ch;
  char done=0,c=1;

    nl();
    dtitle("Dominion User Defined File Formats");
    done=0;

    do {
      sprintf(s,"%sFile%d.fmt",syscfg.gfilesdir,c);
      f=fopen(s,"rt");
      if(f!=NULL) {
        fgets(s,81,f);
        filter(s,'\n');
        stuff_in1(s1,s,"Dom30a  .Zip","Dominion BBS 3.0"," 300","   0","  1","Fallen Angel","01/01/92","100","","");
        sprintf(s,"<%d> %s",c,s1);
        c+=1;
        pl(s);
        fclose(f);
      } else done=1;
    } while(!done&&!hangup);

    nl();
    npr("0Which2(0Q,<A>dd,1-%d2): ",c-1);
    input(s,3);
    if(s[0]&&atoi(s)<c&&!strchr(s,'Q')&&!strchr(s,'A')) thisuser.res[3]=atoi(s);
    else if(strchr(s,'A')) {
        sprintf(s,"%sfile%d.fmt",syscfg.gfilesdir,c);
        f=fopen(s,"wt");
        outchr(12);
        pl("%1 = File Name             %6 = Uploader");
        pl("%2 = Description           %7 = Upload Date");
        pl("%3 = File Size             %8 = Number of Dloads");
        pl("%4 = File Points");
        pl("%5 = File Number");
        nl();
        npr("4Enter your Format\r\n0:");
        strcpy(s1,"");
        inli(s,s1,81,1);
        if(s[0]) {
          stuff_in1(s1,s,"Dom30a  .Zip","Dominion BBS 3.0"," 300","   0","  1","Fallen Angel","01/01/92","100","","");
          npr("%s\r\n\r\n",s1);
          outstr("5Is this what you want? ");
          if(ny()) {
             fputs(s,f);
             fputs("\r\n",f);
             fputs(s,f);
             fputs("\r\n",f);
             fputs(s,f);
             fputs("\r\n",f);
             fclose(f);
             thisuser.res[3]=c;
          }
        }
    }
    if(!thisuser.res[3]) thisuser.res[3]=1;
}

void setcolors(userrec *uu)
{
    userrec u;
    int i;

    u=*uu;
    if(u.sysstatus &  sysstatus_color) {
        for(i=0;i<20;i++)
            u.colors[i]=nifty.defaultcol[i];
    } else {
        u.colors[0]=15;
        u.colors[1]=7;
        u.colors[2]=7;
        u.colors[3]=15;
        u.colors[4]=15;
        u.colors[5]=7;
        u.colors[6]=16*7;
        u.colors[7]=15;
        u.colors[8]=143;
        u.colors[9]=15;
        u.colors[10]=16*7;
        u.colors[11]=7;
        u.colors[12]=15;
        u.colors[13]=7;
        u.colors[14]=15;
        u.colors[15]=7;
        u.colors[16]=143;
        u.colors[17]=16*7;
        u.colors[18]=143;
        u.colors[19]=7;
    }
    *uu=u;
}

void setcolors1(userrec *uu)
{
    userrec u;
    int i;

    u=*uu;
    u.colors[0]=8;
    u.colors[1]=7;
    u.colors[2]=5;
    u.colors[3]=9;
    u.colors[4]=3;
    u.colors[5]=1;
    u.colors[6]=31;
    u.colors[7]=4;
    u.colors[8]=1;
    u.colors[9]=9;
    u.colors[10]=0+(16*7);
    u.colors[11]=8;
    u.colors[12]=5;
    u.colors[13]=3;
    u.colors[14]=6;
    u.colors[15]=1;
    u.colors[16]=141;
    u.colors[17]=4;
    u.colors[18]=142;
    u.colors[19]=2;
    *uu=u;
}

void input_ansistat()
{
  int i,c,c2;
  char ch;

  thisuser.sysstatus &= ~(sysstatus_ansi | sysstatus_color);
  thisuser.res[10]=0;
  nl();
  if (check_ansi()) {
    outstr("ANSI graphics support detected.  Use it? ");
  } else {
    outstr("\x1b[0;34;3mTEST\x1b[C");
    outstr("\x1b[0;30;45mTEST\x1b[C");
    outstr("\x1b[0;1;31;44mTEST\x1b[C");
    outstr("\x1b[0;32;7mTEST\x1b[C");
    outstr("\x1b[0;1;5;33;46mTEST\x1b[C");
    pl("\x1b[0;4mTEST\x1b[0m");
    pl("Is the above line colored, italicized,");
    outstr("bold, inversed, or blinking? ");
  }

  if (yn()) {
    nl();
    thisuser.sysstatus |= sysstatus_ansi;
    outstr("Do you want color? ");
    if (yn()) thisuser.sysstatus |= sysstatus_color;
    ansic(0);
    outstr("Do you want Avatar? (No if unsure): ");
    thisuser.res[10]=yn();
  }
  setcolors(&thisuser);
}

void selecthelplevel()
{
   char c;
   nl();
   dtitle("Select a Help Level");
   pl("3E5xpert  : No Menu or Help is Displayed unless asked for");
   pl("3R5egular : A short list of commands is displayed on command line");
   pl("3I5diot   : A short list of commands and the menu is display with each command");
   nl();
   outstr("9Select your Help Level: ");
   mpl(1);
   c=onek("ERI\r");
   switch(c) {
    case 'R':
    case '\r': thisuser.res[1]=1; break;
    case 'E': thisuser.res[1]=0; break;
    case 'I': thisuser.res[1]=2; break;
   }
   ansic(0);
   nl();
}


