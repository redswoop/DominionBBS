#include "vars.h"
#pragma hdrstop
#include <dir.h>


#define ALLOW_FULLSCREEN 1
#define EMAIL_STORAGE 2

extern int deleted_flag;
extern char commstr[41];
int reply;


/****************************************************************************/

void post()
{
    messagerec m;
    postrec p;
    char s[121],*b,*b1;
    int i,dm,a,f;
    slrec ss;
    long len1,len2;
    unsigned int *list;

    iscan(cursub);
    if (curlsub<0) {
        nl();
        pl("No subs available.");
        nl();
        return;
    }

    ss=syscfg.sl[actsl];

    if (freek1(syscfg.msgsdir)<10.0) {
        nl();
        pl("Sorry, not enough disk space left.");
        nl();
        return;
    }

    if ((restrict_post & thisuser.restrict) || (thisuser.posttoday>=ss.posts)) {
        nl();
        pl("Too many messages posted today.");
        nl();
        return;
    }

    if (actsl<subboards[curlsub].postsl) {
        nl();
        pl("You can't post here.");
        nl();
        return;
    }

    m.storage_type=subboards[curlsub].storage_type;
    a=subboards[curlsub].anony & 0x0f;
    if ((a==0) && (ss.ability & ability_post_anony))
        a=anony_enable_anony;
    if ((a==anony_enable_anony) && (thisuser.restrict & restrict_anony))
        a=0;
    if (subboards[curlsub].type) {
        a &= (anony_real_name);
        if (thisuser.restrict & restrict_net) {
            nl();
            pl("You can't post on networked sub-boards.");
            nl();
            return;
        }
        if (thisuser.restrict & (restrict_validate | restrict_auto_msg_delete)) {
            nl();
            pl("You can't post on networked sub-boards.");
            nl();
            return;
        }
        if (syscfg.systemnumber) {
            nl();
            pl(get_string(23));
            nl();
        }
    }
    upload_post();
    inmsg(&m,p.title,&a,1,(subboards[curlsub].filename),ALLOW_FULLSCREEN);
    if (m.stored_as!=0xffffffff) {
        p.anony=a;
        p.msg=m;
        p.ownersys=0;
        p.owneruser=usernum;
        p.qscan=status.qscanptr++;
        time((long *)(&p.daten));
        if (thisuser.restrict & restrict_auto_msg_delete)
            p.status=status_delete;
        else
            if (thisuser.restrict & restrict_validate)
            p.status=status_unvalidated;
        else
            p.status=0;
        if ((subboards[curlsub].type) && (syscfg.systemnumber) &&
            (subboards[curlsub].anony & anony_val_net) && (!lcs() || irt[0])) {
            p.status |= status_pending_net;
            dm=1;
            for (i=1; i<=nummsgs; i++)
                if (msgs[i].status & status_pending_net)
                    dm=0;
            if (dm) {
                sprintf(s,"Unvalidated net posts on %s.",subboards[curlsub].name);
                ssm(1,0,s);
            }
        }
        if (nummsgs>=subboards[curlsub].maxmsgs) {
            i=1;
            dm=0;
            while ((dm==0) && (i<=nummsgs)) {
                if ((msgs[i].status & status_no_delete)==0)
                    dm=i;
                ++i;
            }
            if (dm==0)
                dm=1;
            delete(dm);
            deleted_flag=dm;
        }
        msgs[++nummsgs]=p;
        sub_dates[curlsub]=p.qscan;
        bchanged=1;
        savebase();
        ++thisuser.msgpost;
        ++thisuser.posttoday;
        ++status.msgposttoday;
        save_status();
        topscreen();
        sprintf(s,"4+ 0%s posted on %s",p.title,subboards[curlsub].name);
        sysoplog(s);
        npr("Posted on %s\r\n",subboards[curlsub].name);
        save_status();
        if ((subboards[curlsub].type) && (syscfg.systemnumber)) {
            ++thisuser.postnet;
            if (!(p.status & status_pending_net))
                send_net_post(&p, subboards[curlsub].type, subboards[curlsub].filename);
        }
    }
}

int ttchk2(char *ttl)
{
    int reval,abort,ct;
    char s[81],s1[81];

    ct=0;
    reval=-1;
    abort=0;
    strcpy(s,ttl);
    while ((!abort) && (!hangup) && (ct<nummsgs)) {
        ++ct;
           sprintf(s1,"5RE: 3%s",msgs[ct].title);
        if (strncmp(s,s1,60)==0) {
          reval=ct;
          abort=1;
        }
    }
    return(reval);
}

void scan(int msgnum, int optype, int *nextsub)
{
  char s[81],s1[81],s2[81],*b,*ss1;
  int i,i1,i2,done,quit,abort,next,val,realexpress;
  int tst,hold,hold1,numrply,hold2,repto=-1;
  char s3[81],s4[81],s5[81],s6[81];
  slrec ss;
  long l,len;
  postrec p,p1;


  irt[0]=0;
  irt_name[0]=0;
  thread=0;
  done=0;
  quit=0;
  val=0;
  realexpress=express;

  iscan(cursub);
  if (curlsub<0) {
    nl();
    pl("No subs available.");
    nl();
    return;
  }

  do {
    tleft(1);
        reply=1;
         {
           hold2=msgnum;
           numrply=0;
           abort=0;
            strcpy(s6,msgs[msgnum].title);
            if (strncmp(s,"5RE: 3",8)!=0) {
             strcpy(s4,"5RE: 3");
             strcat(s4,s6);
           }  else
             strcpy(s4,s6);
             strcpy(s1,s6);
             while ((!abort) && (!hangup) && (hold2<nummsgs)) {
              ++hold2;
              strcpy(s6,msgs[hold2].title);
              if ((!strncmp(s6,s4,60)) || (!strcmp(s6,s1)))
                ++numrply;
            }
        }

    repto=-1;
    switch(optype) {
case 0: /* Read Prompt */

        msgr=msgnum;

        reply=1;
         {
           hold2=msgnum;
           numrply=0;
           abort=0;
            strcpy(s6,msgs[msgnum].title);
            if (strncmp(s,"5RE: 3",8)!=0) {
             strcpy(s4,"5RE: 3");
             strcat(s4,s6);
           }  else
             strcpy(s4,s6);
             strcpy(s1,s6);
             while ((!abort) && (!hangup) && (hold2<nummsgs)) {
              ++hold2;
              strcpy(s6,msgs[hold2].title);
              if ((strncmp(s6,s4,60)==0) || (strcmp(s6,s1)==0)) {
               ++numrply;
              }
            }
        }

        s[0]=0;
        s1[0]=0;
        if(numrply)
            sprintf(s,"Replies: %d",numrply);

        repto=ttchk2(msgs[msgnum].title);
        if(repto==msgnum) repto=0;
        if(repto>=1)
            sprintf(s1,"Reply to: %d",repto);


        if(s[0]&&s1[0]) {
            strcat(s,", ");
            strcat(s,s1);
            s1[0]=0;
        }

        if (express) {
          s[0]=0;
          nl();
        } else {
          if(s[0]) npr(s);
          if(s1[0]) npr(s1);
          nl();
          if(thread)
            npr("Tracking: <]>,<[> Thread, [Q]uit Thread:\r\n");
          outstr(get_string(14));
          input(s,4);
      while (s[0]==32 &&!thread) {
	    strcpy(s1,&(s[1]));
	    strcpy(s,s1);
	  }
        }
        optype=0;
        i=atoi(s);
        if (s[0]==0) {
          i=msgnum+1;
          if (i>=nummsgs+1)
            done=1;
        }
        if ((i!=0) && (i<=nummsgs) && (i>=1)&&!thread) {
          optype=2;
          msgnum=i;
        } else
          if (s[1]==0) {
            switch(s[0]) {
       case 'Q':
            if(thread)
               thread=0;
            else {
               done=1;
               quit=1;
               *nextsub=0;
            }
            break;
       case ']':
            if(!thread) {
                nl();
                outstr("0Keep 7M0essage Posistion, or 7J0ump to Next Reply? ");
                s[0]=onek("MJ\r");
                if(s[0]=='M'||s[0]=='\r') thread=1;
            }
            hold=msgnum;
            tst=0;
            abort=0;
            if (msgnum>=nummsgs) {
                nl();
                pl("No More Messages in Current Area");
                nl();
                nl();
                abort=1;
            }
            strcpy(s,msgs[msgnum].title);
            if (strncmp(s,"5RE: 3",8)!=0) {
                strcpy(s4,"5RE: 3");
                strcat(s4,s);
            }  else strcpy(s4,s);
            while ((!abort) && (!hangup)) {
                ++msgnum;
                strcpy(s,msgs[msgnum].title);
                if (strncmp(s,s4,60)==0) {
                     tst=2;
                     abort=1;
                }
                if (msgnum>nummsgs) {
                    nl();
                    prt(2,"There are no more messages available in this thread.");
                    nl();
                    nl();
                    msgnum=hold;
                    abort=1;
                }
            }
            optype=tst;
            break;
       case '[':
            if(!thread) {
                nl();
                outstr("0Keep 7M0essage Posistion, or 7J0ump to Next Reply? ");
                s[0]=onek("MJ\r");
                if(s[0]=='M'||s[0]=='\r') thread=1;
            }
            hold=msgnum;
            tst=0;
            abort=0;
            if (msgnum<=1) {
                  nl();
                  prt(2,"That are no messages before this one!");
                  nl();
                  nl();
                  abort=1;
            }
            strcpy(s,msgs[msgnum].title);
            if (strncmp(s,"5RE: 3",8)!=0) abort=1;
            strcpy(s4,s);
            memmove(s5,&s4[8],52);
            while ((!abort) && (!hangup)) {
             --msgnum;
             strcpy(s,msgs[msgnum].title);
             if ((strncmp(s,s4,60)==0) || (strncmp(s,s5,60)==0)) {
                  tst=2;
                  abort=1;
            }
            if (msgnum<1) {
                nl();
                prt(2,"That was the first message available in this thread.");
                nl();
                nl();
                msgnum=hold;
                abort=1;
             }
            }
            optype=tst;
            break;
       case 'S':
            nl();
            npr("5Kill %s from Newscan? ",subboards[usub[cursub].subnum].name);
            if(yn()) {
              b=usub[cursub].keys;
               for (i=0; i<64; i++) {
                  if (strcmp(usub[i].keys,b)==0)
                      if(i<32) thisuser.qscn ^=((1L) << (usub[i].subnum));
                      else thisuser.qscn2 ^=((1L) << (usub[i].subnum));
               }
            }
            if (*nextsub!=0&&!thread) {
              *nextsub=1;
              done=1;
              quit=1;
            } else if (*nextsub!=0) {
               *nextsub=1;
               done=1;
               quit=1;
            }
            break;
       case 'T':
            optype=1;
            break;
       case 'A':
            optype=2;
            break;
       case 'E':
          outstr("5Email Author? ");
          if(!yn()) break;
          quote_message(&(msgs[msgnum].msg),(subboards[curlsub].filename));
          if ((msgs[msgnum].ownersys) && (!msgs[msgnum].owneruser))
            grab_user_name(&(msgs[msgnum].msg),subboards[curlsub].filename);
          ss=syscfg.sl[actsl];
          if ((lcs()) || (ss.ability & ability_read_post_anony) || (msgs[msgnum].anony==0))
            email(msgs[msgnum].owneruser,msgs[msgnum].ownersys,0,0);
          else
            email(msgs[msgnum].owneruser,msgs[msgnum].ownersys,0,msgs[msgnum].anony);
          if (quote!=NULL) {
            farfree(quote);
            quote=NULL;
          }
          break;
       case 'P':
            irt[0]=0;
            reply=0;
            irt_name[0]=0;
       case 'R':
            if (s[0]!='P')
                quote_message(&(msgs[msgnum].msg),(subboards[curlsub].filename));
            deleted_flag=0;
            post();
            if (quote!=NULL) {
              farfree(quote);
              quote=NULL;
            }
            if (deleted_flag && (deleted_flag<=msgnum))
                --msgnum;
            break;
       case '?':
            if (lcs()) printmenu(13);
            else printmenu(1);
            break;
       case '-':
           if ((msgnum>1) && (msgnum-1<nummsgs)) {
              --msgnum;
              optype=2;
            }
            break;
       case 'C':
            express=1;
            break;
       case 'V':
            if ((cs()) && (msgs[msgnum].ownersys==0) && (msgnum>0) && (msgnum<=nummsgs))
                uedit(msgs[msgnum].owneruser,0);
            else if ((cs()) && (msgnum>0) && (msgnum<=nummsgs)) {
                nl();
                pl("Post from another system.");
                nl();
            }
            break;
       case 'N':
            if ((lcs()) && (msgnum>0) && (msgnum<=nummsgs)) {
                togglebit(&msgs[msgnum].status,status_no_delete);
                bchanged=1;
                nl();
                if (msgs[msgnum].status & status_no_delete)
                    pl("Message is Not Permament");
                else
                    pl("Message is Permanent");
                nl();
            }
            break;
       case '*':
            if ((lcs()) && (msgnum>0) && (msgnum<=nummsgs)) {
                  togglebit(&msgs[msgnum].status,status_pending_net);
                  bchanged=1;
                  nl();
                  if (msgs[msgnum].status & status_pending_net) {
                    val |= 2;
                    pl("Will be sent out on net now.");
                  } else
                    pl("Not set for net pending now.");
                  nl();
            }
            break;
       case 'U':
            if ((lcs()) && (msgnum>0) && (msgnum<=nummsgs)) {
                  msgs[msgnum].anony=0;
                  bchanged=1;
                  nl();
                  pl("Message is not anonymous now.");
            }
            break;
       case 'K':
            if (lcs()) {
                if (msgnum) {
                    delete(msgnum);
                    if (msgnum>1)
                      msgnum--;
                }
             }
             break;
        case 'X':
             if (so()) {
                  if ((msgnum>0) && (msgnum<=nummsgs)) {
                    b=readfile(&(msgs[msgnum].msg),(subboards[curlsub].filename),&len);
                    extract_out(b,len, msgs[msgnum].title);
                  }
            }
            break;
        case 'M':
                    if ((cs()) && (msgnum>0) && (msgnum<=nummsgs)) {
                nl();
                do {
                    prt(2,"Move to which sub? ");
                    ss1=mmkey(0);
                    if (ss1[0]=='?')
                        sublist('L');
                } while ((!hangup) && (ss1[0]=='?'));
                i=-1;
                if (ss1[0]==0)
                    break;
                for (i1=0; i1<50; i1++)
                    if (strcmp(usub[i1].keys,ss1)==0)
                i=i1;
                if (i!=-1) {
                    p=msgs[msgnum];
                    b=readfile(&(p.msg),(subboards[curlsub].filename),&len);
                    delete(msgnum);
                    savebase();
                    iscan(i);
                    p.msg.storage_type=subboards[curlsub].storage_type;
                    savefile(b,len,&(p.msg),(subboards[curlsub].filename));
                    p.qscan=status.qscanptr++;
                    if (nummsgs>=subboards[curlsub].maxmsgs) {
                      i1=1;
                      i2=0;
                      while ((i2==0) && (i1<=nummsgs)) {
                        if ((msgs[i1].status & status_no_delete)==0)
                          i2=i1;
                        ++i1;
                      }
                      if (i2==0)
                         i2=1;
                      p1=msgs[i2];
                      remove_link(&p1.msg,(subboards[curlsub].filename));
                      for (i1=i2; i1<nummsgs; i1++)
                         msgs[i1]=msgs[i1+1];
                      --nummsgs;
                    }
                    msgs[++nummsgs]=p;
                    bchanged=1;
                    savebase();
                    save_status();
                    iscan(cursub);
                    nl();
                    pl("Message moved.");
                    nl();

            }
        }
		break;
/*************/
       }
	  } else {
	    if (strcmp(s,"CLS")==0)
	      outchr('\x0c');
        if (strcmp(s,"CHAT")==0)
          reqchat("Chat Reason");
      }
        break;
      case 1: /* List Titles */
        i=0;
        abort=0;
        if (msgnum>=nummsgs)
          abort=1;
        while ((!abort) && (!hangup) && (++i<=10)) {
          ++msgnum;
          itoa(msgnum,s,10);
          if ((msgs[msgnum].ownersys==0) && (msgs[msgnum].owneruser==usernum))
            sprintf(s1,"[%s]",s);
          else
            sprintf(s1,"(%s)",s);
          for (i1=0; i1<5; i1++)
            s[i1]=32;
          if (msgs[msgnum].qscan>thisuser.qscnptr[curlsub])
            s[0]='*';
          strcpy(&s[7-strlen(s1)],s1);
          strcat(s," ");
                   strcpy(s1,msgs[msgnum].title);
     if ((subboards[curlsub].type) && (strlen(s1)==52)) {
          memmove(s2,&s1[44],8);
          sprintf(s3,"%-43.43s     %-8.8s",s1,s2);
          strcat(s,s3);
        } else
          strcat(s,s1);                           


          pla(s,&abort);
          if (msgnum>=nummsgs)
            abort=1;
        }
        optype=0;
        break;
      case 2: /* Read Message */
    if ((msgnum>0) && (msgnum<=nummsgs))  read_message(msgnum,&next,&val);
	ansic(0);
        nl();
        if (next) {
          ++msgnum;
          if (msgnum>nummsgs)
            done=1;
          optype=2;
        } else
          optype=0;
        if (expressabort)
	  if (realexpress) {
            done=1;
            quit=1;
            *nextsub=0;
          } else {
	    expressabort=0;
	    express=0;
	    optype=0;
	  }
        break;
    }
  } while ((!done) && (!hangup));

  if (!realexpress) {
    express=0;
    expressabort=0;
  }
  if ((val & 1) && (lcs()) && (!express)) {
    nl();
    prt(5,"Validate messages here? ");
    if (yn()) {
      for (i=1; i<=nummsgs; i++)
        if (msgs[i].status & (status_unvalidated | status_delete))
          msgs[i].status &= (~(status_unvalidated | status_delete));
      bchanged=1;
    }
  }
  if ((val & 2) && (lcs()) && (!express)) {
    nl();
    prt(5,"Network validate here? ");
    if (yn()) {
      i1=0;
      for (i=1; i<=nummsgs; i++)
        if (msgs[i].status & status_pending_net) {
          send_net_post(msgs+i, subboards[curlsub].type,
            subboards[curlsub].filename);
          ++i1;
          msgs[i].status &= (~status_pending_net);
        }
      sprintf(s,"%d messages sent.",i1);
      nl();
      pl(s);
      nl();
      bchanged=1;
    }
  }
  if ((!quit) && (!express)) {
    nl();
    ss=syscfg.sl[thisuser.sl];
    if (
        ((restrict_post & thisuser.restrict)==0) &&
        (thisuser.posttoday<ss.posts) &&
        (thisuser.sl>=subboards[curlsub].postsl)) {
              sprintf(s,"Post on %s? ",subboards[curlsub].name);
              prt(5,s);
              irt[0]=0;
              irt_name[0]=0;
              if(yn()) post();
    }
  }
  savebase();
  nl();
}

void qscan(int bn, int *ns)
{
    int i,nextsub,os,sn;
    char s[81],s1[81];
    unsigned long qscnptrx,sd;

    sn=usub[bn].subnum;

    if ((hangup) || (sn<0))
        return;

    os=cursub;
    cursub=bn;
    qscnptrx=QSCN(sn);
    sd=sub_dates[sn];
    if ((!sd) || (sd>qscnptrx)) {
        nextsub=*ns;
        i=1;

        iscan(cursub);

        pl(get_string(18));

        while ((i<=nummsgs) && (msgs[i].qscan<=qscnptrx))
            ++i;
        if ((nummsgs>0) && (msgs[nummsgs].qscan<=qscnptrx)) {
            QSCN(curlsub)=status.qscanptr-1;
        }
        if ((nummsgs>0) && (i<=nummsgs))
            if (msgs[i].qscan>QSCN(curlsub))
                scan(i,2,&nextsub);

        *ns=nextsub;
        pl(get_string(19));
    } 
    else {
        pl(get_string(35));
    }
    cursub=os;
}

void readmail()
{
    int i,i1,i2,i3,f,mw,mloc[256],mfl,curmail,done,abort,next,okmail,numm;
    unsigned short x,xx;
    char s[81],s1[81],s2[81],fn[81],*b;
    mailrec m;
    slrec ss;
    userrec u,u1;
    char ch;
    long len,num_mail,num_mail1;
    unsigned short un, sy;

    ss=syscfg.sl[actsl];
    numm=nummsgs;
    sprintf(fn,"%sEMAIL.DAT",syscfg.datadir);
    f=open(fn,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
    if (f<0) {
        nl();
        nl();
        pl("No mail file exists!");
        nl();
        return;
    }
    mfl=filelength(f)/sizeof(mailrec);
    mw=0;
    for (i=0; (i<mfl) && (mw<255); i++) {
        lseek(f,((long) (i)) * (sizeof(mailrec)), SEEK_SET);
        read(f,(void *)(&m),sizeof(mailrec));
        if ((m.tosys==0) && (m.touser==usernum))
            mloc[mw++]=i;
    }
    thisuser.waiting=mw;
    if (usernum==1)
        fwaiting=mw;
    if (mw==0) {
        nl();
        nl();
        pl("You have no mail.");
        nl();
        return;
    }
    if (mw==1)
        curmail=0;
    else {
        nl();
        nl();
        pl("You have mail from:");
        nl();
        for (i=0; i<mw; i++) {
            lseek(f,((long) mloc[i]) * sizeof(mailrec),SEEK_SET);
            read(f,(void *) (&m),sizeof(mailrec));
            sprintf(s,"%d. ",i+1);
            if ((m.anony & anony_sender) && ((ss.ability & ability_read_email_anony)==0)) {
                strcat(s,">UNKNOWN<");
            } 
            else {
                if (m.fromsys==0) {
                    if (m.fromuser==65535)
                        strcat(s,"WWIVnet");
                    else {
                        read_user(m.fromuser,&u);
                        strcat(s,nam(&u,m.fromuser));
                    }
                } 
                else {
                    sprintf(s1,"User %u @%u",m.fromuser,m.fromsys);
                    strcat(s,s1);
                }
            }
            pl(s);
        }
        nl();
        outstr(get_string(33));
        input(s,3);
        if (strcmp(s,"Q")==0) {
            close(f);
            return;
        }
        i=atoi(s);
        if (i)
            if (i<=mw)
                curmail=i-1;
        else
            curmail=0;
        else
            curmail=0;
    }
    done=0;
    do {
        abort=0;
        next=0;
        ansic(MSG_COLOR);
        s[0]=0;
        if (mloc[curmail]<0) {
            strcat(s,">>> MAIL DELETED <<<");
            okmail=0;
            pl(s);
            nl();
            nl();
        } 
        else {
            lseek(f,((long) (mloc[curmail])) * (sizeof(mailrec)), SEEK_SET);
            read(f,(void *)&m,sizeof(mailrec));
            if ((m.tosys!=0) || (m.touser!=usernum)) {
                mloc[curmail]=-1;
                strcat(s,">>> MAIL DELETED <<<");
                okmail=0;
                pl(s);
                nl();
                nl();
            } 
            else {
                strcat(s,m.title);
                strcpy(irt,m.title);
                irt_name[0]=0;
                abort=0;
                i=((ability_read_email_anony & ss.ability)!=0);
                okmail=1;
                if ((m.fromsys) && (!m.fromuser))
                    grab_user_name(&(m.msg),"EMAIL");
                else
                    net_email_name[0]=0;
                setorigin(m.fromsys, m.fromuser);
                if (m.status & status_source_verified) {
                    if (strlen(m.title)<=78) {
                        xx=*(short *) (m.title+79);
                        sprintf(s,"-=-=: Type %u Source Verified",xx);
                        if (xx==1) {
                            strcat(s," (From NC)");
                        } 
                        else if ((xx>256) && (xx<512)) {
                            sprintf(s2," (From group %u GC)",xx-256);
                            strcat(s,s2);
                        }
                    } 
                    else {
                        strcpy(s,"-=-=: Source Verified (unknown type)");
                    }
                    if (!abort) {
                        ansic(4);
                        pla(s,&abort);
                    }
                }
                if (!abort) nummsgs=mw;
                strcpy(irt,m.title);
                read_user(m.fromuser,&u);
                strcpy(irt_name,nam(&thisuser,usernum));
                sprintf(commstr,"%s",u.comment);
                i=0;
                if((m.anony & 0x0f) & anony_sender)
                    if ((lcs()) || (syscfg.sl[actsl].ability & ability_read_post_anony))
                      i=2;
                    else
                      i=1;
                read_message1(&m.msg, (m.anony & 0x0f), i, &next, "EMAIL",1,m.title,curmail+1,nam(&thisuser,usernum));
            }
        }
        do {
            i2=1;
            outstr(get_string(36));
                strcpy(s,"QA?-+G\r");
            if (okmail)
                strcat(s,"RD");
            if(cs()||so())
                strcat(s,"EZPVU0");
            ch=onek(s);
            switch (ch) {
            case 'E':
                if ((so()) && (okmail)) {
                    b=readfile(&(m.msg),"EMAIL",&len);
                    extract_out(b,len,m.title);
                }
                i2=0;
                break;
            case 'Q':
                done=1;
                break;
            case 'O':
                if ((cs()) && (okmail) && (m.fromuser!=65535)) {
                    nl();
                    npr("3Which form letter? ");
                    input(s,4);
                    sprintf(s1,"%sFORM%s.MSG",syscfg.gfilesdir,s);
                    if (exist(s1)) {
                        load_workspace(s1,1);
                        close(f);
                        num_mail=((long) thisuser.feedbacksent) +
                            ((long) thisuser.emailsent) +
                            ((long) thisuser.emailnet);
                        if (m.fromuser!=65535)
                            email(m.fromuser,m.fromsys,0,m.anony);
                        f=open(fn,O_RDWR | O_BINARY);
                        num_mail1=((long) thisuser.feedbacksent) +
                            ((long) thisuser.emailsent) +
                            ((long) thisuser.emailnet);

                        if (num_mail != num_mail1) {
                            strcpy(s,nam1(&thisuser,usernum,syscfg.systemnumber));
                            if (m.anony & anony_receiver)
                                strcpy(s,">UNKNOWN<");
                            strcat(s," read your mail on ");
                            strcat(s,date());
                            if (!(m.status & status_source_verified))
                                ssm(m.fromuser,m.fromsys,s);
                            delmail(f,mloc[curmail]);
                            mloc[curmail]=-1;
                            ++curmail;
                            if (curmail>=mw)
                                done=1;
                            if (!wfc)
                                topscreen();
                        } 
                        else {
                            sprintf(s,"%sINPUT.MSG",syscfg.tempdir);
                            unlink(s);
                        }
                    } 
                    else {
                        nl();
                        pl("File not found.");
                        nl();
                        i2=0;
                    }
                }
                break;
            case 'G':
                npr("3Go to which [1-%u] ? ",mw);
                input(s,3);
                i2=atoi(s);
                if ((i2>0) && (i2<=mw)) {
                    curmail=i2-1;
                    i2=1;
                } 
                else
                    i2=0;
                break;
            case '\r':
                nl();
                npr("5Delete This Piece of Mail? ");
                if(ny()) {
                    if (!okmail)
                        break;
                    strcpy(s,nam1(&thisuser,usernum,syscfg.systemnumber));
                    if (m.anony & anony_receiver)
                        strcpy(s,">UNKNOWN<");
                    strcat(s," read your mail on ");
                    strcat(s,date());
                    if (!(m.status & status_source_verified))
                        ssm(m.fromuser,m.fromsys,s);
                    if (!okmail)
                        break;
                    delmail(f,mloc[curmail]);
                    mloc[curmail]=-1;
                    ++curmail;
                    if (curmail>=mw)
                        done=1;
                    if (!wfc)
                        topscreen();
                }
                ++curmail;
                if (curmail>=mw)
                    done=1;
                break;
            case '+':
                ++curmail;
                if (curmail>=mw)
                    done=1;
                break;
            case '-':
                if (curmail)
                    --curmail;
                break;
            case 'A':
                break;
            case '?':
                if(so()||cs())
                    printmenu(29);
                else
                    printmenu(4);
                i2=0;
                break;
            case 'D':
                if (!okmail)
                    break;
                strcpy(s,nam1(&thisuser,usernum,syscfg.systemnumber));
                if (m.anony & anony_receiver)
                    strcpy(s,">UNKNOWN<");
                strcat(s," read your mail on ");
                strcat(s,date());
                if (!(m.status & status_source_verified))
                    ssm(m.fromuser,m.fromsys,s);
            case 'Z':
                if (!okmail)
                    break;
                delmail(f,mloc[curmail]);
                mloc[curmail]=-1;
                ++curmail;
                if (curmail>=mw)
                    done=1;
                if (!wfc)
                    topscreen();
                break;
            case 'P':
                if (!okmail)
                    break;
                purgemail(f,mloc,mw,&curmail,&m,&ss);
                if (curmail>=mw)
                    done=1;
                if (!wfc)
                    topscreen();
                break;
            case 'F':
                if (!okmail)
                    break;
                if (m.status & status_multimail) {
                    nl();
                    pl("Can't forward multimail.");
                    nl();
                    break;
                }
                nl();
                nl();
                prt(2,"Forward to: ");
                input(s,30);
                parse_email_info(s, &un, &sy);
                if (un || sy) {
                    if (forwardm(&un, &sy)) {
                        pl("Mail forwarded.");
                    }
                    if ((un==usernum) && (sy==0) && (!cs())) {
                        pl("Can't forward to yourself.");
                        un=0;
                    }
                    if (un || sy) {
                        if (sy) {
                            if (un) {
                                sprintf(s1,"#%u @%u",un, sy);
                            } 
                            else {
                                sprintf(s1,"%s @%u",net_email_name, sy);
                            }
                        } 
                        else {
                            read_user(un,&u);
                            strcpy(s1,nam1(&u,un,syscfg.systemnumber));
                        }
                        if (ok_to_mail(un, sy, 0)) {
                            sprintf(s,"Forward to %s? ",s1);
                            prt(5,s);
                            if (yn()) {
                                sprintf(s,"\r\nForwarded from: %s",
                                nam1(&thisuser,usernum,syscfg.systemnumber));
                                lineadd(&m.msg,s,"EMAIL");
                                sprintf(s,"%s forwarded your mail to %s",
                                nam1(&thisuser,usernum,syscfg.systemnumber),s1);
                                if (!(m.status & status_source_verified))
                                    ssm(m.fromuser,m.fromsys,s);
                                sysoplog("Forwarded mail.");
                                --thisuser.waiting;
                                if (usernum==1)
                                    --fwaiting;
                                outstr("Forwarding: ");
                                sendout_email(m.title, &m.msg, m.anony, un, sy, 1);
                                m.touser=0;
                                m.tosys=0;
                                m.daten=0xffffffff;
                                m.msg.storage_type=0;
                                m.msg.stored_as=0xffffffff;
                                lseek(f,((long) (mloc[curmail])) * (sizeof(mailrec)), SEEK_SET);
                                write(f,(void *)&m,sizeof(mailrec));
                                mloc[curmail]=-1;
                                ++curmail;
                                if (curmail>=mw)
                                    done=1;
                                if (!wfc)
                                    topscreen();
                                mailcheck=1;
                            }
                        }
                    }
                }
                break;
            case 'R':
                if (!okmail)
                    break;
                npr("5Save Original? ");
                if(yn()) ch='S';
                close(f);
                strcpy(irt,m.title);
                strcpy(irt,nam(&thisuser,usernum));
                quote_message(&(m.msg),"EMAIL");
                num_mail=((long) thisuser.feedbacksent) +
                    ((long) thisuser.emailsent) +
                    ((long) thisuser.emailnet);
                if (m.fromuser!=65535)
                    email(m.fromuser,m.fromsys,0,m.anony);
                if (quote!=NULL) {
                    farfree(quote);
                    quote=NULL;
                }

                f=open(fn,O_RDWR | O_BINARY);
                num_mail1=((long) thisuser.feedbacksent) +
                    ((long) thisuser.emailsent) +
                    ((long) thisuser.emailnet);
                if (ch=='R') {
                    if (num_mail!=num_mail1) {
                        strcpy(s,nam1(&thisuser,usernum,syscfg.systemnumber));
                        if (m.anony & anony_receiver)
                            strcpy(s,">UNKNOWN<");
                        strcat(s," read your mail on ");
                        strcat(s,date());
                        if (!(m.status & status_source_verified))
                            ssm(m.fromuser,m.fromsys,s);
                        delmail(f,mloc[curmail]);
                        mloc[curmail]=-1;
                        ++curmail;
                        if (curmail>=mw)
                            done=1;
                        if (!wfc)
                            topscreen();
                    } 
                    else {
                        nl();
                        pl("No mail sent.");
                        nl();
                        i2=0;
                    }
                } 
                else {
                    if (num_mail != num_mail1) {
                        ++curmail;
                        if (curmail>=mw)
                            done=1;
                        if (!wfc)
                            topscreen();
                    }
                }
                break;
            case 'U':
                if (!okmail)
                    break;
                if ((m.fromsys==0) && (cs()) && (m.fromuser!=65535))
                    uedit(m.fromuser,0);
                else
                    if (cs()) {
                    nl();
                    pl("Mail from another system.");
                    nl();
                }
                i2=0;
                break;
            }
        } 
        while ((!i2) && (!hangup));
    } 
    while ((!hangup) && (!done));
    close(f);
    nummsgs=numm;
}


void anscan(int ss)
{
  int i,nextsub,abort,next,disp=0;

  nl();
  nextsub=1;

    for (i=ss; (usub[i].subnum!=-1) && (i<64) && (nextsub) && (!hangup); i++) {
      if (subboards[usub[i].subnum].anony & anony_no_tag) {
        if(!disp) {
            pl("4AutoScanning Subs");
            disp=1;
         }
         qscan(i,&nextsub);
      }

    abort=next=0;
    checka(&abort,&next,0);
    if (abort)
      nextsub=0;
  }
}
