#pragma hdrstop
#pragma inline
#include <dos.h>

extern int running_dv;

int get_dv_version(void)
{
    union REGS r;
    int v;

    r.h.ah = 0x2B;
    r.h.al = 0x01;
    r.x.cx = 0x4445;
    r.x.dx = 0x5351;
    int86(0x21, &r, &r);
    if (r.h.al == 0xff) {
        running_dv = 0;
        return -1;
    } else {
        v = r.x.bx;
        running_dv = 1;
        return v;
    }
}




void start_dv_crit(void)    // begin DESQview non-swappable region
{                           // (Unlike the Quarterdeck API library
    if (!running_dv)
        return;             // functions, the start_dv_crit and
    asm {                   // end_dv_crit functions do not keep
        mov ax,0x101a;      // track of how many times they are
        int 0x15;           // called.  Each start_dv_crit call
        mov ax,0x101b;      // must have one and only one
        int 0x15;           // corresponding end_dv_crit call
        mov ax,0x1025;      // and no end_dv_crit call can be
        int 0x15;           // permitted without a corresponding
    }                       // start_dv_crit call.)
    return;
}


void end_dv_crit(void)          // end DESQview non-swappable region
{
    if (!running_dv)
        return;
    asm {
        mov ax,0x101a;
        int 0x15;
        mov ax,0x101c;
        int 0x15;
        mov ax,0x1025;
        int 0x15;
    }
}


void dv_pause(void)         // relinquish remainder of timeslice
{
    if (!running_dv)
        return;
    asm {
        mov ax,0x101a;
        int 0x15;
        mov ax,0x1000;
        int 0x15;
        mov ax,0x1025;
        int 0x15;
    }
}


