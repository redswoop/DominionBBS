#include "vars.h"

#pragma hdrstop

extern char commstr[41];

void isr1(int un, char *name)
{
  int cp,i;
  char s[81];
  smalrec sr;

  cp=0;
  while ((cp<status.users) && (strcmp(name,(smallist[cp].name))>0))
    ++cp;
  memmove(&(smallist[cp+1]),&(smallist[cp]),sizeof(smalrec)*(status.users-cp));
  strcpy(sr.name,name);
  sr.number=un;
  smallist[cp]=sr;
  ++status.users;
}

void reset_files()
{
  int i,i1;
  userrec u;
  char s[81];

  status.users=0;

  read_user(1,&u);
  i1=number_userrecs();
  for (i=1; i<=i1; i++) {
    read_user(i,&u);
    if ((u.inact & inact_deleted)==0)
      isr1(i,u.name);
    if ((i % 10)==0) {
      npr("%d\r",i);
    }
  }

  npr("\r\n\r\n");

  sprintf(s,"%suser.idx",syscfg.datadir);
  i=open(s,O_RDWR | O_BINARY | O_TRUNC | O_CREAT,S_IREAD|S_IWRITE);
  if (i<0) {
    printf("Error creating %s.\n",s);
    err(1,s,"In Reset IDX");
  }
  write(i,(void *) (smallist), (sizeof(smalrec) * status.users));
  close(i);

  save_status();
  close_user();
}


void get_status()
{
  char s[81];
  int statusfile;

  sprintf(s,"%sSTATUS.DAT",syscfg.datadir);
  statusfile=open(s,O_RDWR | O_BINARY);
  if (statusfile>=0) {
    read(statusfile,(void *)(&status), sizeof(statusrec));
    close(statusfile);
  } else
    save_status();
}

void prstatus()
{
  int i;
  long l;

  outchr(12);
  npr("New User Pass   : %s\r\n",syscfg.newuserpw);
  npr("Number Users    : %d\r\n",status.users);
  npr("Number Calls    : %ld\r\n",status.callernum1);
  npr("Active Today    : %d\r\n",status.activetoday);
  npr("Calls Today     : %d\r\n",status.callstoday);
  npr("M Posted Today  : %d\r\n",status.msgposttoday);
  npr("Sysop           : %sAvailable\r\n",sysop2()?"":"NOT ");
  i=3;
  l=(long) freek(3);
  while ((l>0) && ((i+'@')<=cdir[0])) {
    npr("%c: Free Space   : %ldk\r\n",i+'@',l);
    i++;
    if ((i+'@')<=cdir[0])
      l=(long) freek(i);
  }
  npr("Feedback Waiting: %d\r\n",fwaiting);
  npr("Downloads Today : %d\r\n",status.dltoday);
  npr("Uploads Today   : %d\r\n",status.uptoday);
}

void print_net_listing(unsigned int ss)
{
  int i,i1,i2,abort,f;
  char s[161],ch;
  net_system_list_rec csne;

  ss = ss%10000;

  abort=0;
  nl();
  pla("  Num  Phone         Name                                     Hop  Next Grp",&abort);
  pla("-----  ============  ---------------------------------------- === ----- ===",&abort);
  sprintf(s,"%sBBSDATA.NET",syscfg.datadir);
  f=open(s,O_RDONLY | O_BINARY);
  for (i=0; (i<num_sys_list) && (!abort); i++) {
    read(f,&csne,sizeof(net_system_list_rec));
    if ((csne.forsys!=65535) && ((csne.sysnum%10000)>=ss)){
      if (csne.other & other_net_coord)
        ch='&';
      else if (csne.other & other_group_coord)
        ch='%';
      else if (csne.other & other_coordinator)
        ch='^';
      else
        ch=' ';
      sprintf(s,"%5d%c %12s  %-40s %3d %5d %3d",
        csne.sysnum,ch,csne.phone,csne.name,csne.numhops,
        csne.forsys, csne.group);
      pla(s,&abort);
      ss=0;
    }
  }
  close(f);
}


void read_new_stuff()
{
  int i;
  char s[81];

  if (ncn!=NULL)
    farfree(ncn);
  if (cnn!=NULL)
    farfree(cnn);
  if (csn!=NULL)
    farfree((void far *) csn);
  if (con!=NULL)
    farfree(con);
  ncn=NULL;
  cnn=NULL;
  csn=NULL;
  con=NULL;
  read_in_file("MENUS.MSG",(menus),50);
  if (csn!=NULL)
    farfree((void far *)csn);
  if (cnn!=NULL)
    farfree(cnn);
  if (con!=NULL)
    farfree(con);
  read_bbs_list_index();
  read_contacts();
}


void mailr()
{
  int i,abort,a,f,next;
  mailrec m;
  char c,s[81];
  userrec u;

  sprintf(s,"%sEMAIL.DAT",syscfg.datadir);
  f=open(s,O_BINARY | O_RDWR);
  if (f!=-1) {
    i=filelength(f)/sizeof(mailrec)-1;
    c=' ';
    while ((i>=0) && (c!='Q') && (!hangup)) {
      lseek(f,((long) (i)) * ((long) sizeof(mailrec)),SEEK_SET);
      read(f,(void *)&m,sizeof(mailrec));
      if (m.touser!=0) {
        do {
          setorigin(m.fromsys, m.fromuser);
          commstr[0]=0;
          read_user(m.touser,&u);
          read_message1(&(m.msg),m.anony & 0x0f,1,&next,"EMAIL",1,m.title,0,nam(&u,m.touser));
          prt(2,"R,D,Q,<space>  : ");
          if (next) c=' ';
          else c=onek("QRD ");
          if (c=='D') {
            delmail(f,i);
            if ((!useron) && (m.touser==1) && (m.tosys==0)) --thisuser.waiting;
          }
          nl();
          nl();
        } while ((c=='R') && (!hangup));
      }
      i-=1;
    }
    close(f);
    close_user();
  }
}


void chuser()
{
  char s[81];
  int i;

  if (!checkpw())
    return;
  prt(2,"User to change to? ");
  input(s,30);
  i=finduser1(s);
  if (i>0) {
    write_user(usernum,&thisuser);
    read_user(i,&thisuser);
    usernum=i;
    close_user();
    actsl=255;
    sprintf(s,"7!!0 Changed to 4%s",nam(&thisuser,usernum));
    topscreen();
    sysoplog(s);
  } else
    pl("Unknown user.");
}

void zlog()
{
  zlogrec z;
  char s[81];
  int abort,f,i,i1;

  sprintf(s,"%sHistory.DAT",syscfg.datadir);
  f=open(s,O_RDWR | O_BINARY);
  if (f<0)
    return;
  i=0;
  abort=0;
  read(f,(void *)&z,sizeof(zlogrec));
  pla("0  Date     Calls  Active   Posts   Email   Fback    U/L   D/L   %Act   T/user",&abort);
  pla("7��������   �����  ������   �����   �����   �����    ���   ���   �����  ������0",&abort);
  while ((i<230) && (!abort) && (!hangup) && (z.date[0]!=0)) {
    if (z.calls)
      i1=z.active/z.calls;
    else
      i1=0;
    sprintf(s,"%s    %4d    %4d     %3d     %3d     %3d    %3d   %3d     %3d     %3d",
         z.date,z.calls,z.active,z.posts,z.email,z.fback,z.up,z.dl,10*z.active/144,i1);
    pla(s,&abort);
    ++i;
    if (i<230) {
      lseek(f,((long) i) * sizeof(zlogrec),SEEK_SET);
      read(f,(void *)&z,sizeof(zlogrec));
    }
  }
  close(f);
}



void beginday()
{
  char s[255];
  zlogrec z,z1;
  int f,i,i1;

  double fk;
  int    nus;

  sprintf(s,"1�1>0Totals for 7%s1<1�",status.date1); sl1(0,s);
  sprintf(s,"   0Calls             1: 7%d",status.callstoday); sl1(0,s);
  sprintf(s,"   0Message Posted    1: 7%d",status.msgposttoday); sl1(0,s);
  sprintf(s,"   0FeedBack          1: 7%d",status.fbacktoday);   sl1(0,s);
  sprintf(s,"   0Uploads           1: 7%d",status.uptoday);      sl1(0,s);
  sprintf(s,"   0Downloads         1: 7%d",status.dltoday);      sl1(0,s);
  sprintf(s,"   0Total Time Active 1: 7%d",status.activetoday);  sl1(0,s);
  strcpy(z.date,status.date1);
  z.active=status.activetoday;
  z.calls=status.callstoday;
  z.posts=status.msgposttoday;
  z.email=status.emailtoday;
  z.fback=status.fbacktoday;
  z.up=status.uptoday;
  z.dl=status.dltoday;
  status.callstoday=0;
  status.msgposttoday=0;
  status.emailtoday=0;
  status.fbacktoday=0;
  status.uptoday=0;
  status.dltoday=0;
  status.activetoday=0;
  strcpy(status.date3,status.date2);
  strcpy(status.date2,status.date1);
  strcpy(status.date1,date());
  sprintf(s,"%s%s",syscfg.gfilesdir, status.log5);
  unlink(s);
  strcpy(status.log5,status.log4);
  strcpy(status.log4,status.log3);
  strcpy(status.log3,status.log2);
  strcpy(status.log2,status.log1);
  sl1(3,status.log1);
  sl1(2,date());
  sprintf(s,"%sUSER.LOG",syscfg.gfilesdir);
  unlink(s);
  save_status();
  sprintf(s,"%sHistory.DAT",syscfg.datadir);
  f=open(s,O_RDWR | O_BINARY);
  if (f<0) {
    f=open(s,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
    z1.date[0]=0;
    z1.active=0;
    z1.calls=0;
    z1.posts=0;
    z1.email=0;
    z1.fback=0;
    z1.up=0;
    z1.dl=0;
    for (i=0; i<230; i++)
      write(f,(void *)&z1,sizeof(zlogrec));
  } else {
    for (i=230; i>=1; i--) {
      lseek(f,(long) ((i-1) * sizeof(zlogrec)),SEEK_SET);
      read(f,(void *)&z1,sizeof(zlogrec));
      lseek(f,(long) (i * sizeof(zlogrec)),SEEK_SET);
      write(f,(void *)&z1,sizeof(zlogrec));
    }
  }
  lseek(f,0L,SEEK_SET);
  write(f,(void *)&z,sizeof(zlogrec));
  close(f);
  voteprint();

  if (syscfg.beginday_c[0]) {
    stuff_in(s,syscfg.beginday_c,create_chain_file("CHAIN.TXT"),"","","","");
    runprog(s,0);
  }

  fk=freek1(syscfg.datadir);
  nus=syscfg.maxusers-status.users;

  if (fk<512.0) {
    sprintf(s,"**>Only %dk free in data directory.",(int) fk);
    ssm(1,0,s);
    sysoplog(s);
  }

  if ((!syscfg.closedsystem) && (nus<15)){
    sprintf(s,"7!!>0Only %d new user slots left.",nus);
    ssm(1,0,s);
    sysoplog(s);
  }
}

void print_local_file(char ss[81])
{
  char s[81];

  if ((syscfg.sysconfig & sysconfig_list) &&!incom) {
    sprintf(s,"LST %s%s",syscfg.gfilesdir,ss);
    if(searchpath("LST.EXE")!=NULL) {
        runprog(s,0);
        return;
    }
  }

  printfile(ss);
  nl();
  nl();
  getkey();
}

void text_edit()
{
  char s[81],s1[81];

  nl();
  npr("3Filename\r\n5: ");
  mpl(71);
  input(s,71);
  if (strstr(s,".LOG")!=NULL)
    s[0]=0;
  if (s[0]) {
    logpr("5@0 Edited 4%s",s);
    if (okfsed())
      external_edit(s,syscfg.gfilesdir,thisuser.defed-1,500);
    else
      tedit(s);
  }
}

void parse_email_info(char *s, unsigned short *un1, unsigned short *sy1)
{
  char *ss;
  unsigned un, sy;
  int i;

  *un1=0;
  *sy1=0;
  ss=strchr(s,'@');
  if (ss==NULL) {
    un=finduser1(s);
    if (un>0)
      *un1=un;
    else
      pl("Unknown user.");
  } else {
    ss[0]=0;
    ss=&(ss[1]);
    i=strlen(s);
    while ((i>0) && (s[i-1]==' '))
      --i;
    s[i]=0;
    un=atoi(s);
    sy=atoi(ss);
    if ((sy==syscfg.systemnumber)) {
      un=finduser1(s);
      if (un>0)
        *un1=un;
      else
        pl("Unknown user.");
    } else {
      if (un==0) {
        strcpy(net_email_name,s);
        i=strlen(net_email_name);
        while ((i>0) && (net_email_name[i-1]==' '))
          --i;
        net_email_name[i]=0;
        if (net_email_name[0])
          *sy1=sy;
        else
          pl("Unknown user.");
      } else {
        *un1=un;
        *sy1=sy;
      }
    }
  }
}

void viewlog()
{
    char s[15],s1[81];

    npr("3View Logs from How Many Days Ago? (1-5,Enter=Today)\r\n5: ");
    mpl(4);
    input(s,4);
    switch(atoi(s)) {
        case 0: sl1(3,s);
                strcpy(s1,s);
                print_local_file(s1); break;
        case 1: print_local_file(status.log1); break;
        case 2: print_local_file(status.log2); break;
        case 3: print_local_file(status.log3); break;
        case 4: print_local_file(status.log4); break;
        case 5: print_local_file(status.log5); break;
    }
}
