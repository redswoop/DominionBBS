#pragma hdrstop
#include <stdio.h>

void err(int err,char *fn,char msg[80])
{
    long l;
    FILE *f;
    char s[161];

    time(&l);

    pl("An Error Has Occured - Will try to save system.  Sorry for any inconvience");
    switch(err) {
        case 1: sprintf(s,"6>>**<< File %s Not Found - Exiting with Error Level 1 - %s - ",fn,msg); break;
        case 2: sprintf(s,"6>>**<< String File Not Found - Exiting with Error Level 2 - %s - ",msg); break;
        case 3: sprintf(s,"6>>**<< Not Enough Memory for Buffer - Exiting with Error Level 3 - %s - ",msg); break;
        case 4: sprintf(s,"6>>**<< File Could Not Be Created - Exiting with Error Level 4 - %s - ",msg); break;
        case 5: sprintf(s,"6>>**<< Fossil Driver Not Installed - Exiting with Error Level 5 - %s - ",msg); break;
        case 6: sprintf(s,"6>>**<< Video Error - Exiting with Error Level 6 - %s - ",msg); break;
        case 7: sprintf(s,"6>>**<< Clock Corrupted - Exiting with Error Level 7 - %s - ",msg); break;
      default : sprintf(s,"6>>**<< UnKnown Error! - Exiting with Error Level %d - %s -",err,msg);
    }
    logpr(">>>>>>>>>>>>System Error at %s",ctime(&l));
    sysoplog(s);
    strcat(s,ctime(&l));
    strcat(s,"\r");
    printf("[0;1m");
    printf(s);
    f=fopen("error.log","at");
    fputs(s,f);
    fclose(f);
    end_bbs(err);
}

