#include "vars.h"

#pragma hdrstop

#include <time.h>
#include <dir.h>

#define INDENTION 30
#define MAX_LINES 10
#define FSED_OK ((okfsed()) && (0))

#define SETREC(i)  lseek(dlf,((long) (i))*((long)sizeof(uploadsrec)),SEEK_SET)

void yourinfodl()
{
  nl();
  dtitle("Your Transfer Status");
  npr("0Downloads     5: 4%ldk in %d files\r\n",thisuser.dk, thisuser.downloaded);
  npr("0Uploads       5: 4%ldk in %d files\r\n",thisuser.uk, thisuser.uploaded);
  npr("0File Points   5: 4%d\r\n",thisuser.fpts);
  npr("0Your KB Ratio 5: 4%-6.3f\r\n",ratio());
  npr("0Required Ratio5: 4%-6.3f\r\n",syscfg.req_ratio);
  nl();
  if(thisuser.exempt & exempt_ratio)
    pl("0Special Flags1:7 No Ratio/File Point Check!");
  if(thisuser.exempt & exempt_post)
    pl("0Special Flags1:7 No Post Call Ratio Check!");
  if(thisuser.exempt & exempt_time)
    pl("0Special Flags1:7 No Time Check!");
  nl();
}



void setldate()
{
  struct date d;
  struct time t;
  char s[81];
  int m,dd,y;

  nl();
  unixtodos(nscandate,&d,&t);
  npr("Current limiting date = %02d/%02d/%02d\r\n",d.da_mon,d.da_day,(d.da_year-1900));
  npr("3Enter NewScan Date\r\n5: ");
  mpl(8);
  inputdate(s,0);
  nl();
  m=atoi(s);
  dd=atoi(&(s[3]));
  y=atoi(&(s[6]))+1900;
  if ((strlen(s)==8) && (m>0) && (m<=12) && (dd>0) && (dd<32) && (y>=1980)) {
    t.ti_min=0;
    t.ti_hour=0;
    t.ti_hund=0;
    t.ti_sec=0;
    d.da_year=y;
    d.da_day=dd;
    d.da_mon=m;
    sprintf(s,"Current limiting date = %02d/%02d/%02d",m,dd,(y-1900));
    nl();
    pl(s);
    nl();
    nscandate=dostounix(&d,&t);
  }
}

void listgen()
{
  int i,i1,pts,abort,pty,ocd,sent;
  char s[81],s1[81],s2[81];
  uploadsrec u;
  FILE *out;

  sprintf(s,"filelist.dom");
  out=fopen(s,"wt");
  abort=0;
  ocd=curdir;
  nl();
  pl("Generating File List:");
  file_mask(s);
  num_listed=0;
  fputs(">>>All Files of ",out);
  fputs(syscfg.systemname,out);
  fputs("\n",out);
  fputs("\n",out);
  for (i=0; (i<64) && (!abort) && (!hangup) && (udir[i].subnum!=-1); i++) {
    pl(get_string(44));
    i1=udir[i].subnum;
    pts=1;
    if (pts) {
      curdir=i;
      dliscan();
      pty=1;
      for (i1=1; (i1<=numf) && (!abort) && (!hangup); i1++) {
    SETREC(i1);
    read(dlf,(void *)&u,sizeof(uploadsrec));
    if (compare(s,u.filename)) {
      if (pty) {
        fputs("\n",out);
        fputs(directories[udir[i].subnum].name,out);
        fputs("\n",out);
        fputs("\n",out);
        pty=0;
      }
    if(u.ats[0])
       sprintf(s1,"%s [%4dk %4dpts] ",u.filename,(u.numbytes+1023)/1024,u.points);
          else
        sprintf(s1,"%s [!UNVALIDATED!] ",u.filename);
        strcat(s1,u.description);
        fputs(s1,out);      fputs("\n",out);
    }
      }
      closedl();
    }
  }
  curdir=ocd;
  if  ((num_listed) && (!abort)) {
    nl();
    nl();
    sprintf(s,"Files For %s",syscfg.systemname);
    fputs(s,out);
    fputs("\n",out);
    sprintf(s,"Files Total: %d",num_listed);
    fputs(s,out);
    fputs("\n",out);

    nl();
  }
  fclose(out);
  add_arc("filelist","filelist.dom");
  sprintf(s1,"%s\\filelist.%s",cdir,syscfg.arcs[ARC_NUMBER].extension);
  i=open(s1,O_RDONLY|O_BINARY);
  i1=filelength(i);
  close(i);
  send_file(s1,&sent,&abort,s2);
  unlink(s);
  unlink(s1);
}

void unlisteddl()
{
    char s[81];
    int abort,sent;

    nl();
    npr("2Enter File Name to Dl\r\n5: ");
    mpl(71);
    input(s,71);
    logpr("5@0 DLed Unlisted file %s",s);
    sent=open(s,O_RDONLY|O_BINARY);
    close(sent);
    send_file(s,&sent,&abort,stripfn(s));
}

void setformat()
{
  FILE *ff;
  char s[81];

  sprintf(s,"%sfile%d.fmt",syscfg.gfilesdir,thisuser.res[3]);
  ff=fopen(s,"rt");
  fgets(filelistformat,81,ff);
  filter(filelistformat,'\n');

  fgets(filelistformat2,81,ff);
  filter(filelistformat2,'\n');

  fgets(filelistformat3,81,ff);
  filter(filelistformat3,'\n');

  fgets(filelistformat4,81,ff);
  filter(filelistformat4,'\n');

  fclose(ff);
}


void arc_cl(int type)
{
  char s[81],s1[81];
  int i,abort,next,i1=0;
  uploadsrec u;

  nl();
  if(file_mask(s)&&type==1) return;
  dliscan();
  abort=0;
  next=0;
  i=recno(s);
  do {
    if (i>0) {
      SETREC(i);
      read(dlf,(void *)&u,sizeof(uploadsrec));
      if(type==1) {
          logpr("3> 0Viewed Archive %s",u.filename);
          i1=list_arc_out(stripfn(u.filename),directories[udir[curdir].subnum].dpath);
      }
      else if(type==0)
          i1=comment_arc(stripfn(u.filename),directories[udir[curdir].subnum].dpath);
      else if(type==2) {
          strcpy(s1,directories[udir[curdir].subnum].dpath);
          strcat(s1,stripfn(u.filename));
          addgif(s1,u.description);
      }
      if (i1)
        abort=1;
      checka(&abort,&next,0);
      i=nrecno(s,i);
    }
  } while ((i>0) && (!hangup) && (!abort));
  closedl();
}



int okfn(char *s)
{
  int i,l,ok;
  unsigned char ch;

  ok=1;
  l=strlen(s);
  for (i=0; i<l; i++) {
    ch=s[i];
    if ((ch<=' ') || (ch=='/') || (ch=='\\') || (ch==':') ||
        (ch=='>') || (ch=='<') || (ch=='|')  || (ch=='+') ||
        (ch==',') || (ch==';') || (ch>126))
      ok=0;
  }
  return(ok);
}

void get_arc_cmd(char *out, char *arcfn, int cmd, char *ofn)
{
  char *ss,*ss1,s[161],s1[161];
  int i;

  out[0]=0;
  ss=strchr(arcfn,'.');
  if (ss==NULL)
    return;
  ++ss;
  ss1=strchr(ss,'.');
  while (ss1!=NULL) {
    ss=ss1;
    ++ss1;
    ss1=strchr(ss,'.');
  }
  for (i=0; i<4; i++)
    if (stricmp(ss,syscfg.arcs[i].extension)==0) {
      switch(cmd) {
        case 0: strcpy(s,syscfg.arcs[i].arcl); break;
        case 1: strcpy(s,syscfg.arcs[i].arce); break;
        case 2: strcpy(s,syscfg.arcs[i].arca); break;
        case 3: strcpy(s,nifty.arc[i].arct); break;
        case 4: strcpy(s,nifty.arc[i].arcc); break;
      }
      if (s[0]==0)
        return;
      sprintf(s1,"%scomment",syscfg.gfilesdir);
      stuff_in(out,s,arcfn,ofn,"","",s1);
      return;
    }

}




int list_arc_out(char *fn, char *dir)
{
  char s[161],s1[81];

  strcpy(s1,dir);
  strcat(s1,fn);
  touchingarc=1;
  get_arc_cmd(s,s1,0,"");
  if (!okfn(fn)) {
    pl("Ouch!");
    s[0]=0;
  }
  if (exist(s1) && (s[0]!=0)) {
    nl();
    nl();
    npr("Archive listing for %s:",fn);
    nl();
    sprintf(s1,"%s>%sarctemp",s,syscfg.gfilesdir);
    system(s1);
    printfile("arctemp.");
    nl();
  } else if(exist(s1))
    npr("\r\nUnKnown Archive Format: %s\r\n",fn);
  else if(!exist(s1))
    npr("\r\nFile %s is Offline\r\n",fn);
  touchingarc=0;
  return(0);
}


int testarc(char *fn, char *dir)
{
  char s[161],s1[81];
  int i=0;

  strcpy(s1,dir);
  strcat(s1,fn);
  incom=0;
  touchingarc=1;
  get_arc_cmd(s,s1,3,"");
  if (!okfn(fn))
    s[0]=0;
  if ((s[0]!=0)) {
    set_protect(0);
    savescreen(&screensave);
    i=runprog(s,0);
    restorescreen(&screensave);
    topscreen();
    nl();
  } else {
    i=0;
  }
  touchingarc=0;
  incom=1;
  return(i);
}


int comment_arc(char *fn, char *dir)
{
  char s[161],s1[81];
  int i=0;

  strcpy(s1,dir);
  strcat(s1,fn);
  touchingarc=1;
  npr("7Commenting: 0%s\r\n",fn);
  get_arc_cmd(s,s1,4,"");
  if (!okfn(fn))
    s[0]=0;
//  if(exist(s1) && (s[0]!=0)) {
  if((s[0]!=0)) {
    set_protect(0);
    printf("[0m");
    savescreen(&screensave);
    runprog(s,0);
    restorescreen(&screensave);
    topscreen();
  } else {
    i=0;
  }
  touchingarc=0;
  return(i);
}


int upload_file(char *fn, int dn)
{
  directoryrec d;
  uploadsrec u,u1;
  int i,i1,i2,ok=1,f;
  char s[81],s1[81],ff[81],*ss;
  long l,len;
  double ti;

  d=directories[dn];
  strcpy(s,fn);
  align(s);
  strcpy(u.filename,s);
  u.ownerusr=usernum;
  u.ownersys=0;
  u.numdloads=0;
  u.filetype=0;
  u.mask=0;
  u.points=0;
  u.ats[0]=1;
  strcpy(ff,d.dpath);
  strcat(ff,s);
  f=open(ff,O_RDONLY | O_BINARY);
  l=filelength(f);
  u.numbytes=l;
  close(f);
  strcpy(u.upby,nam1(&thisuser,usernum,syscfg.systemnumber));
  strcpy(u.date,date());
  if (d.mask & mask_PD)
    d.mask=mask_PD;
  npr("0%s5:3 %ldk 5:2 ",u.filename,(u.numbytes+1023)/1024);
  inputl(u.description,49);
  if (u.description[0]=='.')
    switch(toupper(u.description[1])) {
        case 'Q': return 0;
        case 'S': ok=0; break;
    }
  if(u.description[0]=='/') {
    modify_extended_description(&ss);
    add_extended_description(u.filename,ss);
    farfree(ss);
    u.mask |= mask_extended;
    strcpy(s1,u.description+1);
    strcpy(u.description,s1);
  }
  if (u.description[0]==0)
   strcpy(u.description,"No Description Given at Upload");
  if(ok) {
    thisuser.fpts+=(u.numbytes+1023)/10240;
    ++thisuser.uploaded;
  if (strstr(u.filename,".GIF"))
    addgif(ff,u.description);
  comment_arc(stripfn(u.filename),d.dpath);
  u.points=((l+1023)/10240);
  thisuser.uk += ((l+1023)/1024);
  time(&l);
  u.daten=l;
  for (i=numf; i>=1; i--) {
    SETREC(i);
    read(dlf,(void *)&u1,sizeof(uploadsrec));
    SETREC(i+1);
    write(dlf,(void *)&u1,sizeof(uploadsrec));
  }
  SETREC(1);
  write(dlf,(void *)&u,sizeof(uploadsrec));
  ++numf;
  u1.numbytes=numf;
  SETREC(0);
  write(dlf,(void *)&u1,sizeof(uploadsrec));
  ++status.uptoday;
  save_status();
  logpr("3+ 2Locally uploaded %s on %s",u.filename,d.name);
  }
  return(1);
}


int uploadall(int dn, char s[20])
{
  int i,i1,f1,maxf,ok,ocd,title=0;
  char s1[81];
  struct ffblk ff;
  uploadsrec u;

  dliscan1(dn);
  ocd=curdir;
  curdir=dn;
  nl();
  strcpy(s1,(directories[dn].dpath));
  maxf=directories[dn].maxfiles;
  strcat(s1,s);
  f1=findfirst(s1,&ff,0);
  ok=1;
  i1=0;
  while ((f1==0) && (!hangup) && (numf<maxf) && (ok)) {
    strcpy(s,(ff.ff_name));
    align(s);
    i=recno(s);
    if (i==-1) {
        if(!title) {
          pl("5Enter File Descriptions.  2.S to Skip File, .Q to Quit.");
          pl("0Use 2/0 as first letter of file name to enter Extended Description.");
          pl("Blank Lines will be 'No Description Given at Upload'");
          title=1;
        }

      i1=upload_file(s,dn);
      if(!i1)
        ok=0;
    } else {
      SETREC(i);
      read(dlf,(void *)&u, sizeof(uploadsrec));
    }
    f1=findnext(&ff);
  }
  curdir=ocd;
  closedl();
  if (!ok)
    pl("Aborted.");
  if (numf>=maxf)
    pl("directory full.");
  return(i1);
}


void removefile(int offline)
{
  int i,i1,ok,rm,abort,rdlp;
  char ch,s[81],s1[81];
  uploadsrec u;
  userrec uu;

  dliscan();
  nl();
  if(!offline) {
    npr("3Enter filename to remove\r\n5: ");
    mpl(12);
    input(s,12);
  } else strcpy(s,"*.*");
  if (s[0]==0) {
    closedl();
    return;
  }
  if (strchr(s,'.')==NULL)
    strcat(s,".*");
  align(s);
  i=recno(s);
  abort=0;
  while ((!hangup) && (i>0) && (!abort)) {
    SETREC(i);
    read(dlf,(void *)&u,sizeof(uploadsrec));
    strcpy(s1,(directories[udir[curdir].subnum].dpath));
    strcat(s1,u.filename);
    if ((offline && !exist(s1)) || (!offline && ((dcs()) || (u.ownerusr==usernum))) ) {
      nl();
      printfileinfo(&u,udir[curdir].subnum,0,0);
      prt(2,"Remove (Y/N/Q) : ");
      ch=onek("QNY");
      if (ch=='Q')
        abort=1;
      if (ch=='Y') {
        rdlp=1;
        if (dcs()&&!offline) {
          prt(5,"Delete file too? ");
          rm=yn();
          if (rm) {
            prt(5,"Remove DL fpts? ");
            rdlp=yn();
          }
        } else
          rm=1;
        if (rm) {
          strcpy(s1,(directories[udir[curdir].subnum].dpath));
          strcat(s1,u.filename);
          unlink(s1);
          if ((rdlp) && (u.ownersys==0)) {
            read_user(u.ownerusr,&uu);
            if ((uu.inact & inact_deleted)==0) {
              --uu.uploaded;
              uu.uk -= ((u.numbytes+1023)/1024);
              uu.fpts-=u.points;
              write_user(u.ownerusr,&uu);
            }
            close_user();
          }
        }
        if (u.mask & mask_extended)
          delete_extended_description(u.filename);
        sprintf(s1,"5-4 %s 0Removed off of 4%s",u.filename,
                          directories[udir[curdir].subnum].name);
        sysoplog(s1);
        for (i1=i; i1<numf; i1++) {
          SETREC(i1+1);
          read(dlf,(void *)&u,sizeof(uploadsrec));
          SETREC(i1);
          write(dlf,(void *)&u,sizeof(uploadsrec));
        }
        --i;
        --numf;
        u.numbytes=numf;
        SETREC(0);
        write(dlf,(void *)&u,sizeof(uploadsrec));
      }
    }
    i=nrecno(s,i);
  }
  closedl();
}

void getfileinfo()
{
  int i,abort;
  char s[81];
  uploadsrec u;

  dliscan();
  nl();
  file_mask(s);
  i=recno(s);
  abort=0;

  while ((!hangup) && (i>0) && (!abort)) {
    SETREC(i);
    read(dlf,(void *)&u,sizeof(uploadsrec));
    printfileinfo(&u,udir[curdir].subnum,0,0);
    i=nrecno(s,i);
  }
  closedl();
}


void editfile()
{
  char s[81],s1[81],s2[81],*ss,s3[81],ch;
  int i,cp,done;
  uploadsrec u;

  nl();
  nl();
  file_mask(s);
  dliscan();
  nl();
  strcpy(s3,s);
  i=recno(s);
  done=0;
  while (i>0&&done!=2) {
    cp=i;
    SETREC(i);
    read(dlf,(void *)&u,sizeof(uploadsrec));
    nl();
    do {
    printfileinfo(&u,udir[curdir].subnum,0,0);
    nl();
    prt(2,"File Edit: ");
    ch=onek("QNGFVEPD?\r");
    switch(ch) {
        case '?': printmenu(23); break;
        case '\r': done=1; break;
        case 'Q': done=2; break;
        case 'F': nl();
                    prt(2,"New filename? ");
                    input(s,12);
                    if (!okfn(s))
                      s[0]=0;
                    if (s[0]) {
                      align(s);
                      if (strcmp(s,"        .   ")) {
                        strcpy(s1,directories[udir[curdir].subnum].dpath);
                        strcpy(s2,s1);
                        strcat(s1,s);
                        if (exist(s1))
                          pl("Filename already in use; not changed.");
                        else {
                          strcat(s2,u.filename);
                          rename(s2,s1);
                          if (exist(s1)) {
                            ss=read_extended_description(u.filename);
                            if (ss) {
                              delete_extended_description(u.filename);
                              add_extended_description(s,ss);
                              farfree(ss);
                            }
                            strcpy(u.filename,s);
                          } else
                            pl("Bad filename.");
                        }
                      }
                    } break;
        case 'D': nl();
                  pl("New description:");
                  prt(2,": ");
                  inputl(s,39);
                  if (s[0]) {
                      strcpy(u.description,s);
                  }
                  break;
        case 'V': if(u.ats[0]) u.ats[0]=0; else u.ats[0]=1; break;
        case 'P': nl(); prt(2,"File Points: ");
                  input(s,3);
                  if(s[0]) u.points=atoi(s);
                  break;
        case 'E': ss=read_extended_description(u.filename);
                  nl();
                  nl();
                  prt(5,"Modify extended description? ");
                  if (yn()) {
                    nl();
                    if (ss) {
                      prt(5,"Delete it? ");
                      if (yn()) {
                        farfree(ss);
                        delete_extended_description(u.filename);
                        u.mask &= ~mask_extended;
                      } else {
                        u.mask |= mask_extended;
                        modify_extended_description(&ss);
                        if (ss) {
                          delete_extended_description(u.filename);
                          add_extended_description(u.filename,ss);
                          farfree(ss);
                        }
                      }
                    } else {
                      modify_extended_description(&ss);
                      if (ss) {
                        add_extended_description(u.filename,ss);
                        farfree(ss);
                        u.mask |= mask_extended;
                      } else
                        u.mask &= ~mask_extended;
                    }
                  } else
                    if (ss) {
                      farfree(ss);
                      u.mask |= mask_extended;
                    } else
                      u.mask &= ~mask_extended;
                 break;
            }
    } while (!done);
    SETREC(i);
    write(dlf,(void *)&u,sizeof(uploadsrec));
    i=nrecno(s3,cp);
  }
  closedl();
}

void localupload()
{
    char s[20],s1[20];
    int i=1,i1=0,done=0;

    file_mask(s);
    stripfn(s);
    outstr("5Upload to All Areas? ");
    if(yn()) {
        while(!done) {
            strcpy(s1,s);
            if(i1>num_dirs) {
                done=1;
                continue;
            }
            if(udir[i1].subnum<0) {
                done=1;
                continue;
            }
            nl();
            npr("7Local Uploading: 0 %s\r\n",directories[udir[i1].subnum].name);
            nl();
            i=uploadall(udir[i1].subnum,s1);
            i1++;
        }
    } else uploadall(udir[curdir].subnum,s);
}
