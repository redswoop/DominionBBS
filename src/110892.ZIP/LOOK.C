#include "vardec.h"
#include <fcntl.h>
#include "std.c"
#include <alloc.h>

modem_info *modem_i;

void far *mallocx(unsigned long l)
{
  void *x;

  x=farmalloc(l);
  if (!x) {
    exit(0);
  }
  return(x);
}

void main(int ac,char *ar[]) {

  int i;
  long l;
  char s[81];

  if(ac==1) strcpy(s,"modem.dat");
  else strcpy(s,ar[1]);

  i=open(s,O_RDWR | O_BINARY);
  if (i>0) {
    l=filelength(i);
    modem_i = mallocx(l);
    read(i,modem_i, (unsigned) l);
    close(i);
  }
  npr("Defl: %s, %d bytes, Desc: %s, Mode: %d, Flag_value=%d",modem_i->defl.result,strlen(modem_i->defl.result),modem_i->defl.description,modem_i->defl.main_mode,modem_i->defl.flag_value);
  npr("M/C: %d/%d",modem_i->defl.modem_speed,modem_i->defl.com_speed);
  for(i=0;i<modem_i->num_resl;i++) {
    npr("Resl: %s, %d bytes, Desc: %s, Mode: %d, Flag_value=%d",modem_i->resl[i].result,strlen(modem_i->resl[i].result),modem_i->resl[i].description,modem_i->resl[i].main_mode,modem_i->resl[i].flag_value);
    if(!(modem_i->resl[i].flag_mask & flag_ec)) pl("Error Correcting");
    if(!(modem_i->resl[i].flag_mask & flag_dc)) pl("Compressing");
    if(!(modem_i->resl[i].flag_mask & flag_fc)) pl("Flow Control");
    if(!(modem_i->resl[i].flag_mask & flag_append)) pl("Append");
    if(!(modem_i->resl[i].flag_mask & flag_as)) pl("Async");
  }
}
