#include "vars.h"

#pragma hdrstop

char MCISTR[161];

int ok_local()
{
  if (syscfg.sysconfig& sysconfig_no_local)
    return(0);
  else
    return(1);
}


int finduser1(char *sx)
{
  int i,i1,i2;
  char s[81],s1[81],ch;
  userrec u;

  if (sx[0]==0)
    return(0);
  i=finduser(sx);
  if (i>0)
    return(i);
  strcpy(s,sx);
  for (i=0; s[i]!=0; i++)
    s[i]=toupper(s[i]);
  i2=0;
  for (i=0; (i<status.users) && (i2==0); i++) {
    if (strstr(smallist[i].name,s)!=NULL) {
      i1=smallist[i].number;
      read_user(i1,&u);
      sprintf(s1,"Do you mean %s (Y/N/Q) ? ",nam(&u,i1));
      prt(5,s1);
      ch=onek("QYN");
      if (ch=='Y')
	i2=i1;
      if (ch=='Q')
	i=status.users;
    }
  }
  return(i2);
}

int sysop2()
{
  int ok;

  ok=sysop1();
  if (restrict_chat & thisuser.restrict)
    ok=0;
  if (syscfg.sysoplowtime != syscfg.sysophightime) {
    if (syscfg.sysophightime>syscfg.sysoplowtime) {
      if ((timer()<=(syscfg.sysoplowtime*60.0)) || (timer()>=(syscfg.sysophightime*60.0)))
        ok=0;
    } else {
      if ((timer()<=(syscfg.sysoplowtime*60.0)) && (timer()>=(syscfg.sysophightime*60.0)))
        ok=0;
    }
  }
  return(ok);
}


void yourinfo()
{
  char s[81];

  outchr(12);
  dtitle("Your Information");

  npr("3� 3Your Handle is 4%s3, Your Voice Phone Number is 4%s\r\n",nam(&thisuser,usernum),thisuser.phone);
  npr("3� 3Your Acting Security Level is 4%d3, And Your Transfer Level is 4%d\r\n",actsl,thisuser.dsl);
  nl();
  npr("3� 3You have Downloaded 4%d3 files, And Uploaded 4%d3 files\r\n",thisuser.downloaded,thisuser.uploaded);
  npr("3� 3You have posted 4%d3 times, and Called 4%d3 times\r\n",thisuser.msgpost,thisuser.logons);
  nl();
  npr("3� 3You have 4%d3 minutes left for this call\r\n",(int)((nsl()+30)/60.0));
  sprintf(s,", And have been on 4%d4 times today.",thisuser.ontoday);
  npr("3� 3You last called 4%s3%s\r\n",thisuser.laston,thisuser.ontoday?s:"");
  if (fnet.ad.zone)
    sprintf(s,", NetWork node 4%d:%d/%d",fnet.ad.zone,fnet.ad.net,fnet.ad.node);
  else if(syscfg.systemnumber)
    sprintf(s,", NetWork Node 4%d",syscfg.systemnumber);
  nl();
  npr("3� 3System is 4%s3%s\r\n",wwiv_version,fnet.ad.zone?s:"");
  if(fnet.netname[0])
    npr("3� 3NetWork Name: 4%s\r\n",fnet.netname);
  nl();
  pausescr();
}



void ssm(unsigned int un, unsigned int sy, char *s)
{
  int  f,i,i1;
  userrec u;
  char s1[161];
  shortmsgrec sm;
  net_header_rec nh;

  if (un==65535)
    return;
  if (sy==0) {
    read_user(un,&u);
    if (!(u.inact & inact_deleted)) {
      sprintf(s1,"%sSMW.DAT",syscfg.datadir);
      f=open(s1,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
      i=(int) (filelength(f) / sizeof(shortmsgrec));
      i1=i-1;
      if (i1>=0) {
        lseek(f,((long) (i1)) * sizeof(shortmsgrec), SEEK_SET);
        read(f,(void *)&sm,sizeof(shortmsgrec));
        while ((sm.tosys==0) && (sm.touser==0) && (i1>0)) {
          --i1;
          lseek(f,((long) (i1)) * sizeof(shortmsgrec), SEEK_SET);
          read(f,(void *)&sm,sizeof(shortmsgrec));
        }
        if ((sm.tosys) || (sm.touser))
          ++i1;
      } else
        i1=0;
      sm.tosys=sy;
      sm.touser=un;
      strncpy(sm.message,s,80);
      sm.message[80]=0;
      lseek(f,((long) (i1)) * sizeof(shortmsgrec), SEEK_SET);
      write(f,(void *)&sm,sizeof(shortmsgrec));
      close(f);
      u.sysstatus |= sysstatus_smw;
      write_user(un,&u);
    }
    close_user();
  } else if (syscfg.systemnumber && next_system(sy)) {
    nh.tosys=sy;
    nh.touser=un;
    nh.fromsys=syscfg.systemnumber;
    nh.fromuser=usernum;
    nh.main_type = main_type_ssm;
    nh.minor_type=0;
    nh.list_len=0;
    time((long *)&nh.daten);
    if (strlen(s)>80)
      s[80]=0;
    nh.length=strlen(s);
    nh.method=0;
    sprintf(s1,"%sP0.NET",syscfg.datadir);
    f=open(s1,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
    lseek(f,0L,SEEK_END);
    write(f,(void *)&nh,sizeof(net_header_rec));
    write(f,(void *)s,nh.length);
    close(f);
  }
}

void rsm(int un, userrec *u)
{
  shortmsgrec sm;
  int i,i1,f,any;
  char s1[81];

  any=0;
  if ((u->sysstatus) & sysstatus_smw) {
    sprintf(s1,"%sSMW.DAT",syscfg.datadir);
    f=open(s1,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
    i=(int) (filelength(f) / sizeof(shortmsgrec));
    for (i1=0; i1<i; i1++) {
      lseek(f,((long) (i1)) * sizeof(shortmsgrec),SEEK_SET);
      read(f,(void *)&sm,sizeof(shortmsgrec));
      if ((sm.touser==un) && (sm.tosys==0)) {
        pl(sm.message);
        sm.touser=0;
        sm.tosys=0;
        sm.message[0]=0;
        lseek(f,((long) (i1)) * sizeof(shortmsgrec),SEEK_SET);
        write(f,(void *)&sm,sizeof(shortmsgrec));
	any=1;
      }
    }
    close(f);
    u->sysstatus ^= sysstatus_smw;
    smwcheck=1;
  }
  if (any)
    nl();
}


void setmci(char ch)
{
  char s[81];
  int x;
  strcpy(s,"");

    switch (ch) {
       case '@': strcpy(s,get_string(sysop2()?4:5)); break;
       case 'A': if(umaxsubs>0)
                 sprintf(s,"%s",usub[cursub].keys);
                 else strcpy(s,"");
                 break;
       case 'B': if(umaxsubs>0)
                 sprintf(s,"%s",subboards[usub[cursub].subnum].name);
                 else strcpy(s,"No Subs");
                 break;
       case 'C': if(umaxdirs>0)
                 sprintf(s,"%s",udir[curdir].keys);
                 else strcpy(s,"");
                 break;
       case 'D': if(umaxdirs>0)
                 sprintf(s,"%s",directories[udir[curdir].subnum].name);
                 else strcpy(s,"No Dirs");
                 break;
       case 'E': sprintf(s,"%s",thisuser.laston);
       case 'F': sprintf(s,"%d",thisuser.fpts); break;
       case 'G': sprintf(s,"%s",conf[curconf].name); break;
       case 'H': sprintf(s,"%s",nam(&thisuser,usernum)); break;
       case 'I': strcpy(s,""); break;
       case 'J': sprintf(s,"%d",thisuser.dsl); break;
       case 'K': sprintf(s,"%4ld",thisuser.uk); break;
       case 'M': nl(); break;
       case 'N': strcpy(s,nam(&thisuser,usernum)); break;
       case 'L': sprintf(s,"%d",usernum); break;
       case 'O': sprintf(s,"%4d",thisuser.downloaded); break;
       case 'Q': sprintf(s,"%d",numf); break;
       case 'P': pausescr(); break;
       case 'R': sprintf(s,"%s",thisuser.realname); break;
       case 'S': itoa(thisuser.sl,s,10); break;
       case 'T': strcpy(s,ctim(nsl())); break;
       case 'U': sprintf(s,"%4d",thisuser.uploaded); break;
       case 'V': sprintf(s,"%d",msgr); break;
       case 'W': sprintf(s,"%d",nummsgs); break;
       case 'X': sprintf(s,"%4ld",thisuser.dk); break;
       case 'Y': delay(500); break;
       case 'Z': outstr(get_say(0)); break;
       default: break;
    }
    strcpy(MCISTR,s);
}



void readfilter(char fn[15],char fn2[15])
{
   char s[100];
   int i;
   sprintf(s,"%s%s",syscfg.gfilesdir,fn);
   i=open(s,O_RDONLY|O_BINARY);
   read(i,cfilt,255);
   close(i);
   sprintf(s,"%s%s",syscfg.gfilesdir,fn2);
   i=open(s,O_RDONLY|O_BINARY);
   read(i,scfilt,255);
   close(i);
}

void find_subject(void)
{
    char subject[80], string[80], s[80], s1[80],s2[80];
    char title[80];
    char *result;
    int i,k,yes,count,abort;
    subboardrec sb;
    postrec m;
    FILE *fptr,*fptr2;

    i=k=count=abort=0;
    nl();
    outstr("Search for what? ");
    mpl(30);
    inputl(subject,30);
    if (subject[0]==0)
        return;
    nl();
    strcpy(string,subject);
    strupr(subject);
    strcpy(s1,syscfg.datadir);
    strcat(s1,"\\SUBS.DAT");
    fptr=fopen(s1,"rb");
    prt(0,"Seaching for \"");
    prt(0,string);
    prt(0,"\" ...");
    nl();
    nl();
    while ((fread(&sb, sizeof(sb),1,fptr)==1) && (abort==0)){
        result=NULL;
        if (thisuser.sl>=sb.readsl) {
            k++;
            strcpy(s1,syscfg.datadir);
            strcat(s1,sb.filename);
            strcat(s1,".SUB");
            fptr2=fopen(s1,"rb");
            i=yes=0;
            while (fread(&m, sizeof(m),1,fptr2)==1) {
                strcpy(title,m.title);
                strupr(m.title);
                result=strstr(m.title,subject);
                if ((result!=NULL) && (i!=0)){
                    if (!yes) {
                        ansic(2);
                        itoa(k, s, 10);
                        strcpy(s2, "[");
                        strcat(s2,s);
                        strcat(s2,"] [");
                        strcat(s2,sb.name);
                        strcat(s2,"]");
                        pla(s2,&abort);
                        yes=1;
                    }
                    ansic(0);
                    itoa(i,s,10);
                    strcpy(s2,"\t#");
                    if (strlen(s) < 2)
                        strcat(s2," ");
                    strcat(s2, s);
                    strcat(s2,": ");
                    strcat(s2, title);
                    pla(s2,&abort);
                    count++;
                }
            i++;
            }
        }
    fclose(fptr2);
    }
    fclose(fptr);
    if (abort==0) {
        itoa(count,s,10);
        nl();
        prt(0,s);
        prt(0," match");
        if (count!=1)
            prt(0,"es");
        prt(0," found");
    }
}


void bargraph(int percent)
{
    int x;
    for(x=0;x<50;x++)
        printf("%c",177);
     for(x=50;x>0;x--)
         printf("[D");
     for(x=0;x<percent/2;x++)
         printf("%c",219);
}



void topit(void)
{
    char s[81];
    int i;

    printf("[2;39H");
    for(i=39;i<77;i++) printf(" ");
}


void topit2(void)
{
    char s[81];
    int i;

    printf("[5;39H");
    for(i=39;i<77;i++) printf(" ");
}

#define GODOWN(x,y) printf("[%d;%dH",x,y)

double thing=0.00,reinit=0.00;


void wfct(void)
{
    char s[81];
    double tt;
    tt=timer();
    tt=tt-reinit;
    if(tt>600.0) { imodem(0); reinit=timer(); }
    tt=timer();
    tt-=thing;
    if(tt<60.0) {
    sprintf(s,"[31;1m%s",times());
    GODOWN(17,7);
    outstr(s);
    outstr("[37m");
    }
    else clrscr();
}


void wfcs(void)
{
    char s[81];
    long l;
    int i;
    echo=1;
    clrscr();
    thing=timer();
    reinit=timer();

    _setcursortype(0);
    fastscreen("wfc.dat");

    GODOWN(25,0);
    printf("[0;1;37m%s [33m - [36mDominous Productions",wwiv_version);
    GODOWN(18,14);
    printf("[31m%d",status.callstoday);
    GODOWN(20,11);
    printf("%d%%",(10*status.activetoday/144));
    GODOWN(19,14);
    printf("%d",status.msgposttoday);
    GODOWN(18,46);
    printf("%svailable",sysop2()?"A":"Una");
    GODOWN(19,52);
    printf("%s",status.lastuser);
    GODOWN(21,48);
    printf("%d",status.uptoday);
    GODOWN(20,50);
    printf("%d",status.dltoday);
    GODOWN(17,51);
    l=(long) freek(_getdrive());
    printf("%ldk",l);
    GODOWN(21,11);
    printf("%d",fwaiting);
    printf("[37m");
    movecsr(1,23);
    bargraph(10*status.activetoday/144);
}


void upload_post()
{
  char s[81],s1[21],ch;
  int i,i1,maxli,f;
  long l,l1;

  if(incom) {
     npr("5Upload Prepared File? ");
     if(!yn()) return;
  } else {
      npr("5Load Local File? ");
      if(yn()) {
          nl();
          npr("3Enter File Name\r\n5: ");
          mpl(61);
          input(s,61);
          load_workspace(s,0);
          return;
     }
  } 

  if (actsl<45) maxli=30;
  else if (actsl<60) maxli=50;
  else if (actsl<80) maxli=60;
  else maxli=80;

  sprintf(s,"%sINPUT.MSG",syscfg.tempdir);
  l1=250*(long)maxli;

  nl();
  npr("You may now upload a message, max %ld bytes.",l1);
  nl();
  receive_file(s,&i1,s1,0);
  f=open(s,O_RDWR | O_BINARY);
  if (f>0) {
    l=filelength(f);
    if (l>l1) {
      nl();
      pl("Sorry, your message is too long.  Not saved.");
      nl();
      close(f);
      unlink(s);
    } else {
      close(f);
      use_workspace=1;
      nl();
      dtitle("Message uploaded.  The next post or email will contain that text.");
      nl();
    }
  } else {
    nl();
    pl("Nothing saved.");
    nl();
  }
}


int check_ansi()
{
  long l;
  char ch;

  if (!incom)
    return(1);

  while (comhit())
    get1c();

  pr1("\x1b[6n");

  l=timer1()+36;
  if (modem_flag & flag_ec)
    l += 18;

  while ((timer1()<l) && (!hangup)) {
    checkhangup();
    ch=get1c();
    if (ch=='\x1b') {
      l=timer1()+18;
      while ((timer1()<l) && (!hangup)) {
        if ((timer1()+1820)<l)
          l=timer1()+18;
        checkhangup();
        ch=get1c();
        if (ch) {
          if (((ch<'0') || (ch>'9')) && (ch!=';') && (ch!='['))
            return(1);
        }
      }
      return(1);
    } else if (ch=='N')
      return(-1);
    if ((timer1()+1820)<l)
      l=timer1()+36;
  }
  return(0);
}

char *get_file(char *fn, long *len)
{
  int i;
  char *s;

  i=open(fn,O_RDWR | O_BINARY);
  if (i<0) {
    *len=0L;
    return(NULL);
  }
  if ((s=malloca(filelength(i)+50))==NULL) {
    *len=0L;
    close(i);
    return(NULL);
  }
  *len=(long) read(i,(void *)s, filelength(i));
  close(i);
  return(s);
}





void infoform(char fn[8]) {
char s[161],s1[81];
FILE *fnin,*fno;

sprintf(s1,"%s%s.inf",syscfg.gfilesdir,fn);
if(!exist(s1)) { pl("Infoform Not Found."); return; }
fnin=fopen(s1,"rt");
sprintf(s,"%s%s.ser",syscfg.gfilesdir,fn);
fno=fopen(s,"a");
sprintf(s,"~%s\n",thisuser.name);
fputs(s,fno);

 while(fgets(s,81,fnin)!=NULL&&!hangup) {
    filter(s,'\n');
    if(!strchr(s,'*')) {
       pl(s); strcat(s,"\n"); fputs(s,fno);
       } else {
          filter(s,'*');
          do {
             outstr(s); inputl(s1,51);
             } while(!s1[0]&&!hangup);
          strcat(s,s1); strcat(s,"\n"); fputs(s,fno); }
          }

fclose(fno);
fclose(fnin);
}


void readform(char fn[8],char i[31])
{
    char s[81],s1[81],go=1;
    int i1;
    FILE *fnin;
    userrec u;

    sprintf(s,"%s%s.ser",syscfg.gfilesdir,fn);
    if(!exist(s)) {pl("not found"); return; }
    fnin=fopen(s,"rt");
    i1=finduser(i);
    if(i1>0) read_user(i1,&u); else return;

    while(fgets(s,81,fnin)!=NULL&&go) {
        if(s[0]=='~') {
        filter(s,'\n');
        strcpy(s1,s+1);
        if(!strcmp(u.name,s1)) { go=0;
          while((fgets(s,81,fnin))!=NULL&&s[0]!='~') {
            filter(s,'\n');
            pl(s);
            }
         }
        }
      }
    fclose(fnin);
    pausescr();
}


void packuser(void)
{
    userrec u;
    int i1,i;
    char s[81],s1[81];

    close_user();
    sprintf(s,"%spacked.lst",syscfg.datadir);
    i1=open(s,O_RDWR|O_BINARY|O_CREAT,S_IREAD|S_IWRITE);
    open_user();
    for(i=0;i<=status.users;i++) {
        read_user(i,&u);
        if(!(u.inact & inact_deleted)) write(i1,&u,sizeof(userrec));
    }
    close(i1);
    nl();
    outstr("5Are you sure you want to pack the User List? ");
    if(yn()) {
        sprintf(s,"%suser.lst",syscfg.datadir);
        sprintf(s1,"%suser.bak",syscfg.datadir);
        rename(s,s1);
        sprintf(s1,"%spacked.lst",syscfg.datadir);
        rename(s1,s);
        npr("\r\n0Old User list is saved to %suser.lst",syscfg.datadir);
        pausescr();
    }
}


void glocolor(void)
{
    userrec u;
    int x,uu,i;
    char s[81];

    int sl=-1,dsl=-1,color=-1,prot=-1,edit=-1,format=-1,address=0,pack,resetpc=0;
    int resetptr=-1;

    outstr("Global Sl: "); input(s,3); if(s[0]) sl=atoi(s);
    outstr("Global Dsl: "); input(s,3); if(s[0]) dsl=atoi(s);
    outstr("5Do Colors? "); color=yn();
    outstr("Global Protocol: "); input(s,3); if(s[0]) prot=atoi(s);
    outstr("Global Editor: "); input(s,3); if(s[0]) edit=atoi(s);
    outstr("File Format: "); input(s,3); if(s[0]) format=atoi(s);
    outstr("5Reset Address? "); address=yn();
    outstr("5Reset Computer Types? "); resetpc=yn();
    outstr("5Pack User List? "); pack=yn();
    outstr("5Reset Message Pointers? "); resetptr=yn();
    outstr("5Continue? "); if(!yn()) return;

    dtitle("Setting Users to: ");
    if(sl!=-1)     npr("Sl    : %d\r\n",sl);
    if(dsl!=-1)    npr("Dsl   : %d\r\n",dsl);
    if(prot!=-1)   npr("Prot  : %d\r\n",prot);
    if(format!=-1) npr("Format: %d\r\n",format);
    if(edit!=-1)   npr("Edit  : %d\r\n",edit);
    if(address)    pl("Reseting Addresses");
    if(color)      pl("Reseting Colors");
    if(resetptr)   pl("Reseting Message Ponters");

    for(x=1;x<status.users;x++) {
     read_user(x,&u);
     if(sl!=-1) u.sl=sl;
     if(dsl!=-1) u.dsl=dsl;
     if(prot!=-1) u.defprot=prot;
     if(format!=-1) u.res[3]=format;
     if(edit!=-1) u.defed=edit;
     if(color) setcolors(&u);
     if(resetpc) u.comp_type=99;
     u.res[15]=thisuser.res[15];
     u.res[16]=thisuser.res[16];
     u.res[17]=thisuser.res[17];
     if(address) {
        u.city[0]=0;
        u.street[0]=0;
     }
     for(i=0;i<32;i++)
        u.qscnptr[i]=0;
     for(i=0;i<32;i++)
        u.qscnptr2[i]=0;
     u.res[4]=-1;
     write_user(x,&u);
    }
    if(pack) packuser();
    reset_files();
}

char exempt_str[]="RTP";
extern int rc;

void val_cur_user(int wait)
{
  char sl[4],dsl[4],ar[17],dar[17],restrict[17],ex[17],delff[3];
  char dk[34],uk[34],ndl[33],nul[33],fpts[34],psts[5],lgns[5],timebank[5];
  int cp,i,done;

  if(wait) pr_wait(1);
  thisuser.sl=actsl;
  savescreen(&screensave);
  curatr=11;
  ansic(3);
  makewindow(0,0,79,14);
  itoa((int)thisuser.sl,sl,10);
  itoa((int)thisuser.dsl,dsl,10);
  itoa((int)thisuser.dk,dk,10);
  itoa((int)thisuser.uk,uk,10);
  itoa((int)thisuser.downloaded,ndl,10);
  itoa((int)thisuser.uploaded,nul,10);
  itoa((int)thisuser.fpts,fpts,10);
  itoa((int)thisuser.msgpost,psts,10);
  itoa((int)thisuser.logons,lgns,10);
  itoa((int)thisuser.timebank,timebank,10);
  strcpy(ex,"");

  for (i=0; i<=15; i++) {
    if (thisuser.ar & (1 << i))
      ar[i]='A'+i;
    else
      ar[i]=32;
    if (thisuser.dar & (1 << i))
      dar[i]='A'+i;
    else
      dar[i]=32;
    if (thisuser.exempt & (1 << i))
       ex[i]=exempt_str[i];
    else
       ex[i]=32;
          if (thisuser.restrict & (1 << i))
      restrict[i]=restrict_string[i];
    else
      restrict[i]=32;
  }
  delff[0]=0;
  delff[1]=0;
  delff[2]=0;
  if(thisuser.inact & inact_deleted) delff[0]='D';
  if(thisuser.inact & inact_lockedout) delff[0]='L';
  dar[16]=0;
  ar[16]=0;
  restrict[16]=0;
  ex[4]=0;
  cp=17;
  done=0;


  prdata("Handle",thisuser.name,3,1);
  prdata("RealName",thisuser.realname,40,1);
  prdata("SL",sl,3,2);
  prdata("DSL",dsl,40,2);
  prdata("AR's",ar,3,3);
  prdata("DAR's",dar,40,3);
  prdata("Exempt",ex,3,4);
  prdata("Restrict",restrict,40,4);
  prdata("# of Uls",nul,3,5);
  prdata("# of Dls",ndl,40,5);
  prdata("Up K",uk,3,6);
  prdata("Down K",dk,40,6);
  prdata("Logons",lgns,3,7);
  prdata("Posts",psts,40,7);
  prdata("Fpts",fpts,3,8);
  prdata("TimeBank",timebank,40,8);
  prdata("Deletion",delff,3,9);

  prdata2("Comment",thisuser.comment,3,11);
  prdata2("Note",thisuser.note,3,12);

  while (done==0) {
    switch(cp) {
        case 18: editdata(thisuser.name,25,3,1);
                 strupr(thisuser.name);
                 break;
        case 19: editdata(thisuser.realname,25,40,1);
                 break;
        case 1: thisuser.sl=editdig(sl,3,3,2);  actsl=thisuser.sl; break;
        case 2: thisuser.dsl=editdig(dsl,3,40,2);           break;
        case 3: movecsr(3+11,3);
                editline(ar,16,SET,&rc,"ABCDEFGHIJKLMNOP");
                thisuser.ar=0;
                for (i=0; i<=15; i++)
                    if (ar[i]!=' ') thisuser.ar |= (1 << i);
                break;
        case 4: movecsr(40+11,3);
                editline(dar,16,SET,&rc,"ABCDEFGHIJKLMNOP");
                thisuser.dar=0;
                for (i=0; i<=15; i++)
                    if (dar[i]!=' ') thisuser.dar |= (1 << i);
                break;
        case 5: movecsr(3+11,4);
                editline(ex,3,SET,&rc,exempt_str);
                thisuser.exempt=0;
                for (i=0; i<=3; i++)
                    if (ex[i]!=' ') thisuser.exempt |= (1 << i);
                break;
        case 6: movecsr(40+11,4);
                editline(restrict,16,SET,&rc,restrict_string);
                thisuser.restrict=0;
                for (i=0; i<=15; i++)
                    if (restrict[i]!=' ') thisuser.restrict |= (1 << i);
                break;
        case 17: movecsr(3+11,9);
                editline(delff,2,SET,&rc,"DL");
                thisuser.inact=0;
                if(delff[0]!=' ') thisuser.inact |= inact_deleted;
                if(delff[1]!=' ') thisuser.inact |= inact_lockedout;
                break;
        case 7: thisuser.uploaded=editdig(nul,5,3,5);        break;
        case 8: thisuser.downloaded=editdig(ndl,5,40,5);     break;
        case 9: thisuser.uk=editdig(uk,5,3,6);               break;
        case 10: thisuser.dk=editdig(dk,5,40,6);             break;
        case 11: thisuser.logons=editdig(lgns,5,3,7);        break;
        case 12: thisuser.msgpost=editdig(psts,5,40,7);      break;
        case 13: thisuser.fpts=editdig(fpts,5,3,8);          break;
        case 14: thisuser.timebank=editdig(timebank,3,40,8); break;
        case 15: editdata(thisuser.comment,25,3,11);         break;
        case 16: editdata(thisuser.note,40,3,12);            break;
    }
    switch(rc) {
      case DONE: done=1; break;
      case NEXT: if (cp<20) cp++; else cp=1; break;
      case PREV: if (cp>1) cp--; else cp=19; break;
    }
  }
  restorescreen(&screensave);
  changedsl();
  if(wait) pr_wait(0);
}

void viewfile()
{
    char s[81];
    messagerec m;
    int next;

    m.stored_as=0L;
    m.storage_type=255;
    npr("\r\n2File name to View\r\n5: ");
    mpl(71);
    input(s,71);
    if(exist(s)) read_message1(&m,0,0,&next,s,0,"",1,"");
}

int checkpw()
{
  char s[81];

  if(!incom) return 1;
  nl();
  outstr(get_string(8));
  echo=0;
  input(s,20);
  echo=1;
  if (strcmp(s,(syscfg.systempw))==0)
    return(1);
  else
    return(0);
}


void end_bbs(int lev)
{
  sl1(1,"");
  if (ok_modem_stuff) closeport();
  dtr(0);
  clrscrb();
  printf("\n[0;34;1m� [37m%s is outta here!\n\n",wwiv_version);
  _setcursortype(2);
#ifdef MOUSE
  initpointer(0);
#endif
  exit(lev);
}


int sublist(char type)
{
    int i,abort,i1,r;
    char s[80],s1[80],*ss;

    abort=0;
    r=cursub;
    nl();
    npr("4Message Areas Available on Confernce %s:0",conf[curconf].name);
    nl();
    nl();
    i=0;
    while (i<MAX_SUBS && i<umaxsubs&&type!='+'&&type!='-') {
      strcpy(s,"");
      i1=0;
      if (i>=32) { if (thisuser.qscn2 & (1L << (i-32))) i1=1; }
      else { if (thisuser.qscn & (1L << i)) i1=1; }

      if(i1) sprintf(s,"5<7%-2s5>0 ",usub[i].keys);
      else sprintf(s,"1<1%-2s1>0 ",usub[i].keys);
      strcat(s,noc2(subboards[usub[i].subnum].name));

      i++;

      if (i<umaxsubs&&i<MAX_SUBS) {
        i1=0;
        if (i>=32) { if (thisuser.qscn2 & (1L << (i-32))) i1=1; }
        else { if (thisuser.qscn & (1L << i)) i1=1; }

        if(i1) sprintf(s1,"5<7%-2s5>0 ",usub[i].keys);
        else sprintf(s1,"1<1%-2s1>0 ",usub[i].keys);
        strcat(s1,noc2(subboards[usub[i].subnum].name));
      } else strcpy(s1,"");

      npr("%-46.46s %-46.46s\r\n",s,s1);
      i++;
    }

    if (i==0) pla("None.",&abort);
    if(type=='L') ;
    else if(i&&!type) {
        nl();
        outstr("5Which Message Area? ");
        ss[0]=0;
        input(ss,3);
        if(!ss[0]) return(r);
        for(i1=0; i1<64; i1++) if(!strcmp(usub[i1].keys,ss)) r=i1;
    } 
    if(thisuser.res[1]==2) pausescr();
    return(r);
}


int dirlist(char type)
{
    int i,abort,i1,r;
    char s[80],s1[80],*ss;

    r=curdir;
    abort=0;
    nl();
    npr("4File Areas Available on Confernce %s:0",conf[curconf].name);
    nl();
    nl();
    i=0;
    while (i<MAX_DIRS && i<umaxdirs&&type!='+'&&type!='-') {
      strcpy(s,"");
      i1=0;
      if (i>=32) { if (thisuser.nscn2 & (1L << (i-32))) i1=1; }
      else { if (thisuser.nscn1 & (1L << i)) i1=1; }

      if(i1) sprintf(s,"5<7%-2s5>0 ",udir[i].keys);
      else sprintf(s,"1<1%-2s1>0 ",udir[i].keys);
      strcat(s,noc2(directories[udir[i].subnum].name));

      i++;

      if (i<umaxdirs&&i<MAX_DIRS) {
        i1=0;
        if (i>=32) { if (thisuser.nscn2 & (1L << (i-32))) i1=1; }
        else { if (thisuser.nscn1 & (1L << i)) i1=1; }

        if(i1) sprintf(s1,"5<7%-2s5>0 ",udir[i].keys);
        else sprintf(s1,"1<1%-2s1>0 ",udir[i].keys);
        strcat(s1,noc2(directories[udir[i].subnum].name));
      } else strcpy(s1,"");

      npr("%-46.46s %-46.46s\r\n",s,s1);
      i++;
    }

    if (i==0) pla("None.",&abort);
    if(type=='L') ;
    else if(i&&!type) {
        nl();
        outstr("5Which Directory? 0");
        input(ss,3);
        if(!ss[0]) return(r);
        for(i1=0; i1<64 && udir[i1].subnum>=0; i1++)
            if(strcmp(udir[i1].keys,ss)==0)
                r=i1;
    }
    if(thisuser.res[1]==2)
        pausescr();

    return(r);
}
