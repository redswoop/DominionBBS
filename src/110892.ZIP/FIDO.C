#include "vars.h"
#pragma hdrstop

void tossmsg(int bn,char title[72],char to[36],char from[36],char *b,long len)
{
    messagerec m;
    postrec p;
    char s[121];
    int i,dm,a,f;
    long len1,len2;
    unsigned int *list;

    iscan(bn);

    if (freek1(syscfg.msgsdir)<10.0) {
        nl();
        pl("Sorry, not enough disk space left.");
        nl();
        return;
    }

    i=0;
    while(b[i]) {
       if(b[i]=='\r') b[i]='\n';
       i++;
    }
 
    sprintf(s,"%sinput.msg",syscfg.tempdir);
    i=open(s,O_BINARY|O_RDWR|O_CREAT|O_TRUNC,S_IREAD|S_IWRITE);
    write(i,b,len);
    close(i);
    use_workspace=1;
    strcpy(irt,title);
    strcpy(irt_name,to);
    strcpy(irt_from,from);
    m.storage_type=subboards[bn].storage_type;
    a=0;
    fidotoss=1;
    inmsg(&m,p.title,&a,1,(subboards[bn].filename),0);
    if (m.stored_as!=0xffffffff) {
        p.anony=a;
        p.msg=m;
        p.ownersys=0;
        p.owneruser=0;
        p.qscan=status.qscanptr++;
        time((long *)(&p.daten));
        p.status=0;
        if (nummsgs>=subboards[bn].maxmsgs) {
            i=1;
            dm=0;
            while ((dm==0) && (i<=nummsgs)) {
                if ((msgs[i].status & status_no_delete)==0)
                    dm=i;
                ++i;
            }
            if (dm==0)
                dm=1;
            delete(dm);
        }
        msgs[++nummsgs]=p;
        sub_dates[bn]=p.qscan;
        fnet.qp[bn]=p.qscan;
        bchanged=1;
        savebase();
        ++status.msgposttoday;
        save_status();
        topscreen();
        save_status();
    }
}

void fidotosser(int bn)
{
  int i,os,i2=1,i1;
  char s[81],s1[81],c;
  long len;
  char *b;
  fmsgrec f;

  sprintf(s,"%s%s\\HI-WATER.MRK",syscfg.msgsdir,subboards[bn].filename);
  i=open(s,O_BINARY|O_RDWR);
  if(i<0) {
    i=open(s,O_BINARY|O_RDWR|O_CREAT|O_TRUNC,S_IREAD|S_IWRITE);
    c=1;
    write(i,&c,sizeof(c));
    i2=2;
  } else {
    read(i,&i2,1);
  }
  close(i);
  i=1;

  while(i) {
    sprintf(s,"%s%s\\%d.msg",syscfg.msgsdir,subboards[bn].filename,i2+1);
    if(exist(s)) {
        i1=open(s,O_BINARY|O_RDWR);
        read(i,&f,sizeof(fmsgrec));
        len=filelength(i1)-sizeof(fmsgrec);
        read(i,b,len);
        close(i);
        tossmsg(bn,f.title,f.to,f.from,b,len);
        i2++;
    } else i=0;
  }
  sprintf(s,"%s%s\\HI-WATER.MRK",syscfg.msgsdir,subboards[bn].filename);
  i=open(s,O_BINARY|O_RDWR|O_CREAT|O_TRUNC,S_IREAD|S_IWRITE);
  write(i,&i2,1);
  close(i);
}


void writeto2(char *b, long len, char *title,char *fn)
{
    char s1[81],s2[128],ch1,n[41],to[41],d[41];
    int i,p,p1,p2,cur;
    fmsgrec f;
    FILE *c;
    struct date dd;
    struct time tt;
    char *dats[]={"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec",""};


    strcpy(s2,fn);
    p=0;
    while ((b[p]!=13) && ((long)p<len) && (p<60))
        n[p]=b[p++];
    n[p]=0;
    ++p;

    p1=0;

    if (b[p]==10) ++p;
    while ((b[p+p1]!=13) && ((long)p+p1<len) && (p1<60))
     d[p1]=b[(p1++)+p];
    d[p1]=0;

    p1+=2;
    p2=0;

    while ((b[p+p1+p2]!=13) && ((long)p+p1+p2<len) && (p2<60))
      to[p2]=b[(p2++)+p1+p];
    to[p2]=0;
    if(!strchr(to,'�')) {
      strcpy(to,"All");
      cur=p+p1;
    } else {
      strcpy(to,to+1); cur=p+p1+p2;
    }

    strncpy(f.to,to,36);
    strncpy(f.from,n,36);
    strncpy(f.title,title,72);
    getdate(&dd);
    gettime(&tt);
    dd.da_year-=1900;
    sprintf(s1,"%02d %s %d  %02d:%02d:%02d",dd.da_day,dats[dd.da_mon],dd.da_year,
            tt.ti_hour,tt.ti_min,tt.ti_sec);
    strncpy(f.date,s1,20);
    f.timesread=0; f.timesread1=0;
    f.destnode=0;  f.destnode1=0;
    f.orignode=0;  f.orignode1=0;
    f.cost=0;      f.cost1=0;
    f.orignet=0;   f.orignet1=0;
    f.destnet=0;   f.destnet1=0;
    strcpy(f.res,"        ");
    f.replyto=0;   f.replyto1=0;
    f.attrib=1;    f.attrib1=1;
    f.nextreply=0; f.nextreply1=0;

    i=0;
    while(b[i]) {
        if(b[i]=='\n') b[i]='\r';
        i++;
    }

    c=fopen(s2,"wb");
    fwrite(&f,sizeof(fmsgrec),1,c);
    fwrite(&b[cur],len-cur,1,c);

    sprintf(s1,"\r\r--- %s",wwiv_version);
    fputs(s1,c);

    fputs("\r * Origin: ",c);
    fputs(fnet.origin1,c);
    sprintf(s1," (%d:%d/%d)",fnet.ad.zone,fnet.ad.net,fnet.ad.node);
    fputs(s1,c);
    fputc('\r',c);

    fclose(c);

    farfree(b);
}



void fidoscan(int bn)
{
  int i,os,i2=1,i1,f;
  char s[81],s1[81],c;
  long len;
  char *b;

  sprintf(s,"%s%s\\HI-WATER.MRK",syscfg.msgsdir,subboards[bn].filename);
  f=open(s,O_BINARY|O_RDWR);
  if(f<0) {
    f=open(s,O_BINARY|O_RDWR|O_CREAT|O_TRUNC,S_IREAD|S_IWRITE);
    c=1;
    write(f,&c,sizeof(c));
    i2=2;
  } else {
    read(f,&i2,1);
  }
  close(f);
  i=1;

  while ((i<=nummsgs) && (msgs[i].qscan<=fnet.qp[bn]))
    ++i;
  if ((nummsgs>0) && (msgs[nummsgs].qscan<=fnet.qp[bn]))
    fnet.qp[bn]=status.qscanptr-1;
  if ((nummsgs>0) && (i<=nummsgs))
    if (msgs[i].qscan>fnet.qp[bn]) {
          for(i1=i;i1<=nummsgs;i1++) {
            if(msgs[i1].status & status_pending_fido) {
                i2++;
                b=readfile(&msgs[i1].msg,subboards[bn].filename,&len);
                sprintf(s,"%s%s\\%d.msg",syscfg.msgsdir,subboards[bn].filename,i2);
                writeto2(b,len,msgs[i1].title,s);
                msgs[i1].status ^= status_pending_fido;
            }
          }
          fnet.qp[bn]=msgs[i].qscan;
    }
    sprintf(s,"%s%s\\HI-WATER.MRK",syscfg.msgsdir,subboards[bn].filename);
    f=open(s,O_BINARY|O_RDWR|O_CREAT|O_TRUNC,S_IREAD|S_IWRITE);
    write(f,&i2,1);
    close(f);
    savebase();
}

void mailsys(int m)
{
    int i=0,i1;
    char s[81];
    FILE *f;

    i1=open("fnet.dat",O_BINARY|O_RDWR|O_CREAT,S_IREAD|S_IWRITE);
    read(i1,&fnet,sizeof(fnet));
    close(i1);
    for(i=0;i<num_subs;i++) {
        switch(m) {
            case 'S':
                npr("Scanning Sub %s [%d]\r\n",subboards[i].name,i);
                iscan(i);
                fidoscan(i);
                break;
            case 'T':
                npr("Tossing Sub %s [%d]\r\n",subboards[i].name,i);
                iscan(i);
                fidotosser(i);
                break;
            case 'P':
                sprintf(s,"%s%s\\*.*",syscfg.msgsdir,subboards[i].filename);
                unlink(s);
                sprintf(s,"%s%s\\HI-WATER.MRK",syscfg.msgsdir,subboards[i].filename);
                f=fopen(s,"wb");
                fputc(1,f);
                break;
          }
    }
    i1=open("fnet.dat",O_BINARY|O_RDWR|O_CREAT,S_IREAD|S_IWRITE);
    write(i1,&fnet,sizeof(fnet));
    close(i1);
}

