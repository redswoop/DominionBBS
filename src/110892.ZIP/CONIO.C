#include "vars.h"

#pragma hdrstop

#include <mem.h>
#include <conio.h>
#include "swap.h"


void SCROLL_UP(int t, int b, int l) {
  union REGS r;
  r.h.ch=t;
  r.h.dh=b;
  r.h.bh=curatr;
  r.h.al=l;
  r.h.cl=0;
   r.h.dl=79;
  r.h.ah=6;
  int86(0x10,&r,&r);
}


#define GLOBAL_SIZE 4096

static char *global_buf;
static int global_ptr;
static int wx=0;
int begxx,begyy;

void set_global_handle(int i)
{
  char s[81];

  if (x_only)
    return;

  if (i) {
    if (!global_handle) {
      sprintf(s,"%sGLOBAL.TXT",syscfg.gfilesdir);
      global_handle=open(s,O_RDWR | O_APPEND | O_BINARY | O_CREAT,
                           S_IREAD | S_IWRITE);
      global_ptr=0;
      global_buf=malloca(GLOBAL_SIZE);
      if ((global_handle<0) || (!global_buf)) {
        global_handle=0;
        if (global_buf) {
          farfree(global_buf);
          global_buf=NULL;
        }
      }

    }
  } else {
    if (global_handle) {
      write(global_handle,global_buf,global_ptr);
      close(global_handle);
      global_handle=0;
      if (global_buf) {
        farfree(global_buf);
        global_buf=NULL;
      }
    }
  }
}

void runconfig()
{
    temp_cmd("Config.exe",0);
    configfile=open("CONFIG.DAT",O_RDWR | O_BINARY);
    read(configfile,(void *) (&syscfg), sizeof(configrec));
    read(configfile,&nifty,sizeof(niftyrec));
    close(configfile);
}

void global_char(char ch)
{

  if (global_buf && global_handle) {
    global_buf[global_ptr++]=ch;
    if (global_ptr==GLOBAL_SIZE) {
      write(global_handle,global_buf,global_ptr);
      global_ptr=0;
    }
  }
}

void movecsr(int x,int y)
{
  union REGS r;
  if (x<0)
    x=0;
  if (x>79)
    x=79;
  if (y<0)
    y=0;
  y+=topline;
  if (y>screenbottom)
    y=screenbottom;
   r.h.bh=0x00;
   r.h.dh=y;
   r.h.dl=x;
   r.h.ah=0x02;
   int86(0x10,&r,&r);

}



int wherex()
{
  union REGS r;

  r.h.bh=0x00;
  r.h.ah=0x03;
  int86(0x10,&r,&r);
  tempio=r.h.dl;
  return(tempio);
}


int wherey()
{
  union REGS r;

  r.h.bh=0x00;
  r.h.ah=0x03;
  int86(0x10,&r,&r);
  tempio=r.h.dh;
  return(tempio-topline);

}



void lf()
{
  union REGS r;

  r.h.bh=0x00;
  r.h.ah=0x03;
  int86(0x10,&r,&r);
  tempio=r.h.dl;
  if (r.h.dh==screenbottom) {
	SCROLL_UP(topline,screenbottom,1);
	r.h.dl=tempio;
	r.h.dh=screenbottom;
	r.h.bh=0;
	r.h.ah=0x02;
	int86(0x10,&r,&r);
  } else {
	tempio=r.h.dh+1;
	r.h.dh=tempio;
	r.h.ah=0x02;
	int86(0x10,&r,&r);
  }
}

void cr()
{
  union REGS r;

  r.h.bh=0x00;
  r.h.ah=0x03;
  int86(0x10,&r,&r);
  r.h.dl=0x00;
  r.h.ah=2;
  int86(0x10,&r,&r);
}

void clrscrb()
{
  SCROLL_UP(topline,screenbottom,0);
  movecsr(0,0);
  lines_listed=0;
}



void bs()
 {
  union REGS r;

  r.h.bh=0;
  r.h.ah=3;
  int86(0x10,&r,&r);
  if (r.h.dl==0) {
	if (r.h.dh != topline) {
	  r.h.dl=79;
	  tempio=r.h.dh-1;
	  r.h.dh=tempio;
	  r.h.ah=2;
	  int86(0x10,&r,&r);
	}
  } else {
	r.h.dl--;
	r.h.ah=2;
	int86(0x10,&r,&r);
  }
}



void out1chx(unsigned char ch)
{
  union REGS r;

  r.h.bl=curatr;
  r.h.bh=0x00;
  r.x.cx=0x01;
  r.h.al=ch;
  r.h.ah=0x09;
  int86(0x10,&r,&r);
  r.h.bh=0x00;
  r.h.ah=0x03;
  int86(0x10,&r,&r);
  ++(r.h.dl);
  if (r.h.dl==80) {
    r.h.dl=0;
    if (r.h.dh==screenbottom) {
      SCROLL_UP(topline,screenbottom,1);
      r.h.dh=screenbottom;
      r.h.dl=0;
	  r.h.bh=0;
	  r.h.ah=0x02;
	  int86(0x10,&r,&r);
	} else {
	  tempio=r.h.dh+1;
	  r.h.dh=tempio;
	  r.h.ah=0x02;
	  int86(0x10,&r,&r);
    }
  } else {
	r.h.ah=0x02;
	int86(0x10,&r,&r);
  }
}



void out1ch(unsigned char ch)
{
  if (x_only) {
    if (ch>31) {
      wx=(wx+1)%80;
    } else if ((ch==13) || (ch==12)) {
      wx=0;
    } else if (ch==8) {
      if (wx)
        wx--;
    }
    return;
  }

  if (ch>31)
    out1chx(ch);
  else
    if (ch==13)
      cr();
    else
      if (ch==10)
        lf();
      else
        if (ch==12)
          clrscrb();
        else
          if (ch==8)
            bs();
          else
            if (ch==7)
              if (outcom==0) {
                setbeep(1);
                wait1(4);
                setbeep(0);
              }
}


void outs(char *s)
/* This (obviously) outputs a string TO THE SCREEN ONLY */
{
  int i;
  char ch;

  for (i=0; s[i]!=0; i++) {
    ch=s[i];

  if (change_color) {
    change_color = 0;
    if ((ch >= '0') && (ch <= '9'))
      ansic(ch - '0');
    break;
  }

  if (ch == 3) {
    change_color = 1;
    break;
  }

  if (change_ecolor) {
    change_ecolor = 0;
    if ((ch >= '0') && (ch <= '9'))
      ansic(ch - '0'+10);
    break;
  }

  if (ch == 14) {
    change_ecolor = 1;
    break;
  }
    out1ch(ch);
  }
}

void pr_wait(int i1)
{
  int i;

  if(i1) {
    outstr(get_string(24)); begxx=wherex(); begyy=wherey();
    }
   else {
    for(i=0;i<strlenc(get_string(24));i++) backspace();
    }
}

void set_protect(int l)
/* set_protect sets the number of lines protected at the top of the screen. */
{
  union REGS r;   /** Add   */

  if (l!=topline) {
	if (l>topline) {
	  if ((wherey()+topline-l) < 0) {
		r.h.ch=topline;   /** Add       */
		r.h.dh=screenbottom+1;
		r.h.al=l-topline;
		r.h.cl=0;
		r.h.dl=79;
		r.h.bh=0x07;
		r.h.ah=7;
		int86(0x10,&r,&r);  /* To here */
		movecsr(wherex(),wherey()+l-topline);
	  } else {
		oldy += (topline-l);
	  }
	} else {
	  SCROLL_UP(l,topline-1,0);
	  oldy += (topline-l);
	}
  }
  topline=l;
  if (using_modem)
	screenlinest=thisuser.screenlines;
  else
	screenlinest=defscreenbottom+1-topline;
}




void savescreen(screentype *s)
{
  memmove(s->scrn1,scrn,screenlen);
  s->x1=wherex();
  s->y1=wherey();
  s->topline1=topline;
  s->curatr1=curatr;
}


void restorescreen(screentype far *s)
{
  memmove(scrn,s->scrn1,screenlen);
  topline=s->topline1;
  curatr=s->curatr1;
  movecsr(s->x1,s->y1);
}



    
void temp_cmd(char *s, int ccc)
{
  int i;

  pr_wait(1);
  savescreen(&screensave);
  i=topline;
  topline=0;
  curatr=0x07;
  clrscrb();
  runprog(s,ccc);
  restorescreen(&screensave);
  topline=i;
  pr_wait(0);
}


char xlate[] = {
  'Q','W','E','R','T','Y','U','I','O','P',0,0,0,0,
  'A','S','D','F','G','H','J','K','L',0,0,0,0,0,
  'Z','X','C','V','B','N','M',
};

void skey(unsigned char ch)
{
  int i,i1;
  char s[81];

  if (((syscfg.sysconfig & sysconfig_no_local) ==0) && (okskey)) {
    if ((ch>=104) && (ch<=113)) {
      set_autoval(ch-104);
    } else
      switch ((unsigned char) ch) {
        case 94:
        case 59: /* F1 */
          val_cur_user(ch==94?0:1);
          break;
        case 60: /* F2 */
          topdata+=1;
          if (topdata==3)
            topdata=0;
          topscreen();
          break;
	case 61: /* F3 */
	  if (using_modem) {
        incom=opp(incom);
	    dump();
        tleft(0);
	  }
	  break;
        case 62: /* F4 */
          chatcall=0;
          chatreason[0]=0;
          topscreen();
          break;
        case 63: /* F5 */
          hangup=1;
	  dtr(0);
	  break;
	case 64: /* F6 */
	  sysop_alert=!sysop_alert;
          tleft(0);
	  break;
        case 65: /* F7 */
          thisuser.extratime-=5.0*60.0;
          tleft(0);
          break;
        case 66: /* F8 */
          thisuser.extratime+=5.0*60.0;
          tleft(0);
          break;
        case 67: /* F9 */
          if (thisuser.sl!=255) {
            if (actsl!=255)
              actsl=255;
            else
              reset_act_sl();
            changedsl();
            tleft(0);
          }
          break;
        case 68: /* lF10 */
          if (chatting==0)
              chat1("",syscfg.sysconfig & sysconfig_2_way);
          else
            chatting=0;
          break;
	case 71: /* HOME */
	  if (chatting) {
	    if (chat_file)
	      chat_file=0;
	    else
	      chat_file=1;
	  }
	  break;
    case 86: if(using_modem) outcom=opp(outcom); break;
	case 88: /* Shift-F5 */
	  i1=(rand() % 20) + 10;
	  for (i=0; i<i1; i++)
	    outchr(rand() % 256);
      if(ch==88) {
          hangup=1;
          dtr(0);
      }
	  break;

	case 98: /* Ctrl-F5 */
	  nl();
	  pl("Call back later when you are there.");
	  nl();
	  hangup=1;
	  dtr(0);
	  break;
        case 103: /* Ctrl-F10 */
          if (chatting==0)
            chat1("",0);
          else
            chatting=0;
          break;
        case 84: /* Shift-F1 */
          set_global_handle(!global_handle);
          topscreen();
          break;
        case 93: /* Shift-F10 */
          temp_cmd(getenv("COMSPEC"),1);
          break;
        case 45: savescreen(&screensave);
      printf("[0;1m[2JExit BBS?!?! ");
       if(toupper(getche()) == 'Y') {
        printf("[2JSave Online data? ");
        if(toupper(getche())=='Y')
        save_state("restore.dom",1,0);
        sl1(1,"");
        write_user(usernum,&thisuser);
        sysoplog("7SysOp BBS Exit");
        pr_wait(1);
        if (ok_modem_stuff)
          closeport();
          exit(oklevel);
       }
       restorescreen(&screensave);
       break;
       case 72: strcpy(charbuffer,";[A");
                charbufferpointer=1;
                break;
       case 80: strcpy(charbuffer,";[B");
                charbufferpointer=1;
                break;
       case 75: strcpy(charbuffer,";[D");
                charbufferpointer=1;
                break;
       case 77: strcpy(charbuffer,";[C");
                charbufferpointer=1;
                break;
       case 35: savescreen(&screensave);
                fastscreen("syshelp.dat");
                getch();
                restorescreen(&screensave);
                break;
       case 24: runconfig(); break;
       case 44:
        save_state("restore.dom",1,0);
        sl1(1,"");
        write_user(usernum,&thisuser);
        sysoplog("SysOp Quick BBS Exit");
        pr_wait(1);
        if (ok_modem_stuff)
          closeport();
          exit(oklevel);
       break;
      }
  }
}

void prit(char s[41])
{
      printf("[5;40;30m�[40;37;1m%s[0;1;30m�",s);
}

void puttop(char *s)
{
    int ln;

    topscreen();

  if (chatreason[0] && (topdata==2))
    ln=6;
  else if(topdata==1)
    ln=10;
  else if(topdata==3)
    ln=11;
  else if(topdata==2) ln=5;


   printf("[s[%d;%dH[0;1;40;36;5m",ln,1);

   for(ln=0;ln<79;ln++) printf(" ");

   printf("[%d;%dH%s[u",ln,1,s);

}

void tleft(int x)
{
  int cx,cy,ctl,cc,ln,i;
  double nsln;
  char tl[80],s[81];

  cx=wherex();
  cy=wherey();
  ctl=topline;
  cc=curatr;
  if (crttype==7)
    curatr=0x30;
  else
    curatr=0x0e;
  topline=0;
  nsln=nsl();
  if (chatreason[0] && (topdata==2))
    ln=5;
  else if(topdata==1)
    ln=9;
  else if(topdata==3)
    ln=10;
  else if(topdata==2) ln=4;

  if (topdata) {
    movecsr(0,ln);
    printf("[0;40;37;5m");
    for(i=0;i<80;i++) tl[i]=32;
    tl[80]=0;
    printf(tl);
    movecsr(10,ln);
    if ((using_modem) && (!incom))
      prit("Remote Lock");

    movecsr(24,ln);
    if ((actsl==255) && (thisuser.sl!=255))
      prit("Temp SysOp");

    movecsr(40,ln);
    if (global_handle)
      prit("Capture");

    movecsr(55,ln);
    if (sysop_alert)
      prit("Alert!");

    movecsr(65,ln);
    if (sysop1())
      prit("Available");
  }
  switch (topdata) {
    case 1:
    case 2:
    case 3:
      if(useron) sprintf(s,"Time Left %6.2f",nsln/60.0);
      else sprintf(s,"%s, %s",thisuser.pw,thisuser.phone);
      movecsr(0,ln);
      printf("[0;1;30m�[5;37m%s[0;1;30m�",s);
  }
  printf("[0;1m");
  topline=ctl;
  curatr=cc;
  movecsr(cx,cy);
  if ((x) && (useron))
    if ((nsln==0.0) && (thisuser.sl!=255)){
        printfile("outtime");
        hangup=1;
    }
}

void topscreen()
{
  int cc,cx,cy,ctl,i,x,ff;
  char sl[81],s2[100],ar[17],dar[17],restrict[17],rst[17],lo[90],ol[255],
  fpts[10];
  zlogrec z;


  switch(topdata) {
    case 0:
      set_protect(0);
      break;
    case 1:
      set_protect(10);
      break;
    case 3:
      set_protect(11);
      break;
    case 2:
      if (chatreason[0])
        set_protect(6);
      else {
        if (topline==6)
          set_protect(0);
        set_protect(5);
      }
      break;
  }
  cx=wherex();
  cy=wherey();
  ctl=topline;
  cc=curatr;
  if (crttype==7)
    curatr=0x07;
  else
    curatr=0x0e;
  topline=0;
  movecsr(0,3);

  asm mov ax,0x1003;
  asm mov bl,0x0;
  asm int 0x10;

  switch (topdata) {
        case 0:
          asm mov ax,0x1003;
          asm mov bl,0x1;
          asm int 0x10;
          break;
        case 1:
      movecsr(0,0);
      printf("[0;33;1m[K%-30s",nam(&thisuser,usernum));
      movecsr(53,0);
      printf("[32m[>%d<]",modem_speed);
      movecsr(0,1);
      printf("[K[33m%s",thisuser.street);
      movecsr(45,1);
      printf("[35mLast On: [36m%s",thisuser.laston);
      movecsr(0,2);
      printf("[33m%s",thisuser.city);
      movecsr(45,2);
      printf("[K[35mAvatar :[36m %s",thisuser.res[10] ? "On":"Off");
      movecsr(0,3);
      printf("[K%s",thisuser.note);
      movecsr(45,3);
      printf("[35mSL/DSL : [36m%-2d/%-2d",thisuser.sl,thisuser.dsl);
      movecsr(62,0);
      printf("[0;1;30m�[33mToday's Info");
      movecsr(62,1);
      printf("[30m�[0;1;35mPosted      :[36m%3d",status.msgposttoday);
      movecsr(62,2);
      printf("[30m�[35mE-mail sent :[36m%3d ",status.emailtoday);
      movecsr(62,3);
      printf("[30m�[35mFeedback    :[36m%3d",fwaiting);
      movecsr(0,4);
      printf("[K[30;1m��������������������������������������������������������������[30m�[35mWaiting     :[36m%3d",fwaiting);
      movecsr(0,5);
      printf("[K  Date     Calls  Active   Posts   Email   Fback    U/L   Act [30m�[35mUploads     :[36m%3d",status.uptoday);
      sprintf(ol,"%shistory.dat",syscfg.datadir);
      ff=open(ol,O_RDWR|O_BINARY);
      lseek(ff,0L,SEEK_SET);
      for(x=6;x<9;x++) {
      movecsr(0,x);
      read(ff,(void *)&z,sizeof(zlogrec));
      printf("[K[0;35m%s    %4d    %4d     %3d     %3d     %3d    %3d   %3d     ",
         z.date,z.calls,z.active,z.posts,z.email,z.fback,z.up,10*z.active/144);
    } close(ff);
      movecsr(62,6);
      printf("[30;1m�[35mActivity    : [36m%2d%%",10*status.activetoday/144);
      movecsr(62,7);
      printf("[30m�[35mTime On     :[36m%4d",status.activetoday);
      movecsr(62,8);
      printf("[30m�[35mCalls Today :[36m%3d",status.callstoday);
      break;

    case 2:
         itoa((int)thisuser.fpts,fpts,10);
      strcpy(rst,restrict_string);
      for (i=0; i<=15; i++) {
        if (thisuser.ar & (1 << i))
          ar[i]='A'+i;
        else
          ar[i]='a'+i;
        if (thisuser.dar & (1 << i))
          dar[i]='A'+i;
        else
          dar[i]='a'+i;
        if (thisuser.restrict & (1 << i))
          restrict[i]=rst[i];
        else
          restrict[i]=32;
      }
      dar[16]=0;
      ar[16]=0;
      restrict[16]=0;

      movecsr(0,0);
      strcpy(lo,"");
      if(thisuser.exempt & exempt_ratio) lo[0]='R'; else lo[0]=32;
      if(thisuser.exempt & exempt_time)  lo[1]='T'; else lo[1]=32;
      if(thisuser.exempt & exempt_post)  lo[2]='P'; else lo[2]=32;

      printf("[K[0;33;1m%-36s[30;1m  �[35;1mSL/DL=%-4d/%-4d[30;1m�[32;1mExemptions = %c%c%c ",nam(&thisuser,usernum),thisuser.sl
      ,thisuser.dsl,lo[0],lo[1],lo[2]);

      movecsr(0,1);
      printf("[K[33;1m%-36s[30;1m  �[35;1mPS/TC=%-4d/%-4d[30;1m�[32;1mRestrict = %s",thisuser.realname,thisuser.msgpost,thisuser.logons,restrict);
      
      movecsr(0,2);
      printf("[K[33;1m%-36.36s[30;1m  �[35;1mUL/DL=%-4d/%-4d[30;1m�[32;1mAR =%s",thisuser.comment,thisuser.uploaded,thisuser.downloaded,ar);

      movecsr(0,3);
      sprintf(s2,"[K[33;1m%-12s, %-2d, %c, %-17s",thisuser.phone,thisuser.age,thisuser.sex,ctypes[thisuser.comp_type]);
      printf("%-36s[30;1m�[35;1mFP/TB=%-4d/%-4d[30;1m�[32;1m[32;1mDAR=%s",s2,thisuser.fpts,(int)thisuser.timebank,dar);

      if (chatreason[0]) {
        movecsr(0,4);
        printf("[K[34;1m��>[36m%-73s[34m<��",chatreason);
      }
      break;
  }
  topline=ctl;
  movecsr(cx,cy);
  curatr=cc;
  tleft(0);
}




void set_autoval(int n)
{
  valrec v;

  v=syscfg.autoval[n];

  thisuser.sl=v.sl;
  thisuser.dsl=v.dsl;
  thisuser.ar=v.ar;
  thisuser.dar=v.dar;
  thisuser.restrict=v.restrict;
  reset_act_sl();
  changedsl();
}
