#include "vars.h"
#pragma hdrstop

char *stripfn(char *fn)
{
  static char ofn[15];
  int i,i1;
  char s[81];

  i1=-1;
  for (i=0; i<strlen(fn); i++)
    if ((fn[i]=='\\') || (fn[i]==':') || (fn[i]=='/'))
      i1=i;
  if (i1!=-1)
    strcpy(s,&(fn[i1+1]));
  else
    strcpy(s,fn);
  for (i=0; i<strlen(s); i++)
    if ((s[i]>='A') && (s[i]<='Z'))
      s[i]=s[i]-'A'+'a';
  i=0;
  while (s[i]!=0) {
    if (s[i]==32)
      strcpy(&s[i],&s[i+1]);
    else
      ++i;
  }
  strcpy(ofn,s);
  return(ofn);
}


void stripfn1(char *fn)
{
  int i,i1;
  char s[81],s1[81];

  i1=0;
  for (i=0; i<strlen(fn); i++)
    if ((fn[i]=='\\') || (fn[i]==':') || (fn[i]=='/'))
      i1=i;
  strcpy(s1,fn);
  if (i1) {
    strcpy(s,&(fn[i1+1]));
    s1[i1+1]=0;
  } else {
    strcpy(s,fn);
    s1[0]=0;
  }

  for (i=0; i<strlen(s); i++)
    if ((s[i]>='A') && (s[i]<='Z'))
      s[i]=s[i]-'A'+'a';
  i=0;
  while (s[i]!=0) {
    if (s[i]==32)
      strcpy(&s[i],&s[i+1]);
    else
      ++i;
  }
  strcat(s1,s);
  strcpy(fn,s1);
}


int extern_prot(int pn, char *fn1, int sending)
{
  char s[255],s1[81],s2[81],fn[81],sx1[21],sx2[21],sx3[21];
  int i,i1;

  i=0;
  for (i1=0; i1<81; i1++) {
    i+=proto[pn].description[i1];
    i+=proto[pn].sendfn[i1];
    i+=proto[pn].receivefn[i1];
  }
  if (sending) {
    nl();
    pl("\x03""2> Beginning file transmission, ^X to abort");
    if(pn>-1) strcpy(s1,(proto[pn].sendfn));
    else strcpy(s1,"dsz port %2 ha slow sb -s %3");
    strcpy(s1,(proto[pn].sendfn));
  } else {
    nl();
    pl("\x03""2> Ready to receive, ^X to abort.");
    if (pn>-1) strcpy(s1,(proto[pn].receivefn));
    else strcpy(s1,"dsz port %2 ha slow rb %3");
    strcpy(s1,(proto[pn].receivefn));
  }
  strcpy(fn,fn1);
  stripfn1(fn);
  ultoa(com_speed,sx1,10);
  ultoa(modem_speed,sx3,10);
  sx2[0]='0'+syscfg.primaryport;
  sx2[1]=0;
  stuff_in(s,s1,sx1,sx2,fn,sx3,"");
  if (s[0]) {
    set_protect(0);
    clrscr();
    printf("[0;37;1;44m[KCurrent user: %s\n\n[0;1m",nam(&thisuser,usernum));
    outs(s);
    outs("\r\n");
 //   if (incom) {
      i=runprog(s,0);
      topscreen();
      return(i);
/*     } else {
      topscreen();
      return(-5);
    }*/
  }
  return(-5);
}

int get_batchprotocol(int dl,int *hang)
{
  char ch;
  int i1,prot;


  prot=thisuser.defprot;
  if(prot<0) prot=get_protocol(0,1);
  if(dl);
  *hang=0;

    top:
    npr(get_string2(12),proto[prot].description);
    nl();
    npr(get_string2(13),proto[prot].description);
    nl();
    npr(get_string2(14),proto[prot].description);
    ch=onek("\rHXASB");
    switch(ch) {
        case 13: return(prot);
        case 'X': return(get_protocol(0,1));
        case 'A': return(-1);
        case 'S': return(0);
        case 'B': batchdled(); goto top;
        case 'H': *hang=1; return(prot);
    }
  return(0);
}


int get_protocol(int dl,int batch)
{
  char s[81],s1[81],oks[81],s2[81],ch;
  int i,i1,i2,maxprot,done;

  strcpy(oks,"Q?N");
  if(batch) strcat(oks,"B");

  maxprot=0;
  done=0;

  for (i1=0; i1<numextrn; i1++) {
    if(batch||(!batch&&proto[i1].singleok)) {
      ++maxprot;
      sprintf(s1,"%c",proto[i1].key);
      strcat(oks,s1);
    }
  }

  strcpy(s,"7Protocol 5<3?5>0list2>0 ");
  strcpy(s1,oks);

  do {
    nl();
    prt(2,s);
    ch=onek(s1);
    if (ch=='?') {
      nl();
      dtitle("Dominion Transfer Protocols");
      pl("5<7Q5>0 Abort Transfer(s)");
      pl("5<7N5>0 Next File");
      pl("5<7B5>0 BiModem");
      if (dl==1)
        pl("5<7A5>0 Ascii");
      for (i1=0; i1<numextrn; i1++) {
        if(batch||(!batch&&proto[i1].singleok))
          npr("5<7%c5>0 %s\r\n",proto[i1].key,(proto[i1].description));
      }
      nl();
    } else
      done=1;
  } while ((!done) && (!hangup));
    if (ch=='Q')
      return(-1);
    if(ch=='B') return(-2);
    if(ch=='N') return(-3);
    if(ch=='A') return(-4);

    for(i=0;i<numextrn;i++)
    if(ch==proto[i].key) return(i);

return(-1);
}

void ascii_send(char *fn, int *sent, double *percent)
{
  char b[2048];
  int i,i1,done,abort,i2,next;
  long pos,max;

  i=open(fn,O_RDONLY | O_BINARY);
  if (i>0) {
    max=filelength(i);
    if (!max)
      max=1;
    i1=read(i,(void *)b,1024);
    pos=0L;
    abort=0;
    while ((i1) && (!hangup) && (!abort)) {
      i2=0;
      while ((!hangup) && (!abort) && (i2<i1)) {
	checkhangup();
	outchr(b[i2++]);
    checka(&abort,&next,0);
      }
      pos += (long) i2;
      checka(&abort,&next,0);
      i1=read(i,(void *)b,1024);
    }
    close(i);
    if (!abort)
      *sent=1;
    else {
      *sent=0;
      thisuser.dk += ((pos+1023L)/1024L);
    }
    *percent=((double) pos)/((double)max);
  } else {
    nl();
    pl("File not found.");
    nl();
    *sent=0;
    *percent=0.0;
  }
}
 
void send_file(char *fn, int *sent, int *abort, char *ft)
{
  int i,i1,ok;
  double percent,t;
  char s[81];

  ft[0]=0;
  i=get_protocol(1,0);
  ok=0;
  percent=0.0;
  switch(i) {
    case -1:
      *sent=0;
      *abort=1;
      ok=1;
      break;
    case -3:
      *sent=0;
      *abort=0;
      ok=1;
      break;
    case -4:
      *sent=0;
      *abort=0;
      ascii_send(fn,sent,&percent);
      strcpy(ft,"ASCII");
      break;
    case -2: break;
    default:
      i1=extern_prot(i,fn,1);
      strcpy(ft,(proto[i].description));
      *abort=0;
      if (i1==proto[i].ok1)
        *sent=1;
      else
        *sent=0;
      break;
  }

}


void receive_file(char *fn, int *received, char *ft, int okbatch)
{
  int i,i1;
  char s[81];

  ft[0]=0;
  i=get_protocol(1,okbatch);
  switch(i) {
    case -1:
    case -3:
      *received=0;
      break;
    default:
    i1=extern_prot(i,fn,0);
    strcpy(ft,(proto[i].description));
    if (i1==proto[i].ok1) {
      pl("\x03""2> File received.");
      *received=1;
    } else {
      pl("\x03""2> File reception aborted.");
      *received=0;
    }
    break;
  }
}



