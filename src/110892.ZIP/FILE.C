#include "vars.h"
#pragma hdrstop


#define SETREC(i)  lseek(dlf,((long) (i))*((long)sizeof(uploadsrec)),SEEK_SET);
#define INDENTION 30
#define MAX_LINES 10


int ratio_ok()
{
  int ok=1;
  char s[101];

  if (!(thisuser.exempt & exempt_ratio))
    if ((nifty.nifstatus & nif_ratio) && (syscfg.req_ratio>0.0001) && (ratio()<syscfg.req_ratio)) {
      ok=0;
      nl();
      nl();
      npr("Your up/download ratio is %-5.3f.  You need a ratio of %-5.3f to download.\r\n",
        ratio(), syscfg.req_ratio);
      nl();
    }

  if (!(thisuser.exempt & exempt_post))
    if ((nifty.nifstatus & nif_pcr) &&(syscfg.post_call_ratio>0.0001) && (post_ratio()<syscfg.post_call_ratio)) {
      ok=0;
      nl();
      nl();
      npr("Your post/call ratio is %-5.3f.  You need a ratio of %-5.3f to download.\r\n",
        post_ratio(), syscfg.post_call_ratio);
      nl();
    }

  return(ok);
}

int postr_ok()
{
  int ok=1;
  char s[101];

  if (!(thisuser.exempt & exempt_post))
    if ((syscfg.post_call_ratio>0.0001) && (post_ratio()<syscfg.post_call_ratio)) {
      ok=0;
      nl();
      sprintf(s,"Your post/call ratio is %-5.3f.  You need a ratio of %-5.3f to download.",
        post_ratio(), syscfg.post_call_ratio);
      pl(s);
      nl();
    }

  return(ok);
}

int filer_ok()
{

   if ((syscfg.req_ratio>0.0001) && (ratio()<syscfg.req_ratio)) {
     nl();
     npr("Your File ratio is %-5.3f.  You need a ratio of %-5.3f to download.\r\n",
        ratio(), syscfg.req_ratio);
     nl();
     return 0;
   }
  return 1;
}



int dcs() {
  if (thisuser.dsl>=100)
    return(1);
  else
    return(0);
}


void dliscan1(int dn)
{
  char s[81];
  int i;
  uploadsrec u;

  closedl();
  if(directories[dn].type)
  sprintf(s,"%sTEMPDIR.dir",directories[dn].dpath);
  else
  sprintf(s,"%sdir\\%s.DIR",syscfg.datadir,directories[dn].filename);
  dlf=open(s,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
  i=filelength(dlf)/sizeof(uploadsrec);
  if (i==0) {
    u.numbytes=0;
    SETREC(0);
    write(dlf,(void *)&u,sizeof(uploadsrec));
  } else {
    SETREC(0);
    read(dlf,(void *)&u,sizeof(uploadsrec));
  }
  numf=u.numbytes;

  sprintf(s,"%sdir\\%s.EXT",syscfg.datadir,directories[dn].filename);
  edlf=open(s,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
}


void dliscan()
{
  dliscan1(udir[curdir].subnum);
}


void closedl()
{
  if (dlf>0) {
    close(dlf);
    dlf=-1;
  }
  if (edlf>0) {
    close(edlf);
    edlf=-1;
  }
}


void align(char *s)
{
  char f[40],e[40],s1[20],*s2;
  int i,i1,i2;

  i1=0;
  if (s[0]=='.')
    i1=1;
  for (i=0; i<strlen(s); i++)
    if ((s[i]=='\\') || (s[i]=='/') || (s[i]==':') || (s[i]=='<') ||
      (s[i]=='>') || (s[i]=='|'))
      i1=1;
  if (i1) {
    strcpy(s,"        .   ");
    return;
  }
  s2=strchr(s,'.');
  if (s2==NULL) {
    e[0]=0;
  } else {
    strcpy(e,&(s2[1]));
    e[3]=0;
    s2[0]=0;
  }
  strcpy(f,s);

  for (i=strlen(f); i<8; i++)
    f[i]=32;
  f[8]=0;
  i1=0;
  i2=0;
  for (i=0; i<8; i++) {
    if (f[i]=='*')
      i1=1;
    if (f[i]==' ')
      i2=1;
    if (i2)
      f[i]=' ';
    if (i1)
      f[i]='?';
  }

  for (i=strlen(e); i<3; i++)
    e[i]=32;
  e[3]=0;
  i1=0;
  for (i=0; i<3; i++) {
    if (e[i]=='*')
      i1=1;
    if (i1)
      e[i]='?';
  }

  for (i=0; i<12; i++)
    s1[i]=32;
  strcpy(s1,f);
  s1[8]='.';
  strcpy(&(s1[9]),e);
  strcpy(s,s1);
  for (i=0; i<12; i++)
    s[i]=toupper(s[i]);
}


int compare(char s1[15], char s2[15])
{
  int ok,i;

  ok=1;
  for (i=0; i<12; i++)
    if ((s1[i]!=s2[i]) && (s1[i]!='?') && (s2[i]!='?'))
      ok=0;
  return(ok);
}

void printinfo(uploadsrec *u, int *abort, int *next,int number)
{
  char s[100],ss[39],s1[10],s2[5],s3[5],s4[5],f[81];
  int i,i1,i2;

  i=(u->numbytes+1023)/1024;
  sprintf(s1,"%4d",i);
  sprintf(s2,"%4d",u->points);
  sprintf(s3,"%3d",number);
  sprintf(ss,"%-39.39s",u->description);
  sprintf(s4,"%3d",u->numdloads);

  sprintf(f,"%s%s",directories[udir[curdir].subnum].dpath,u->filename);
  if(u->numbytes==-1)
  stuff_in1(s,filelistformat4,u->filename,ss,s1,s2,s3,u->upby,u->date,s4,"");

  if(!(u->ats[0]))
  stuff_in1(s,filelistformat3,u->filename,ss,s1,s2,s3,u->upby,u->date,s4,"");

  else if(exist(f))
  stuff_in1(s,filelistformat,u->filename,ss,s1,s2,s3,u->upby,u->date,s4,"");
  else
  stuff_in1(s,filelistformat2,u->filename,ss,s1,s2,s3,u->upby,u->date,s4,"");

  plan(s,abort,next);

   if ((!*abort) && (u->mask & mask_extended))
     num_listed+=print_extended(u->filename,abort,10,1);
   if (!(*abort))
     ++num_listed;
}


void printtitle() {
    int x;

    outchr(12);
    pl(get_string(22));
    ansic(5);
    for(x=0;x<79;x++) outchr(196);
    nl();
}


int file_mask(char *s)
{
  int i=0;

  nl();
  outstr(get_string(47));
  mpl(12);
  input(s,12);
  if (s[0]==0) {
    strcpy(s,"*.*");
    i=1;
  }
  if (strchr(s,'.')==NULL)
    strcat(s,".*");
  align(s);
  nl();
  return(i);
}

int nonstop;

int pauseline(int *abort)
{
  int go=0,i;
  char c;
  char s[40];

  ansic(5);
  for(i=0;i<79;i++) outchr(196);
  nl();

  if(nonstop) return 0;
  do {
  outstr(get_string(39));
  strcpy(s,"I?VMDSNBR\r");
  if(cs())
    strcat(s,"!@#$");
  c=onek(s);
  switch(c) {
      case '!': valfiles(); dliscan(); break;
      case '@': removefile(0); dliscan(); break;
      case '#': editfile(); dliscan(); break;
      case '$': move_file(0); dliscan(); break;
      case 'D': newdl(curdir); dliscan(); break;
      case 'V': arc_cl(1); dliscan(); break;
      case 'B': ex("FB",""); dliscan(); break;
      case 'N': nonstop=1; go=1; break;
      case 'S': *abort=1; go=1; break;
      case 'M': mark(curdir); dliscan(); break;
      case '\r': go=1; break;
      case 'I': getfileinfo(); break;
      case '?': printmenu(22); if(cs()) printmenu(17); break;
      case 'R': return 1;
   }
 } while(!go&&!hangup);
 if(abort);
if(okansi()) outstr("[A[K");
return 0;
}


int lfs(char ss[81],int *abort,long *bytes)
{
  char s[81],s1[81],c;
  int i,next,x,prtitle,listed=0,topofpage=0;
  uploadsrec u;

  dliscan(udir[curdir].subnum);
  strcpy(s,ss);
  listing=1;
  num_listed=0;
  prtitle=0;

  
  setformat();
  topofpage=1;

  for (i=1; (i<=numf) && (! (*abort)) && (!hangup); i++) {
    SETREC(i);
    read(dlf,(void *)&u,sizeof(uploadsrec));
    if (compare(s,u.filename)) {
      if(!prtitle) {
        printtitle();
        prtitle=1;
      }
      printinfo(&u,abort,&next,i);
      listed++;
      (*bytes)+=(u.numbytes+1023)/1024;
    }
    if(num_listed>thisuser.screenlines-4) {
        if(!pauseline(abort))
        topofpage=i+1;
        else i=topofpage-1;
        num_listed=0;
        prtitle=0;
    }
  }
  closedl();

  if (!(* abort)&&prtitle) {
    pauseline(abort);
  }

  listing=0;
  return listed;
}

void listfiles(int dn)
{
    char s[81];
    int abort=0,num;
    long len=0;

    if(dn) curdir=dn;
    file_mask(s);
    nonstop=0;
    nl();
    num=lfs(s,&abort,&len);
    npr("\r\n\r\n5%d 0Files Listed, 5%ld0 KB Total",num,len);
    nl();
}

void nscandir(int d, int *abort, int title,int *next)
{
  int i,od,did=0,x;
  uploadsrec u;
  char s[81],s1[81];

  od=curdir;
  curdir=d;
  nonstop=0;
  listing=1;
  *next=0;
  dliscan();
  if(title) {
    pl(get_string(44));
  }
  for (i=1; i<=numf && !(*abort) && !(*next) && !hangup; i++) {
    SETREC(i);
    read(dlf,(void *)&u,sizeof(uploadsrec));
    if ((u.daten>=nscandate)||(!u.ats[0])) {
        if(!did) {
          ansic(5);
          for(x=0;x<79;x++) outchr(196);
          nl();
        }
      printinfo(&u,abort,next,i);
      did=1;
    }
  }
  closedl();
  curdir=od;
  if(did&&!(*abort)&&!(*next)) pauseline(abort);
  if(*next) *abort=0;
  listing=0;
}


void nscanall()
{
  int abort,i,i1,next,save;
  char s[81];

  abort=0;
  num_listed=0;
  save=curdir;
  logpr("NewScaned File Areas");
  for (curdir=0; (curdir<64) && (!abort) && (udir[curdir].subnum!=-1); curdir++) {
    i1=udir[curdir].subnum;
    if (i1>=32) {
      if (thisuser.nscn2 & (1L << (i1-32)))
        nscandir(curdir,&abort,1,&next);
    } else {
      if (thisuser.nscn1 & (1L << i1))
        nscandir(curdir,&abort,1,&next);
    }
  }
  if ((num_listed) && (!abort)) {
    nl();
    nl();
    npr("%d Files listed",num_listed);
    nl();
  }
  curdir=save;
}

void searchall()
{
  int i,abort=0,ocd;
  char s[81],s1[81];
  uploadsrec u;
  long len=0;

  abort=0;
  ocd=curdir;
  nonstop=0;
  nl();
  setformat();
  dtitle("Search all directories.");
  file_mask(s);
  num_listed=0;
  for (i=0; (i<64) && (!abort) && (!hangup) && (udir[i].subnum!=-1); i++) {
    curdir=i;
    num_listed+=lfs(s,&abort,&len);
  }
  curdir=ocd;
  if  ((num_listed) && (!abort)) {
    nl();
    npr("5%d 0Files Listed, 5%ld0 KB Total",num_listed,len);
  }
}

int recno(char s[15])
{
  int i;
  uploadsrec u;

  i=1;
  if (numf<1)
    return(-1);
  SETREC(i);
  read(dlf,(void *)&u,sizeof(uploadsrec));
  while ((i<numf) && (compare(s,u.filename)==0)) {
    ++i;
    SETREC(i);
    read(dlf,(void *)&u,sizeof(uploadsrec));
  }
  if (compare(s,u.filename))
    return(i);
  else
    return(-1);
}


int nrecno(char s[15],int i1)
{
  int i;
  uploadsrec u;

  i=i1+1;
  if ((numf<1) || (i1>=numf))
    return(-1);

  SETREC(i);
  read(dlf,(void *)&u,sizeof(uploadsrec));
  while ((i<numf) && (compare(s,u.filename)==0)) {
    ++i;
    SETREC(i);
    read(dlf,(void *)&u,sizeof(uploadsrec));
  }
  if (compare(s,u.filename))
    return(i);
  else
    return(-1);
}


void printfileinfo(uploadsrec *u, int dn,int mark,int mode)
{
  char s[81],s1[81];
  double t;
  int i,abort;

  t=((double) (((u->numbytes)+127)/128)) * (1620.0)/((double) (modem_speed));
  if(!mark) {
  if (mode) npr("2>>>0Directory: %s\r\n",directories[dn].name);
  sprintf(s,"%s%s",directories[dn].dpath,u->filename);
  strcpy(s1,"");
  if(!exist(s)) strcpy(s1,"0(6File is OffLine0) ");
  if(u->ats[0]==0) strcat(s1,"0(8Unvalidated0) ");
  if(u->numbytes==-1) strcat(s1,"0(8InComplete0)");
  npr("2>>>0Filename    : %s %s\r\n",stripfn(u->filename),s1);
  npr("2>>>0Description : %s\r\n",(u->description));
  ltoa(((u->numbytes)+1023)/1024,s,10);
  if(u->numbytes==-1) strcpy(s,"InComplete");
  npr("2>>>0File size   : %sK\r\n",s);
  npr("2>>>0File Points : %d\r\n",u->points);
  npr("2>>>0Apprx. time : %s\r\n",ctim(t),"");
  npr("2>>>0Uploaded By : %s\r\n",u->upby);
  nl();
  abort=0;
  if (u->mask & mask_extended) {
    pl("4>>>0Extended Description");
    print_extended(u->filename,&abort,255,0);
  }
 }
}


int checkdl(uploadsrec u,int dn)
{
   double t;
   char s[81];

   tleft(1);


   t=((double) (((u.numbytes)+127)/128)) * (1620.0)/((double) (modem_speed));

    if(t>nsl()&&!dcs()&&!(thisuser.exempt & exempt_time)) {
      pl("Not Enough Time to DL");
      return 0;
    }

    sprintf(s,"%s%s",directories[dn].dpath,u.filename);
    if(!exist(s)) {
          pl("File is OffLine");
          return 0;
    }

    if(!u.ats[0] && !dcs()) {
       npr("%s",get_string(43));
       return 0;
    }

         
    if(!dcs()&&!(thisuser.exempt & exempt_ratio)) {
         if(nifty.nifstatus & nif_fpts)
            if(thisuser.fpts*nifty.fptsratio<u.points) {
               nl();
               npr("%s",get_string(27));
               return 0;
             }
    }
         
    if(!dcs())  {
        if(!ratio_ok()) return 0;
    }

    if(!dcs())  {
        if(u.numbytes==-1) {
            pl("InComplete files may not be downloaded.");
            return 0;
        }
    }

    outstr("[K");
    return(1);
}

void finddescription()
{
  uploadsrec u;
  int i,i1,i2,abort,pty,d,ocd,next=0;

  char s[81],s1[81];

  nl();
  dtitle("Find File Description");
  pl("Enter string to search for in file description:");
  outstr(":");
  input(s1,58);
  if (s1[0]==0)
    return;

  ocd=curdir;
  abort=0;
  num_listed=0;

  outstr("5Scan All Directories? ");
  if(ny())
  for (i=0; (i<64) && (!abort) && (!hangup) && (udir[i].subnum!=-1); i++) {
    i1=udir[i].subnum;
    curdir=i;
    dliscan();
    pty=1;
    for (i1=1; (i1<=numf) && (!abort) && (!hangup); i1++) {
      SETREC(i1);
      read(dlf,(void *)&u,sizeof(uploadsrec));
      strcpy(s,u.description);
      for (i2=0; i2<strlen(s); i2++)
        s[i2]=toupper(s[i2]);
      if (strstr(s,s1)!=NULL) {
        if (pty) {
          printtitle();
          pty=0;
        }
        printinfo(&u,&abort,&next,i1);
      } else if (!empty())
        checka(&abort,&next,0);
    }
    if(!pty) pauseline(&abort);
    closedl();
  } else {
    pty=1;
    dliscan();
    for (i1=1; (i1<=numf) && (!abort) && (!hangup); i1++) {
      SETREC(i1);
      read(dlf,(void *)&u,sizeof(uploadsrec));
      strcpy(s,u.description);
      for (i2=0; i2<strlen(s); i2++)
        s[i2]=toupper(s[i2]);
      if (strstr(s,s1)!=NULL) {
        if (pty) {
          printtitle();
          pty=0;
        }
        printinfo(&u,&abort,&next,i1);
      } else if (!empty())
        checka(&abort,&next,0);
    }
    closedl();
    if(!pty) pauseline(&abort);
  }

  curdir=ocd;
  if ((num_listed) && (!abort)) {
    nl();
    npr("%d Files Listed\r\n",num_listed);
    nl();
  }
}


