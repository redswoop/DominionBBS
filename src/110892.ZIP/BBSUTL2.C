#include "vars.h"
#pragma hdrstop
#include <conio.h>

#define frequency 500

void jumpconf()
{
    char c,s[81];
    int i;

    dtitle("Conferences Available: ");
    for(c=0;c<num_conf;c++)
      if(slok(conf[c].sl,0)) npr("0<%d> %s\r\n",c+1,conf[c].name);
    nl();
    outstr("Select: ");
    mpl(2);
    input(s,2);
    i=atoi(s);
    if(i==0) return;
    i--;
    if(i>num_conf) return;
    if(slok(conf[i].sl,0)) curconf=i;
    else {
        pl("Unavailable Conference");
        curconf=0;
        return;
    }
    changedsl();
}

void add_time(int limit)
{
  int minutes;
  char s[81];
  double nsln;

  nsln=nsl();
  npr("Time in Bank: %d\r\n",thisuser.timebank);
  npr("2%.0f minutes left online.\r\n",nsln/60.0);
  npr("How many minutes would you like to deposit? ");
  mpl(3);
  ansic(4);
  inputl(s,3);
  minutes = atoi(s);
  if (minutes<1) return;
  if (hangup) return;
  if (minutes > (int)((nsl() - 20.0)/60.0)) {
    nl();
    prt(7, "You do not have enough time left to deposit that much.");
    nl();
    pausescr();
    return;
    }
  if ((minutes + thisuser.timebank) > limit) {
    nl();
    npr("7You may only have up to %d minutes in your account at once.\r\n", limit);
    nl();
    pausescr();
    return;
    }
  thisuser.timebank += minutes;
  write_user(usernum,&thisuser);
  logpr("5- 3Deposit 4%d3 minutes.", minutes);
  nl();
  npr("%d minute%c deposited.", minutes,((minutes > 1) ? 's' : 0));
  nl();

  if (extratimecall > 0) {
    if (extratimecall >= (double)(minutes * 60)) {
      extratimecall -= (double)(minutes * 60);
      return;
    }
    minutes -= (int)(extratimecall / 60.0);
    extratimecall = 0.0;
  }
  thisuser.extratime -= (float)(minutes * 60);
  pausescr();
}

void remove_time()
{
  char s[81];
  int minutes;

  nl(); nl();
  npr( "Time in account: %d minutes.\r\n", thisuser.timebank);
  nl();
  ansic(0);
  outstr("How many minutes would you like to withdraw? ");
  ansic(4);
  inputl(s,3);
  minutes = atoi(s);
  if (minutes<1) return;

  if (hangup) return;
  if (minutes > thisuser.timebank) {
    nl(); nl();
    prt(7, "You don't have that much time in the account!");
    nl();
    nl();
    pausescr();
    return;
  }
  logpr("5- 3Withdrew 4%d3 minutes.", minutes);
  thisuser.extratime += (float)(minutes * 60);
  thisuser.timebank -= minutes;
  nl(); nl();
  npr("4%d minute%c withdrawn.", minutes,((minutes > 1) ? 's' :0));
  nl();
  pausescr();
}

void bank2(int limit)
{
int done = 0;
char s[81], ch;

  sysoplog("7*>0 Entered Time Bank");
  do {
    dtitle("Dominion Time Bank");
    nl();
    tleft(0);
    npr("Time in Bank: %d\r\n",thisuser.timebank);
    nl();
    outstr("5[3D5]0eposit, 5[3W5]0ithdraw, 5[3Q5]0uit: ");
    ch = onek("QD?W");
    switch (ch) {
      case '?': printmenu(24); break;
      case 'Q': done = 1; break;
      case 'D': add_time(limit); break;
      case 'W': if(thisuser.restrict & restrict_timebank) {
                    nl();
                    pl(get_string(53));
                    nl();
                    logpr("8- Tried to withdraw time, but was dissallowed");
                    break;
                }
                remove_time();  break;
    }
  } while ((!hangup) && (!done));
  nl();
 }

int rc;

void prdata(char *str,char *what,int xcoord, int ycoord)
{
    char s[81],i;

    movecsr(xcoord,ycoord);
    sprintf(s,"[%-8s] ",str);
    i=curatr;
    curatr=9;
    outs(s);
    curatr=11;
    sprintf(s,"%-24s",what);
    outs(s);
    curatr=i;
}

void prdata2(char *str,char *what,int xcoord,int ycoord)
{
    char s[81],i;

    movecsr(xcoord,ycoord);
    sprintf(s,"[%-8s] ",str);
    i=curatr;
    curatr=9;
    outs(s);
    curatr=11;
    sprintf(s,"%s",what);
    outs(s);
    curatr=i;

}

void editdata(char *str,int len,int xcoord,int ycoord)
{
    int i;

    movecsr(xcoord+11,ycoord);
    editline(str,len,ALL,&rc,"");
    for(i=strlen(str)-1;i>=0 && str[i]==32;i--);
        str[i+1]=0;
}

int editdig(char *str,int len,int xcoord,int ycoord)
{
    int real;

    movecsr(xcoord+11,ycoord);
    editline(str,len,NUM_ONLY,&rc,"");
    real=atoi(str);
    return(real);
}

 

int so()
{
  if (actsl==255)
    return(1);
  else
    return(0);
}

int cs()
{
  slrec ss;

  ss=syscfg.sl[actsl];
  if (so())
    return(1);
  if (ss.ability & ability_cosysop)
    return(1);
  else
    return(0);
}


int lcs()
{
  slrec ss;

  ss=syscfg.sl[actsl];
  if (cs())
    return(1);
  if (ss.ability & ability_limited_cosysop) {
    if (thisuser.sysopsub==255)
      return(1);
    if (thisuser.sysopsub==usub[cursub].subnum)
      return(1);
    else
      return(0);
  } else
    return(0);
}

void makewindow(int x, int y, int xlen, int ylen)
{
  int i,xx,yy,old;
  unsigned char s[81];

  old=curatr;
  if (xlen>80)
    xlen=80;
  if (ylen>(screenbottom+1-topline))
    ylen=(screenbottom+1-topline);
  if ((x+xlen)>80)
    x=80-xlen;
  if ((y+ylen)>screenbottom+1)
    y=screenbottom+1-ylen;

  xx=wherex();
  yy=wherey();
  directvideo=1;
  for (i=1; i<xlen-1; i++)
    s[i]=205;
  s[0]=213;
  s[xlen-1]=184;
  s[xlen]=0;
  movecsr(x,y);
  textcolor(9);
  cprintf(s);
  s[0]=212;
  s[xlen-1]=190;
  movecsr(x,y+ylen-1);
  cprintf(s);
  textcolor(8);
  cprintf("�");
  movecsr(x+1,y+1);
  for (i=1; i<xlen-1; i++)
    s[i]=32;
  s[0]=179;
  s[xlen-1]=179;
  for (i=1; i<ylen-1; i++) {
    movecsr(x,i+y);
    textcolor(9);
    cprintf(s);
    textcolor(8);
    cprintf("�");
  }
  movecsr(x+1,y+ylen);
  for(i=0;i<xlen;i++) cprintf("�");
  movecsr(xx,yy);
  curatr=old;
}


void editline(char *s, int len, int status, int *returncode, char *ss)
{
  int i,j,k,oldatr,cx,cy,pos,ch,done,insert,i1;

  oldatr=curatr;
  cx=wherex();
  cy=wherey();
  for (i=strlen(s); i<len; i++)
    s[i]=32;
  s[len]=0;
  curatr=31;
  outs(s);
  movecsr(cx,cy);
  done=0;
  pos=0;
  insert=0;
  do {
    ch=getchd();
    if (ch==0) {
      ch=getchd();
      switch (ch) {
        case 59:
          done=1;
          *returncode=DONE;
          break;
        case 71: pos=0; movecsr(cx,cy); break;
        case 79: pos=len; movecsr(cx+pos,cy); break;
        case 77: if (pos<len) {
            pos++;
            movecsr(cx+pos,cy);
          }
          break;
        case 75: if (pos>0) {
            pos--;
            movecsr(cx+pos,cy);
          }
          break;
        case 72:
        case 15:
          done=1;
          *returncode=PREV;
          break;
        case 80:
          done=1;
          *returncode=NEXT;
          break;
        case 82:
          if (status!=SET) {
            if (insert)
              insert=0;
            else
              insert=1;
          }
          break;
        case 83:
          if (status!=SET) {
            for (i=pos; i<len; i++)
              s[i]=s[i+1];
            s[len-1]=32;
            movecsr(cx,cy);
            outs(s);
            movecsr(cx+pos,cy);
          }
          break;
      }
    } else {
      if (ch>31) {
        if (status==UPPER_ONLY)
          ch=toupper(ch);
    if (status==SET) {
      ch=toupper(ch);
      if (ch!=' ') {
        i1=1;
            for (i=0; i<len; i++)
          if ((ch==ss[i]) && (i1)) {
        i1=0;
        pos=i;
        movecsr(cx+pos,cy);
        if (s[pos]==' ')
          ch=ss[pos];
        else
          ch=' ';
          }
        if (i1)
          ch=ss[pos];
      }
    }
        if ((pos<len)&&((status==ALL) || (status==UPPER_ONLY) || (status==SET) ||
            ((status==NUM_ONLY) && (((ch>='0') && (ch<='9')) || (ch==' '))))) {
          if (insert) {
            for (i=len-1; i>pos; i--)
              s[i]=s[i-1];
            s[pos++]=ch;
            movecsr(cx,cy);
            outs(s);
            movecsr(cx+pos,cy);
          } else {
            s[pos++]=ch;
            out1ch(ch);
          }
        }
      } else {
    ch=ch;
        switch(ch) {
      case 13:
          case 9:
            done=1;
            *returncode=NEXT;
            break;
          case 27:
            done=1;
            *returncode=DONE;
            break;
          case 8:
            if (pos>0) {
              if (insert) {
                for (i=pos-1; i<len; i++)
                  s[i]=s[i+1];
                s[len-1]=32;
                pos--;
                movecsr(cx,cy);
                outs(s);
                movecsr(cx+pos,cy);
              } else {
                pos--;
                movecsr(cx+pos,cy);
              }
            }
            break;
        }
      }
    }
  } while (done==0);
  movecsr(cx,cy);
  curatr=oldatr;
  outs(s);
  movecsr(cx,cy);
}


void get_quote(int fsed)
{
  static char s[141];
  static int i,i1,i2,abort,next,rl;

  rl=1;
  do {
    if (rl) {
        i=1; i2=0; abort=0; next=0;
      do {
        npr("0%2d: ",i++);
        i1=0;
        if (abort) {
          do {
            i2++;
          } while ((quote[i2]!=13) && (quote[i2]!=0));
        } else {
          do {
            s[i1++]=quote[i2++];
          } while ((quote[i2]!=13) && (quote[i2]!=0));
        }
        if (quote[i2]) {
          i2+=2;
          s[i1]=0;
        }
        pla(s,&abort);
      } while (quote[i2]!=0);
      --i;
    }
    nl();
    i1=0; i2=0; s[0]=0;
    while (!s[0]) {
      sprintf(s,"Quote from line 1-%d? (A=All,?=relist,Q=quit) ",i);
      prt(2,s);
      input(s,3);
    }
    if (s[0]=='A') {
        quoting=0;
        charbufferpointer=0;
        bquote=1;
        equote=i;
        return;
    }
    if (s[0]=='Q')
      rl=0;
    else if (s[0]!='?') {
      i1=atoi(s);
      if (i1==i)
        i2=i1;
      else {
        s[0]=0;
        while (!s[0]) {
          sprintf(s,"through line %d-%d? (Q=quit) ",i1,i);
          prt(2,s);
          input(s,3);
        }
        if (s[0]=='Q')
          rl=0;
        else if (s[0]!='?')
          i2=atoi(s);
      }
    }
    if (i2) {
      sprintf(s,"Quote line(s) %d-%d? ",i1,i2);
      prt(5,s);
      if (!ny())
        i2=0;
    }
  } while ((!abort) && (!hangup) && (rl) && (!i2));
  quoting=0;
  charbufferpointer=0;
  if ((i1>0) && (i2>=i1) && (i2<=i) && (i2-i1<50) && (rl)) {
    bquote=i1;
    equote=i2;
  }
}

void ptime()
{
  char xl[81], cl[81], atr[81], cc, s[81];
  long l;

  savel(cl, atr, xl, &cc);

  ansic(0);
  nl();
  nl();
  time(&l);
  strcpy(s, ctime(&l));
  s[strlen(s) - 1] = 0;
  npr("3It is 0%s3.\r\n",s);
  if (useron)
    npr("3You have been on for 0%s3, and have 0`T3 left\r\n",ctim(timer()-timeon));
  nl();

  restorel(cl, atr, xl, &cc);
}


void reprint()
{
  char xl[81], cl[81], atr[81], cc, ansistr_1[81];
  int ansiptr_1;

  ansiptr_1=ansiptr;
  ansiptr=0;
  ansistr[ansiptr_1]=0;
  strcpy(ansistr_1,ansistr);

  savel(cl, atr, xl, &cc);
  nl();
  restorel(cl, atr, xl, &cc);

  strcpy(ansistr,ansistr_1);
  ansiptr=ansiptr_1;
}


void setbeep(int i)
{
  int i1,i2;

  if (i) {
    i1 = 0x34DD / frequency;
    i2 = inportb(0x61);
    if (!(i2 & 0x03)) {
      outportb(0x61, i2 | 0x03);
      outportb(0x43, 0xB6);
    }
    outportb(0x42, i1 & 0x0F);
    outportb(0x42, i1 >> 4);
  } else
    outportb(0x61, inportb(0x61) & 0xFC);
}


