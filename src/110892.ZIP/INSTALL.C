#include "std.c"
#include <dir.h>

void main(void)
{
    int i;
    char s[MAXPATH],s1[MAXPATH],cmd[MAXPATH];
    FILE *f;

    npr("5� 0Dominion BBS v3.0 Installation");
    nl();
    outstr("5Continue?0");
    if(!ny()) exit(0);
    pr("5� 0Enter Path to Install Into\r\n3 <Enter=CurDir, Exclude Trailing Backslash>: ");
    input(s,MAXPATH);
    if(!s[0]) { s[0]='.'; s[1]=0; } else mkdir(s);

    getcwd(s1,MAXPATH);
    cd_to(s);

    nl();
    npr("5� 0Creating Directories");
    mkdir("afiles");
    mkdir("data");
    mkdir("data\\dir");
    mkdir("temp");
    mkdir("menus");
    mkdir("msgs");
    mkdir("batch");

    cd_to(s1);
    npr("5� 0UnZipping Files");
    sprintf(cmd,"pkunzip -o afiles.dom %s\\afiles>nul",s);
    system(cmd);
    sprintf(cmd,"pkunzip -o menus.dom %s\\menus>nul",s);
    system(cmd);
    sprintf(cmd,"pkunzip -o msgs.dom %s\\msgs>nul",s);
    system(cmd);
    sprintf(cmd,"pkunzip -o exes.dom %s>nul",s);
    system(cmd);
    sprintf(cmd,"pkunzip -o data.dom %s\\data>nul",s);
    system(cmd);

    npr("5� 0Modifying Configuration Files");
    f=fopen("c:\\autoexec.bat","at");
    sprintf(cmd,"set DOM=%s",s1);
    fputs(cmd,f);
    fputs("\n",f);
    sprintf(cmd,"path %%path%%;%s",s1);
    fputs(cmd,f);
    fputs("\n",f);
    fclose(f);
    npr("5� 0Installation Complete");
    nl();
}

