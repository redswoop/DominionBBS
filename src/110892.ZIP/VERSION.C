char *wwiv_version = "Dominion ��s v3.0�eta";

unsigned int wwiv_num_version=3.0;

char *wwiv_date = __DATE__ ", " __TIME__;

