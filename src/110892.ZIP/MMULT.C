#include "vars.h"
#pragma hdrstop

#define ALLOW_FULLSCREEN 1
#define EMAIL_STORAGE 2

typedef struct {
    int un,
        sy;
} mmailrec;

void multimail(mmailrec *un, int numu,int all)
{
  int i,i1,f,ff,len,an,cv,ok;
  mailrec m,m1;
  char s[81],s1[81],t[81];
  userrec ur;
  slrec ss;
  char *b,*b1;
  net_header_rec nh;


  if (freek1(syscfg.msgsdir)<10.0) {
    nl();
    pl("Sorry, not enough disk space left.");
    nl();
    return;
  }
  nl();
  sprintf(s,"%sEMAIL.DAT",syscfg.datadir);
  ss=syscfg.sl[thisuser.sl];

  if (ss.ability & ability_email_anony)
    i=anony_enable_anony;
  else
    i=0;
  m.msg.storage_type=EMAIL_STORAGE;
  strcpy(irt,"Multi-Mail");
  irt_name[0]=0;
  inmsg(&m.msg,t,&i,1,"EMAIL",ALLOW_FULLSCREEN);
  if (m.msg.stored_as==0xffffffff)
    return;
  strcpy(m.title,t);
  m.anony=i;
  m.fromuser=usernum;
  m.tosys=0;
  m.touser=0;
  m.status=status_multimail;
  time((long *)&(m.daten));
  f=open(s,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
  len=(int) filelength(f)/sizeof(mailrec);
  if (len==0)
    i=0;
  else {
    i=len-1;
    lseek(f,((long) (i))*(sizeof(mailrec)), SEEK_SET);
    read(f,(void *)&m1,sizeof(mailrec));
    while ((i>0) && (m1.tosys==0) && (m1.touser==0)) {
      --i;
      lseek(f,((long) (i))*(sizeof(mailrec)), SEEK_SET);
      i1=read(f,(void *)&m1,sizeof(mailrec));
      if (i1==-1)
        pl("DIDN'T READ RIGHT.");
    }
    if ((m1.tosys) || (m1.touser))
      ++i;
  }
  lseek(f,((long) (i))*(sizeof(mailrec)), SEEK_SET);
  pl("Mail sent to:");
  sysoplog("Multi-Mail to:");

  for (cv=0; cv<numu; cv++) {
    ok=1;
    if(!un[cv].sy) {
        read_user(un[cv].un,&ur);
        if (((ur.sl==255) && (ur.waiting>(syscfg.maxwaiting * 5))) ||
            ((ur.sl!=255) && (ur.waiting>syscfg.maxwaiting)) ||
            (ur.waiting>200)) {
          strcpy(s,nam(&ur,un[cv].un));
          strcat(s,"  mailbox full, not sent.");
          pl(s);
          ok=0;
        }
        if (ur.inact & inact_deleted) {
              sprintf(s,"User #%d deleted, not sent.",un[cv].un);
          pl(s);
          ok=0;
        }
    }

    if (ok) {
      m.touser=un[cv].un;
      if(un[cv].sy) m.fromsys=syscfg.systemnumber;
      else m.fromsys=0;
      m.tosys=un[cv].sy;

      if(!un[cv].sy) {
          write(f,(void *)&m,sizeof(mailrec));
          strcpy(s,"   ");
          ++ur.waiting;
          write_user(un[cv].un,&ur);
          if (un[cv].un==1)
            ++fwaiting;
          strcat(s,nam(&ur,un[cv].un));
          if (un[cv].un==1)  {
            ++status.fbacktoday;
            ++thisuser.feedbacksent;
            ++thisuser.fsenttoday1;
            ++fsenttoday;
          } else {
            ++status.emailtoday;
            ++thisuser.etoday;
            ++thisuser.emailsent;
          }
          sysoplog(s);
          pl(s);
      } else {
        if ((b=readfile(&(m.msg),"EMAIL",&len1))==NULL)
      return;
    remove_link(&(m.msg),"EMAIL");
    nh.tosys=un[cv].sy;
    nh.touser=un[cv].un;
    nh.fromsys=syscfg.systemnumber;
    nh.fromuser=usernum;
    nh.main_type=main_type_email;
    nh.minor_type=0;
    nh.list_len=0;
    nh.daten=m.daten;
    nh.method=0;
    if ((b1=malloca(len1+300))==NULL) {
      farfree(b);
      return;
    }
    i=0;
    if (un[cv].un==0) {
      nh.main_type=main_type_email_name;
      strcpy(&(b1[i]),net_email_name);
      i+= strlen(net_email_name)+1;
    }
    strcpy(&(b1[i]),m.title);
    i += strlen(m.title)+1;
    memmove(&(b1[i]),b,(unsigned int) len1);
    nh.length=len1+(long)i;
    if (nh.length > 32760) {
      npr("Message truncated by %lu bytes for the network.\r\n",nh.length-32760L);
      nh.length = 32760;
    }
    sprintf(s,"%sP0.NET",syscfg.datadir);
    ff=open(s,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
    lseek(ff,0L,SEEK_END);
    write(ff,(void *)&nh,sizeof(net_header_rec));
    write(ff,(void *)b1,nh.length);
    close(ff);
    farfree(b);
    farfree(b1);
  }
    }
  }

  close_user();
  close(f);
  save_status();
  if (!wfc) topscreen();
}


char *mml_s;
int mml_started;


mmailrec oneuser()
{
  char s[81],*ss;
  unsigned short un,sn,i,sy;
  userrec u;
  mmailrec mmail;

  if (mml_s) {
    if (mml_started)
      ss=strtok(NULL,"\r\n");
    else
      ss=strtok(mml_s,"\r\n");
    mml_started=1;
    if (ss==NULL) {
      farfree(mml_s);
      mml_s=NULL;
      return(-1);
    }
    strcpy(s,ss);
    for (i=0; s[i]!=0; i++)
      s[i]=toupper(s[i]);
  } else {
    prt(2,">");
    input(s,40);
  }
  parse_email_info(s,&un,&sy);

  sn=0;

  if (un==0) {
    nl();
    pl("Unknown user.");
    nl();
    return(0);
  }

  if(!sy) {
      read_user(un,&u);
      if (((u.sl==255) && (u.waiting>(syscfg.maxwaiting * 5))) ||
          ((u.sl!=255) && (u.waiting>syscfg.maxwaiting)) ||
          (u.waiting>200)) {
        nl();
        pl("Mailbox full.");
        nl();
        return(0);
      }
      if (u.inact & inact_deleted) {
        nl();
        pl("Deleted user.");
        nl();
        return(0);
      }
      sprintf(s,"     -> %s",nam(&u,un));
      pl(s);
  }
  mmail.un=un;
  mmail.sy=un;

  return(mmail);
}


void add_list(mmailrec *un, int *numu, int maxu, int allowdup)
{
  int i,i1,i2,done, mml;
  mmailrec mm;

  done=0;
  mml=(mml_s!=NULL);
  mml_started=0;
  while ((!done) && (!hangup) && (*numu<maxu)) {
    mm=oneuser();
    if (mml && (!mml_s))
      done=1;
    if (mmail.un==-1)
      done=1;
    else
      if (mmail.un) {
        if (!allowdup)
          for (i1=0; i1<*numu; i1++)
            if (un[i1].un==i) {
              nl();
              pl("Already in list, not added.");
              nl();
              mmail.un=0;
            }
        if (mmail.un)
          un[(*numu)++].un=mmail.un;
      }
  }
  if (*numu==maxu) {
    nl();
    pl("List full.");
    nl();
  }
}


#define MAX_LIST 40


void slash_e()
{
  int numu,done,i,i1,f1;
  mmailrec un[MAX_LIST];
  char s[81],s1[81],ch,*sss;
  slrec ss;
  userrec u;
  struct ffblk ff;

  mml_s=NULL;
  mml_started=0;
  ss=syscfg.sl[thisuser.sl];
  if (freek1(syscfg.msgsdir)<10.0) {
    nl();
    pl("Sorry, not enough disk space left.");
    nl();
    return;
  }
  if (((fsenttoday>=5) || (thisuser.fsenttoday1>=10) ||
    (thisuser.etoday>=ss.emails)) && (!cs())) {
    pl("Too much mail sent today.");
    return;
  }
  if (restrict_email & thisuser.restrict) {
    pl("You can't send mail.");
    return;
  }
  done=0;
  numu=0;
  do {
    nl();
    nl();
    prt(2,"Multi-Mail: A,M,D,L,E,U,Q,? : ");
    ch=onek("QUAMDEL?");
    switch(ch) {
      case '?':
        printmenu(12);
        break;
      case 'Q':
        done=1;
        break;
      case 'A':
        nl();
        pl("Enter user Name(s)/Number(s), one per line, max 20.");
        nl();
        mml_s=NULL;
        add_list(un,&numu,MAX_LIST,so());
        break;
      case 'M':
        sprintf(s,"%s*.mml",syscfg.datadir);
        f1=findfirst(s,&ff,0);
        if (f1) {
          nl();
          pl("No mailing lists available.");
          nl();
          break;
        }
        nl();
        pl("Available mailing lists:");
        nl();
        while (f1==0) {
          strcpy(s,ff.ff_name);
          sss=strchr(s,'.');
          if (sss)
            *sss=0;
          pl(s);

          f1=findnext(&ff);
        }

        nl();
        prt(2,"Which? ");
        input(s,8);

        sprintf(s1,"%s%s.mml",syscfg.datadir,s);
        i=open(s1,O_RDONLY | O_BINARY);
        if (i<0) {
          nl();
          pl("Unknown mailing list.");
          nl();
        } else {
          i1=filelength(i);
          mml_s=malloca(i1+10L);
          read(i,mml_s,i1);
          mml_s[i1]='\n';
          mml_s[i1+1]=0;
          close(i);
          mml_started=0;
          add_list(un,&numu,MAX_LIST,so());
          if (mml_s) {
            farfree(mml_s);
            mml_s=NULL;
          }
        }
        break;
      case 'E':
        if (!numu) {
          nl();
          pl("Need to specify some users first - use A or M");
          nl();
        } else {
          multimail(un,numu,0);
          done=1;
        }
        break;
      case 'U': if (so()) multimail(un,numu,1); break;
      case 'D':
        if (numu) {
          nl();
          prt(2,"Delete which? ");
          input(s,2);
          i=atoi(s);
          if ((i>0) && (i<=numu)) {
            --numu;
            for (i1=i-1; i1<numu; i1++)
              un[i1].un=un[i1+1].un;
          }
        }
        break;
      case 'L':
        for (i=0; i<numu; i++) {
          if(!un[i].sy) {
              read_user(un[i].un,&u);
              npr("%d. %s\r\n",i+1,nam(&u,un[i].un));
          } else {
              npr("%d. %d@%d\r\n",i+1,un[i].un,un[i].sy);
        }
        break;
    }
  } while ((!done) && (!hangup));
}

void smail(char ms[81])
{
    char *p, s[81];
    int i=0,node=0;

    p=strtok(ms,";");
    while(p!=NULL) {
        strcpy(s,p);
        if(atoi(s)) i=atoi(s);
        else if(s[0]=='@') node=atoi(s+1);
        else strcpy(irt,s);
        p=strtok(NULL,";");
    }
  if(i==0) send_email();
  else imail(i,node);
}
