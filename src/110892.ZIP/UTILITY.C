#include "vars.h"
#pragma hdrstop


#include <dir.h>
#include <math.h>
#include <share.h>


void reset_act_sl()
{
  actsl = thisuser.sl;
}

void check_event()
{
  double tl;

  if (syscfg.executetime) {
    tl=time_event-timer();
    if (tl<0.0)
      tl += 24.0*3600.0;
    if ((tl-last_time)>2.0)
      do_event=1;
    last_time=tl;
  }
}


void run_event()
{
  if ((do_event) && (syscfg.executetime)) {
    do_event=0;
    nl();
    pl("Now running external event.");
    nl();
    if (syscfg.executestr[0]) {
      holdphone(1,0);
      runprog(syscfg.executestr,1);
      /* run_external(syscfg.executestr); */
      holdphone(0,0);
    } else
      end_bbs(oklevel);
  }
  clrscrb();
}


double freek(int dr)
{
  float d;
  struct dfree df;

  getdfree(dr,&df);
  d=(float) df.df_avail;
  d*=((float) df.df_bsec);
  d*=((float) df.df_sclus);
  d/=1024.0;
  if (df.df_sclus==0xffff)
    d=-1.0;
  return(d);
}


unsigned char years_old(unsigned char m, unsigned char d, unsigned char y)
{
  struct date today;
  int a;

  getdate(&today);
  a=(int) (today.da_year-1900-y);
  if (today.da_mon<m)
    --a;
  else
    if ((today.da_mon==m) && (today.da_day<d))
      --a;
  return((unsigned char)a);
}



void itimer()
/* This function initializes the high-resolution timer */
{
  outportb(0x43,0x34);
  outportb(0x40,0x00);
  outportb(0x40,0x00);

}

double timer()
/* This function returns the time, in seconds since midnight. */
{
  double cputim;
  unsigned short int h,m,l1,l2;

  disable();
  outportb(0x43,0x00);
  m=peek(0x0040,0x006c);
  h=peek(0x0040,0x006e);
  l1=inportb(0x40);
  l2=inportb(0x40);
  enable();
  l1=((l2*256)+l1) ^ 65535;
  cputim=((h*65536. + m)*65536. + l1)*8.380955e-7;
  return (cputim);
}


long timer1()
/* This function returns the time, in ticks since midnight. */
{
  unsigned short h,m;
  long l;

  m=peek(0x0040,0x006c);
  h=peek(0x0040,0x006e);
  l=((long)h)*65536 + ((long)m);
  return(l);
}


int sysop1()
{
  if ((peekb(0,1047) & 0x10)==0)
    return(1);
  else
    return(0);
}

int okansi()
{
  if (thisuser.sysstatus & sysstatus_ansi)
    return(1);
  else
    return(0);
}


int okavt()
{
  if (thisuser.res[10])
    return(1);
  else
    return(0);
}


void frequent_init()
{
  mciok=1;
  msgr=1;
  fidotoss=0;
  ARC_NUMBER=-1;
  chatsoundon=1;
  curlsub=-1;
  ansiptr=0;
  avtptr=0;
  curatr=0x07;
  outcom=0;
  incom=0;
  charbufferpointer=0;
  andwith=0xff;
  checkit=0;
  topline=0;
  screenlinest=defscreenbottom+1;
  endofline[0]=0;
  hangup=0;
  hungup=0;
  chatcall=0;
  chatreason[0]=0;
  useron=0;
  change_color=0;
  chatting=0;
  echo=1;
  irt[0]=0;
  irt_name[0]=0;
  okskey=0;
  lines_listed=0;
  read_user(1,&thisuser);
  if (thisuser.inact & inact_deleted)
    fwaiting=0;
  else
    fwaiting=thisuser.waiting;
  okmacro=1;
  okskey=1;
  mailcheck=0;
  smwcheck=0;
  in_extern=0;
  gatfn[0]=0;
  use_workspace=0;
  extratimecall=0.0;
  two_color=0;
  using_modem=0;
  set_global_handle(0);
  live_user=1;
  _chmod(dszlog,1,0);
  unlink(dszlog);
  ltime=0;
}


void read_in_file(char *fn, messagerec *m, int maxary)
{
  int i,i1,i2;
  char *buf,s[81];
  long l,l1;

  for (i=0; i<maxary; i++) {
    m[i].stored_as=0L;
    m[i].storage_type=255;
  }
  sprintf(s,"%s%s",syscfg.gfilesdir,fn);
  i=open(s,O_RDWR | O_BINARY);
  if (i<0) {
    err(1,s,"In Read_in_file");
  }
  l=filelength(i);
  buf=(char *) farmalloc(l);
  lseek(i,0L,SEEK_SET);
  if (buf==NULL) {
    err(3,"","In Read_in_file");
  }
  read(i,(void *) buf,l);
  close(i);
  i1=0;
  for (l1=0; l1<l; l1++) {
    if (buf[l1]=='`') {
      i1=1;
      i2=0;
    } else
      if (i1) {
        if ((buf[l1]>='0') && (buf[l1]<='9')) {
          i2*=10;
          i2+=(buf[l1])-'0';
        } else {
          while ((l1<l) && (buf[l1]!=10))
            ++l1;
          ++l1;
          if ((i2>=0) && (i2<maxary))
            m[i2].stored_as=l1;
          i1=0;
        }
      }
  }
  farfree((void *) buf);
}


void far *mallocx(unsigned long l)
{
  void *x;

  x=farmalloc(l);
  if (!x) {
    err(3,"","In Mallocx");
  }
  return(x);
}



void fix_user_rec(userrec *u)
{
  u->name[30]=0;
  u->realname[20]=0;
  u->callsign[6]=0;
  u->phone[12]=0;
  u->pw[20]=0;
  u->laston[8]=0;
  u->note[40]=0;
  u->macros[0][80]=0;
  u->macros[1][80]=0;
  u->macros[2][80]=0;
}


void close_user()
{
  if (userfile!=-1) {
    close(userfile);
    userfile=-1;
  }
}

void open_user()
{
  char s[81];

  if (userfile==-1) {
    sprintf(s,"%sUSER.LST",syscfg.datadir);
    userfile=open(s,O_RDWR | O_BINARY);
    if (userfile<0&&userfile!=-2) {
      userfile=-1;
    }
  }
}


int number_userrecs()
{
  open_user();
  return((int) (filelength(userfile)/syscfg.userreclen)-1);
}

void read_user(unsigned int un, userrec *u)
{
  long pos;
  char s[80];
  int i;

  open_user();
  if(userfile==-2) sysoplog(">*< File Locked!!! >*<");
  if ((userfile<0) || (un>number_userrecs())) {
    u->inact=inact_deleted;
    fix_user_rec(u);
    return;
  }

  if (((useron) && (un==usernum)) || ((wfc) && (un==1))) {
    *u=thisuser;
    fix_user_rec(u);
    return;
  }

  pos=((long) syscfg.userreclen) * ((long) un);
  lseek(userfile,pos,SEEK_SET);
  i=read(userfile, (void *)u, syscfg.userreclen);
  if (i==-1) {
    open_user();
    if ((userfile<0) || (un>number_userrecs())) {
      u->inact=inact_deleted;
      fix_user_rec(u);
      return;
    }
    pos=((long) syscfg.userreclen) * ((long) un);
    lseek(userfile,pos,SEEK_SET);
    i=read(userfile, (void *)u, syscfg.userreclen);
    if (i==-1) {
      pl("COULDN'T READ USER.");
    }
    close_user();
  }
  fix_user_rec(u);
}


void write_user(unsigned int un, userrec *u)
{
  long pos;
  char s[80];
  unsigned char oldsl;
  int i;

  if(usernum==0) return;
  if (userfile==-1) {
    sprintf(s,"%sUSER.LST",syscfg.datadir);
    userfile=open(s,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
  }
  if (((useron) && (un==usernum)) || ((wfc) && (un==1))) {
    thisuser=*u;
  }
  pos=((long) syscfg.userreclen) * ((long) un);
  lseek(userfile,pos,SEEK_SET);
  i=write(userfile, (void *)u, syscfg.userreclen);
  if (i==-1) {
    sprintf(s,"%sUSER.LST",syscfg.datadir);
    userfile=open(s,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
    pos=((long) syscfg.userreclen) * ((long) un);
    lseek(userfile,pos,SEEK_SET);
    i=write(userfile, (void *)u, syscfg.userreclen);
    if (i==-1) {
      pl("COULDN'T WRITE USER.");
    }
    close_user();
  }
}


void save_status()
{
  char s[80];

  sprintf(s,"%sSTATUS.DAT",syscfg.datadir);
  statusfile=open(s,O_RDWR | O_BINARY);
  write(statusfile, (void *)(&status), sizeof(statusrec));
  close(statusfile);
  statusfile=-1;
}




double ratio()
{
  double r;

  if (thisuser.dk==0)
    return(99.999);
  r=((float) thisuser.uk) / ((float) thisuser.dk);
  if (r>99.998)
    r=99.998;
  return(r);
}


double post_ratio()
{
  double r;

  if (thisuser.logons==0)
    return(99.999);
  r=((float) thisuser.msgpost) / ((float) thisuser.logons);
  if (r>99.998)
    r=99.998;
  return(r);
}

char *pnam(userrec *u1, unsigned int un)
{
  static char o[81];
  int i,f,p;
  userrec u;

  u=*u1;
  f=1;
  for (p=0; p<strlen(u.name); p++) {
    if (f) {
      if ((u.name[p]>='A') && (u.name[p]<='Z'))
	f=0;
      o[p]=u.name[p];
    } else {
      if ((u.name[p]>='A') && (u.name[p]<='Z'))
        o[p]=u.name[p]-'A'+'a';
      else {
        if ((u.name[p]>=' ') && (u.name[p]<='/'))
          f=1;
        o[p]=u.name[p];
      }
    }
  }
  o[p++]=0;//32;
  o[p++]=0;//'#';
  itoa(un,&o[p],10);
  o[p]=0;
  return(o);
}



char *nam(userrec *u1, unsigned int un)
{
  static char o[81];
  int i,f,p;
  userrec u;

  u=*u1;
  f=1;
  for (p=0; p<strlen(u.name); p++) {
    if (f) {
      if ((u.name[p]>='A') && (u.name[p]<='Z'))
	f=0;
      o[p]=u.name[p];
    } else {
      if ((u.name[p]>='A') && (u.name[p]<='Z'))
        o[p]=u.name[p]-'A'+'a';
      else {
        if ((u.name[p]>=' ') && (u.name[p]<='/'))
          f=1;
        o[p]=u.name[p];
      }
    }
  }
  o[p++]=32;
  o[p++]='#';
  itoa(un,&o[p],10);
  return(o);
}


char *nam1(userrec *u1, unsigned int un, unsigned int sy)
{
  static char o[81];
  char s[10];

  strcpy(o,nam(u1,un));
  if (sy) {
    sprintf(s," @%u",sy);
    strcat(o,s);
  }
  return(o);
}

double nsl()
{
  double tlt,tlc,tot,tpl,tpd,dd,rtn;
  slrec xx;

  dd=timer();
  if (useron) {
    if (timeon>(dd+60.0))
      timeon -= 24.0*3600.0;
    tot=(dd-timeon);
    xx=syscfg.sl[actsl];
    tpl=((double) xx.time_per_logon) * 60.0;
    tpd=((double) xx.time_per_day) * 60.0;
    tlc = tpl - tot + (thisuser.extratime) + extratimecall;
    tlt = tpd - tot - ((double) thisuser.timeontoday) + (thisuser.extratime);

    tlt=(((tlc)<(tlt)) ? (tlc) : (tlt));
    if (tlt<0.0)
      tlt=0.0;
    if (tlt>32767.0)
      tlt=32767.0;
    rtn=tlt;
  } else {
    rtn=1.00;
  }
  ltime=0;
  if (syscfg.executetime) {
    tlt=time_event-dd;
    if (tlt<0.0)
      tlt += 24.0*3600.0;
    if (rtn>tlt) {
      rtn=tlt;
      ltime=1;
    }
    check_event();
    if (do_event)
      rtn=0.0;
  }
  if (rtn<0.0)
    rtn=0.0;
  if (rtn>32767.0)
    rtn=32767.0;
  return(rtn);
}


char *date()
{
  static char ds[9];
  struct date today;

  getdate(&today);
  sprintf(ds,"%02d/%02d/%02d",today.da_mon,today.da_day,today.da_year-1900);
  return(ds);
}

char *times()
{
  static char ti[9];
  int h,m,s;
  double t;

  t=timer();
  h=(int) (t/3600.0);
  t-=((double) (h)) * 3600.0;
  m=(int) (t/60.0);
  t-=((double) (m)) * 60.0;
  s=(int) (t);
  sprintf(ti,"%02d:%02d:%02d",h,m,s);
  return(ti);
}

unsigned int finduser(char *s)
{
  int un;
  smalrec *sr;
  userrec u;
  char *ss;

  if (strcmp(s,"NEW")==0)
    return(-1);
  if (strcmp(s,"!-@NETWORK@-!")==0)
    return(-2);
  if (strcmp(s,"!-@REMOTE@-!")==0)
    return(-3);
  if (strncmp(s,"!=@",3)==0) {
    ss=s+strlen(s)-3;
    if (strcmp(ss,"@=!")==0) {
      strcpy(s,s+3);
      s[strlen(s)-3]=0;
      return(-4);
    }
  }

  if ((un=atoi(s))>0) {
    if (un>number_userrecs())
      return(0);
    read_user(un,&u);
    if (u.inact & inact_deleted)
      return(0);
    return(un);
  }

  sr=(smalrec *) bsearch((void *)s,
			 (void *)smallist,
			 (size_t)status.users,
			 (size_t)sizeof(smalrec),
			 (int _Cdecl (*) (const void *, const void *))strcmp);
  if (sr==0L)
    return(0);
  else {
    read_user(sr->number,&u);
    if (u.inact & inact_deleted)
      return(0);
    else
      return(sr -> number);
  }
}


void changedsl()
{
  int i,i1,i2,i3,i4,ok,dp,ddp;
  subboardrec s;
  directoryrec d;
  usersubrec s1;

  topscreen();
  dp=0;
  umaxsubs=0;
  umaxdirs=0;
  dc[dp++]='/';
  ddp=0;
  dcd[ddp++]='/';
  for (i=0; i<3; i++) {
    s1.keys[i]=0;
  }
  s1.subnum=-1;
  for (i=0; i<MAX_SUBS; i++)
    usub[i]=s1;
  for (i=0; i<MAX_DIRS; i++)
    udir[i]=s1;
  i1=1;
  i2=0;
  i3=0;
  for (i=0; i<num_subs; i++) {
    ok=1;
    s=subboards[i];
    if (actsl<s.readsl) ok=0;
    if (thisuser.age<s.age) ok=0;
    if (s.ar) if(!(thisuser.ar & s.ar)) ok=0;
    if ((s.anony & anony_ansi_only) && (!okansi())) ok=0;
    if (!strchr(conf[curconf].flagstr,s.key)&&s.key!='@'&&!strchr(conf[curconf].flagstr,'@')) ok=0;
    if (ok) {
      s1.subnum=i;
        if ((i1 % 10)==0)
          dc[dp++]=('0'+(i1/10));
        itoa(i1++,s1.keys,10);
        s1.subnum=i;
        for (i4=i3; i4>i2; i4--)
          usub[i4]=usub[i4-1];
        i3++;
        usub[i2++]=s1;
        umaxsubs++;
    }
  }
  i1=1;
  i2=0;
  for (i=0; i<num_dirs; i++) {
    ok=1;
    d=directories[i];
    if (!slok(d.acs,1)) ok=0;
    if (d.dar) if ((d.dar & thisuser.dar)==0) ok=0;
    if(!strchr(conf[curconf].flagstr,d.confnum)&&d.confnum!='@'&&!strchr(conf[curconf].flagstr,'@')) ok=0;
    if (ok) {
      s1.subnum=i;
      if (i==0)
        strcpy(s1.keys,"0");
      else {
        if ((i1 % 10)==0)
          dcd[ddp++]=('0'+(i1/10));
        itoa(i1++,s1.keys,10);
      }
      udir[i2++]=s1;
      umaxdirs++;
    }
  }
  dcd[ddp]=0;
  dc[dp]=0;
}


void isr(int un, char *name)
{
  int cp,i;
  char s[81];
  smalrec sr;

  cp=0;
  while ((cp<status.users) && (strcmp(name,(smallist[cp].name))>0))
    ++cp;
  memmove(&(smallist[cp+1]),&(smallist[cp]),sizeof(smalrec)*(status.users-cp));
  strcpy(sr.name,name);
  sr.number=un;
  smallist[cp]=sr;
  sprintf(s,"%suser.idx",syscfg.datadir);
  i=open(s,O_RDWR | O_BINARY | O_TRUNC);
  if (i<0) {
    err(1,s,"In ISR");

  }
  ++status.users;
  save_status();
  write(i,(void *) (smallist), (sizeof(smalrec) * status.users));
  close(i);
}


void dsr(char *name)
{
  int cp,i;
  char s[81];
  smalrec sr;

  cp=0;
  while ((cp<status.users) && (strcmp(name,(smallist[cp].name))!=0))
    ++cp;
  if (strcmp(name,(smallist[cp].name))) {
    sprintf(s,"6%s NOT ABLE TO BE DELETED",name);
    sl1(0,s);
    sl1(0,"9### 7Reset User Index to fix it");
    return;
  }
  memmove(&(smallist[cp]),&(smallist[cp+1]),sizeof(smalrec)*(status.users-cp));
  sprintf(s,"%suser.idx",syscfg.datadir);
  i=open(s,O_RDWR | O_BINARY | O_TRUNC | O_CREAT, S_IREAD | S_IWRITE);
  if (i<0) {
    err(4,s,"In Dsr");
  }
  --status.users;
  save_status();
  write(i,(void *) (smallist), (sizeof(smalrec) * status.users));
  close(i);
}


void wait(double d)
{
  long l1;

  l1=((long) (18.2*d));
  l1 += timer1();

  enable();
  while (timer1()<l1)
    ;
}

void wait1(long l)
{
  long l1;

  l1 = timer1()+l;

  enable();
  while (timer1()<l1)
    ;
}


double freek1(char *s)
{
  int d;

  d=cdir[0];
  if (s[1]==':')
    d=s[0];
  d=d-'A'+1;
  return(freek(d));
}


int exist(char *s)
{
  int i;
  struct ffblk ff;

  i=findfirst(s,&ff,0);
  if (i)
    return(0);
  else
    return(1);
}


void send_net(net_header_rec *nh, unsigned int *list, char *text)
{
  int f;
  char s[100];

  sprintf(s,"%sP1.NET",syscfg.datadir);
  f=open(s,O_RDWR | O_BINARY | O_CREAT, S_IREAD | S_IWRITE);
  lseek(f,0L,SEEK_END);
  if (!list)
    nh->list_len=0;
  if (!text)
    nh->length=0;
  if (nh->list_len)
    nh->tosys=0;
  write(f,(void *)nh,sizeof(net_header_rec));
  if (nh->list_len)
    write(f,(void *)list,2*(nh->list_len));
  if (nh->length)
    write(f,(void *)text,nh->length);
  close(f);
}


void send_email()
{
  char s1[81],*ss;
  int i;
  unsigned short sy,un;

  nl();
  nl();
  pl("Enter user's name or number.");
  outstr(":");
  input(s1,40);
  irt[0]=0;
  irt_name[0]=0;
  parse_email_info(s1,&un,&sy);
  if (un || sy)
    email(un,sy,0,0);
}

