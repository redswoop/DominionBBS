#include "vars.h"

#pragma hdrstop

#include <math.h>



void read_call_out_list()
{
  char s[161],b[256],s1[81],*ss;
  int f,i,i1,i2,n,cur_sys;
  long l,p;
  float fl;

  sprintf(s,"%sCALLOUT.NET",syscfg.datadir);
  f=open(s,O_RDWR | O_BINARY);
  if (f<0)
    con=NULL;
  else {
    l=filelength(f);
    if ((ss=malloca(l+512))==NULL)
      err(3,"","In Connect1.C");
    read(f,(void *)ss,(int) l);
    close(f);
    num_call_sys=0;
    for (p=0L; p<l; p++)
      if (ss[p]=='@')
	++num_call_sys;
    farfree(ss);
    if ((con=malloca(((long)(num_call_sys+2))*sizeof(net_call_out_rec)))==NULL)
      err(3,"","In Connect1.C");
    f=open(s,O_RDWR | O_BINARY);
    if ((ss=malloca(l+512))==NULL)
      err(3,"","In Connect1.C");
    read(f,(void *)ss,(int) l);
    close(f);
    p=0L;
    cur_sys=-1;
    while (p<l) {
      while ((p<l) && (strchr("@%/\"&-=+~!();^",ss[p])==NULL))
	++p;
      if (p<l) {
	switch(ss[p]) {
	  case '@':
	    ++p;
	    ++cur_sys;
	    con[cur_sys].macnum=0;
	    con[cur_sys].options=0;
	    con[cur_sys].call_anyway=0;
	    con[cur_sys].password[0]=0;
	    con[cur_sys].sysnum=atoi(&(ss[p]));
            con[cur_sys].min_hr=-1;
            con[cur_sys].max_hr=-1;
            con[cur_sys].times_per_day=0;
	    break;
          case '&':
	    con[cur_sys].options |= options_sendback;
	    ++p;
	    break;
          case '-':
	    con[cur_sys].options |= options_ATT_night;
	    ++p;
	    break;
          case '=':
	    con[cur_sys].options |= options_PCP_night;
	    ++p;
	    break;
          case '+':
	    con[cur_sys].options |= options_no_call;
	    ++p;
	    break;
	  case '~':
	    con[cur_sys].options |= options_receive_only;
	    ++p;
	    break;
	  case '!':
	    con[cur_sys].options |= options_once_per_day;
	    ++p;
            con[cur_sys].times_per_day=atoi(&(ss[p]));
            if (!con[cur_sys].times_per_day)
              con[cur_sys].times_per_day=1;
	    break;
	  case '%':
	    ++p;
	    con[cur_sys].macnum=(unsigned char) atoi(&(ss[p]));
	    break;
	  case '/':
	    ++p;
	    con[cur_sys].call_anyway=(unsigned char) atoi(&(ss[p]));
	    break;
          case '(':
            ++p;
            con[cur_sys].min_hr = (unsigned char) atoi(&(ss[p]));
            break;
          case ')':
            ++p;
            con[cur_sys].max_hr = (unsigned char) atoi(&(ss[p]));
            break;
          case ';':
            ++p;
            con[cur_sys].options |= options_compress;
            break;
          case '^':
            ++p;
            con[cur_sys].options |= options_hslink;
            break;
	  case '\"':
	    ++p;
	    i=0;
            while ((i<19) && (ss[p+(long)i]!='\"'))
	      ++i;
	    for (i1=0; i1<i; i1++)
	      con[cur_sys].password[i1]=ss[p+(long)i1];
	    con[cur_sys].password[i]=0;
	    p+=(long)(i+1);
	    break;
	}
      }
    }
    farfree(ss);
  }
}


void write_call_out_list()
{
  char s[161],b[256],s1[81],*ss;
  int f,i,i1,i2,n,cur_sys;
  long l,p;
  float fl;

  sprintf(s,"%sCALLOUT.NET",syscfg.datadir);
  f=open(s,O_RDWR | O_BINARY | O_CREAT | O_TRUNC, S_IREAD | S_IWRITE);
  if (f>0) {
    for (i=0; i<num_call_sys; i++) {
      sprintf(s,"@%-6u ",con[i].sysnum);
      if (con[i].macnum) {
        sprintf(s1,"%%%-3u ",(int) con[i].macnum);
	strcat(s,s1);
      } else
        strcat(s,"     ");
      if (con[i].call_anyway) {
        sprintf(s1,"/%-3u ",(int) con[i].call_anyway);
	strcat(s,s1);
      } else
        strcat(s,"     ");
      sprintf(s1,"%c %c %c %c %c %c %c %c",
        (con[i].options & options_sendback)?'&':' ',
        (con[i].options & options_ATT_night)?'-':' ',
        (con[i].options & options_PCP_night)?'=':' ',
        (con[i].options & options_no_call)?'+':' ',
        (con[i].options & options_receive_only)?'~':' ',
        (con[i].options & options_compress)     ? ';' : ' ',
        (con[i].options & options_hslink) ? '^' : ' ',
        (con[i].options & options_once_per_day) ? '!' : ' ');
      strcat(s,s1);
      if ((con[i].options & options_once_per_day) &&
          (con[i].times_per_day!=1)) {
        sprintf(s1,"%-3u ",(int) con[i].times_per_day);
        strcat(s,s1);
      } else
        strcat(s,"    ");
      if (con[i].min_hr>0) {
        sprintf(s1,"(%-3u ",(int) con[i].min_hr);
        strcat(s,s1);
      } else
        strcat(s,"     ");
      if (con[i].max_hr>0) {
        sprintf(s1,")%-3u ",(int) con[i].max_hr);
        strcat(s,s1);
      } else
        strcat(s,"     ");

      sprintf(s1,"\"%s\"\r\n",con[i].password);
      strcat(s,s1);
      write(f,(void *)s,strlen(s));
    }
    close(f);
  }
}



void read_bbs_list()
{
  char s[161];
  int f,i;
  long l,p;

  csn=NULL;
  cnn=NULL;
  con=NULL;
  num_sys=0;
  num_sys_list=0;
  num_call_sys=0;
  if (syscfg.systemnumber==0)
    return;
  sprintf(s,"%sBBSDATA.NET",syscfg.datadir);
  f=open(s,O_RDWR | O_BINARY);
  if (f>0) {
    l=filelength(f);
    num_sys_list=(int) (l/sizeof(net_system_list_rec));
    if ((csn=malloca(l+512L))==NULL)
      err(3,"","In Connect1.C");
    for (i=0; i<num_sys_list; i+=256) {
      read(f,(void *)&(csn[i]),256*sizeof(net_system_list_rec));
    }
    close(f);
    read_call_out_list();
  }
}


void read_bbs_list_index()
{
  char s[161];
  int f;
  long l;

  csn=NULL;
  cnn=NULL;
  con=NULL;
  num_sys=0;
  num_sys_list=0;
  num_call_sys=0;
  if (syscfg.systemnumber==0)
    return;
  sprintf(s,"%sBBSDATA.IND",syscfg.datadir);
  f=open(s,O_RDWR | O_BINARY);
  if (f>0) {
    l=filelength(f);
    num_sys_list=(int) (l/2);
    if ((csn_index=malloca(l))==NULL)
      err(3,"","In Connect1.C");
    read(f,(void *)csn_index,l);
    close(f);
    read_call_out_list();
  } else
    read_bbs_list();
}



net_system_list_rec *next_system(unsigned int ts)
{
  int i,f;
  static net_system_list_rec csne;
  char s[81];

  if (csn) {
    for (i=0; i<num_sys_list; i++)
      if (csn[i].sysnum==ts) {
        if (csn[i].forsys==65535)
          return(NULL);
        else
          return((net_system_list_rec *) &(csn[i]));
      }
    return(NULL);
  } else {
    for (i=0; i<num_sys_list; i++)
      if (csn_index[i]==ts) {
        sprintf(s,"%sBBSDATA.NET",syscfg.datadir);
        f=open(s,O_RDONLY | O_BINARY);
        lseek(f,sizeof(net_system_list_rec)*((long)i),SEEK_SET);
        read(f,&csne,sizeof(net_system_list_rec));
        close(f);
        if (csne.forsys==65535)
          return(NULL);
        else
          return(&csne);
      }
    return(NULL);
  }
}



void read_contacts()
{
  int i,f;
  char s[81];
  long l;

  if (ncn!=NULL)
    farfree(ncn);
  ncn=NULL;
  num_ncn=0;

  sprintf(s,"%sCONTACT.NET",syscfg.datadir);
  f=open(s,O_RDWR | O_BINARY);
  if (f>=0) {
    l=filelength(f);
    num_ncn=(int) (l/sizeof(net_contact_rec));
    if ((ncn=malloca((num_ncn+2)*sizeof(net_contact_rec)))==NULL)
      err(3,"","In Connect1.C");
    lseek(f,0L,SEEK_SET);
    read(f,(void *)ncn,num_ncn*sizeof(net_contact_rec));
    close(f);
  }
}

