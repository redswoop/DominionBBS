#include "vars.h"

#pragma hdrstop
#ifdef USETEDIT
#include <dir.h>



#define utoa(s,v,r) ultoa((unsigned long)(s),v,r)


struct line *read_file(char *fn, int *numlines)
{
  char b[1024],s[160],s1[160];
  int f,i,n,nb,cb,sp,oor;
  struct line *l,*l1,*topline;

  *numlines=-1;
  oor=0;
  topline=NULL;
  sprintf(s,"%s",fn);
  f=open(s,O_RDWR | O_BINARY);
  if (f<0) {
    nl();
    pl("File not found.");
    nl();
    return(NULL);
  }
  nb=read(f,(void *)b,1024);
  cb=0;
  sp=0;
  *numlines=0;
  while ((nb) && (!oor)) {
    if (b[cb]==13) {
      s[sp]=0;
      sp=0;
      if (farcoreleft()<10240) {
        nl();
        pl("Ran out of memory.  Not all of file read.");
        nl();
        oor=1;
      } else {
        l1=(struct line *)farmalloc((long) sizeof(struct line));
        strcpy((l1->text),s);
        l1->next=NULL;
        l1->prev=NULL;
        if (topline==NULL) {
          topline=l1;
          l=l1;
        } else {
          l->next=l1;
          l1->prev=l;
          l=l1;
        }
        ++(*numlines);
      }
    } else {
      if (b[cb]!=10)
        s[sp++]=b[cb];
    }
    ++cb;
    if (cb==nb) {
      nb=read(f,(void *)b,1024);
      cb=0;
    }
  }
  return(topline);
}

void kill_file(struct line *topline)
{
  struct line *l,*l1;

  l=topline;
  while (l!=NULL) {
    l1=l->next;
    farfree((void *)l);
    l=l1;
  }
}

void save_file(char *fn, struct line *topline)
{
  int i,f;
  char s[170];
  struct line *l,*l1;

  nl();
  pl("Saving...");
  sprintf(s,"%s",fn);
  f=open(s,O_RDWR | O_BINARY | O_CREAT | O_TRUNC, S_IREAD | S_IWRITE);
  l=topline;
  while (l!=NULL) {
    strcpy(s,(l->text));
    strcat(s,"\r\n");
    write(f,(void *)s,strlen(s));
    l=l->next;
  }
  s[0]=26;
  write(f,(void *)s,1);
  close(f);
}

int printl(int n, struct line *l)
{
  int abort;
  char s[160];

  abort=0;
  if (n<1)
    strcpy(s,"     [TOP]");
  else
    if (l==NULL)
      strcpy(s,"     [END]");
    else
      sprintf(s,"%3d: %s",n,(l->text));
  pla(s,&abort);
  if (abort)
    nl();
  return(abort);
}

#endif
void tedit(char *fn)
{
#ifdef USETEDIT
  struct line *topline,*l,*l1,*c,*bottomline;
  int numlines,curline,i,i1,i2,done,save,abort;
  char s[160],s1[160],rollover[160];

  rollover[0]=0;
  thisuser.screenchars -= 5;
  topline=NULL;
  numlines=0;
  curline=0;
  topline=read_file(fn,&numlines);
  npr("%d lines read in.\r\n",numlines);
  nl();
  done=0;
  save=0;
  if (numlines>0) {
    curline=1;
    bottomline=topline;
    while ((bottomline->next)!=NULL)
      bottomline=bottomline->next;
  } else
    curline=0;
  if (numlines<1)
    numlines=0;
  c=topline;
  printl(curline,c);
  do {
    outstr(":");
    input(s,10);
    i=atoi(s);
    if ((s[0]>='0') && (s[0]<='9')) {
      i-=curline;
      if (i==0)
        strcpy(s,"~");
      else
        if (i>0) {
          s[0]='+';
          itoa(i,&(s[1]),10);
        } else {
          itoa(i,s,10);
        }
    }
    if (s[0]==0)
      strcpy(s,"+");
    switch(s[0]) {
      case '?':
        printmenu(11);
        break;
      case 'Q':
        done=1;
        save=0;
        break;
      case 'S':
        done=1;
        save=1;
        break;
      case 'L':
        i=curline;
        l=c;
        while ((l!=NULL) && (printl(i,l)==0)) {
          l=l->next;
          ++i;
        }
        break;
      case 'T':
        c=topline;
        if (topline==NULL)
          curline=0;
        else
          curline=1;
        printl(curline,c);
        break;
      case 'B':
        c=NULL;
        curline=numlines+1;
        printl(curline,c);
        break;
      case '-':
        if (curline) {
          i=atoi(&(s[1]));
          if (i==0)
            i=1;
          for (i1=0; (i1<i) && (curline); i1++) {
            if (c==NULL)
              c=bottomline;
            else
              c=c->prev;
            --curline;
          }
        }
        printl(curline,c);
        break;
      case '+':
        if (curline!=numlines+1) {
          i=atoi(&(s[1]));
          if (i==0)
            i=1;
          for (i1=0; (i1<i) && (curline!=numlines+1); i1++) {
            if (c==NULL)
              c=topline;
            else
              c=c->next;
            ++curline;
          }
        }
        printl(curline,c);
        break;
      case 'D':
        i=atoi(&(s[1]));
        if (i==0)
          i=1;
        for (i1=0; (i1<i) && (c!=NULL); i1++) {
          if (c->prev==NULL)
            if (c->next==NULL) {
              topline=NULL;
              bottomline=NULL;
            } else
              topline=c->next;
          else
            if (c->next==NULL)
              bottomline=c->prev;
          l=c;
          if (c->prev!=NULL)
            c->prev->next=c->next;
          if (c->next!=NULL)
            c->next->prev=c->prev;
          c=c->next;
          farfree((void *)l);
          --numlines;
        }
        printl(curline,c);
        break;
      case 'P':
        printl(curline,c);
        break;
      case 'C':
        nl();
        prt(5,"Clear workspace? ");
        if (yn()) {
          kill_file(topline);
          topline=NULL;
          bottomline=NULL;
          c=NULL;
          numlines=0;
          curline=0;
          pl("File cleared.");
        }
        break;
      case 'I':
        nl();
        pl("Enter '.' on its own line to exit insert mode.");
        i1=0;
        do {
          if (farcoreleft()<10240) {
            nl();
            pl("Not enough memory left to insert anything.");
            nl();
            i1=1;
          } else {
            sprintf(s1,"%3d: ",curline);
            if (curline<1)
              strcpy(s1,"  1: ");
            outstr(s1);
            inli(s1,rollover,150,1);
            if (strcmp(s1,".")==0)
              i1=1;
            else {
              l=(struct line *)farmalloc(sizeof(struct line));
              strcpy((l->text),s1);
              if (c!=NULL) {
                l->next=c;
                if (c->prev!=NULL) {
                  c->prev->next=l;
                  l->prev=c->prev;
                  c->prev=l;
                } else {
                  c->prev=l;
                  l->prev=NULL;
                  topline=l;
                }
              } else {
                if (topline==NULL) {
                  l->prev=NULL;
                  l->next=NULL;
                  topline=l;
                  bottomline=l;
                  curline=1;
                } else
                  if (curline==numlines+1) {
                    l->prev=bottomline;
                    bottomline->next=l;
                    l->next=NULL;
                    bottomline=l;
                  } else {
                    l->prev=NULL;
                    l->next=topline;
                    topline->prev=l;
                    c=topline;
                    topline=l;
                    curline=1;
                  }
              }
              ++numlines;
              ++curline;
            }
          }
        } while ((!i1) && (!hangup));
        break;
    }
  } while ((!done) && (!hangup));
  thisuser.screenchars += 5;
  if (save)
    save_file(fn,topline);
  kill_file(topline);
#endif
}


