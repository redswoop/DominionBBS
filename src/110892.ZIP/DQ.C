#include "vars.h"
#pragma hdrstop

#include "strips.c"
#include "stristr.c"
#include "qwk.h"
#include "writline.c"


void xwriteqwkmsg (FILE *fp,FILE *idx,long len,char *hold,char name[25],char title[25],char date[25],char to[25],int msgnum,int area);

void writeqwk(char *b, long len, char *title,FILE *msd,FILE *idx,int msgnum,int area)
{
    char s1[81],s2[128],ch1,n[41],to[41],d[41];
    int i,p,p1,p2,cur;

    p=0;
    while ((b[p]!=13) && ((long)p<len) && (p<60))
        n[p]=b[p++];
    n[p]=0;
    ++p;

    p1=0;

    if (b[p]==10) ++p;
    while ((b[p+p1]!=13) && ((long)p+p1<len) && (p1<60))
     d[p1]=b[(p1++)+p];
    d[p1]=0;

    p1+=2;
    p2=0;

    while ((b[p+p1+p2]!=13) && ((long)p+p1+p2<len) && (p2<60))
      to[p2]=b[(p2++)+p1+p];
    to[p2]=0;
    if(!strchr(to,'�')) {
      strcpy(to,"All");
      cur=p+p1;
    } else {
      strcpy(to,to+1); cur=p+p1+p2;
    }

    pl("Xwriting Message");
    xwriteqwkmsg(msd,idx,len-cur,&b[cur],n,title,d,to,msgnum,area);
}

void xwriteqwkmsg (FILE *fp,FILE *idx,long len,char *hold,char name[25],char title[25],char date[25],char to[25],int msgnum,int area)
{

    QWKHDR hdr;
    long pos;
    char *ln,*p,s[81];
    unsigned int w;
    long bpos;
    QWKIDX i;
    int i1;


    pl("Doing header");
    pos = ftell(fp);
    strncpy(hdr.from,name,25);
    strncpy(hdr.to,to,25);
    strncpy(hdr.subj,title,25);
    hdr.subj[25] = hdr.to[25] = hdr.from[25] = 0;
    hdr.status = QWKPUBUNREAD;
    hdr.msgnum = msgnum;
    hdr.confnum = 1;
    hdr.date = time(NULL);
    *hdr.pword = 0;
    hdr.repnum = 0;
    hdr.numchunks = (long)(len / QWKBLKSIZE) + ((len % QWKBLKSIZE) != 0);
    hdr.live = 1;

    if(!qwkwritehdr(fp,&hdr,0)) {
        return;
    }
    pl("done writing header");

         p = hold;
/*    pl("Treating it");
        while (*p) {
          if(*p == '\x8d' || *p == '\n') {
              memmove(p,&p[1],len - ((unsigned int)p - (unsigned int)hold));
              len--;
              if(!len) break;
              continue;
          }
          else p++;
        }
        pl("part one is done");
        if(*(p - 1) != '\r' && p > hold) {
          *p = '\r';
          p[1] = 0;
        }
    
    pl("Treat done");*/

    i1=0;
    p = hold;
    while(p[i1]) {
        if(p[i1]=='\n') p[i1]=32;
        i1++;
    }

//    p = hold;
    len = 0;
    pl("writing out message");
    while(p && *p) {
        ln = write_line(&p,76,1);
        len += fprintf(fp,"%s\xe3",ln);
    }

    /* fill out last block w/ spaces */

    pl("Computing size of extra");
    hdr.numchunks = (long)((len / QWKBLKSIZE) + ((len % QWKBLKSIZE) != 0));
    w = ((unsigned int)hdr.numchunks * QWKBLKSIZE) - len;
    while(w--) {
        fputc(' ',fp);
    }
    pl("Done Fputcing");

    /* backtrack and rewrite header */

    bpos = ftell(fp);
    fseek(fp,pos,SEEK_SET);
    qwkwritehdr(fp,&hdr,0);
    fseek(fp,bpos,SEEK_SET);
    pl("done rewrting header");

    i.recnum = (float)2.0;
//    (pos / (long)QWKBLKSIZE);
    i.junk = (char)area;
    fwrite(&i,sizeof(QWKIDX),1,idx);
/*    if(qwkwriteidx(idx,&i)==NULL) {
        pl("error in IDX Write");
        pausescr();
    }*/
    pl("done with IDX write");
    farfree(hold);
}

void qmailsys()
{
    int i,i1=0;
    char s[81],*b;
    long len;
    FILE *msd,*idx;

    msd=fopen("messages.dat","wb");
    qwkwriteblk(msd,"Not produced by Qmail, no Copyright (c) 1987 and No Rights Reserved.");

    npr("Scanning Sub %s [%d]\r\n",subboards[0].name,0);
    iscan(0);
    idx=fopen("000.ndx","wb");
    for(i1=1;i1<nummsgs;i1++) {
        pl("reading message");
        b=readfile(&msgs[i1].msg,subboards[0].filename,&len);
        writeqwk(b,len,msgs[i1].title,msd,idx,1,0);
    }
    fclose(idx);
    fclose(msd);
}
