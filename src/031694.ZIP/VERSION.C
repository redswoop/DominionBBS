char *wwiv_version = "Dominion Bulletin Board System v3.1 Beta";

unsigned int wwiv_num_version=31;

char *wwiv_date = __DATE__ ", "__TIME__;

unsigned int CRCVal = 3597;
