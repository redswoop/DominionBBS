

void savel(char *cl, char *atr, char *xl, char *cc)
{
    int i, i1;

    *cc = curatr;
    strcpy(xl, endofline);
    i = ((whereY() + topline) * 80) * 2;
    for (i1 = 0; i1 < whereX(); i1++) {
        cl[i1]  = scrn[i + (i1 * 2)];
        atr[i1] = scrn[i + (i1 * 2) + 1];
    }
    cl[whereX()]  = 0;
    atr[whereX()] = 0;
}


void restorel(char *cl, char *atr, char *xl, char *cc)
{
    int i;

    if (whereX())
        nl();
    for (i = 0; cl[i] != 0; i++) {
        setc(atr[i]);
        outchr(cl[i]);
    }
    setc(*cc);
    strcpy(endofline, xl);
}






void setfgc(int i)
{
    curatr = (curatr & 0xf8) | i;
}



void setbgc(int i)
{
    curatr = (curatr & 0x8f) | (i << 4);
}


void execute_ansi()
{
    int args[11], argptr, count, ptr, tempptr, ox, oy;
    char cmd, temp[11], teol[81], *clrlst = "04261537";
    union REGS r;

    if (ansistr[1] != '[') {

    } 
    else {
        argptr = tempptr = 0;
        ptr = 2;
        for (count = 0; count < 10; count++)
            args[count] = temp[count] = 0;
        cmd = ansistr[ansiptr - 1];
        ansistr[ansiptr - 1] = 0;
        while ((ansistr[ptr]) && (argptr<10) && (tempptr<10)) {
            if (ansistr[ptr] == ';') {
                temp[tempptr] = 0;
                tempptr = 0;
                args[argptr++] = atoi(temp);
            } 
            else
                temp[tempptr++] = ansistr[ptr];
            ++ptr;
        }
        if (tempptr && (argptr<10)) {
            temp[tempptr]  = 0;
            args[argptr++] = atoi(temp);
        }
        if ((cmd >= 'A') && (cmd <= 'D') && !args[0])
            args[0] = 1;
        switch (cmd) {
            case 'f':
                case 'H':
                movecsr(args[1] - 1, args[0] - 1);
            break;
            case 'A':
                movecsr(whereX(), whereY() - args[0]);
            break;
            case 'B':
                movecsr(whereX(), whereY() + args[0]);
            break;
            case 'C':
                movecsr(whereX() + args[0], whereY());
            break;
            case 'D':
                movecsr(whereX() - args[0], whereY());
            break;
            case 's':
                oldx = whereX();
            oldy = whereY();
            break;
            case 'u':
                movecsr(oldx, oldy);
            break;
            case 'J':
                if (args[0] == 2) {
                clrscrb();
            }
            break;
            case 'k':
                case 'K':
                ox = whereX();
            oy = whereY();
            r.x.cx = 80 - ox;
            r.h.ah = 0x09;
            r.h.bh = 0x00;
            r.h.al = 32;
            r.h.bl = curatr;
            int86(0x10,&r,&r);
            movecsr(ox, oy);

            break;
            case 'm':
                if (!argptr) {
                argptr = 1;
                args[0] = 0;
            }
            for (count = 0; count < argptr; count++)
                switch (args[count]) {
                    case 0: 
                        curatr = 0x07; 
                    break;
                    case 1: 
                        curatr = curatr | 0x08; 
                    break;
                    case 4: 
                        break;
                    case 5: 
                        curatr = curatr | 0x80;
                    break;
                    case 7:
                        ptr = curatr & 0x77;
                    curatr = (curatr & 0x88) | (ptr << 4) | (ptr >> 4);
                    break;
                    case 8: 
                        curatr = 0; 
                    break;
                    default:
                        if ((args[count] >= 30) && (args[count] <= 37))
                        setfgc(clrlst[args[count] - 30] - '0');
                    else if ((args[count] >= 40) && (args[count] <= 47))
                        setbgc(clrlst[args[count] - 40] - '0');
                }
            break;
        }
    }
    ansiptr = 0;
}

int kbhitb()
{
    union REGS r;
#ifdef MOUSE
    if(checklclick()) executemouse(getmx(),getmy());
#endif

    r.h.ah = 1;
    int86(0x16, &r, &r);
    return((r.x.flags & 64) == 0);
}

int empty(void)
{
    if(x_only)
	return 0;

    if (kbhitb() || (incom && comhit()) ||
        (charbufferpointer && charbuffer[charbufferpointer]))
        return(0);
    return(1);
}


char getchd()
{
    union REGS r;

    r.h.ah = 0x07;
    int86(0x21, &r, &r);
    return(r.h.al);
}


char getchd1()
{
    union REGS r;

    r.h.ah = 0x06;
    r.h.dl = 0xFF;
    int86(0x21, &r, &r);
    return((r.x.flags & 0x40) ? 255 : r.h.al);
}





/*
void makewindow(int x, int y, int xlen, int ylen)
{
    int i,xx,yy,old;
    unsigned char s[81];

    old=curatr;
    if (xlen>80)
        xlen=80;
    if (ylen>(screenbottom+1-topline))
        ylen=(screenbottom+1-topline);
    if ((x+xlen)>80)
        x=80-xlen;
    if ((y+ylen)>screenbottom+1)
        y=screenbottom+1-ylen;

    xx=whereX();
    yy=whereY();
    directvideo=1;
    textcolor(8);
    for (i=1; i<xlen-1; i++)
        s[i]=196;
    s[0]=194;
    s[xlen-1]=194;
    s[xlen]=0;
    movecsr(x,y);
    cprintf(" ");
    cprintf("�");
    cprintf(s);
    cprintf("�");
    cprintf(" ");
    s[0]=193;
    s[xlen-1]=193;
    movecsr(x,y+ylen-1);
    cprintf(" ");
    cprintf("�");
    cprintf(s);
    cprintf("�");
    cprintf(" ");
    movecsr(x+1,y+1);
    for (i=1; i<xlen-1; i++)
        s[i]=32;
    s[0]=179;
    s[xlen-1]=179;
    for (i=1; i<ylen-1; i++) {
        movecsr(x,i+y);
        cprintf(" ");
        cprintf("�");
        cprintf(s);
        cprintf("�");
        cprintf(" ");
    }
    movecsr(xx,yy);
    curatr=old;
}
*/



int rc;

void outsat(char *s, int x, int y)
{
    movecsr(x-1,y-1);
    outs(s);
}


void editdata(char *str,int len,int xcoord,int ycoord)
{
    int i;
    char s[81];

    strcpy(s,str);
    movecsr(xcoord-1,ycoord-1);
    editline(s,len,ALL,&rc,"");
    for(i=strlen(s)-1;i>=0 && s[i]==32;i--);
    s[i+1]=0;
    strcpy(str,s);
    curatr=15;
}


int editdig(char *str,int len,int xcoord,int ycoord)
{
    int real;

    movecsr(xcoord-1,ycoord-1);
    editline(str,len,NUM_ONLY,&rc,"");
    real=atoi(str);
    curatr=15;
    return(real);
}


void editline(char *s, int len, int status, int *returncode, char *ss)
{
    int i,j,k,oldatr,cx,cy,pos,ch,done,insert,i1;

    oldatr=curatr;
    cx=whereX();
    cy=whereY();
    for (i=strlen(s); i<len; i++)
        s[i]=32;
    s[len]=0;
    curatr=31;
    outs(s);
    movecsr(cx,cy);
    done=0;
    pos=0;
    insert=0;
    do {
        ch=getchd();
        if (ch==0) {
            ch=getchd();
            switch (ch) {
            case 59:
                done=1;
                *returncode=DONE;
                break;
            case 71: 
                pos=0; 
                movecsr(cx,cy); 
                break;
            case 79: 
                pos=len; 
                movecsr(cx+pos,cy); 
                break;
            case 77: 
                if (pos<len) {
                    pos++;
                    movecsr(cx+pos,cy);
                }
                break;
            case 75: 
                if (pos>0) {
                    pos--;
                    movecsr(cx+pos,cy);
                }
                break;
            case 72:
            case 15:
                done=1;
                *returncode=PREV;
                break;
            case 80:
                done=1;
                *returncode=NEXT;
                break;
            case 82:
                if (status!=SET) {
                    if (insert)
                        insert=0;
                    else
                        insert=1;
                }
                break;
            case 83:
                if (status!=SET) {
                    for (i=pos; i<len; i++)
                        s[i]=s[i+1];
                    s[len-1]=32;
                    movecsr(cx,cy);
                    outs(s);
                    movecsr(cx+pos,cy);
                }
                break;
            }
        } 
        else {
            if (ch>31) {
                if (status==UPPER_ONLY)
                    ch=toupper(ch);
                if (status==SET) {
                    ch=toupper(ch);
                    if (ch!=' ') {
                        i1=1;
                        for (i=0; i<len; i++)
                            if ((ch==ss[i]) && (i1)) {
                                i1=0;
                                pos=i;
                                movecsr(cx+pos,cy);
                                if (s[pos]==' ')
                                    ch=ss[pos];
                                else
                                    ch=' ';
                            }
                        if (i1)
                            ch=ss[pos];
                    }
                }
                if ((pos<len)&&((status==ALL) || (status==UPPER_ONLY) || (status==SET) ||
                    ((status==NUM_ONLY) && (((ch>='0') && (ch<='9')) || (ch==' '))))) {
                    if (insert) {
                        for (i=len-1; i>pos; i--)
                            s[i]=s[i-1];
                        s[pos++]=ch;
                        movecsr(cx,cy);
                        outs(s);
                        movecsr(cx+pos,cy);
                    } 
                    else {
                        s[pos++]=ch;
                        out1ch(ch);
                    }
                }
            } 
            else {
                ch=ch;
                switch(ch) {
                case 13:
                case 9:
                    done=1;
                    *returncode=NEXT;
                    break;
                case 27:
                    done=1;
                    *returncode=DONE;
                    break;
                case 8:
                    if (pos>0) {
                        if (insert) {
                            for (i=pos-1; i<len; i++)
                                s[i]=s[i+1];
                            s[len-1]=32;
                            pos--;
                            movecsr(cx,cy);
                            outs(s);
                            movecsr(cx+pos,cy);
                        } 
                        else {
                            pos--;
                            movecsr(cx+pos,cy);
                        }
                    }
                    break;
                }
            }
        }
    } 
    while (done==0);
    movecsr(cx,cy);
    curatr=oldatr;
    outs(s);
    movecsr(cx,cy);
}


void clickat(long byte,long bit,int x, int y)
{
    movecsr(x-1,y-1);
    if(byte & bit) {
        curatr=31;
        outs("�");
    } 
    else {
        curatr=15;
        outs(" ");
    }
}


int click(long *byt,long bit,int x, int y)
{
    long byte;
    int done=0,returncode=0;
    char ch;

    byte= *byt;

    while(!done) {
        movecsr(x-1,y-1);
        if(byte & bit) {
            curatr=31;
            outs("�");
        } 
        else {
            curatr=15;
            outs(" ");
        }

        movecsr(x-1,y-1);

        ch=getchd();
        if(!ch) {
            ch=getchd();
            switch (ch) {
            case 59:
                done=1;
                returncode=DONE;
                break;
            case 72:
                done=1;
                returncode=PREV;
                break;
            case 80:
                done=1;
                returncode=NEXT;
                break;
            }
            break;
        } 
        else
            switch(ch) {
        case 13:
            returncode=NEXT;
            done=1;
            break;
        case 32:
            togglebit(byte,bit);
            break;
        case 27:
            done=1;
            returncode=DONE;
            break;
        } 
    } 

    *byt= byte;
    curatr=15;
    return returncode;
}

















