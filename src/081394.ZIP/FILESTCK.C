#include <dir.h>
#include <string.h>


#include "filedir.h"

int EmptyStack(StackContainer *s)
{
    if(s->NumItem)
        return 0;
    return 1;
}

void CreateStack(StackContainer *s)
{
    s->NumItem=0;
}

void popStack(StackContainer *s)
{
    if(!EmptyStack(s))
        s->NumItem--;
}

void pushStack(StackContainer *s,stackItem *data)
{
    if(s->NumItem<STACKSIZE) {
        npr("putting %s on stack (%dth item)\r\n",data->alias,s->NumItem);
        memmove(&s->p[(s->NumItem)],data,sizeof(stackItem));
        s->NumItem++;
    }
}

void getStackItem(StackContainer *s,stackItem *data,int which)
{
    if(!EmptyStack(s)) {
        memmove(data,&s->p[which],sizeof(stackItem));
    }
}

void getStackTop(StackContainer *s,stackItem *data)
{
    getStackItem(s,data,s->NumItem-1);
}
