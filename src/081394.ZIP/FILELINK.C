#pragma hdrstop
#include <alloc.h>

#include "filedir.h"


Links *FindLink(PWDrec *file,int which)
{
    int i;
    Links *p=file->lh;

    if(which<0||which>file->numl)
        return NULL;

    if(!which)
        return p;

    for(i=0;i<which;i++)
        p=p->next;

    return p;           
}

int GetLink(PWDrec *file,int which,linkRec *v)
{
    Links *p;

    if(which<0||which>file->numl) {
        puts("getitem error out of bounds");
        exit(100);
        //        return 1;
    }

    p=FindLink(file,which);
    (*v)=p->data;
    return 0;
}

int PutLink(PWDrec *file,int which,linkRec *v)
{
    Links *p;

    if(which<0||which>file->numl) {
        puts("putitem error out of bounds");
        exit(101);
        //        return 1;
    }

    p=FindLink(file,which);
    p->data=(*v);
    return 0;
}

int InsertLink(PWDrec *file,int as,linkRec v)
{
    Links *p,*q;

    if(!as) {
        if(file->numl<1) {
            file->lh=(Links *)malloc(sizeof(Links));
            if(file->lh==NULL) {
                puts("argh 1!");
                exit(0);
            }
            file->lh->data=v;
            file->lh->next=0;
        } 
        else {
            q=(Links *)malloc(sizeof(Links));
            if(q==NULL) {
                puts("argh 2!");
                exit(0);
            }
            q->data=v;
            q->next=file->lh;
            file->lh=q;
        }
        file->numl++;
        return 0;
    }
    p=FindLink(file,as-1);
    q=(Links *)malloc(sizeof(Links));
    if(q==NULL) {
        puts("argh 3!");
        exit(0);
    }
    q->data=v;
    q->next=p->next;
    p->next=q;
    file->numl++;
    return 0;
}

int DeleteLink(PWDrec *file,int which)
{
    Links *p,*q;

    if(which<0||which>file->numl)
        return 1;

    file->numl--;

    if(!which) {
        p=file->lh;
        file->lh=p->next;
        farfree(p);
        return 0;
    }
    p=FindLink(file,which - 1);
    q=FindLink(file,which);
    p->next=q->next;
    farfree(q);
    return 0;
}

