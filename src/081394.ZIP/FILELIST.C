#pragma hdrstop
#include <alloc.h>

#include "filedir.h"


Files *FindItem(PWDrec *file,int which)
{
    int i;
    Files *p=file->head;

    if(which<0||which>file->num)
        return NULL;

    if(!which)
        return p;

    for(i=0;i<which;i++)
        p=p->next;

    return p;           
}

int GetItem(PWDrec *file,int which,fileRec *v)
{
    Files *p;

    if(which<0||which>file->num) {
        puts("getitem error out of bounds");
        exit(100);
        //        return 1;
    }

    p=FindItem(file,which);
    (*v)=p->data;
    return 0;
}

int PutItem(PWDrec *file,int which,fileRec *v)
{
    Files *p;

    if(which<0||which>file->num) {
        puts("putitem error out of bounds");
        exit(101);
        //        return 1;
    }

    p=FindItem(file,which);
    p->data=(*v);
    return 0;
}

int InsertList(PWDrec *file,int as,fileRec v)
{
    Files *p,*q;

    /*    if(as<0||as>(numItems+1)) {
            return 1;
        }
    */

    if(!as) {
        if(file->num<1) {
            file->head=(Files *)malloc(sizeof(Files));
            if(file->head==NULL) {
                puts("argh 1!");
                exit(0);
            }
            file->head->data=v;
            file->head->next=0;
        } 
        else {
            q=(Files *)malloc(sizeof(Files));
            if(q==NULL) {
                puts("argh 2!");
                exit(0);
            }
            q->data=v;
            q->next=file->head;
            file->head=q;
        }
        file->num++;
        return 0;
    }
    p=FindItem(file,as-1);
    q=(Files *)malloc(sizeof(Files));
    if(q==NULL) {
        puts("argh 3!");
        exit(0);
    }
    q->data=v;
    q->next=p->next;
    p->next=q;
    file->num++;
    return 0;
}

int DeleteItem(PWDrec *file,int which)
{
    Files *p,*q;

    if(which<0||which>file->num)
        return 1;

    file->num--;

    if(!which) {
        p=file->head;
        file->head=p->next;
        farfree(p);
        return 0;
    }
    p=FindItem(file,which - 1);
    q=FindItem(file,which);
    p->next=q->next;
    farfree(q);
    return 0;
}
