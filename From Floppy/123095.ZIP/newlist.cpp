#include <fcntl.h>
#include <sys/stat.h>
#include <io.h>
#include "link.h"
#include "vardec.h"

void setcolors(userrec *u)
{
    u->colors[0]=15;
    u->colors[1]=7;
    u->colors[2]=13;
    u->colors[3]=11;
    u->colors[4]=14;
    u->colors[5]=9;
    u->colors[6]=32;
    u->colors[7]=7;
    u->colors[8]=7;
    u->colors[9]=10;
    u->colors[10]=10;
    u->colors[11]=1;
    u->colors[12]=6;
    u->colors[13]=3;
    u->colors[14]=5;
    u->colors[15]=1;
    u->colors[16]=32;
    u->colors[17]=4;
    u->colors[18]=4;
    u->colors[19]=2;
}


void main(void)
{
    userrec u;
    smalrec index;
    int f;

    memset(&u.name,0,sizeof(userrec));

    strcpy(u.name,"GUEST");
    strcpy(u.realname,"Guest User");
    strcpy(u.phone,"000-000-0000");
    strcpy(u.dphone,"000-000-0000");
    strcpy(u.pw,"GUEST");
    strcpy(u.laston,"never");
    strcpy(u.firston,"never");
    strcpy(u.note,"Guest User");
    strcpy(u.comment,"Guest User");
    strcpy(u.street,"No where");
    strcpy(u.city,"No where");
    u.sex='?';

    u.screenchars=80;
    u.screenlines=24;

    u.sl=10;
    u.dsl=10;

    u.sysstatus= sysstatus_ansi|sysstatus_color|sysstatus_pause_on_page;

    setcolors(&u);

    f=open("user.lst",O_BINARY|O_RDWR|O_TRUNC|O_CREAT,S_IREAD|S_IWRITE);
    write(f,&u,sizeof(userrec));

    memset(&u.name,0,sizeof(userrec));

    strcpy(u.name,"Sysop");
    strcpy(u.realname,"Sysop");
    strcpy(u.phone,"000-000-0000");
    strcpy(u.dphone,"000-000-0000");
    strcpy(u.pw,"Sysop");
    strcpy(u.laston,"never");
    strcpy(u.firston,"never");
    strcpy(u.note,"");
    strcpy(u.comment,"");
    strcpy(u.street,"No where");
    strcpy(u.city,"No where");
    u.sex='?';

    u.screenchars=80;
    u.screenlines=24;

    u.sl=255;
    u.dsl=255;

    u.sysstatus= sysstatus_ansi|sysstatus_color|sysstatus_pause_on_page;

    setcolors(&u);

    write(f,&u,sizeof(userrec));
    close(f);

//---

    f=open("user.idx",O_BINARY|O_RDWR|O_TRUNC|O_CREAT,S_IREAD|S_IWRITE);

    strcpy(index.name,"GUEST");
    index.number=0;
    write(f,&index,sizeof(index));

    strcpy(index.name,"SYSOP");
    index.number=1;
    write(f,&index,sizeof(index));

    close(f);
}
