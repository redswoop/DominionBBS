#pragma hdrstop

#include <alloc.h>
#include <fcntl.h>
#include <io.h>
#include <sys/stat.h>
#include "link.h"
#include "queue.h"

int emptyQueue(QueueContainer *s)
{
    if(s->list.num)
        return 0;

    return 1;
}

void createQueue(QueueContainer *s,long size)
{
    int i;

    s->itemSize=size;
    createList(&s->list,size);
}

int deleteQueue(QueueContainer *s)
{
    int i;

    deleteList(&s->list);

    return 0;
}

int removeQueue(QueueContainer *s)
{
    if(!emptyQueue(s))
        return(DeleteLink(&s->list,0));

    return -1;
}

int addQueue(QueueContainer *s,void *data)
{
    return(InsertLink(&s->list,numLinks(&s->list),data));
}

int getQueueItem(QueueContainer *s,void *data,int which)
{
    if(!emptyQueue(s))
        return(GetLink(&s->list,which,data));

    return -1;
}

int getQueueTop(QueueContainer *s,void *data)
{
    return(GetLink(&s->list,0,data));
}


void writeQueue(QueueContainer *s,char *fn)
{
    int f;
    int i;
    void *b;

    f=open(fn,O_BINARY|O_RDWR|O_CREAT|O_TRUNC,S_IREAD|S_IWRITE);

    write(f,&s->itemSize,sizeof(s->itemSize));
    write(f,&s->list.num,sizeof(s->list.num));

    b=malloc(s->itemSize);
    for(i=0;i<s->list.num;i++) {
        GetLink(&s->list,i,b);
        write(f,b,s->itemSize);
    }

    farfree(b);
    close(f);
}

void readQueue(QueueContainer *s,char *fn)
{
    int f;
    int i;
    void *b;
    long size;
    int num;


    f=open(fn,O_BINARY|O_RDWR);


    read(f,&size,sizeof(s->itemSize));
    createQueue(s,size);

    read(f,&num,sizeof(s->list.num));

    b=malloc(s->itemSize);

    for(i=0;i<num;i++) {
        read(f,b,s->itemSize);
        InsertLink(&s->list,i,b);
    }

    farfree(b);
    close(f);

    unlink(fn);
}
