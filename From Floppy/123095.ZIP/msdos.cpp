// functions that MSDos lacks

#include <string.h>

int strcasecmp(const char *s1, const char *s2)
{
    return(strcmpi(s1,s2));
}

void far *mallocx(unsigned long l)
{
    void *x;

    x=farmalloc(l);
    if (!x) {
        err(3,"","In Mallocx");
    }
    return(x);
}


double freek(int dr)
{
    float d;
    struct dfree df;

    getdfree(dr,&df);
    d=(float) df.df_avail;
    d*=((float) df.df_bsec);
    d*=((float) df.df_sclus);
    d/=1024.0;
    if (df.df_sclus==0xffff)
        d=-1.0;
    return(d);
}
