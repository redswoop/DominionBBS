#ifndef __DIRECTORY__
#define __DIRECTORY__

#include "link.h"
#include "filedir.h"

class directory {

protected:

public:
    List files;
    List links;


    char alias[15];
    char desc[51];
    char acs[31];
    char path[81];

    directory(void);
    directory(char *openPath);
    ~directory(void);

    int  open(void);
    int  open(char *openPath);
    int  openDirectory(char *openPath);
    void save(void);
    void save(char *path);

    void emptyDir(void);
    void addFiles(void);
    void registerDir(void);

    int  checkFile(fileRec f);
    int  checkLink(linkRec l);

// Dummy functions for list access

    int  numFiles(void);
    void putFile(fileRec *,int as);
    void getFile(fileRec *,int which);
    void insertFile(fileRec *,int where);
    void deleteFile(int which);

    int  numDirLinks(void);
    void getLink(linkRec *,int which);
    void putLink(linkRec *,int as);
    void insertLink(linkRec *,int as);
    void deleteLink(int which);
};
#endif
