#include "vars.h"

#pragma hdrstop

#include <time.h>


void ascii_send(char *fn, int *sent, double *percent)
{
    char b[2048];
    int i,i1,done,abort,i2,next;
    long pos,max;
    int mcif=mciok;
    mciok=0;

    i=open(fn,O_RDONLY | O_BINARY);
    if (i>0) {
        max=filelength(i);
        if (!max)
            max=1;
        i1=read(i,(void *)b,1024);
        pos=0L;
        abort=0;
        while ((i1) && (!hangup) && (!abort)) {
            i2=0;
            while ((!hangup) && (!abort) && (i2<i1)) {
                checkhangup();
                outchr(b[i2++]);
                checka(&abort,&next,0);
            }
            pos += (long) i2;
            checka(&abort,&next,0);
            i1=read(i,(void *)b,1024);
        }
        close(i);
        if (!abort)
            *sent=1;
        else {
            *sent=0;
            thisuser.dk += ((pos+1023L)/1024L);
        }
        *percent=((double) pos)/((double)max);
    } 
    else {
        nl();
        pl("File not found.");
        nl();
        *sent=0;
        *percent=0.0;
    }
    mciok=mcif;
}

void sendSingleFile(char *fn, int *sent, int *abort, char *ft)
{
    int i,i1;
    double percent,t;
    char s[81];

    ft[0]=0;
    i=get_protocol(0);
    switch(i) {
    case -1:
        *sent=0;
        *abort=1;
        break;
    case -3:
        *sent=0;
        *abort=0;
        break;
    case -2: 
        break;
    default:
        i1=extern_prot(i,fn,1);
        strcpy(ft,(proto[i].description));
        *abort=0;
        if (i1==proto[i].ok1)
            *sent=1;
        else
            *sent=0;
        break;
    }

}


void receive_file(char *fn, int *received, char *ft, int okbatch)
{
    int i,i1;
    char s[81];

    ft[0]=0;
    i=get_protocol(okbatch);
    switch(i) {
    case -1:
    case -3:
        *received=0;
        break;
    default:
        i1=extern_prot(i,fn,0);
        strcpy(ft,(proto[i].description));
        if (i1==proto[i].ok1) {
            *received=1;
        } 
        else {
            *received=0;
        }
        break;
    }
}

int get_batchprotocol(int dl,int *hang)
{
    char ch;
    int i1,prot;


    prot=thisuser.defprot;
    if(!proto[prot].description[0]||prot<0) prot=get_protocol(1);
    if(dl);
    *hang=0;

top:
    pl(get_string(67));
    pl(get_string(68));
    npr(get_string(69));
    ch=onek("\rHXAB");
    switch(ch) {
    case 13: 
        return(prot);
    case 'X': 
        return(thisuser.defprot=get_protocol(1));
    case 'A': 
        return(-1);
    case 'B': 
//        batchdled(0,0);
        goto top;
    case 'H': 
        *hang=1; 
        return(prot);
    }
    return(0);
}


int get_protocol(int batch)
{
    char s[81],s1[81],oks[81],s2[81],ch;
    int i,i1,i2,maxprot,done;

    strcpy(oks,"Q?");

    maxprot=0;
    done=0;

    for (i1=0; i1<numextrn; i1++) {
        if(batch||(!batch&&proto[i1].singleok)) {
            ++maxprot;
            sprintf(s1,"%c",proto[i1].key);
            strcat(oks,s1);
        }
    }

    strcpy(s,get_string(73));
    strcpy(s1,oks);

    do {
        nl();
        prt(2,s);
        ch=onek(s1);
        if (ch=='?') {
            nl();
            dtitle("Dominion Transfer Protocols");
            pl("5<5Q5>0 Abort");
            for (i1=0; i1<numextrn; i1++) {
                if(batch||(!batch&&proto[i1].singleok))
                    npr("5<5%c5>0 %s\r\n",proto[i1].key,(proto[i1].description));
            }
            nl();
        } 
        else
            done=1;
    } 
    while ((!done) && (!hangup));
    if (ch=='Q')
        return(-1);
    if(ch=='N') return(-3);
    if(ch=='A') return(-4);

    for(i=0;i<numextrn;i++)
        if(ch==proto[i].key) return(i);

    return(-1);
}


int extern_prot(int pn, char *fn1, int sending)
{
    char s[255],s1[81],s2[81],fn[81],sx1[21],sx2[21],sx3[21];
    int i,i1;

    i=0;
    for (i1=0; i1<81; i1++) {
        i+=proto[pn].description[i1];
        i+=proto[pn].sendfn[i1];
        i+=proto[pn].receivefn[i1];
    }
    if (sending) {
        nl();
        if(pn>-1) strcpy(s1,(proto[pn].sendfn));
    } 
    else {
        nl();
        if (pn>-1) strcpy(s1,(proto[pn].receivefn));
    }
    strcpy(fn,fn1);
    stripfn1(fn);
    sprintf(sx1,"%ld",com_speed);
    sprintf(sx3,"%ld",modem_speed);
    sx2[0]='0'+syscfg.primaryport;
    sx2[1]=0;
    stuff_in(s,s1,sx1,sx2,fn,sx3,"");
    if (s[0]) {
        set_protect(0);
        clrscr();
        printf("[0;37;1;44m[KCurrent user: %s\n\n[0;1m",nam(&thisuser,usernum));
        outs(s);
        outs("\r\n");
        if (incom) {
            i=runprog(s,0);
            topscreen();
            return(i);
        }
    }
    return(-5);
}


