#include "vars.h"
#pragma hdrstop
#include <stdarg.h>


void getcmdtype(void)
{
    menurec mm;

    nl();
    inputdat("Type",mm.type,2,0);
    nl();
    inputdat("Parameters",mm.ms,40,1);
    executeCommand(&mm,"");
}

void logtypes(char type,char *fmt, ...)
{
    va_list ap;
    char s[512],s1[81];

    va_start(ap, fmt);
    vsprintf(s, fmt, ap);
    va_end(ap);

    switch(type) {
    case 0: 
        strcpy(s1,"7�7>"); 
        break;
    case 1: 
        strcpy(s1,"5�5�"); 
        break;
    case 2: 
        strcpy(s1,"1�1>"); 
        break;
    case 3: 
        strcpy(s1,"2�2�"); 
        break;
    case 4: 
        strcpy(s1,"3�3>"); 
        break;
    case 5: 
        strcpy(s1,"9#9#9#"); 
        break;
    }

    strcat(s1,"0 ");
    strcat(s1,s);
    if(type==5) sl1(0,s1);
    else
        sysoplog(s1);
}



void badcommand(menurec *m,char *args)
{
    char s[81];

    nl();
    sprintf(s,"2�2� 0Invalid Command Type %s",m->type);
    sysoplog(s);
    pl(s);
    nl();
}

extern int donematrix;

void matrixcmd(menurec *m,char *args)
{
    switch(m->type[1]) {
    case 'C': 
        checkmatrixpw(); 
        break;
    case 'L': 
        getmatrixpw(); 
        break;
    case 'G':
        donematrix=1;
        break;
    case 'N': 
        nl();
        npr("5Logon as New? ");
        if(yn())
            newuser();
        break;
    default: 
        badcommand(m,args);
    }
}

void bbsListCommands(menurec *m,char *args)
{
    switch(m->type[1])
    {
    case 'A': 
        addbbs(m->ms[0]?m->ms:"bbslist.msg");
        break;
    case 'R': 
        printfile(m->ms[0]?m->ms:"bbslist.msg");
        pausescr();
        break;
    case 'S': 
        searchbbs(m->ms[0]?m->ms:"bbslist.msg");
        break;
    default: 
        badcommand(m,args);
        break;
    }
}

void amsgcommand(menurec *m,char *args)
{
    switch(m->type[1]) {
    case 'W': 
        write_automessage(); 
        break;
    case 'R': 
        read_automessage();
#ifdef PD_OLD
        if(usepldns) pausescr();
#endif
        break;
    case 'A':
        if(status.amsguser)
            email(status.amsguser,"Reply to AutoMessage",1);
        break;
    default: 
        badcommand(m,args);
    }
}



void hangupcmd(menurec *m,char *args)
{
    if(numbatchdl) {
        outstr(get_string(78));
        if(!yn()) return;
    }
    switch(m->type[1]) {
    case 'H': 
        hangup=1; 
        break;
    case 'A':
    case 'L':
    case 'C': 
        nl();
        outstr(m->ms);
        if(yn()) {
            if(m->type[1]=='C'||m->type[1]=='L') {
                outstr("5Leave Feedback to SysOp? ");
                if(yn()) {
                    //                    strcpy(irt,"LogOff Feedback.");
                }
                nl();
                if(m->type[1]=='L') {
                    outstr("5Leave Message to Next User? ");
                    if(yn()) {
                        ex("JW","");
                    }
                }
            }
            printfile("logoff");
            hangup=1;
        }
        break;
    default: 
        badcommand(m,args);
    }
}


void sysopcmd(menurec *m,char *args)
{
    switch(m->type[1])
    {
    case 'B': 
        logtypes(3,"Edited Message Areas");
        boardedit(); 
        break;
    case '-': 
        glocolor(); 
        break;
    case 'P': 
        logtypes(3,"Edited Configuration");
        config(); 
        break;
    case 'F': 
        logtypes(3,"Edited Directories");
        diredit(); 
        break;
    case 'M': 
        logtypes(3,"Read All Mail");
        break;
    case 'H': 
        logtypes(3,"Changed Users");
        chuser(); 
        break;
    case 'C': 
        pl(((*(char far *)0x00000417L ^= 0x10) & 0x10) ?
        "Sysop now unavailable" : "Sysop now available");
        logtypes(3,"Changed Chat Availability");
        topscreen();
        break;
    case 'U': 
        logtypes(3,"Edited Users");
        uedit(usernum); 
        break;
    case 'Z': 
        zlog(); 
        break;
    case 'E': 
        logtypes(3,"Edited Strings");
        if(m->ms[0]) edstring(atoi(m->ms));
        else edstring(0); 
        break;
    case 'R': 
        reset_files(1); 
        break;
    case 'X': 
        logtypes(3,"Edited Protocols");
        protedit(); 
        break;
    case 'L': 
        logtypes(3,"Edited Conferences");
        confedit(); 
        break;
    case 'O': 
        viewlog(); 
        break;
    case '#': 
        logtypes(3,"Edited Menus");
        menu("");
        break;
    default: 
        badcommand(m,args);
    }
}


#ifdef PD

char *retfrompldn;

#endif


#ifdef PD

#ifdef OLDPOP
void makerembox(int x,int y,int ylen,char *fn)
{
    int i,xx,yy,old;
    unsigned char s[212];
    FILE *f;

    sprintf(s,"%s%s.fmt",syscfg.menudir,fn);
    f=fopen(s,"rt");


    fgets(s,211,f);
    filter(s,'\n');
    npr("[%d;%dH%s",y,x,s);

    fgets(s,211,f);
    filter(s,'\n');
    npr("[%d;%dH%s",y+ylen-1,x,s);


    fclose(f);
}


char *makelen(char *in ,int len)
{
    int r;
    static char out[161];

    r=ccount(in);

    memset(out,32,70);
    out[len]=0;
    strcpy(out,in);
    out[strlen(out)]=32;
    out[len+r]=0;

    return out;
}

void popup(char *fn)
{
    int done=0,draw=4;
    int i,x,y,slen,em;
    char ch;
    char s[81],fmt[200],fmto[200],s1[81],s2[81],desc[81],key[20];
    FILE *f;
    menurec tg;
    char availKeys[81];

    x=50;
    y=24-numitems[0];

    makerembox(x,y-1,(24-y)+2,fn);

    sprintf(s,"%s%s.fmt",syscfg.menudir,fn);
    f=fopen(s,"rt");


    fgets(s,211,f);
    fgets(s,211,f);
    fgets(fmt,211,f);
    filter(fmt,'\n');
    fgets(fmto,211,f);
    filter(fmto,'\n');
    fgets(s,211,f);
    slen=atoi(s);
    fclose(f);

    curtitle=0;
    curitem=0;

    go(x,y);

    for(i=0;i<numitems[curtitle];i++) {
        go(x,y+i);
        if(i==curitem)
            strcpy(s1,fmt);
        else
            strcpy(s1,fmto);

        GetLink(&menuC.menuCmd,ml[curtitle][curitem+i],&tg);
        aligncmd1(tg.desc,key,desc);
        stuff_in(s,s1,key,makelen(desc,slen),tg.desc,"","");
        npr(s);
    }

    while(!done&&!hangup) {
        if(draw==2||draw==3) {
            if(draw==2)
                i=-1;
            else
                i=1;

            go(x,curitem+y+i);
            GetLink(&menuC.menuCmd,ml[curtitle][curitem+i],&tg);
            aligncmd1(tg.desc,key,desc);
            stuff_in(s,fmto,key,makelen(desc,slen),tg.desc,"","");
            npr(s);

            go(x,curitem+y);
            GetLink(&menuC.menuCmd,ml[curtitle][curitem],&tg);
            aligncmd1(tg.desc,key,desc);
            stuff_in(s,fmt,key,makelen(desc,slen),tg.desc,"","");
            npr(s);
        }


        /* strcpy(availKeys,menuAvailKeys(&i,&i));
           retfrompldn=smkey(availKeys,0,1,1,0,&r); */

        ch=getKeyWithArrows();
        switch(ch) {
        case CR:
            GetLink(&menuC.menuCmd,ml[curtitle][curitem],&tg);
            strcpy(retfrompldn,tg.key);
            done=1;
            break;
        case DOWN:
            if(curitem<numitems[curtitle]-1) {
                curitem++;
                draw=2;
            }
            break;
        case UP:
            if(curitem>0) {
                curitem--;
                draw=3;
            }
            break;
        default:
            sprintf(retfrompldn,"%c",toupper(ch));
            done=1;
            break;
        }

    } 

    ansic(0);
    go(0,24);

    return;
}

#endif
#endif
