#include "vars.h"

#pragma hdrstop

#include <dir.h>
#include <math.h>
#include "ansi.h"
#include "stack.h"


extern List Quote;
extern int doinghelp;

void writeLoadupStatus(char *fn)
{
    int i;

    textattr(1);
    cprintf("� ");
    textattr(9);
    cprintf("Reading %s\r\n",fn);
}

void checkSystemDirectories(void)
{
    int i;
    char s[81],s1[81];
    char *dirNames[]={"Data","Afiles","Temp","Msgs","Batch","Menus"};
    char *dirs[]={syscfg.datadir,syscfg.gfilesdir,syscfg.tempdir,
                  syscfg.msgsdir,syscfg.batchdir,syscfg.menudir};

    for(i=0;i<6;i++) {
        sprintf(s,"%snul",dirs[i]);

        if (!exist(s)) {
            printf("\n\nYour %s directory isn't valid!\nNow set to: %s\n",
                   dirNames[i],dirs[i]);

            printf("\nEnter a new value: ");
            gets(s);
            if(s[strlen(s)-1]!='\\')
                strcat(s,"\\");
            printf("%s\n",s);
            sprintf(s1,"%snul",s);
            if(!exist(s1)) {
                strcpy(s1,s);
                s1[strlen(s1)-1]=0;
                if(mkdir(s1))
                    err(1,s1,"In Init()");
            }
            strcpy(dirs[i],s);
        }
    }
}


void loadKeyMappings(void)
{
    FILE *f;
    char s[81];
    char *p;
    keyMap key;

    deleteList(&keyMappings);

    sprintf(s,"%skbdef.dat",syscfg.gfilesdir);
    f=fopen(s,"rt");
    while(fgets(s,81,f)!=NULL) {
        filter(s,'\n');

        p=strtok(s,",;");
        strcpy(key.key,p);

        p=strtok(NULL,",;");
        strcpy(key.define,p);

        InsertLink(&keyMappings,0,&key);
    }

    fclose(f);

}

void init(int silentStartup)
{
    char s[161],*buf,ch,*ss,s1[81],s2[10];
    int i,i1,i2,sm,cp,n,f;
    long l;
    union REGS r;
    struct date today;
    int resaveconfig=0;
    subboardrec tmpSub;

    testShare();

    crttype=peekb(0x0040,0x0049);
    if (crttype==7)
        scrn=(char *)MK_FP(0xb000,0x0000);
    else
        scrn=(char *)MK_FP(0xb800,0x0000);
    r.h.ah=15;
    int86(0x10,&r,&r);
    sm=r.h.al;

    if ((sm==4) || (sm==5) || (sm==6)) {
        printf("\n\nYou must be in text mode to run BBS.\n\n");
        err(6,"","In Init()");
    }

    defscreenbottom=(int) peekb(0x0000,0x0484);
    if (defscreenbottom<24)
        defscreenbottom=24;
    if (defscreenbottom>63)
        defscreenbottom=24;
    screenbottom=defscreenbottom;
    screenlen=160*(screenbottom+1);

    restoring_shrink=exist("exitdata.dom");

    if (!restoring_shrink&&!silentStartup) {
        clrscr();
        memmove(scrn,ANSIHEADER,4000);
        gotoxy(1,12);
    }

    strcpy(cdir,"X:\\");
    cdir[0]='A'+getdisk();
    getcurdir(0,&(cdir[3]));
    userfile=-1;
    configfile=-1;
    statusfile=-1;
    dlf=-1;
    curlsub=-1;
    curldir=-1;
    oldx=0;
    oldy=0;
    itimer();
    use_workspace=0;
    chat_file=0;
    do_event=0;
    sysop_alert=0;
    global_handle=0;
    confmode=1;


    if(!restoring_shrink&&!silentStartup) {
        writeLoadupStatus("Config.dat");
    }

    configfile=open("CONFIG.DAT",O_RDWR | O_BINARY);
    if (configfile<0) {
        printf("\n\nConfig.Dat, Main Configuration File, Not Found!!.\n");
        err(1,"Config.dat","In Init()");
    }

    read(configfile,(void *) (&syscfg), sizeof(configrec));
    close(configfile);

    if (!syscfg.primaryport)
        ok_modem_stuff=0;

    if(!restoring_shrink&&!silentStartup)
        writeLoadupStatus("Checking Directories");

    checkSystemDirectories();

    if(resaveconfig) {
        configfile=open("CONFIG.DAT",O_RDWR | O_BINARY);
        if (configfile<0) {
            printf("\n\nConfig.Dat, Main Configuration File, Not Found!!.\n");
            err(1,"Config.dat","In Init()");
        }
        write(configfile,(void *) (&syscfg), sizeof(configrec));
        close(configfile);
    }


    if(!restoring_shrink&&!silentStartup)
        writeLoadupStatus("Status.dat");

    sprintf(s,"%sSTATUS.DAT",syscfg.datadir);
    statusfile=open(s,O_RDWR | O_BINARY);
    if (statusfile<0) {
        printf("\n\n\n%sStatus.Dat not found!\n\n",syscfg.datadir);
        err(1,s,"In Init()");
    }

    read(statusfile,(void *)(&status), sizeof(statusrec));
    close(statusfile);

    getdate(&today);
    if (today.da_year<1993) {
        char s[4];
        printf("\r\nYou need to set the date & time before running the BBS.\n");
        printf("System will set time to last known good date\n");

    }



    smallist=(smalrec *) mallocx((long)500 * (long)sizeof(smalrec));

    screensave.scrn1=(char *)mallocx(screenlen);

    read_in_file("mnudata.dat",(menus),50);

    sprintf(s,"%suser.idx",syscfg.datadir);
    i=open(s,O_RDWR | O_BINARY);
    if (i<0) {
        reset_files(0);
    } 
    else {
        read(i,(void *) (smallist), (sizeof(smalrec) * status.users));
        close(i);
    }


    createList(&subboards,sizeof(subboardrec));

    directories=(directoryrec *)mallocx(200*sizeof(directoryrec));
    if(!restoring_shrink&&!silentStartup)
        writeLoadupStatus("Config.dat");

    if(!restoring_shrink&&!silentStartup) {
        writeLoadupStatus("Subs.dat");
    }

    sprintf(s,"%sSUBS.DAT",syscfg.datadir);
    i=open(s,O_RDWR | O_BINARY);
    if (i<0) {
        printf("\n\n%sSubs.Dat not found!",syscfg.datadir);
        err(1,s,"In Init()");
    }

    i1=0;
    while(read(i,&tmpSub,sizeof(subboardrec)))
        InsertLink(&subboards,i1++,&tmpSub);

/*
    if(subboards[0].postacs[0])
        subboards[0].postacs[0]=0;
    if(subboards[0].readacs[0])
        subboards[0].readacs[0]=0;
    if(!(subboards[0].attr & mattr_private)) {
        togglebit((long *)&subboards[0].attr,mattr_private);
        strcpy(subboards[0].name,"Private Mail");
        strcpy(subboards[0].filename,"email");
        subboards[0].conf='@';
    }
    lseek(i,0L,SEEK_SET);
    write(i,&subboards[0],sizeof(subboardrec));
*/
    close(i);

    sprintf(s,"%sDIRS.DAT",syscfg.datadir);
    i=open(s,O_RDWR | O_BINARY);
    if (i<0) {
        printf("\n\n%sDirs.dat Not found!\n\n",syscfg.datadir);
        err(1,s,"In Init()");
    }

    num_dirs=(read(i,directories, (200*sizeof(directoryrec))))/
        sizeof(directoryrec);
    close(i);
    sprintf(s,"%snul",directories[0].dpath);
    if(!exist(s)) {
        printf("\n\nYour SysOp directory is invalid!\n");
        printf("Now Set to: %s\n\n",directories[0].dpath);
        err(1,directories[0].dpath,"In Init()");
    }

#ifdef OLDFIDO
    sprintf(s,"%sfnet.dat",syscfg.datadir);
    i=open(s,O_BINARY|O_RDWR|O_CREAT,S_IREAD|S_IWRITE);
    read(i,&fnet,sizeof(fnet));
    close(i);
#endif

    if(!restoring_shrink&&!silentStartup)
        writeLoadupStatus("Protocol.dat");

    sprintf(s,"%sprotocol.dat",syscfg.datadir);
    i=open(s,O_RDWR | O_BINARY);
    if(i<0) {
        printf("\n\n%sProtocol.dat Not Found\n",syscfg.datadir);
        err(1,s,"In Init()");
    }
    numextrn=(read(i,(void *)&proto,20*sizeof(protocolrec)))/
        sizeof(protocolrec);
    close(i);

    sprintf(s,"%sRESULTS.DAT",syscfg.datadir);
    i=open(s,O_RDWR | O_BINARY);
    if (i>0) {
        l=filelength(i);
        num_result_codes=(read(i,result_codes,(unsigned) l))/sizeof(resultrec);
        close(i);
    } 
    else {
        end_bbs(noklevel);
    }


    if(!restoring_shrink&&!silentStartup) {
        writeLoadupStatus("Conf.dat");
    }

    sprintf(s,"%sconf.dat",syscfg.datadir);
    i=open(s,O_RDWR | O_BINARY);
    if(i<0) {
        printf("\n\n%sConf.dat Not Found!\n\n",syscfg.datadir);
        err(1,s,"In Init()");
    }
    num_conf=(read(i,(void *)&conf[0],20*sizeof(confrec)))/ sizeof(confrec);
    if(conf[0].sl[0])
        conf[0].sl[0]=0;
    close(i);


    if(!restoring_shrink&&!silentStartup) {
        writeLoadupStatus("Archive.dat");
    }

    sprintf(s,"%sarchive.dat",syscfg.datadir);
    i=open(s,O_BINARY|O_RDWR);
    if(i<0) {
        printf("\n\n%sArchive.dat Not Found\n",syscfg.datadir);
        err(1,s,"In Init()");
    }
    read(i,&xarc[0],8*sizeof(xarc[0]));
    close(i);



    if(!restoring_shrink&&!silentStartup) {
        writeLoadupStatus("Modem.dat");
    }

    sprintf(s,"%sMODEM.DAT",syscfg.datadir);
    i=open(s,O_RDWR | O_BINARY);
    if (i>0) {
        l=filelength(i);
        modem_i = (modem_info *)mallocx(l);
        read(i,modem_i, (unsigned) l);
        close(i);
    } 
    else {
        printf("\n\n%sModem.Dat not found!\n\n",syscfg.datadir);
    }

    read_user(1,&thisuser);
    cursub=0;
    fwaiting=numwaiting(&thisuser);

    sl1(2,status.date1);

    if (ok_modem_stuff) {
        initport(syscfg.primaryport);
        set_baud(syscfg.baudrate[syscfg.primaryport]);
    }
    if (syscfg.sysconfig & sysconfig_no_local)
        topdata=0;
    else
        topdata=status.topScreenMode;

    ss=getenv("PROMPT");
    strcpy(newprompt,"PROMPT=BBS: ");
    if (ss)
        strcat(newprompt,ss);
    else
        strcat(newprompt,"$P$G");
    sprintf(dszlog,"%s\\BBSDSZ.LOG",cdir);
    sprintf(s,"DSZLOG=%s",dszlog);
    i=i1=0;
    while (environ[i]!=NULL) {
        if (strncmp(environ[i],"PROMPT=",7)==0)
            xenviron[i1++]=newprompt;
        else
            if (strncmp(environ[i],"DSZLOG=",7)==0)
            xenviron[i1++]=strdup(s);
        else {
            if (strncmp(environ[i],"BBS=",4) )
                xenviron[i1++]=environ[i];
        }
        ++i;
    }
    if (!getenv("DSZLOG"))
        xenviron[i1++]=strdup(s);
    if (!ss)
        xenviron[i1++]=newprompt;

    sprintf(s,"BBS=%s",bbsVersion);
    xenviron[i1++]=s;

    xenviron[i1]=NULL;

    if(!restoring_shrink&&!silentStartup)
        writeLoadupStatus("Final Data");

// Creating dynamic structures
    if(!restoring_shrink)
        createStack(&menuStack,13);

    createList(&menuC.menuCmd,sizeof(menurec));
    createList(&Quote,161);

    createList(&keyMappings,sizeof(keyMap));
    loadKeyMappings();

    time_event=((double)syscfg.executetime)*60.0;
    last_time=time_event-timer();
    if (last_time<0.0)
        last_time+=24.0*3600.0;
    do_event=0;
    if (status.callernum!=65535) {
        status.callernum1=(long)status.callernum;
        status.callernum=65535;
        save_status();
    }
    frequent_init();
    if (!restoring_shrink&&!silentStartup && !already_on) {
        remove_from_temp("*.*",syscfg.tempdir,0);
        remove_from_temp("*.*",syscfg.batchdir,0);
    }
    lecho=ok_local();
    quote=NULL;
    bquote=0;
    equote=0;

    daylight=0;

#ifdef MOUSE
    initpointer(1);
#endif

    if (!restoring_shrink&&!silentStartup) {
        cprintf("Completed Loading - ");
        textattr(10);
        cprintf("Entering WFC\n\n\n");
    }

}

void end_bbs(int lev)
{
    sl1(1,"");

    if (ok_modem_stuff)
        closeport();

    dtr(0);
    clrscrb();
    textattr(9);
    cprintf("\n� ");
    textattr(15);
    cprintf("%s is outta here!\n\n",bbsVersion);
    _setcursortype(2);

    asm mov ax,0x1003;
    asm mov bl,0x1;
    asm int 0x10;

    exit(lev);
}

void frequent_init(void)
{
    doinghelp=0;
    mciok=1;
    msgr=1;
    ARC_NUMBER=-1;
    chatsoundon=1;
    curlsub=-1;
    ansiptr=0;
    curatr=0x07;
    outcom=0;
    incom=0;
    charbufferpointer=0;
    andwith=0xff;
    checkit=0;
    topline=0;
    screenlinest=defscreenbottom+1;
    endofline[0]=0;
    hangup=0;
    chatcall=0;
    chatreason[0]=0;
    useron=0;
    change_color=0;
    chatting=0;
    echo=1;
    okskey=0;
    lines_listed=0;
    okmacro=1;
    okskey=1;
    mailcheck=0;
    smwcheck=0;
    in_extern=0;
    use_workspace=0;
    extratimecall=0.0;
    using_modem=0;
    set_global_handle(0);
    live_user=1;
    _chmod(dszlog,1,0);
    unlink(dszlog);
    ltime=0;
    backdoor=0;
    status.topScreenMode=topdata;
}


