#include "vars.h"
#pragma hdrstop

#include <iostream.h>
#include <sys/stat.h>
#include <dirent.h>
#include <dir.h>
#include "link.h"
#include "stack.h"

#include "dir.hpp"

class dirPathItem {
public:
    char path[81];
    char alias[21];


    dirPathItem(char *,char *);
    dirPathItem(void);
};

dirPathItem::dirPathItem(char *p,char *a)
{
    strcpy(path,p);
    strcpy(alias,a);
}

dirPathItem::dirPathItem(void)
{
    path[0]=0;
    alias[0]=0;
}

class fileSystem {
public:

    fileSystem(void);
    fileSystem(char *);

    directory pwd;

    char rootPath[81];

    // List of Char[81] showing all dirs used in stack
    List dirList;

    void selectRoot(void);
    int selectDir(char *);
    int selectPrev(void);

    void pathName(void);
};

fileSystem::fileSystem(void)
{
    createList(&dirList,sizeof(dirPathItem));
    strcpy(rootPath,"d:\\dls");
    pwd.open(rootPath);
}

fileSystem::fileSystem(char *path)
{
    createList(&dirList,sizeof(dirPathItem));
    strcpy(rootPath,path);
    pwd.open(rootPath);
}


void fileSystem::selectRoot(void)
{
    while(numLinks(&dirList))
        DeleteLink(&dirList,0);

    pwd.openDirectory(rootPath);
}

int fileSystem::selectDir(char *path)
{
    linkRec l;
    int i;

    strcpy(l.fn,path);

    cout << "trying to open " << path << endl;

    i=pwd.checkLink(l);

    if(i!=-1) {
        pwd.getLink(&l,i);
        cout << "matches: " << "#" << i << " " << l.linkData << endl;
        pwd.openDirectory(l.linkData);
        InsertLink(&dirList,numLinks(&dirList),new dirPathItem(pwd.path,pwd.alias));
        return 1;
    }

    return 0;
}

int fileSystem::selectPrev(void)
{
    dirPathItem newPath;

    if(!numLinks(&dirList))
        return 0;

    if(numLinks(&dirList)==1) {
        DeleteLink(&dirList,1);
        pwd.openDirectory(rootPath);
        return 1;
    }

    DeleteLink(&dirList,numLinks(&dirList)-1);
    GetLink(&dirList,numLinks(&dirList)-1,&newPath);

    pwd.openDirectory(newPath.path);

    return 1;
}


void fileSystem::pathName(void)
{
    int i;
    dirPathItem dir;

    cout << "/";

    for(i=0;i<numLinks(&dirList);i++) {
        GetLink(&dirList,i,&dir);
        cout << dir.alias << "/";
    }
}



void ftest(void)
{
    fileSystem fsys("e:\\dom");
    int i;
    linkRec l;
    fileRec f;
    int done=0;
    char s[81];


    while(!done) {
        cout << fsys.pwd.numDirLinks() << endl;
        fsys.pathName();
        cout << "> ";
        cin >> s;

        switch(s[0]) {
            case 'l':
            for(i=0;i<fsys.pwd.numDirLinks();i++) {
                fsys.pwd.getLink(&l,i);
                cout << i << ", " << l.fn << endl;
            }
            break;

            case 'c':
            cin >> s;
            fsys.selectDir(s);
            break;

            case '.':
            fsys.selectPrev();
            break;

            case 'q':
            done=1;
            break;
        }
    }
}
