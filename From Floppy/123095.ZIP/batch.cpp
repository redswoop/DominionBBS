#include "vars.h"
#pragma hdrstop

#include "link.h"
#include "stack.h"
#include "fileDir.h"
#include "queue.h"

extern StackContainer dirStack;
extern List batchList;
extern PWDrec PWD;
extern char dirPath[81];

void findPath(char path[81],PWDrec *tmpPwd);

void batchSize(UINT32 *size, int *numFiles,int *points)
{
    int i,i1;
    PWDrec tmpPwd;
    fileRec f;
    int n,n1;

    *size=0;
    *numFiles=0;

    n=numLinks(&batchList);
    for(i=0;i<n;i++) {
        GetLink(&batchList,i,&tmpPwd);
        n=numLinks(&tmpPwd.files);
        *numFiles+=n;
        for(i1=0;i1<n1;i1++) {
            GetLink(&tmpPwd.files,i1,&f);
            *size+=f.size;
            *points+=f.points;
        }
    }
}

int okToTag(fileRec *f,PWDrec *tmpPwd)
{
    double t;
    char s[81];
    unsigned long ucrc;

    sprintf(s,"%s\\%s",tmpPwd->path,f->fn);
    if(!exist(s)) {
        pl("File is OffLine");
        if(printfile("offline"))
            email(1,"Offline File Request",1);
        return 0;
    }

    if(dcs())
        return 1;

    tleft(1);

    strcpy(s,thisuser.realname);
    strlwr(s);
    ucrc=JAMsysCrc32( s,strlen(s), ( UINT32 ) -1L );

    if((f->attr & File_private)&&f->owner==ucrc) {
        pl("That file is private, and not for you");
        return 0;
    }

    if(modem_speed)
        t=((double) (((f->size*10)+127)/128)) * (1620.0)/((double) (modem_speed));

    if(t>nsl()&&!(thisuser.exempt & exempt_time)&&!checkacs(3)) {
        pl(get_string(87));
        printfile("nodl");
        return 0;
    }

// Unvalidated file
    if(!(f->attr && File_val)) {
        npr("%s",get_string(43));
        return 0;
    }

    if(f->attr & File_free)
        return 1;

    if(syscfg.nifstatus & nif_fpts)
        if(!(thisuser.exempt & exempt_ratio)&&!checkacs(2)) {
            if(thisuser.fpts*syscfg.fptsratio<f->points) {
                nl();
                npr("%s",get_string(27));
                printfile("nodl");
                return 0;
            }
        }

    if(!ratio_ok()) {
        printfile("nodl");
        return 0;
    }

    return(1);
}

void tagFiles(char *arg)
{
    char *p;
    PWDrec tmpPwd;
    fileRec f;
    int i;

    p=strtok(arg," ,;");
    while(p) {
        pl(p);
        findPath(p,&tmpPwd);
        for(i=0;i<numLinks(&tmpPwd.files);) {
            GetLink(&tmpPwd.files,i,&f);
            if(!okToTag(&f,&tmpPwd)) {
                npr("%s was not added\r\n",f.fn);
                DeleteLink(&tmpPwd.files,i);
            }
            else
                i++;
        }

        if(numLinks(&tmpPwd.files))
            InsertLink(&batchList,0,&tmpPwd);
        p=strtok(NULL," ,;");
    }
}

void listBatch(void)
{
    int i;
    int i1;
    PWDrec tmpPwd;
    fileRec f;

    for(i=0;i<numLinks(&batchList);i++) {
        GetLink(&batchList,i,&tmpPwd);
        pl(tmpPwd.alias);
        for(i1=0;i1<numLinks(&tmpPwd.files);i1++) {
            GetLink(&tmpPwd.files,i1,&f);
            npr("\t%s\r\n",f.fn);
        }
        nl();
    }
}

void generateBatchLst(void)
{
    int i;
    int i1;
    PWDrec tmpPwd;
    fileRec f;
    FILE *batchfn;

    batchfn=fopen("batch.lst","wt");
    for(i=0;i<numLinks(&batchList);i++) {
        GetLink(&batchList,i,&tmpPwd);
        for(i1=0;i1<numLinks(&tmpPwd.files);i1++) {
            GetLink(&tmpPwd.files,i1,&f);
            fprintf(batchfn,"%s\\%s\n",tmpPwd.path,f.fn);
        }
    }
    fclose(batchfn);
}

int entireBatchOk(void)
{
    UINT32 size;
    int numFiles,points;

    batchSize(&size,&numFiles,&points);

    if(syscfg.nifstatus & nif_fpts)
        if(!(thisuser.exempt & exempt_ratio)&&!checkacs(2))
            if(thisuser.fpts*syscfg.fptsratio<points)
                return 0;

    return 1;
}
