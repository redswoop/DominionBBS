#include <iostream.h>

#include "dir.hpp"
#include "filedir.h"
#include "link.h"

#include "fsys.cpp"

int exist(char *s)
{
    int i;
    struct ffblk ff;

    i=findfirst(s,&ff,0);
    if (i)
        return(0);
    else
        return(1);
}

void filterChar(char *s,unsigned char c)
{
    int x=0;

    while(s[x++]!=c);
    s[x-1]=0;

}



void main(int argc,char **argv)
{
    fileSystem fsys("e:\\dom");
    int i;
    linkRec l;
    fileRec f;
    int done=0;
    char s[81];


    while(!done) {
        cout << fsys.pwd.numDirLinks() << endl;
        fsys.pathName();
        cout << "> ";
        cin >> s;

        switch(s[0]) {
            case 'l':
            for(i=0;i<fsys.pwd.numDirLinks();i++) {
                fsys.pwd.getLink(&l,i);
                cout << i << ", " << l.fn << endl;
            }
            break;

            case 'c':
            cin >> s;
            fsys.selectDir(s);
            break;

            case '.':
            fsys.selectPrev();
            break;

            case 'q':
            done=1;
            break;
        }
    }

}
