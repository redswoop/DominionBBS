// New functions, definitions, etc, for porability.

#include <sys/param.h>
#include <unistd.h>

#define O_BINARY 0

unsigned long filelength(int);
void itoa(long ,char *,int);

void *malloca(size_t);
void freeMem(void *);
char *strupr(char *);
char *strlwr(char *);
char *searchpath(char *);
int makeDir(char *);
