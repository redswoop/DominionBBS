#ifndef _LINK_H_
#define _LINK_H_


typedef struct nodeLink {
    void *data;
    struct nodeLink *next;
} nodeL;

typedef struct {
    int num;
    long size;
    nodeL *head;
} List;

int numLinks(List *list);
nodeL *FindLink(List *list,int which);
int GetLink(List *list,int which,void *v);
int PutLink(List *list,int which,void *v);
int InsertLink(List *list,int as,void *data);
int DeleteLink(List *list,int which);
void createList(List *l,long size);
void deleteList(List *l);
#endif
