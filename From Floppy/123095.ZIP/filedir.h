#ifndef __FILEDIR__
#define __FILEDIR__

#include <dir.h>

#define File_val 0x0001
#define File_private 0x0002
#define File_free 0x0004
#define File_unAvail 0x0008
#define File_extended 0x0010

typedef struct {
    char fn[13],
         description[51],
         uploader[31];
    int  points,
         numDls,
         owner;
    unsigned long
         ulDate,
         attr,
         size;
} fileRec;

typedef struct {
    char fn[15],
         linkData[81];
    unsigned long
         attr;
} linkRec;

typedef struct {
    List files;
    List links;

    char alias[15];
    char desc[51];
    char acs[31];
    char path[81];
} PWDrec;

typedef struct {
    fileRec *f;
    char *parameter;
    int depth;
} recurseRec;

typedef struct {
    char
        sending,
        pathName[59],
        path[81];
    float time;
    int points;

    unsigned long
        size;

} batchRec;

#endif
