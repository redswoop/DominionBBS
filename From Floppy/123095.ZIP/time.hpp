#include <time.h>
#include <stdio.h>

class aTime {
public:

    struct tm currTime;

    // the time of day, HH:MM:SS
    char *timeOfDayStr(char *);

    // the time of day, in am/pm
    char *timeOfDayStrAP(char *);    
    
    // Seconds since midnight
    int secondsToday(void);

};
