#include "vars.h"
#pragma hdrstop

#include <iostream.h>


#include "fsys.hpp"


void syncLinkNames(fileSystem& fsys)
{
    linkRec l;
    int i;
    directory dir;

    for(i=0;i<fsys.pwd.numDirLinks();i++) {
        fsys.pwd.getLink(&l,i);
        dir.open(l.linkData);
        cout << dir.alias << " to " << l.fn << endl;
        strcpy(dir.alias,l.fn);
        dir.save();
    }
}


void changeDir(fileSystem& fsys,char *args)
{
    char s[81];

    if(!args[0])
        inputdat("Link to Change to",s,21,0);
    else
        strcpy(s,args);

    if(!strcmp(s,".."))
        fsys.selectPrev();
    else if(!strcmp(s,"/"))
        fsys.selectRoot();
    else if(!fsys.selectDir(s)) {
        npr("Link not found!\r\n");
    }
}
