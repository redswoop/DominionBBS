#include "vars.h"
#pragma hdrstop


#include "link.h"
#include "fileDir.h"

void setString(char *s,char *prompt,int len,int lowerOk)
{
  char *tmp;

  tmp=(char *)malloca(len+1);

  nl();  
  inputdat(tmp,prompt,len,lowerOk);
  if(tmp[0])
    strcpy(s,tmp);

  farfree(tmp);
}

char menuKey(char *keys,int menu)
{
  char ch;

  if(!strchr(keys,'?'))
    strcat(keys,"?");

  ch=onek(keys);
  if(ch=='?') {
    printmenu(menu);
    return 0;
  }
  
  return ch;
}

void changeExtendedDescription(fileRec *f)
{ /*
  ss=read_extended_description(u.filename);
  nl();
  nl();
  prt(5,"Modify extended description? ");
  if (yn()) {
    nl();
    if (ss) {
      prt(5,"Delete it? ");
      if (yn()) {
	farfree(ss);
	delete_extended_description(u.filename);
	u.mask &= ~mask_extended;
      } 
      else {
	u.mask |= mask_extended;
	modify_extended_description(&ss);
	if (ss) {
	  delete_extended_description(u.filename);
	  add_extended_description(u.filename,ss);
	  farfree(ss);
	}
      }
    } else {
      modify_extended_description(&ss);
      if (ss) {
	add_extended_description(u.filename,ss);
	farfree(ss);
	u.mask |= mask_extended;
      } else
	u.mask &= ~mask_extended;
    }
  } else
    if (ss) {
      farfree(ss);
      u.mask |= mask_extended;
    } 
    else
      u.mask &= ~mask_extended;
  break;
*/
}


void editFile(char *path)
{
  char s[81],s1[81],s2[81];
  int i,done=0;
  int fileNum=0;
  userrec ur;
  fileRec f;
  PWDrec tmpPwd;

  findPath(path,&tmpPwd);

  while (!done&&fileNum<numLinks(&tmpPwd.files)) {
    GetLink(&tmpPwd.files,fileNum,&f);

    while(!done) {
      printInfo(&tmpPwd,&f,&done,fileNum);
      nl();

      npr("5File Information Editor (?=Help) ");
    
      switch(menuKey("NDQNGFVEUPS!BX\r",23)) {
      case 'X':
	togglebit((long *)&f.attr,File_unAvail);
	break;
      case 'B':
	togglebit((long *)&f.attr,File_private);
	break;
      case 'V': 
	togglebit((long *)&f.attr,File_val);
	break;
      case 'F':
	togglebit((long *)&f.attr,File_free);
	break;

      case '\r':
	done=1;
	break;
      case 'Q': 
	done=1;
	break;

      case 'U': 
	setString(f.uploader,"Uploader",31,1);
	break;
      case 'N':
	/*
	   nl();
	   inputdat("Filename",s,12,0);
	   if (!okfn(s))
	   s[0]=0;
	   if (s[0]) {
	   align(s);
	   if (strcmp(s,"        .   ")) {
	   strcpy(s1,directories[udir[curdir].subnum].dpath);
	   strcpy(s2,s1);
	   strcat(s1,s);
	   if (exist(s1))
	   pl("Filename already in use; not changed.");
	   else {
	   strcat(s2,u.filename);
	   rename(s2,s1);
	   if (exist(s1)) {
	   ss=read_extended_description(u.filename);
	   if (ss) {
	   delete_extended_description(u.filename);
	   add_extended_description(s,ss);
	   farfree(ss);
	   }
	   strcpy(u.filename,s);
	   } 
	   else
	   pl("Bad filename.");
	   }
	   }
	   }
	   break;*/
      case 'D': 
    inputdat("Description",f.description,50,1);
	break;
      case 'P': 
	nl();
	inputdat("File Points",s,3,0);
	if(s[0]) 
	  f.points=atoi(s);
	break;
      case 'E': 
	changeExtendedDescription(&f);
	break;
      
      }     
    }

    PutLink(&tmpPwd.files,fileNum,&f);
    fileNum++;

    done=0;
  }

  destroyPath(&tmpPwd);
}
