// functions that MSDos lacks

#ifdef __MSDOS__
#include <dos.h>
#include <conio.h>
#include <io.h>
#include <share.h>
#include <dir.h>
#endif

int strcasecmp(const char *s1, const char *s2);
