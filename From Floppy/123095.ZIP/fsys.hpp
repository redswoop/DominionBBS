#ifndef __FILESYSTEM__
#define __FILESYSTEM__

#include "dir.hpp"

class dirPathItem {
public:
    char path[81];
    char alias[21];


    dirPathItem(char *,char *);
    dirPathItem(void);
};



class fileSystem {
public:

    fileSystem(void);
    fileSystem(char *);

    directory pwd;

    char rootPath[81];

    // List of Char[81] showing all dirs used in stack
    List dirList;

    void selectRoot(void);
    void selectRoot(char *);
    int selectDir(char *);
    int selectPrev(void);

    void pathName(char *);

};
#endif
