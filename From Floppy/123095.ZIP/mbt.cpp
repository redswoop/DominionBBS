#include "vars.h"
#pragma hdrstop

char getKeyWithArrows(void)
{
    char c;

    c=getkey();

    if(c==27) {

        if(getkey()=='[') {
            c=getkey();

            switch(c) {
                case 'A': return UP;
                case 'B': return DOWN;
                case 'C': return RIGHT;
                case 'D': return LEFT;
                case 'H': return HOME;
                case 'K': return END;
            }
        }
    }

    return c;
}

int evalSpecialKey(char key,char *mask)
{
    if(mask[0]=='<') {
        if((!stricmp(mask,"<CR>"))    &&(key=='\n'||key=='\r'))  return 1;
        if((!stricmp(mask,"<UP>"))    &&(key==UP))    return 1;
        if((!stricmp(mask,"<DOWN>"))  &&(key==DOWN))  return 1;
        if((!stricmp(mask,"<RIGHT>")) &&(key==RIGHT)) return 1;
        if((!stricmp(mask,"<LEFT>"))  &&(key==LEFT))  return 1;
        if((!stricmp(mask,"<HOME>"))  &&(key==HOME))  return 1;
        if((!stricmp(mask,"<END>"))   &&(key==END))   return 1;
    }

    if(key==mask[0])
        return 1;

    return 0;
}

extern int fastlogon;

int mslok(char val[81],char inp[81],int qyn,int mbtKey)
{
    char ok=1,neg=0,*p,s1[81],s[81],curok=1,s2[81];
    int i,i1;
    subboardrec tmpSub;

    if(backdoor)
        return 1;

    strcpy(s,val);

    p=strtok(s,"&");
    if(p)
        strcpy(s,p);
    else
        s[0]=0;

    ok=1;
    while(s[0]) {
        curok=1;
        neg=0;

        if(s[0]=='!') {
            strcpy(s,s+1);
            neg=1;
        }

        switch(toupper(s[0])) {
        case 'K':
            curok=evalSpecialKey(mbtKey,&s[1]);
            break;
        case 'A': 
            if(!(thisuser.ar & (1 << toupper(s[1])-'A'))) curok=0; 
            break;
        case 'B': 
            if((modem_speed/100)<atoi(s+1)) curok=0; 
            break;
        case 'C': 
            if(!postr_ok()) curok=0; 
            break;
        case 'D': 
            if(thisuser.dsl<atoi(s+1)) curok=0; 
            break;
        case 'G': 
            if(thisuser.age<atoi(s+1)) curok=0; 
            break;
        case 'I': 
            if(!(thisuser.dar & (1 << toupper(s[1])-'A'))) curok=0;
            break;
        case 'S': 
            if(actsl<atoi(s+1)) curok=0; 
            break;
        case 'U': 
            if(atoi(s+1)!=usernum) curok=0; 
            break;
        case 'V': 
            if(!running_dv) curok=0; 
            break;
        case '@': 
            if(!strchr(conf[curconf].flagstr,s[1])) curok=0; 
            break;
        case '#': 
            if(!sysop2()) curok=0; 
            break;
        case 'F': 
            if(!fastlogon) curok=0; 
            break;
        case 'T': 
            if(stricmp(s,inp)) curok=0; 
            break;
        case 'Y': 
            if(!qyn) curok=0; 
            break;
        case 'N': 
            if(qyn) curok=0; 
            break;
        case 'H':
            if(atoi(s+1)!=thisuser.helplevel) curok=0;
            break;
        case 'M':
            GetLink(&subboards,usub[cursub].subnum,&tmpSub);
            if(stricmp(s+1,tmpSub.filename)) curok=0;
            break;
        case 'W':
            if(stricmp(s+1,directories[udir[curdir].subnum].filename)) curok=0;
            break;
        case 'E':
            switch(upcase(s[1])) {
            case 'R': 
                if(!(thisuser.exempt & exempt_ratio)) curok=0; 
                break;
            case 'T': 
                if(!(thisuser.exempt & exempt_time)) curok=0; 
                break;
            case 'U': 
                if(!(thisuser.exempt & exempt_userlist)) curok=0; 
                break;
            case 'P': 
                if(!(thisuser.exempt & exempt_post)) curok=0; 
                break;
            }
            break;
        }


        if(neg)
            curok=!curok;
        p=strtok(NULL,"&");
        if(p)
            strcpy(s,p);
        else
            s[0]=0;
        if(!curok)
            ok=0;
    }

    return ok;
}

#ifdef PD

int numpopers;

void addpop(char param[81])
{
    char *p;
    char s[81],s1[81];
    int i;
    menurec m;

    p=strtok(param,",");
    strcpy(s1,p);
    p=strtok(NULL,",");
    strcpy(m.key,p);
    p=strtok(NULL,",");
    strcpy(m.type,p);
    p=strtok(NULL,",");
    strcpy(m.ms,p);

    sprintf(m.desc,"[%s] %s",m.key,s1);
    InsertLink(&menuC.menuCmd,numpopers,&m);
    numpopers++;
}


extern char *retfrompldn;

void batchpop(char param[81])
{
    int i;
    menurec tg;

    newPopUp(param);
    for(i=0;i<numpopers;i++) {
        GetLink(&menuC.menuCmd,i,&tg);
        if(!stricmp(retfrompldn,tg.key))
            ex(tg.type,tg.ms);
    }
    reloadMenu();
    strcpy(retfrompldn,"");
}

#endif

typedef struct {
    char functionName[21];
    int startLine;
    int endLine;
    List gotoLabels;
} subRoutinePointer;

void loadMBT(char *fn,List *executionCode)
{
    FILE *f;
    char s[81];

    f=fopen(fn,"rt");

    while(fgets(s,81,f)!=NULL) {
        filter(s,'\n');
        if(s[0]!=';'&&strlen(s))
            InsertLink(executionCode,numLinks(executionCode),&s);
    }

    fclose(f);
}


int askNy(char *param)
{
    nl();
    npr("5%s? ",param);
    return ny();
}

void menubatch(char fn[12])
{
    char s[81],s1[81],*p,type[21],param[81];
    char inp[81];
    int i,qyn,done=0,mbtKey=0;
    List executionCode;
    int execLine;
    char gotoLabel[41];


    sprintf(s,"%s%s.mbt",syscfg.menudir,fn);
    if(!exist(s))
        return;

    gotoLabel[0]=0;
#ifdef PD
    numpopers=0;
#endif

    createList(&executionCode,81);

    loadMBT(s,&executionCode);

    for(execLine=0;execLine<numLinks(&executionCode)&&!done&&!hangup;execLine++) {
        GetLink(&executionCode,execLine,&s);

        if(gotoLabel[0]) {
            if(s[0]==':'&&(!stricmp(&s[1],gotoLabel)))
                gotoLabel[0]=0;
            else
                continue;
        }

        if(s[0]==':')
            continue;

        param[0]=type[0]=0;
        strcpy(s1,s);
        p=strtok(s,";");
        strcpy(s1,p);
        p=strtok(s1,"(");
        strcpy(type,p);
        p=strtok(NULL,")");
        strcpy(param,p);

        if(!stricmp(type,"GOTO")) {
            strcpy(gotoLabel,param);
            execLine=0;
        }
        else if(!stricmp(type,"PROMPT")) {
            inputl(inp,atoi(param));
        }
        else if(!stricmp(type,"GETKEY")) {
            mbtKey=toupper(getKeyWithArrows());
        }
        else if(!stricmp(type,"ONEKEY")) {
            mbtKey=nek(param,0);
        } 
        else if(!stricmp(type,"QUIT")) {
            done=1;
        } 
#ifdef PD
        else if(!stricmp(type,"ADDPOP")) {
            addpop(param);
        } 
        else if(!stricmp(type,"POPUP")) {
            if(!param[0])
                strcpy(param,"popup");
            batchpop(param);
       }
       else if(!stricmp(type,"RESETPOP")) {
            numpopers=0;
        } 
#endif
        else if(!stricmp(type,"ASK")) {
            qyn=askNy(param);
        }
        else if(!stricmp(type,"ASKN")) {
            nl();
            npr("5%s? ",param);
            qyn=yn();
        } 
        else if(!stricmp(type,"ECHO")) {
            pl(param);
        } 
        else if(!stricmp(type,"TYPE")) {
            printfile(param);
        } 
 
        else if(!stricmp(type,"IF")) {
            if(!mslok(param,inp,qyn,mbtKey))
                execLine++;
        } 
        else
            ex(type,param);

        checkhangup();
    }

    deleteList(&executionCode);
}
